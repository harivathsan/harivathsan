declare const styles: {};
export default styles;
//# sourceMappingURL=sections.module.scss.d.ts.map