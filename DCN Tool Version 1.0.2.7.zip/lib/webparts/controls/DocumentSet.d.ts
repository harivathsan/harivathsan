import * as React from 'react';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
export interface ICreateDocumentSetProps {
    context: IWebPartContext;
}
export interface ICreateDocumentSetState {
    documentSetName: string;
}
declare class CreateDocumentSet extends React.Component<any, any> {
    constructor(props: ICreateDocumentSetProps);
    handleInputChange: (e: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string | undefined) => void;
    handleCreateDocumentSet: () => Promise<void>;
    UpdateDocSet: (Id: any) => void;
    getContentTypeId(): Promise<string>;
    render(): JSX.Element;
}
export default CreateDocumentSet;
//# sourceMappingURL=DocumentSet.d.ts.map