import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import './shell-font.css';
import './DCNToolGlobal.module.scss';
import { IDcnToolProps } from './IDcnToolProps';
import { IDcnState } from './IDcnState';
export default class DcnTool extends React.Component<IDcnToolProps, IDcnState> {
    constructor(props: any);
    render(): React.ReactElement<IDcnToolProps>;
}
//# sourceMappingURL=DcnTool.d.ts.map