declare const styles: {
    spinner: string;
    'spinner-zp9dbg': string;
    layerMask: string;
    attachmentFiles: string;
    uploadControl: string;
    imgloader: string;
    close_button: string;
};
export default styles;
//# sourceMappingURL=DcnTool.module.scss.d.ts.map