export interface IDcnState {
}
//# sourceMappingURL=IDcnState.d.ts.map