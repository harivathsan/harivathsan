declare const styles: {
    dcnTool: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=DCNToolGlobal.module.scss.d.ts.map