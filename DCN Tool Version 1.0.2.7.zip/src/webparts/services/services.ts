import { SPHttpClient, SPHttpClientResponse,ISPHttpClientOptions } from '@microsoft/sp-http';
import * as _ from 'lodash';
  //Get current Login User 
 export const FetchCurrentUserInfo = async (props:any) => {
  
    let url = props.webURL + "/_api/web/currentuser";
     let currentloginUser =  await props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async(response: SPHttpClientResponse) => {
            return await response.json().then((response): void => {
                 return response                
            });
        });
        return Promise.resolve<any>(currentloginUser)
  }
  //Master Call All option list  
  export const getReasonChangeOptionList = (props:any) => {
    let ReasonChangeOptions: any = [];
    let url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/fields?$filter=EntityPropertyName eq 'ReasonforChange'";
    let listdata = props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {           
            return await response.json().then((res) => {                  
                    if (res != null) {
                        res.value[0].Choices.map((item: any) => {
                            ReasonChangeOptions.push({
                                text: item, key: item
                            });
                        });                       
                        return ReasonChangeOptions;
                    } else {
                        console.log('recoard failed');
                    }
                });            
        });
        return Promise.resolve<any>(listdata);
  }

  export const getOriginating_DisciplineOptionList = (props:any) => {
    let OriginatingDisciplineOptions: any = [];
    let url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/fields?$filter=EntityPropertyName eq 'OriginatingDiscipline'";
    let listdata = props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {           
            return await response.json().then((res) => {                  
                    if (res != null) {
                        res.value[0].Choices.map((item: any) => {
                          OriginatingDisciplineOptions.push({
                                text: item, key: item
                            });
                        });                       
                        return OriginatingDisciplineOptions;
                    } else {
                        console.log('recoard failed');
                    }
                });            
        });
        return Promise.resolve<any>(listdata);
  }

  export const getDisciplineOptionList = (props:any) => {
    let DisciplineOptions: any = [];
    let url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/fields?$filter=EntityPropertyName eq 'Discipline'";
    let listdata = props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {           
            return await response.json().then((res) => {                  
                    if (res != null) {
                        res.value[0].Choices.map((item: any) => {
                          DisciplineOptions.push({
                                text: item, key: item
                            });
                        });                       
                        return DisciplineOptions;
                    } else {
                        console.log('recoard failed');
                    }
                });            
        });
        return Promise.resolve<any>(listdata);
  }

  export const getImpoactDocumentOptionList = (props:any) => {
    let impoactDocumentOptions: any = [];
    let url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/fields?$filter=EntityPropertyName eq 'ImpactonDocuments'";
    let listdata = props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {           
            return await response.json().then((res) => {                  
                    if (res != null) {
                        res.value[0].Choices.map((item: any) => {
                          impoactDocumentOptions.push({
                                text: item, key: item
                            });
                        });                       
                        return impoactDocumentOptions;
                    } else {
                        console.log('recoard failed');
                    }
                });            
        });
        return Promise.resolve<any>(listdata);
  }
  export const getOtherAreasPotentiallyImpactedOptionsList = (props:any) => {
    let PotentiallyImpactedOptions: any = [];
    let url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/fields?$filter=EntityPropertyName eq 'AreasPotentiallyImpacted'";
    let listdata = props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {           
            return await response.json().then((res) => {                  
                    if (res != null) {
                        res.value[0].Choices.map((item: any) => {
                          PotentiallyImpactedOptions.push({
                                text: item, key: item
                            });
                        });                       
                        return PotentiallyImpactedOptions;
                    } else {
                        console.log('recoard failed');
                    }
                });            
        });
        return Promise.resolve<any>(listdata);
  }

  //New 
  export const handleCreateDocumentFolder =async (props:any,data:any,file:any): Promise<void> => {
    debugger;
    const folderUrl = `${props.context.pageContext.web.serverRelativeUrl}/DCNLibrary/${data.DCNNumber}`;
    const requestUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/folders`;
    const requestBody = JSON.stringify({
      '__metadata': { 'type': 'SP.Data.DCNLibraryItem' },
      'ServerRelativeUrl': folderUrl,
    });

    const headers = {
      'Accept': 'application/json;odata=nometadata',
      'Content-Type': 'application/json;odata=nometadata',
       'odata-version': ''
    };
    
    try {
      const options: ISPHttpClientOptions = {
        method: "POST",
        body: requestBody,
        headers: headers,
      };

      const response: SPHttpClientResponse = await props.context.spHttpClient.post(
        requestUrl,
        SPHttpClient.configurations.v1,
        options
      );

      if (response.ok) {
        debugger;
        console.log("Folder created successfully.");
      } else {
        console.error("Error while creating folder.");
      }
    } catch (error) {
      console.error('Error creating folder:', error);
      alert('Failed to create folder. Please try again.');
    }

  };

 
//Create Folder New Concept Working Code
export const handleCreateFolder = async (props: any, data: any,file:any): Promise<void> => {
  try {
    const folderUrl = `${props.context.pageContext.web.serverRelativeUrl}/DCNLibrary/${data.DCNNumber}`;
    const requestUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/folders`;

    let options: ISPHttpClientOptions = {
      method: "POST",
      body: JSON.stringify({      
        'ServerRelativeUrl': folderUrl
       
      }),
      headers: {
        "content-type": "application/json;odata=nometadata",
        "Accept": "application/json;odata=nometadata",
        'odata-version': ''
      },
    };

    await props.context.spHttpClient.post(requestUrl,SPHttpClient.configurations.v1,options)
    .then(async(response: SPHttpClientResponse) => {
        if (response.ok) {
          debugger;
          await response.json().then(async(res) => {
            console.log("Folder created successfully.", res);
            const folderItemId = await getFolderId(props, folderUrl);
            console.log('folder'+folderItemId);
            DocFolderListItemUpdateSet(props,folderItemId,data,folderUrl,file)
            //await uploadFileToFolder(props, folderUrl, file);
            //UpdateDocSet(props,res,data,file);
            // You can call other functions here if you need to perform additional actions after folder creation.
          });
        } else {
          console.log("Error while creating folder.");
        }
      },
      (error: any): void => {
        console.log("Error while creating folder: " + error);
      }
    );
  } catch (error) {
    console.error('Error creating folder:', error);
    alert('Failed to create folder. Please try again.');
  }
};


export const uploadFileToFolder = async (props: any, folderUrl: string, files: FileList): Promise<void> => {
  try {
    debugger;
    if (files.length === 0) {
      console.error("No files to upload.");
      return;
    }
    for (let i = 0; i < files.length; i++) {
      const file:any = files[i];
      const uploadUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/getfolderbyserverrelativeurl('${folderUrl}')/files/add(overwrite=true, url='${file.name}')`;

      const fileData = await file.arrayBuffer(); // Convert the file to ArrayBuffer

      const options: ISPHttpClientOptions = {
        method: "POST",
        body: fileData,       
        headers: {
          'Accept': 'application/json;odata=nometadata',
          'Content-type': 'application/json;odata=verbose',
          'odata-version': ''
        },
      };

      await props.context.spHttpClient.post(uploadUrl, SPHttpClient.configurations.v1, options)
        .then(async(response: SPHttpClientResponse) => {
          debugger;
          if (response.ok) {
            debugger;
            console.log(`File ${file.name} uploaded successfully to the folder.`);
          } else {
            const errorMessage = await response.json() ;
            console.error(`Error uploading file ${file.name}: ${response.statusText}, Details: ${errorMessage}`);
          }
        });
    }
  } catch (error) {
    console.error('Error uploading files:', error);
  }
};
export const getFolderId = async (props: any, folderUrl: string): Promise<number | null> => {
  try {
    const folderItemUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/getfolderbyserverrelativeurl('${folderUrl}')?$expand=listItemAllFields`;
    
    const folderResponse: SPHttpClientResponse = await props.context.spHttpClient.get(
      folderItemUrl,
      SPHttpClient.configurations.v1
    );

    if (folderResponse.ok) {
      debugger;
      const folderData = await folderResponse.json();
      const listItemId = folderData.ListItemAllFields.Id;
      console.log(`Folder ID: ${listItemId}`);
      return listItemId;
    } else {
      const errorDetails = await folderResponse.text();
      console.error(`Error fetching folder ID: ${folderResponse.status} - ${folderResponse.statusText}. Details: ${errorDetails}`);
      return null;
    }
  } catch (error) {
    console.error('Error fetching folder ID:', error);
    return null;
  }
};
export const DocFolderListItemUpdateSet=(props:any,Id:any,data:any,folderUrl:any,file:any)=>{
  try {     
  
    const body: string = JSON.stringify({        
      'OriginatorNameId':props.context.pageContext.legacyPageContext.userId,
      'DCNID': data.Id.toString(),
      'DesignChangeTitle':data.Title,
      'Title':  data.DCNNumber,
       });
    props.context.spHttpClient
      .post(
        `${props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('DCN Library')/items(${Id})`,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata",
            "Content-type": "application/json;odata=nometadata",
            "odata-version": "",
            "IF-MATCH": "*",
            "X-HTTP-Method": "MERGE",
          },
          body: body,
        }
      )
      .then(async(response: SPHttpClientResponse) => {
          if (response.ok) {
            console.log("Record Updated Successfully");
            debugger;
            await uploadFileToFolder(props, folderUrl, file);
            // file.length >0 && file.map((val:any) => {
            //   uploadFileToLibrary(props,val, data.DCNNumber);
            // }); 
           
          } else {
            (error: any): void => {
              console.log(
                "Error while updating document set fields value: " + error
              );
            }
            
          }
        },
        (error: any): void => {
          console.log(
            "Error while updating document set fields value: " + error
          );
        }
      );
  }
  catch (error) {
    console.log("Exception while creating document set: " + error);
  }

}
//Working Code End



  // New End
  export const handleCreateDocumentSet = async (props:any,data:any,file:any): Promise<void> => {
    
    const contentTypeId = await getContentTypeId(props);
    try {
        let options: ISPHttpClientOptions = {
        method: "POST",
        body: JSON.stringify({
          '__metadata': { 'type': 'SP.Data.DCNLibraryItem' }, 
          'Title':  data.DCNNumber,
         
          'Path': 'https://eu023-sp.shell.com/sites/SPOAA1198/Sparta/DCNLibrary'
        }),
        headers: {
          "content-type": "application/json;odata=nometadata",
          Accept: "application/json;odata=nometadata",
          Slug: `${'https://eu023-sp.shell.com/sites/SPOAA1198/Sparta/DCNLibrary'}/${data.DCNNumber}|${contentTypeId}`,

          //https://eu023-sp.shell.com/:f:/r/sites/SPOAA1198/Sparta/DCNLibrary/DCN001?d=w4e5f19f5392b4bca81164fe0f3db086f&csf=1&web=1&e=pxbIc3
        },
      };
      await props.context.spHttpClient.post(
        
        `${props.context.pageContext.web.absoluteUrl}/_vti_bin/listdata.svc/DCNLibrary`,
        SPHttpClient.configurations.v1,
        options)
        .then(
          (d: SPHttpClientResponse) => {
            if (d.ok == true) {
              d.json().then((res) => {
                console.log("document set created."+res);
                //Old Code
                //UpdateDocSet(props,res['d'].Id,data,file);
                //Old Code
debugger;
                
                
              });
            } else {
              console.log("Error while creating document set.");
            }
          },
          (error: any): void => {
            console.log("Error while creating document set: " + error);
          }
        );
       
    } catch (error) {
      
      console.error('Error creating document set:', error);
      alert('Failed to create document set. Please try again.');
    }
  };


  export const UpdateDocSet=(props:any,Id:any,data:any,file:any)=>{
    try {     
    
      const body: string = JSON.stringify({        
        'OriginatorNameId':props.context.pageContext.legacyPageContext.userId,
        'DCNID': data.Id.toString(),
        'DesignChangeTitle':data.Title,
         });
      props.context.spHttpClient
        .post(
          `${props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('DCN Library')/items(${Id})`,
          SPHttpClient.configurations.v1,
          {
            headers: {
              Accept: "application/json;odata=nometadata",
              "Content-type": "application/json;odata=nometadata",
              "odata-version": "",
              "IF-MATCH": "*",
              "X-HTTP-Method": "MERGE",
            },
            body: body,
          }
        )
        .then(async(response: SPHttpClientResponse) => {
            if (response.ok) {
              console.log("Record Updated Successfully");
              debugger;              
              file.length >0 && file.map((val:any) => {
                uploadFileToLibrary(props,val, data.DCNNumber);
              }); 
             
            } else {
              (error: any): void => {
                console.log(
                  "Error while updating document set fields value: " + error
                );
              }
              
            }
          },
          (error: any): void => {
            console.log(
              "Error while updating document set fields value: " + error
            );
          }
        );
    }
    catch (error) {
      console.log("Exception while creating document set: " + error);
    }

  }

  // export const createFolder=(props:any,data:any,file:any,)=>{    
  //   try {      
  //     let apiURL ='/_api/web/Lists/GetByTitle';
  //     let libraryName ="DCN Library";
  //     let endpointUrl = props.context.pageContext.web.absoluteUrl + apiURL +"('"+libraryName+"')"+ data.DCNNumber;
      
  //     console.log("createFolder: " + endpointUrl);
  //     const itemResults = props.context.spHttpClient.post(endpointUrl, SPHttpClient.configurations.v1, {
  //       headers: {
  //         'Accept': 'application/json;odata=nometadata',
  //         'Content-type': 'application/json;odata=verbose',
  //         'odata-version': ''
  //       }
  //     }).then((response: SPHttpClientResponse) => {
  //       if (response.ok) {
  //         response.json().then(async(response) => {
  //           if (response != null) {
  //             if (data.files.length > 0) {
  //               data.files.map((val:any) => {
  //                  uploadFileToLibrary(props,val, data.DCNNumber);
  //               });               

  //             }
  //             else {
  //                 alert("Please attach the document!")
  //               // swal({
  //               //   text: "Please attach the document!" + "error",
  //               //   icon: "error",
  //               //   dangerMode: false,
  //               //   closeOnClickOutside: false,
  //               //   closeOnEsc: false
  //               // })
  //               //swal("Error!" + "Please attach the document!" + "error");
  //             }

  //           }
  //         });
  //       }
  //     });
  //     return Promise.resolve<any>(itemResults);
  //   }
  //   catch (error) {
  //     console.log("createFolder-" + error);
  //   }
  // }


  // export const uploadFileToLibrary=(props:any,file:any, folderName:any)=> {
  //   try {    
  //     debugger;
  //     let reader = new FileReader();
  //     reader.readAsArrayBuffer(file);
  //     reader.onload = async (evt:any) => {
  //       debugger;
  //       //let buffer = reader.result;        
  //       let buffer = evt.target.result;
  //       const endpointUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/GetFolderByServerRelativeUrl('${"Shell Document Set"}/${folderName}')/Files/Add(url='${encodeURIComponent(file.name)}',overwrite=true)`;
  //       const itemResults = await props.context.spHttpClient.post(endpointUrl, SPHttpClient.configurations.v1, {
  //         method: "POST",
  //         headers: {
  //           'Accept': 'application/json;odata=nometadata',
  //           'Content-Type': 'application/json;odata=verbose',
  //           'odata-version': '',
  //         },
  //         body: buffer
  //       }).then((response: SPHttpClientResponse) => {
  //         debugger;
  //         if (response.ok) {
  //           debugger;
  //           response.json().then((response) => {
  //             if (response != null) {
  //                 alert("File added to Doc library");
  //               //alert("Success!"+ "Item created " +  "success");  
  //             }
  //             else {
  //                  alert("File added to Doc library");
  //               // swal("Error", "Upload Failed", "Error");
  //             }
  //           });
  //         }
  //       });
      
  //       return Promise.resolve<any>(itemResults);
  //     };
  //   }
  //   catch (error) {
  //     debugger;
  //     console.log("uploadFileToLibrary-" + error);
  //   }
  // }


  export const uploadFileToLibrary = async (props: any, file: any, folderName: string) => {
    try {
      const reader = new FileReader();
      reader.onload = async (evt: any) => {
        const buffer = evt.target.result;
        // Construct endpoint URL
        const folderUrl = encodeURIComponent(`DCNLibrary/${folderName}`);
        const endpointUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/GetFolderByServerRelativeUrl('${folderUrl}')/Files/Add(url='${encodeURIComponent(file.name)}',overwrite=true)`;
  
        try {
          const response = await props.context.spHttpClient.post(endpointUrl, SPHttpClient.configurations.v1, {
            headers: {
              'Accept': 'application/json;odata=nometadata',
              'Content-Type': 'application/json;odata=verbose',
              'odata-version': '',
            },
            body: buffer,
          });

          if (response.ok) {
            const jsonResponse = await response.json();
            if (jsonResponse) {
              console.log("File added to Document Library");
            } else {
              console.log("Failed to add file to Document Library");
            }
          } else {
            const errorResponse = await response.json();
            console.log(`Error uploading file: ${errorResponse.error.message}`);
          }
        } catch (uploadError) {
          console.error("Error during file upload:", uploadError);
          console.log("Error during file upload");
        }
      };
  
      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error("uploadFileToLibrary error:", error);
      console.log("Error in file upload process");
    }
  };

  export const getContentTypeId =async(props:any)=>{
    
    try {
      const response: SPHttpClientResponse = await props.context.spHttpClient.get(
        `${props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('DCN Library')/contenttypes`,
        SPHttpClient.configurations.v1
      );

      if (response.ok) {
        const data = await response.json();
        let documentSetContentTypeId = '';
        for (const contentType of data.value) {
          if (contentType.Name === 'Shell Document Set') {
            documentSetContentTypeId = contentType.StringId;
            break;
          }
        }
        if (documentSetContentTypeId) {
          return documentSetContentTypeId;
        } else {
          throw new Error('Document Set content type not found.');
        }
      } else {
        throw new Error('Error fetching content types.');
      }
    } catch (error) {
      console.error('Error fetching content type ID:', error);
      throw new Error('Failed to fetch content type ID.');
    }
  }
//Mastaer Call End

//Send Email For Discipline Leads
 export const sendMail = async (props:any, from: any, to: any[],cc:any, subject: string, bodyMsg: string, listID: any, name: string | null, status: string | null, RejectComment: null) => {

    //let RejectReasons = this.props.listItems.RejectReasons == null ? "" : this.props.listItems.RejectReasons;
    let RejectComments = RejectComment == null ? "" : RejectComment;
    let linkUrl: any = "";
    linkUrl += "<a href='" + props.webURL + "/SitePages/DCN-Tool.aspx?itemID=" + listID + "&Mode=EditForm'> click here </a>";
    let body = '';
    if (status == null) {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear Team,</span><br/>";
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/>" + linkUrl + "<br/>"; // Current user's display name

    }
    if (status == 'Proceed') {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/><br/>"; // Current user's display name

    }
    if (status == 'Rejected') {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
        //xbody += "<span style='font-size:11pt; font-family:Calibri;'> A Project " + ProjectNo + " request has been Rejected by <b>" + this.props.userDisplayName + "</b></span></br>"; // Current user's display name
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/>" + linkUrl + "<br/>"; // Current user's display name
        body += "<b>Rejection Reason(s) and text explanation</b> <br/>";
        body += "<span>" + RejectComments + "</span> <br/><br/><br/>";      

    }
    body += "Regards," + "<br/>";
    body += "<span>" + name + "</span>";

    let url = props.webURL + '/_api/SP.Utilities.Utility.SendEmail';
    const reqOptions: any = {
        headers: {
            "Accept": "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "odata-version": "3.0",
        },
        body: JSON.stringify({
            'properties': {
                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                'From': from,
                'To': { 'results': to },
                'CC': { 'results': [cc] },
                'Body': body,
                'Subject': subject
            }
        })
    };

 let sendmail =  await props.spHttpClient.post(url, SPHttpClient.configurations.v1, reqOptions)
        .then(async (response: SPHttpClientResponse) => {
            console.log(`Status code: ${response.status}`);
            console.log(`Status text: ${response.statusText}`);
            return await response.json().then((responseJSON: JSON) => {
                console.log("ResponseJSON:" + responseJSON);
                //toast.success('Mail sent successfully');
                // alert("Email Send Successfully!!!");
                return response
            });
            
        });
        return Promise.resolve<any>(sendmail)
 }

 //Send Email For Discipline Leads
 export const sendMailToOrginater = async (props:any, from: any, to: any[], subject: string, bodyMsg: string, DCNNumber:string|null, listID: any, name: string | null, status: string | null, RejectComment: null) => {

  //let RejectReasons = this.props.listItems.RejectReasons == null ? "" : this.props.listItems.RejectReasons;
  let RejectComments = RejectComment == null ? "" : RejectComment;
  let linkUrl: any = "";
  let CloseOutUrl:any="";
  let documentSetLink:any ="";
  linkUrl += "<a href='" + props.webURL + "/SitePages/DCN-Tool.aspx?itemID=" + listID + "&Mode=EditForm'> Click Here </a>";
  CloseOutUrl += "<a href='" + props.webURL + "/SitePages/DCN-Tool.aspx?itemID=" + listID + "&Mode=ViewForm'> click Here </a>";
  documentSetLink += "<a href='" + props.webURL + "/DCNLibrary/" + DCNNumber + "'> click here </a>"; 

  let body = '';
  if (status == null) {
      body = "<span style='font-size:11pt; font-family:Calibri;'>Dear "+ name + ",</span><br/>";
      body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
      body += bodyMsg + "<span/>" + linkUrl + "<br/> Go To DocumentSet : " + documentSetLink; // Current user's display name

  }else  if (status == 'Reviewed') {
      body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
      body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
      body += bodyMsg + "<span/> " + linkUrl + "<br/>"; // Current user's display name

  }else  if (status == 'ReviewedModified') {
    body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
    body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
    body += bodyMsg + "<span/> For More Details " + linkUrl + "<br/>"; // Current user's display name

}else  if (status == 'Approve') {
    body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
    body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
    body += bodyMsg + "<span/> " + linkUrl + "<br/>"; // Current user's display name
}
else  if (status == 'CloseOut') {
    body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
    body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
    body += bodyMsg + "<span/> " + CloseOutUrl + "<br/>"; // Current user's display name

}else  if (status == 'Open') {
    body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
    body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
    body += bodyMsg + "<span/> " + linkUrl + "<br/>"; // Current user's display name
    
}else if (status == 'Reject') {
      body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
      //xbody += "<span style='font-size:11pt; font-family:Calibri;'> A Project " + ProjectNo + " request has been Rejected by <b>" + this.props.userDisplayName + "</b></span></br>"; // Current user's display name
      body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
      body += bodyMsg + "<span/>" + linkUrl + "<br/>"; // Current user's display name
      body += "<b>Rejection Reason(s) and text explanation</b> <br/>";
      body += "<span>" + RejectComments + "</span> <br/><br/><br/>";
      body += "Regards," + "<br/>";
      body += "<span>" + name + "</span>";

  }
  let url = props.webURL + '/_api/SP.Utilities.Utility.SendEmail';
  const reqOptions: any = {
      headers: {
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose",
          "odata-version": "3.0",
      },
      body: JSON.stringify({
          'properties': {
              '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
              'From': from,
              'To': { 'results': to },
              'CC': { 'results': to },
              'Body': body,
              'Subject': subject
          }
      })
  };

  let resmail = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, reqOptions)
      .then(async (response: SPHttpClientResponse) => {
          console.log(`Status code: ${response.status}`);
          console.log(`Status text: ${response.statusText}`);
          return await response.json().then((responseJSON: JSON) => {
              console.log("ResponseJSON:" + responseJSON);
              //toast.success('Mail sent successfully');
              // alert("Email Send Successfully!!!");    
              return response         
          });
          
      });
      return Promise.resolve<any>(resmail)
}
//Send Email For Discipline Leads
export const sendMailToApprover = async (props:any, from: any, to: any[], subject: string, bodyMsg: string, DCNNumber:string|null, listID: any, name: string | null, status: string | null, RejectComment: null) => {
  
    //let RejectReasons = this.props.listItems.RejectReasons == null ? "" : this.props.listItems.RejectReasons;
    let RejectComments = RejectComment == null ? "" : RejectComment;
    let linkUrl: any = "";
    //let documentSetLink:any ="";
    linkUrl += "<a href='" + props.webURL + "/SitePages/DCN-Tool.aspx?itemID=" + listID + "&Mode=EditForm'> click here </a>";
    //documentSetLink += "<a href='" + props.webURL + "/DCNLibrary/" + DCNNumber + "'> click here </a>"; 
  
    let body = '';
   
    if (status == 'AllApproved') {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span> <br/>";
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/> For More Details "+ linkUrl; // Current user's display name
  
    }else
    if (status == 'ReviewedModified') {
      body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
      body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
      body += bodyMsg + "<span/> For More Details " + linkUrl + "<br/>"; // Current user's display name
  
  }
    
    if (status == 'Rejected') {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
        //xbody += "<span style='font-size:11pt; font-family:Calibri;'> A Project " + ProjectNo + " request has been Rejected by <b>" + this.props.userDisplayName + "</b></span></br>"; // Current user's display name
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/>" + linkUrl + "<br/>"; // Current user's display name
        body += "<b>Rejection Reason(s) and text explanation</b> <br/>";
        body += "<span>" + RejectComments + "</span> <br/><br/><br/>";
        //body += "Regards," + "<br/>";
        //body += "<span>" + name + "</span>";
  
    }
    let url = props.webURL + '/_api/SP.Utilities.Utility.SendEmail';
    const reqOptions: any = {
        headers: {
            "Accept": "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "odata-version": "3.0",
        },
        body: JSON.stringify({
            'properties': {
                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                'From': from,
                'To': { 'results': to },
                'CC': { 'results': to },
                'Body': body,
                'Subject': subject
            }
        })
    };
  
    let resmail = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, reqOptions)
        .then(async (response: SPHttpClientResponse) => {
            console.log(`Status code: ${response.status}`);
            console.log(`Status text: ${response.statusText}`);
            return await response.json().then((responseJSON: JSON) => {
                console.log("ResponseJSON:" + responseJSON);
                //toast.success('Mail sent successfully');
                // alert("Email Send Successfully!!!");    
                return response         
            });
            
        });
        return Promise.resolve<any>(resmail)
  }
//Send Email to Close Out Member
//Send Email For Discipline Leads
export const sendMailToCloseOutMember = async (props:any, from: any, to: any[], subject: string, bodyMsg: string, DCNNumber:string|null, listID: any, name: string | null, status: string | null, RejectComment: null) => {
  
    //let RejectReasons = this.props.listItems.RejectReasons == null ? "" : this.props.listItems.RejectReasons;
    let RejectComments = RejectComment == null ? "" : RejectComment;
    let linkUrl: any = "";
    let documentSetLink:any ="";
    linkUrl += "<a href='" + props.webURL + "/SitePages/DCN-Tool.aspx?itemID=" + listID + "&Mode=EditForm'> click here </a>";
    documentSetLink += "<a href='" + props.webURL + "/DCNLibrary/" + DCNNumber + "'> click here </a>"; 
  
    let body = '';
    if (status == null) {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear "+ name + ",</span><br/>";
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/>" + documentSetLink + "<br/> For More Details "+ linkUrl; // Current user's display name
  
    }else
    if (status == 'Reviewed') {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/> " + linkUrl + "<br/>"; // Current user's display name
  
    }else
    if (status == 'ReviewedModified') {
      body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
      body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
      body += bodyMsg + "<span/> For More Details " + linkUrl + "<br/>"; // Current user's display name
  
  }else
    if (status == 'Approve') {
      body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
      body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
      body += bodyMsg + "<span/> " + linkUrl + "<br/>"; // Current user's display name
  }
    
    if (status == 'Reject') {
        body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + name + ",</span><br/>";
        //xbody += "<span style='font-size:11pt; font-family:Calibri;'> A Project " + ProjectNo + " request has been Rejected by <b>" + this.props.userDisplayName + "</b></span></br>"; // Current user's display name
        body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
        body += bodyMsg + "<span/>" + linkUrl + "<br/>"; // Current user's display name
        body += "<b>Rejection Reason(s) and text explanation</b> <br/>";
        body += "<span>" + RejectComments + "</span> <br/><br/><br/>";
        //body += "Regards," + "<br/>";
       // body += "<span>" + name + "</span>";
  
    }
    let url = props.webURL + '/_api/SP.Utilities.Utility.SendEmail';
    const reqOptions: any = {
        headers: {
            "Accept": "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "odata-version": "3.0",
        },
        body: JSON.stringify({
            'properties': {
                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                'From': from,
                'To': { 'results': to },
                'CC': { 'results': to },
                'Body': body,
                'Subject': subject
            }
        })
    };
  
    let resmail = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, reqOptions)
        .then(async (response: SPHttpClientResponse) => {
            console.log(`Status code: ${response.status}`);
            console.log(`Status text: ${response.statusText}`);
            return await response.json().then((responseJSON: JSON) => {
                console.log("ResponseJSON:" + responseJSON);
                //toast.success('Mail sent successfully');
                // alert("Email Send Successfully!!!");    
                return response         
            });
            
        });
        return Promise.resolve<any>(resmail)
  }
//Auto Generate DCN Number 
  export const generateSerialNumber=()=> {

  let min = 0;
  let max = 9999;
  let currentDate = new Date();
  let month: any = '0';
  if (currentDate.getMonth() < 10) {
      month = '0' + (currentDate.getMonth() + 1);
  } else {
      month = currentDate.getMonth() + 1;
  }

  let Num = currentDate.getDate() + '' + (month) + '' + currentDate.getFullYear();
  let randamNo = ('DCN' + '-' + Num + '-' + Math.round(Math.random() * (max - min) + min));
  console.log(randamNo);       
  return randamNo
}
//Get User Group
 export const getUsersinAdminGroup=async(props:any)=>{
  debugger;
    //let obj:any = {}
    let url = props.webURL + "/_api/web/RoleAssignments/Groups?$filter=(substringof('DCN Administrator',Title))&$expand=Users";
    const itemResults = await props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
            return response.json().then((response):any => {
             
              const DCN_Administrator = response.value.filter((group: { Title: string; }) => group.Title == 'DCN Administrator');
              // const ApproverGroup = response.value.filter((group: { Title: string; }) => group.Title == 'Approver Group');
              // const CloseoutApproverGroup = response.value.filter((group: { Title: string; }) => group.Title == 'Closeout Approver Group');
              // const DisciplineLeadGroup = response.value.filter((group: { Title: string; }) => group.Title == 'Discipline Lead Group');
              // const OriginatorGroup = response.value.filter((group: { Title: string; }) => group.Title == 'Originator Group');

              let DCN_AdministratorMembers = [];
              // let ApproverGroupMembers = [];
              // let OriginatorGroupMembers = [];
              // let CloseoutApproverGroupMembers = [];
              // let DisciplineLeadGroupMembers = [];

              DCN_AdministratorMembers = DCN_Administrator.length > 0 && DCN_Administrator[0].Users.filter((user: { Email: any; }) => user.Email == props.userEmail);
              // ApproverGroupMembers = ApproverGroup.length > 0 && ApproverGroup[0].Users.filter((user: { Email: any; }) => user.Email == props.userEmail);
              // CloseoutApproverGroupMembers = CloseoutApproverGroup.length > 0 && CloseoutApproverGroup[0].Users.filter((user: { Email: any; }) => user.Email == props.userEmail);
              // DisciplineLeadGroupMembers = DisciplineLeadGroup.length > 0 && DisciplineLeadGroup[0].Users.filter((user: { Email: any; }) => user.Email == props.userEmail);
              // OriginatorGroupMembers = OriginatorGroup.length > 0 && OriginatorGroup[0].Users.filter((user: { Email: any; }) => user.Email == props.userEmail);

             
              // if (DCN_AdministratorMembers.length > 0 && ApproverGroupMembers.length > 0 && CloseoutApproverGroupMembers.length > 0 && DisciplineLeadGroupMembers.length > 0 && OriginatorGroupMembers.length > 0) {
              //     obj = {
              //         isUserAllGroupMember: true
              //     }
              // }
              // else if (DCN_AdministratorMembers.length > 0) {
              //     obj = {
              //         isDCN_AdministratorMembers: true
              //     }
              // } else if (ApproverGroupMembers.length > 0) {
              //     obj = {
              //         isApproverGroupMembers: true,
              //     }
              // } else if (CloseoutApproverGroupMembers.length > 0) {
              //     obj = {
              //         isCloseoutApproverGroupMembers: true
              //     }
              // } else if (DisciplineLeadGroupMembers.length > 0) {
              //     obj = {
              //         isDisciplineLeadGroupMembers: true
              //     }

              // } else if (OriginatorGroupMembers.length > 0) {
              //     obj = {
              //         OriginatorGroupMembers: true
              //     }
              // }
              // else {
              //     obj = {

              //         isDCN_AdministratorMembers: false,
              //         isApproverGroupMembers: false,
              //         isCloseoutApproverGroupMembers: false,
              //         isDisciplineLeadGroupMembers: false,
              //         isOriginatorGroupMembers: false
              //     }
              // }
              // if (DCN_AdministratorMembers.length > 0) {
              //       obj = {
              //           isDCN_AdministratorMembers: true
              //       }
              //   }else{
              //     obj = {
              //       isDCN_AdministratorMembers: false
              //   }
              //   }
               return (DCN_AdministratorMembers.length > 0) ? true : false
            });
        })
        return itemResults;
    }
//Get Final Approver List
export const getDCNConfigList = async(props:any) => {
  
  const url = props.webURL + "/_api/web/Lists/GetByTitle('DCN ConfigList')/items?$select=*,ApproverName/EMail,ApproverName/Title,ApproverName/ID&$expand=ApproverName";
  const dcnConfigList =  await props.spHttpClient.get(url, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json().then((res): void => {
             return res.value
            });
      });
      return dcnConfigList;
  }
//get Discipline Master List
export const getDisciplineList = async(props:any) => {
    
    const url = props.webURL + "/_api/web/Lists/GetByTitle('Disciplines List')/items?$select=*,DisciplineLead/EMail,DisciplineLead/Title,DisciplineLead/ID&$expand=DisciplineLead";
    const disciplineList =  await props.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json().then((res): void => {
               return res
              });
        });
        return disciplineList;
    }
//get Discipline Reviewed List item
export const getDisciplineReviewedList = async(props:any) => {
  
  const url = props.webURL + "/_api/web/Lists/GetByTitle('Discipline Review List')/items";
  const disciplineReviewList =  await props.spHttpClient.get(url, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json().then((res): void => {
             return res
            });
      });
      return disciplineReviewList;
  }

//Discipline Lead Review New Entry
export const  DisciplineReviewCreate=async(props:any,data:any,RequesterTitle:any,RequestFormId:any,DCNNumber:any)=>{
  
      const postJosnData: string = JSON.stringify({
          __metadata: {
              type: 'SP.Data.DisciplineReviewListListItem'
          },
          DCNID:RequestFormId.toString(),
          Title:DCNNumber,
          DesignChangeTitle:RequesterTitle,       
          DisciplineNameItem:data.Title,            
          DisciplineLead:data.DisciplineLead.EMail,
          FeedBack:data.SummaryReview,
          Reviewed:data.disciplinesReviewed           
      });

      const url = props.webURL + "/_api/web/Lists/GetByTitle('Discipline Review List')/items";
      const reviewlist = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
          headers: {
              'Accept': 'application/json;odata=verbose',
              'Content-type': 'application/json;odata=verbose',
              'odata-version': ''
          },
          body: postJosnData
      }).then(async (response: SPHttpClientResponse) => {          
              return await response.json().then((response) => {
                  return response
              })
          
      });
      return reviewlist
     
    }
//Discipline Lead Review Exgisting Entry Updated 
export const  DisciplineReviewUpdate=async(props:any,data:any)=>{
  const postJosnData: string = JSON.stringify({
    __metadata: {
        type: 'SP.Data.DisciplineReviewListListItem'
    },
    DesignChangeTitle:data.RequesterTitle,      
    FeedBack:data.SummaryReview,
    Reviewed:data.disciplinesReviewed           
});

const url = props.webURL + "/_api/web/Lists/GetByTitle('Discipline Review List')/items('"+data.Id+"')";
const reviewlist = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
  headers: {
    'Accept': 'application/json;odata=nometadata',
    'Content-type': 'application/json;odata=verbose',
    'odata-version': '',
    'IF-MATCH': '*',
    'X-Http-Method': 'PATCH'

  },
    body: postJosnData
}).then(async (response: SPHttpClientResponse) => {
  if (response.ok) {
    return response;
  } else {
    console.log('Updated Review failed');
  }
});
return reviewlist
    }

//Discipline Lead Review Exgisting Item Fetch
export const  DisciplineReviewFetch=async(props:any)=>{   
  
  const url = props.webURL + "/_api/web/Lists/GetByTitle('Discipline Review List')/items";
  const listdata =  await props.spHttpClient.get(url, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json().then((res): void => {
             return res.value
            });
      });
      return Promise.resolve<any>(listdata);
    }
//Discipline Lead Review Exgisting Item Fetch
export const  DisciplineReviewDelete=async(props:any,Id:any)=>{   
  debugger;
  const url = props.webURL + "/_api/web/Lists/GetByTitle('Discipline Review List')/items('"+Id+"')";
  const listdata =  await props.spHttpClient.post(url, SPHttpClient.configurations.v1,{
    async: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            'OData-Version': '3.0',
            "If-Match": "*",
            "X-Http-Method": "DELETE",
        },
  })
      .then((response: SPHttpClientResponse) => {
        return response.json().then((res): void => {
             return res.value
            });
      });
      return Promise.resolve<any>(listdata);
    }
//DCN List Status Update For "Proceed","Approve","CloseOut","Open"
export const  DCNListStatusUpdate=async(props:any,Status:any,Id:any)=>{
  const postJosnData: string = JSON.stringify({
    __metadata: {
        type: 'SP.Data.DCNListListItem'
    },      
    DCNStatus:Status,
    AllDisciplineReviewed:true
          
});

const url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/items('"+Id+"')";
const reviewlist = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
  headers: {
    'Accept': 'application/json;odata=nometadata',
    'Content-type': 'application/json;odata=verbose',
    'odata-version': '',
    'IF-MATCH': '*',
    'X-Http-Method': 'PATCH'

  },
    body: postJosnData
}).then(async (response: SPHttpClientResponse) => {
  if (response.ok) {
    return response;
  } else {
    console.log('Updated Review failed');
  }
});
return reviewlist
}

//Approver Update or Reject 
export const  DCNListApprovalUpdate=async(props:any,data:any)=>{
  
  const postJosnData: string = JSON.stringify({
    __metadata: {
        type: 'SP.Data.DCNListListItem'
    },      
    ApprovedDisciplineUser:data.DCNConfigList.ApproverName.EMail,
    ApprovedDisciplineStatus:data.ApproveRejectStatus,
    ApproverRejectedComment:data.ApproverOrRejectComment,
    ApprovedOrRejectedDate:new Date(data.ApproveOrRejectDate),
    ImplementationDate:new Date(data.ImplementationDate),
    DCNStatus:data.ApproveRejectStatus =="Approve" ? "Move to CloseOut" :"Move to Reject"
          
});

const url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/items('"+data.RequestFormId+"')";
const reviewlist = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
  headers: {
    'Accept': 'application/json;odata=nometadata',
    'Content-type': 'application/json;odata=verbose',
    'odata-version': '',
    'IF-MATCH': '*',
    'X-Http-Method': 'PATCH'

  },
    body: postJosnData
}).then(async (response: SPHttpClientResponse) => {
  if (response.ok) {
    return response;
  } else {
    console.log('Updated Review failed');
  }
});
return reviewlist
}

//Close Out Open or Close Out 
export const  DCNListCloseOutUpdate=async(props:any,data:any)=>{
  const postJosnData: string = JSON.stringify({
    __metadata: {
        type: 'SP.Data.DCNListListItem'
    },
    CloseOutApprover:data.OriginatorEmail,      
    CloseOutReviewStatus:data.CloseOutReviewStatus,
    CloseOutReOpenComment:data.CloseOutReOpenComment,
    CloseOutReviewDate:new Date(data.CloseOutReviewDate),
    DCNStatus:data.CloseOutReviewStatus =="CloseOut" ? "Completed" :"Move to Re-Open"
          
});

const url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/items('"+data.RequestFormId+"')";
const reviewlist = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
  headers: {
    'Accept': 'application/json;odata=nometadata',
    'Content-type': 'application/json;odata=verbose',
    'odata-version': '',
    'IF-MATCH': '*',
    'X-Http-Method': 'PATCH'

  },
    body: postJosnData
}).then(async (response: SPHttpClientResponse) => {
  if (response.ok) {
    return response;
  } else {
    console.log('Updated Review failed');
  }
});
return reviewlist
}

//Re-Open Case Updated Exgisting Item with out Generate DCN Number
export const  DCNListReOpen=async(props:any,data:any)=>{
  
  const postJosnData: string = JSON.stringify({
    __metadata: {
        type: 'SP.Data.DCNListListItem'
    },      
    Title:data.Design_Change_Title,
    OriginatorUserId:data.OriginatorId,
    Date: new Date(data.OriginatorDate),
    Description:data.description,
    ProposedChange:data.proposedChange,
    OriginatingDiscipline:data.Originating_Discipline,
    Discipline:data.Discipline,
    ReasonforChange:data.ReasonforChange == undefined ? null :data.ReasonforChange,
    //ReasonforChange: { '__metadata': { 'type': 'Collection(Edm.String)' }, results:data.Reason_for_Change == undefined ? [] :data.Reason_for_Change },
    ImpactsDetails:data.What_are_the_impacts,
    ImpactonDocuments: { '__metadata': { 'type': 'Collection(Edm.String)' }, results:data.ImapactDocuments == undefined ? [] :data.ImapactDocuments },
    AreasPotentiallyImpacted: { '__metadata': { 'type': 'Collection(Edm.String)' }, results:data.OtherPotentiallyImpacted == undefined ? [] :data.OtherPotentiallyImpacted },
    IsReHazopRequired:data.Re_Hazop_required,
    TopsidesHAZOP_LOPAreport:data.Topsides_HAZOP_LOPA_report,
    DCNStatus: 'Move to Proceed',
    AllDisciplineReviewed:false,

    ApprovedDisciplineUser:null,
    ApprovedDisciplineStatus:null,
    ApproverRejectedComment:null,
    ApprovedOrRejectedDate:new Date(),
    ImplementationDate:new Date(),

    CloseOutApprover:null,      
    CloseOutReviewStatus:null,
    CloseOutReOpenComment:null,
    CloseOutReviewDate:new Date(),
    
    
          
});

const url = props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/items('"+data.RequestFormId+"')";
const reviewlist = await props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
  headers: {
    'Accept': 'application/json;odata=nometadata',
    'Content-type': 'application/json;odata=verbose',
    'odata-version': '',
    'IF-MATCH': '*',
    'X-Http-Method': 'PATCH'

  },
    body: postJosnData
}).then(async (response: SPHttpClientResponse) => {
  if (response.ok) {
    return response;
  } else {
    console.log('Updated Review failed');
  }
});
return reviewlist
}



  export const isEmpty = function (obj:any) {
    if (obj === null) return true;
    if (_.isArray(obj) || _.isString(obj)) return obj.length === 0;
    for (const key in obj)
        if (_.has(obj, key)) return false;
    return true;
  };
