import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient } from "@microsoft/sp-http";
export interface IDcnToolProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  userEmail:string;
  webURL: string;
  spHttpClient:SPHttpClient;
  context:WebPartContext;
  css:any;
  reviewersLeadEmail:string;
}
