/* tslint:disable */
require("./DcnTool.module.css");
const styles = {
  spinner: 'spinner_28414fe5',
  'spinner-zp9dbg': 'spinner-zp9dbg_28414fe5',
  layerMask: 'layerMask_28414fe5',
  attachmentFiles: 'attachmentFiles_28414fe5',
  uploadControl: 'uploadControl_28414fe5',
  imgloader: 'imgloader_28414fe5',
  close_button: 'close_button_28414fe5'
};

export default styles;
/* tslint:enable */