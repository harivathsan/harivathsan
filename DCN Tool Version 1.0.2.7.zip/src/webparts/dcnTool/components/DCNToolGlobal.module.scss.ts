/* tslint:disable */
require("./DCNToolGlobal.module.css");
const styles = {
  dcnTool: 'dcnTool_48f4c24e',
  teams: 'teams_48f4c24e',
  welcome: 'welcome_48f4c24e',
  welcomeImage: 'welcomeImage_48f4c24e',
  links: 'links_48f4c24e'
};

export default styles;
/* tslint:enable */