import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import './shell-font.css';
import  './DCNToolGlobal.module.scss';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { Container,Row,Col} from 'react-bootstrap';
import { IDcnToolProps } from './IDcnToolProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { IDcnState } from './IDcnState';
//import Sections from '../../controls/Sections';
import DesignChangeRequestForm from '../../controls/DesignChangeRequestForm';

export default class DcnTool extends React.Component<IDcnToolProps, IDcnState> {
  constructor(props:any) {
    super(props);   
    let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
        SPComponentLoader.loadCss(cssPath);
    }
    this.state = {

    }
  }
  public render(): React.ReactElement<IDcnToolProps> {
    
    return (  
       <Container>
        <Row>
           <Col lg={12}>
            <DesignChangeRequestForm {...this.props}/>
           </Col>
        </Row>
        
        {/* <Sections {...this.props}/> */}
       </Container>
     
    );
  }
}
