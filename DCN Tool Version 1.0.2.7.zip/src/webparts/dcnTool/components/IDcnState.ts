export interface IDcnState {
   
}