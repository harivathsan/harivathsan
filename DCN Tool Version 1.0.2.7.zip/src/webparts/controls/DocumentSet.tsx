import * as React from 'react';
import { TextField, PrimaryButton } from 'office-ui-fabric-react';
import { SPHttpClient, SPHttpClientResponse,ISPHttpClientOptions } from '@microsoft/sp-http';
//import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
//import { sp } from "@pnp/sp";
import { IWebPartContext } from '@microsoft/sp-webpart-base';

export interface ICreateDocumentSetProps {
  context: IWebPartContext;
}

export interface ICreateDocumentSetState {
  documentSetName: string;
}

class CreateDocumentSet extends React.Component<any,any> {
  constructor(props: ICreateDocumentSetProps) {
    super(props);
    this.state = {
      documentSetName: '',
    };
  }

  handleInputChange = (e: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
    this.setState({ documentSetName: newValue || '' });
  };

  handleCreateDocumentSet = async (): Promise<void> => {
    
    const contentTypeId = await this.getContentTypeId();
    //const folderUrl = `${this.props.context.pageContext.web.serverRelativeUrl}/DCNLibrary/${this.state.documentSetName}`;
  //   const requestUrl = `${this.props.context.pageContext.web.absoluteUrl}/_api/web/folders`;

  // const requestBody = JSON.stringify({
  //   '__metadata': { 'type': 'SP.Data.DCNLibraryItem' },
  //   'ServerRelativeUrl': folderUrl,
  // });

  // const headers = {
  //   'Accept': 'application/json;odata=verbose',
  //   'Content-Type': 'application/json;odata=verbose',
  // };
    try {
     


      // const requestBody = {
      //   '__metadata': { 'type': 'SP.Data.DCNLibraryItem' },
      //   'Title': this.state.documentSetName,
      //   'ContentTypeId': contentTypeId,
      // };
      let options: ISPHttpClientOptions = {
        method: "POST",
        body: JSON.stringify({
          '__metadata': { 'type': 'SP.Data.DCNLibraryItem' }, 
          'Title':  this.state.documentSetName,
          'Path': 'https://eu023-sp.shell.com/sites/SPOAA1198/Sparta/DCNLibrary'
        }),
        headers: {
          "content-type": "application/json;odata=nometadata",
          Accept: "application/json;odata=nometadata",
          Slug: `${'https://eu023-sp.shell.com/sites/SPOAA1198/Sparta/DCNLibrary'}/${this.state.documentSetName}|${contentTypeId}`,

          //https://eu023-sp.shell.com/:f:/r/sites/SPOAA1198/Sparta/DCNLibrary/DCN001?d=w4e5f19f5392b4bca81164fe0f3db086f&csf=1&web=1&e=pxbIc3
        },
      };
      await this.props.context.spHttpClient.post(
        
        `${this.props.context.pageContext.web.absoluteUrl}/_vti_bin/listdata.svc/DCNLibrary`,
        SPHttpClient.configurations.v1,
        options)
        .then(
          (d: SPHttpClientResponse) => {
            if (d.ok == true) {
              d.json().then((res) => {
                console.log("document set created."+res);
                this.UpdateDocSet(res['d'].Id);
              });
            } else {
              console.log("Error while creating document set.");
            }
          },
          (error: any): void => {
            console.log("Error while creating document set: " + error);
          }
        );
       
    } catch (error) {
      
      console.error('Error creating document set:', error);
      alert('Failed to create document set. Please try again.');
    }
  };

  public UpdateDocSet=(Id:any)=>{
    try {
      
    
      const body: string = JSON.stringify({        
        'OriginatorNameId':this.props.context.pageContext.legacyPageContext.userId
         });
      this.props.context.spHttpClient
        .post(
          `${this.props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('DCN Library')/items(${Id})`,
          SPHttpClient.configurations.v1,
          {
            headers: {
              Accept: "application/json;odata=nometadata",
              "Content-type": "application/json;odata=nometadata",
              "odata-version": "",
              "IF-MATCH": "*",
              "X-HTTP-Method": "MERGE",
            },
            body: body,
          }
        )
        .then(
          (response: SPHttpClientResponse): void => {
            if (response.ok) {
              console.log("Record Updated Successfully");
             
            } else {
              (error: any): void => {
                console.log(
                  "Error while updating document set fields value: " + error
                );
              }
              
            }
          },
          (error: any): void => {
            console.log(
              "Error while updating document set fields value: " + error
            );
          }
        );
    }
    catch (error) {
      console.log("Exception while creating document set: " + error);
    }

  }

  async getContentTypeId() {
    
    try {
      const response: SPHttpClientResponse = await this.props.context.spHttpClient.get(
        `${this.props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('DCN Library')/contenttypes`,
        SPHttpClient.configurations.v1
      );

      if (response.ok) {
        const data = await response.json();
        let documentSetContentTypeId = '';
        for (const contentType of data.value) {
          if (contentType.Name === 'Shell Document Set') {
            documentSetContentTypeId = contentType.StringId;
            break;
          }
        }
        if (documentSetContentTypeId) {
          return documentSetContentTypeId;
        } else {
          throw new Error('Document Set content type not found.');
        }
      } else {
        throw new Error('Error fetching content types.');
      }
    } catch (error) {
      console.error('Error fetching content type ID:', error);
      throw new Error('Failed to fetch content type ID.');
    }
  }

  render() {
    return (
      <div>
        <TextField
          label="Enter document set name"
          value={this.state.documentSetName}
          onChange={this.handleInputChange}
        />
        <PrimaryButton onClick={this.handleCreateDocumentSet}>Create Document Set</PrimaryButton>
      </div>
    );
  }
}

export default CreateDocumentSet;
