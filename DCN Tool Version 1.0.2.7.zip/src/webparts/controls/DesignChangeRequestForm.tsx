import * as React from 'react';
import * as _ from 'lodash';
import styles from '../dcnTool/components/DcnTool.module.scss'
import { Form, Card, CardBody, Row, Col, Button, Accordion } from 'react-bootstrap';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import swal from 'sweetalert';
import { Label, TextField } from 'office-ui-fabric-react';
import { DatePicker } from '@fluentui/react';
import { Dropdown, IDropdownOption, ComboBox, IComboBox, IComboBoxOption} from 'office-ui-fabric-react';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { Editor } from 'react-draft-wysiwyg';
import { EditorState, convertToRaw, ContentState } from 'draft-js';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';
import { FilePond } from "react-filepond";
import 'filepond/dist/filepond.min.css';
//import {enCodeHtmlEntities} from '../services/services';
//import SectionSix from './sectionSix';
//import SectionSeven from './sectionSeven';
//import CreateDocumentSet from './DocumentSet';

import {
    //handleCreateDocumentSet,
    //handleCreateDocumentFolder,
    handleCreateFolder,
    sendMail,
    generateSerialNumber,
    getUsersinAdminGroup,
    getDisciplineList,
    getReasonChangeOptionList,
    getOriginating_DisciplineOptionList,
    getDisciplineOptionList,
    getImpoactDocumentOptionList,
    getOtherAreasPotentiallyImpactedOptionsList,
    FetchCurrentUserInfo,
    sendMailToOrginater,
    sendMailToCloseOutMember,
    getDisciplineReviewedList,
    //DisciplineReviewFetch,
    DisciplineReviewCreate,
    DisciplineReviewUpdate,
    sendMailToApprover,
    getDCNConfigList,
    DCNListStatusUpdate,
    DCNListApprovalUpdate,
    DCNListCloseOutUpdate,
    DCNListReOpen,
    DisciplineReviewFetch,
    DisciplineReviewDelete,
    //createFolder,
    //uploadFileToLibrary

} from '../services/services'


export const LoaderRipple = () => {
    return (
        <>
            <div className={styles.spinner}></div>
            <div className={styles.layerMask}></div>
        </>
    )

}


export default class DesignChangeRequestForm extends React.Component<any, any> {

    constructor(props: any) {
        super(props)
        this.state = {
            isloadRipple:true,
            isSaveBtnEnableFlag:0,
            formType: "NewForm",
            AccordionActivekey:"0",
            isAllReviewed: false,
            formID: null,
            OriginatorId: '',
            //OriginatorEmail: this.props.userEmail,
            //OriginatorName: this.props.userDisplayName,
            OriginatorEmail: '',
            OriginatorName: '',
            isOpen: false,
            isValidate: false,
            Title: "",
            OriginatorDate: new Date(),
            ApproveOrRejectDate: new Date(),
            ImplementationDate:new Date(),
            CloseOutReviewDate: new Date(),
            editorState: EditorState.createEmpty(),
            description: '',
            //ReasonforChange: [],
            ReasonforChange:null,
            OtherPotentiallyImpacted: [],
            DCN_No: '',
            ReasonChangeOptions: [],
            Originating_DisciplineOptions: [],
            ImapactDocuments: [],
            DisciplineOptions: [],
            impoactDocumentOptions: [],
            OtherAreasPotentiallyImpactedOptions: [],
            DisciplineList: [],
            DisciplineReviewItem: [],
            DisciplineReviewData: [],
            DisciplinesEmailList: [],
            DCNConfigList: null,
            DCNStatus: "",
            DCNFromStatus: "",
            AllDisciplineReviewed:false,
            ApproverOrRejectComment:"",
            //ApproveRejectStatus:"",
            CloseOutReviewStatus:"",
            CloseOutReOpenComment:"",
            files: [],
            files_Flag:false,

            DCNOptions: [{
                key: 'Proceed', text: 'Proceed'
            }, {
                key: 'Reject', text: 'Reject'
            }],
            ApprovalRejectOptions: [
                {
                    key: 'Approve', text: 'Approve'
                }, {
                    key: 'Reject', text: 'Reject'
                }
            ],
            OpenCloseOutOptions: [{
                key: 'Open', text: 'Open'
            }, {
                key: 'CloseOut', text: 'CloseOut'
            }],
            OpenCloseOutApprovedOptions: [ {
                key: 'CloseOut', text: 'CloseOut'
            }],
            userlevel: {},
            isDocDeleteFlag:false,
            uploadFileList:[]
        }

    }
    //getUserGrup
    public fetchCurrentGroup = async () => {
        debugger;
        await getUsersinAdminGroup(this.props).then((response) => {

            this.setState({ isDCN_AdministratorMembers: response })
        });
    }
    //Get DisciplineList
    public fetchDisciplineList = async () => {
        let disciplinesEmailList: any = [];
        await getDisciplineList(this.props).then((res) => {
            
            if (res.value != null) {
                res.value.map((item: any, index: number) => {
                    if (item.DisciplineLead != undefined) {
                        disciplinesEmailList.push(item.DisciplineLead.EMail);
                    }
                })
            } else {
                console.log('recoard failed');
            }

            // this.setState({ DisciplineList: res.value, 
            //     DisciplinesEmailList:disciplinesEmailList })
            this.setState({
                DisciplineList: res.value
            })
        })
    }

    //Fetch Current User
    public getCurrentUserInfo = async () => {
        await FetchCurrentUserInfo(this.props).then((response: any) => {
            this.setState({
                OriginatorId: response.Id,
                OriginatorEmail: response.Email,
                OriginatorName: response.Title
            })

        })
    }
    //Get all Dropdown Option List 
    public ReasonChangeOptionList = async () => {
        await getReasonChangeOptionList(this.props).then((OptionList: any) => {
            if (OptionList.length > 0) {
                this.setState({ ReasonChangeOptions: OptionList })
            }
        })
    }
    public Originating_DisciplineOptionList = async () => {
        await getOriginating_DisciplineOptionList(this.props).then((OptionList: any) => {
            if (OptionList.length > 0) {
                this.setState({ Originating_DisciplineOptions: OptionList })
            }
        })
    }
    public DisciplineOptionList = async () => {
        await getDisciplineOptionList(this.props).then((OptionList: any) => {
            if (OptionList.length > 0) {
                this.setState({ DisciplineOptions: OptionList })
            }
        })
    }
    public ImpoactDocumentOptionList = async () => {
        await getImpoactDocumentOptionList(this.props).then((OptionList: any) => {
            if (OptionList.length > 0) {
                this.setState({ impoactDocumentOptions: OptionList })
            }
        })
    }
    public OtherAreasPotentiallyImpactedOptionsList = async () => {
        await getOtherAreasPotentiallyImpactedOptionsList(this.props).then((OptionList: any) => {
            if (OptionList.length > 0) {
                this.setState({ OtherAreasPotentiallyImpactedOptions: OptionList })
            }
        })
    }
    //All Dropdown Option List Data End
    public GetDCNConfig = async () => {
        await getDCNConfigList(this.props).then((list: any) => {
            
            if (list.length > 0) {
                this.setState({ DCNConfigList: list[0] })
            };
        })
    }


    //All Mutilselect Dropdown Fuction 
    public multiSelectOptions(Name: any, event: any, item: any) {
        debugger;
        
        if (event.target.checked && Name == "OtherPotentiallyImpacted") {
            let DisciplineSeletedItem: any = [];
            DisciplineSeletedItem = this.state.DisciplineList.filter((listitem: any) => listitem.Title == item.text);
            this.setState({ [Name]: [...this.state[Name], item.text], DisciplineReviewData: [...this.state.DisciplineReviewData, ...DisciplineSeletedItem], [Name+"_Flag"]:false });

        } else if (Name == "OtherPotentiallyImpacted") {
            let disciplineitem: any = [];
            const dis: any = this.state.DisciplineReviewData;
            disciplineitem = dis.filter((listItem: any) => listItem.Title !== item.text);
            let arr: any = this.state[Name]
            _.pull(arr, item.text);
            this.setState({ [Name]: [...arr], DisciplineReviewData: [...disciplineitem], [Name+"_Flag"]: (arr.length == 0 ? true : false) });
        }

        else if (event.target.checked && Name != "OtherPotentiallyImpacted") {
            this.setState({ [Name]: [...this.state[Name], item.text] });
        }
        else {
            
            let arr: any = this.state[Name]
            _.pull(arr, item.text);
            this.setState({ [Name]: [...arr] });
        }
    }

    

    //On Changes Orgineter Pepole Picker Fuction
    _GetOriginatorName = (people: any[]) => {
        if (people.length > 0) {

            this.setState({
                OriginatorId: people[0].id,
                OriginatorEmail: people[0].secondaryText,
                OriginatorName: people[0].text
            });



        } else {
            this.setState({
                OriginatorId: '',
                OriginatorEmail: '',
                OriginatorName: ''

                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });


        }
    }

    // Find On Load URl New From or Edit Form Link 
    FetchFormType = async () => {

        let url = new URL(window.location.href);
        var params = new URLSearchParams(url.search);
        var mode;
        var itemId;
        var userType;
        if (params.has('Mode')) {
            mode = params.get('Mode');
            itemId = params.get('itemID');
            userType = params.get('type')

        }
        this.setState({
            formType: (mode != undefined ? mode : "NewForm"),
            formID: itemId != undefined ? itemId : null,
            userType: userType != undefined ? userType : null
        });
    }

    //On Change Editer Box Fuctions
    onEditorStateChange = (newEditorState: any) => {
        const contentState = newEditorState.getCurrentContent();
        const rawContentState = convertToRaw(contentState);
        const htmlContent = draftToHtml(rawContentState);
        this.setState({
            editorState: newEditorState,
            description: htmlContent,

        });
    };

    onEditorProposedChange = (newEditorProposedState: any) => {
        const contentProposedState = newEditorProposedState.getCurrentContent();
        const rawContentProposedState = convertToRaw(contentProposedState);
        const htmlProposedContent = draftToHtml(rawContentProposedState);
        this.setState({
            editorProposedState: newEditorProposedState,
            proposedChange: htmlProposedContent,

        });
    };
    //On Change Editer Box Fuctions End

    //On Handle Change Text,Dropdown and Switch box Function

    public handleChange = (
        ev: React.ChangeEvent<HTMLInputElement>,
    ): void => {

        this.setState({
            [ev.target.name]: ev.target.value
        });
    }

    private onDropdownChange = (ev: React.FormEvent<HTMLDivElement>,
        item: IDropdownOption): void => {
        const controlName = (ev.target as HTMLInputElement).title;
        
        this.setState({ [controlName]: item.text });
    }

    private onSelectDate = (o_date: Date | null | undefined): void => {
        this.setState({ OriginatorDate: o_date });
    }

    private onSelectApproveDate = (date: Date | null | undefined): void => {
        this.setState({ ApproveOrRejectDate: date });
    }

    private onSelectImplementationDate = (date: Date | null | undefined): void => {
        this.setState({ ImplementationDate: date });
    }

    private onSelectCloseOutDate = (date: Date | null | undefined): void => {
        this.setState({ CloseOutReviewDate: date });
    }

    // Date Formate
    private _onFormatDate = (date: Date):any => {
        return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
    }


    public handleSwitchChange = (e: any) => {
        this.setState({ [e.target.name]: e.target.checked });
    }

    public _handleReviewNameChange = (idx: any) => (evt: any) => {

        const newRevieholders = this.state.DisciplineReviewData.map((item: any, sidx: any) => {

            if (idx !== sidx) return item;
            return  { ...item, [evt.target.name]: evt.target.value,
                     IsUpdated: true, 
                     disciplinesReviewedSummary_flag: (evt.target.value == "" ? true :false)
                    };
        });

        this.setState({ DisciplineReviewData: newRevieholders });

    }
    public _onReviewSwitchChange = (idx: any) => (evt: any) => {

        const newRevieholders = this.state.DisciplineReviewData.map((item: any, sidx: any) => {
            if (idx !== sidx) return item;
            return { ...item, [evt.target.name]: evt.target.checked, 
                    IsUpdated: true, disciplinesReviewed_flag:false };
        });
        this.setState({ DisciplineReviewData: newRevieholders });
    }

    public _getPeoplePickerFocalName = (idx: any) => (peopleItem: any[]) => {

        if (peopleItem.length > 0) {
            const newShareholders = this.state.DisciplineReviewData.map((item: any, sidx: any) => {
                if (idx !== sidx) return item;
                return { ...item, DisciplineLeadNameId: peopleItem[0].id, DisciplineLeadNameEmail: peopleItem[0].secondaryText, DisciplineLeadName: peopleItem[0].text, IsUpdated: true };
            });
            this.setState({ DisciplineReviewData: newShareholders });
        } else {
            const newShareholders = this.state.DisciplineReviewData.map((item: any, sidx: any) => {
                if (idx !== sidx) return item;
                return { ...item, DisciplineLeadNameId: '', DisciplineLeadNameEmail: '', DisciplineLeadName: '', IsUpdated: true };
            });
            this.setState({ DisciplineReviewData: newShareholders });
        }
    }

    async componentDidMount(): Promise<void> {
        await this.GetDCNConfig();
        await this.FetchFormType();
        await this.fetchCurrentGroup();
        await this.getCurrentUserInfo();
        await this.fetchDisciplineList();
        await this.ReasonChangeOptionList();
        await this.Originating_DisciplineOptionList();
        await this.DisciplineOptionList();
        await this.ImpoactDocumentOptionList();
        await this.ImpoactDocumentOptionList();
        await this.OtherAreasPotentiallyImpactedOptionsList();
           
        if (this.state.formType != "NewForm") {
            await this.getEditFormInfo();
           
        }
        this.setState({isloadRipple:false});

    }

    // public selectedFileUpload=()=>{
    //     debugger;
    //     this.state.files.length >0 && this.state.files.map((val:any) => {
    //         uploadFileToLibrary(this.props,val, this.state.DCNNumber);
    //      });  
    // }

    public handleSubmit = async () => {
debugger;
        if (this.validation()) {
            let generateDCNNumber = generateSerialNumber();
            const postJosnData: string = JSON.stringify({
                __metadata: {
                    type: 'SP.Data.DCNListListItem'
                },
                Title: this.state.Design_Change_Title,
                DCNNumber: generateDCNNumber,
                OriginatorUserId: this.state.OriginatorId,
                Date: new Date(this.state.OriginatorDate),
                Description: this.state.description,
                ProposedChange: this.state.proposedChange,
                OriginatingDiscipline: this.state.Originating_Discipline,
                Discipline: this.state.Discipline,
                ReasonforChange:this.state.ReasonforChange == undefined ? null :this.state.ReasonforChange,
                
                ImpactsDetails: this.state.What_are_the_impacts,
                ImpactonDocuments: { '__metadata': { 'type': 'Collection(Edm.String)' }, results: this.state.ImapactDocuments == undefined ? [] : this.state.ImapactDocuments },
                AreasPotentiallyImpacted: { '__metadata': { 'type': 'Collection(Edm.String)' }, results: this.state.OtherPotentiallyImpacted == undefined ? [] : this.state.OtherPotentiallyImpacted },
                IsReHazopRequired: this.state.Re_Hazop_required,
                TopsidesHAZOP_LOPAreport: this.state.Topsides_HAZOP_LOPA_report,
                DCNStatus: 'Move to Proceed'
            });

            let url = this.props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/items";
            await this.props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
                headers: {
                    'Accept': 'application/json;odata=verbose',
                    'Content-type': 'application/json;odata=verbose',
                    'odata-version': ''
                },
                body: postJosnData
            }).then(async (response: SPHttpClientResponse) => {
                if (response.ok) {
                    await response.json().then(async (response) => {
                        if (response.d != null) {
                            console.log(response);
                            let disciplinesEmailList: any = [];
                            this.state.DisciplineReviewData.map(async (item: any, index: number) => {

                                if (item.DisciplineLead != undefined) {
                                    disciplinesEmailList.push(item.DisciplineLead.EMail);
                                    await DisciplineReviewCreate(this.props, item, this.state.Design_Change_Title, response.d.Id, response.d.DCNNumber)
                                }
                            });
debugger;
                             //await handleCreateDocumentSet(this.props, response.d,this.state.files);
                             //await handleCreateDocumentFolder(this.props, response.d,this.state.files);
                             //await createFolder(this.props,response.d,this.state.files);
                             await handleCreateFolder(this.props,response.d,this.state.files);
                             
                            //this.selectedFileUpload();
                            let BodyMsg = "New Design Change Request No : " + response.d.DCNNumber + "  is created Successfully. To Provide your Feedback";
                            let OrginaterEmailBodyMsg = "New Document Set is Created For DCN Number:" + response.d.DCNNumber + " To Edit an Item: ";
                            await sendMail(this.props, this.state.OriginatorEmail,disciplinesEmailList,this.props.reviewersLeadEmail, 'Request Feedback For : ' + response.d.DCNNumber, BodyMsg, response.d.Id, this.props.userDisplayName, null, null).then(async (res: any) => {
debugger;
                                if (res) {
                                    await sendMailToOrginater(this.props, this.state.OriginatorEmail, [this.state.OriginatorEmail], 'New Document Set is Created For : ' + response.d.DCNNumber, OrginaterEmailBodyMsg, response.d.DCNNumber, response.d.Id, this.props.userDisplayName, null, null).then((subRes: any) => {

                                        if (subRes) {
                                            swal({
                                                text: "New Request Submitted Successfully",
                                                icon: "success",
                                                dangerMode: false,
                                                closeOnClickOutside: false,
                                                closeOnEsc: false
                                            }).then(willok => {
                                                if (willok) {
                                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                                }
                                            })
                                        } else {
                                            swal({
                                                text: "New Request Submited Failed",
                                                icon: "error",
                                                dangerMode: false,
                                                closeOnClickOutside: false,
                                                closeOnEsc: false
                                            }).then(willok => {
                                                if (willok) {
                                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                                }
                                            })
                                        }

                                    });
                                }
                            })


                        } else {
                            swal({
                                text: "Submited Failed",
                                icon: "error",
                                dangerMode: false,
                                closeOnClickOutside: false,
                                closeOnEsc: false
                            }).then(willok => {
                                if (willok) {
                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                }
                            })
                        }
                    })
                }
            })

        }
    }

    public handleReOpen = async ()=>{
        debugger;
        if(this.validation()){
            await DCNListReOpen(this.props, this.state).then(async (res: any) => {
                if (res) {
                     // Discipline List Exgisting user Delete the Item
                     let exgistingDisciplineItem:any=[];
                    debugger;
                     exgistingDisciplineItem = await DisciplineReviewFetch(this.props);
                     let exgistingDiscipline = exgistingDisciplineItem.filter((e_item:any)=> e_item.Title == this.state.DCNNumber)
                 debugger;
                     const differenceDisciplineItem = _.differenceBy(exgistingDiscipline,this.state.DisciplineReviewData.filter((item:any)=>item.Id !== undefined), 'Id');                   
                     differenceDisciplineItem.length > 0 && differenceDisciplineItem.map(async(item:any)=>{
                        await DisciplineReviewDelete(this.props,item.Id)
                     });
                    // Discipline List if user add New Item
                    let disciplinesEmailList: any = [];     
                    this.state.DisciplineReviewData.map(async (item: any, index: number) => {
                        if (item.DisciplineLead != undefined) {
                            disciplinesEmailList.push(item.DisciplineLead.EMail);
                        }
                        if(item.SummaryReview == undefined && item.disciplinesReviewed == undefined ){
                            await DisciplineReviewCreate(this.props, item, this.state.Design_Change_Title, this.state.RequestFormId, this.state.DCNNumber);
                        }else{
                            await DisciplineReviewUpdate(this.props, item);
                        } 
                    });
    
                    let BodyMsg = "Request No : " + this.state.DCNNumber + " is Re-Open successfully. To Provide your Feedback";               
                   
                    await sendMail(this.props, this.state.OriginatorEmail,  disciplinesEmailList, this.props.reviewersLeadEmail, 'Request Feedback For : ' + this.state.DCNNumber, BodyMsg, this.state.RequestFormId, this.props.userDisplayName, null, null).then(async (subRes: any) => {
                        if (subRes) {
                            swal({
                                text: "Item Submitted Successfully",
                                icon: "success",
                                dangerMode: false,
                                closeOnClickOutside: false,
                                closeOnEsc: false
                            }).then(willok => {
                                if (willok) {
                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                }
                            })
                        } else {
                            swal({
                                text: "Re-Open Failed",
                                icon: "error",
                                dangerMode: false,
                                closeOnClickOutside: false,
                                closeOnEsc: false
                            }).then(willok => {
                                if (willok) {
                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                }
                            })
                        }
                    })
                }
            })
        }
      
    }

    // All Discipline given Feedback and checked Rewvied send mail to Approver
    public DisciplineReviewSubmit = async () => {
        if(this.DisciplineValidation()){
            let updateReviewItem: any = [];
            let AllDisciplineReviewed: any = [];
            AllDisciplineReviewed = this.state.DisciplineReviewData.filter((item: any) => item.disciplinesReviewed == false);
            if (this.state.isDCN_AdministratorMembers) {
                updateReviewItem = this.state.DisciplineReviewData;
            } else {
                updateReviewItem = this.state.DisciplineReviewData.filter((item: any) => item.DisciplineLead['EMail'] == this.props.userEmail);
    
            }
            updateReviewItem.map(async (item: any, index: number) => {
                await DisciplineReviewUpdate(this.props, item).then(async (res: any) => {
                    
                    if (index == (updateReviewItem.length - 1)) {
    
                        if (AllDisciplineReviewed.length == 0) {
                            await DCNListStatusUpdate(this.props, "Move to Approve", this.state.RequestFormId);
                            let OrginaterEmailBodyMsg = "Reviewed by All Discipline Leads. To Approve/Reject the DCN Item " + this.state.DCNNumber;
                            await sendMailToApprover(this.props, this.state.OriginatorEmail,  [this.state.DCNConfigList != null && this.state.DCNConfigList.ApproverName.EMail], 'Request Approval For : '+this.state.DCNNumber, OrginaterEmailBodyMsg, this.state.DCNNumber, this.state.RequestFormId, (this.state.DCNConfigList != null && this.state.DCNConfigList.ApproverName.Title), "AllApproved", null)
                        }
    
                        if (res) {
                            swal({
                                text: "Reviewed Successfully",
                                icon: "success",
                                dangerMode: false,
                                closeOnClickOutside: false,
                                closeOnEsc: false
                            }).then(willok => {
                                if (willok) {
                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                }
                            })
                        } else {
                            swal({
                                text: "Review Submited Failed",
                                icon: "error",
                                dangerMode: false,
                                closeOnClickOutside: false,
                                closeOnEsc: false
                            }).then(willok => {
                                if (willok) {
                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                }
                            })
                        }    
                    }
    
                });
    
            });

        }
    }
    public ApprovalUpdate = async () => {
        if(this.ApproveValidation()){
            await DCNListApprovalUpdate(this.props, this.state).then(async (res: any) => {
                if (res) {
                    let OrginaterEmailBodyMsg = "To CloseOut the Item.";
                    if (this.state.ApproveRejectStatus == "Approve") {
                        await sendMailToCloseOutMember(this.props, this.state.OriginatorEmail, [this.state.OriginatorEmail], 'Item is Approved For: ' + this.state.DCNNumber, OrginaterEmailBodyMsg, this.state.DCNNumber, this.state.RequestFormId, this.state.OriginatorName, this.state.ApproveRejectStatus, this.state.ApproverOrRejectComment).then((subRes: any) => {
                            if (subRes) {
                                swal({
                                    text: "Approved Successfully",
                                    icon: "success",
                                    dangerMode: false,
                                    closeOnClickOutside: false,
                                    closeOnEsc: false
                                }).then(willok => {
                                    if (willok) {
                                        window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                    }
                                })
                            } else {
                                swal({
                                    text: "Approved Submited Failed",
                                    icon: "error",
                                    dangerMode: false,
                                    closeOnClickOutside: false,
                                    closeOnEsc: false
                                }).then(willok => {
                                    if (willok) {
                                        window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                    }
                                })
                            }
                        })
                    } else {
                        await sendMailToOrginater(this.props, this.state.OriginatorEmail, [this.state.OriginatorEmail], 'Item is Rejected For: ' + this.state.DCNNumber, "To Open the Item.", this.state.DCNNumber, this.state.RequestFormId, this.state.OriginatorName, this.state.ApproveRejectStatus, this.state.ApproverOrRejectComment).then((subRes: any) => {
                            if (subRes) {
                                swal({
                                    text: "Rejected Successfully",
                                    icon: "success",
                                    dangerMode: false,
                                    closeOnClickOutside: false,
                                    closeOnEsc: false
                                }).then(willok => {
                                    if (willok) {
                                        window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                    }
                                })
                            } else {
                                swal({
                                    text: "Rejected Submited Failed",
                                    icon: "error",
                                    dangerMode: false,
                                    closeOnClickOutside: false,
                                    closeOnEsc: false
                                }).then(willok => {
                                    if (willok) {
                                        window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                    }
                                })
                            }
                        })
                    }
    
                }
            })
        }
    }
   
    public CloseOutUpdate = async () => {
        if(this.CloseValidation()){
        DCNListCloseOutUpdate(this.props, this.state).then(async (res: any) => {
            if (res) {
                let OrginaterEmailBodyMsg="";
                if(this.state.CloseOutReviewStatus === "CloseOut"){
                    OrginaterEmailBodyMsg = "Item is " + this.state.CloseOutReviewStatus + " successfully. To View the Item. ";
                }else{
                    OrginaterEmailBodyMsg = "Item is Re-" + this.state.CloseOutReviewStatus + " successfully. To Edit the Item. ";
                }
               
                await sendMailToOrginater(this.props, this.state.OriginatorEmail, [this.state.OriginatorEmail], ' Item Request No :  ' + this.state.DCNNumber, OrginaterEmailBodyMsg, this.state.DCNNumber, this.state.RequestFormId, this.props.userDisplayName, this.state.CloseOutReviewStatus, this.state.CloseOutReOpenComment).then((subRes: any) => {
                    if (subRes) {
                        swal({
                            text: (this.state.CloseOutReviewStatus === "CloseOut" ? this.state.CloseOutReviewStatus + " Successfully" : "Re-"+this.state.CloseOutReviewStatus + " Successfully"  ),
                            icon: "success",
                            dangerMode: false,
                            closeOnClickOutside: false,
                            closeOnEsc: false
                        }).then(willok => {
                            if (willok) {
                                window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                            }
                        })
                    } else {
                        swal({
                            text: this.state.CloseOutReviewStatus +" Failed",
                            icon: "error",
                            dangerMode: false,
                            closeOnClickOutside: false,
                            closeOnEsc: false
                        }).then(willok => {
                            if (willok) {
                                window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                            }
                        })
                    }
                })
            }
        })
    }
}

   

    public proceedOrRejectSubmit = async () => {

        if (this.validation()) {
            const postJosnData: string = JSON.stringify({
                __metadata: {
                    type: 'SP.Data.DCNListListItem'
                },
                //DCNNumber: this._generateSerialNumber(),
                DCNStatus: this.state.DCNFromStatus,
                DCNReasonsRejectComment: this.state.DCN_RejectComment,
                ApprovedDisciplineUser: this.props.userEmail
            });

            let url = this.props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/items";
            await this.props.spHttpClient.post(url, SPHttpClient.configurations.v1, {
                headers: {
                    'Accept': 'application/json;odata=nometadata',
                    'Content-type': 'application/json;odata=verbose',
                    'odata-version': '',
                    'IF-MATCH': '*',
                    'X-Http-Method': 'PATCH'
                },
                body: postJosnData
            }).then(async (response: SPHttpClientResponse) => {
                if (response.ok) {
                    await response.json().then((response) => {

                        if (response != null) {
                            console.log(response);
                            let BodyMsg = "";
                            let subject = "";
                            let RejectComment = null;
                            if (this.state.DCNFromStatus == 'Proceed') {
                                BodyMsg = "Approved for New Design Change Request";
                                subject = "Approved";
                                RejectComment = null

                            } else {
                                BodyMsg = "Rejected for New Design Change Request";
                                subject = "Rejected";
                                RejectComment = this.state.DCN_RejectComment;

                            }

                            sendMail(this.props, this.state.OriginatorEmail, this.state.disciplinesEmailList, null, subject, BodyMsg, response.Id, this.props.userDisplayName, this.state.DCNFromStatus, RejectComment)
                            swal({
                                text: "Successfully Submitted",
                                icon: "success",
                                dangerMode: false,
                                closeOnClickOutside: false,
                                closeOnEsc: false
                            }).then(willok => {
                                if (willok) {
                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                }
                            })
                            return response;
                        } else {
                            swal({
                                text: "Submited Failed",
                                icon: "error",
                                dangerMode: false,
                                closeOnClickOutside: false,
                                closeOnEsc: false
                            }).then(willok => {
                                if (willok) {
                                    window.open(this.props.webURL + '/Lists/DCNList/AllItems.aspx', '_self');
                                }
                            })
                            return response;
                        }
                    })
                }
            })

        }
    }

    public getEditFormInfo = async () => {

        let DiscriptionState: EditorState;
        let ProposedChange: EditorState;
        let url = this.props.webURL + "/_api/web/Lists/GetByTitle('DCN List')/items('" + this.state.formID + "')?$select=*,OriginatorUser/Title,OriginatorUser/EMail,OriginatorUser/ID&$expand=OriginatorUser";

        this.props.spHttpClient.get(url, SPHttpClient.configurations.v1)
            .then(async (response: SPHttpClientResponse) => {
                if (response.ok) {
                    await response.json().then((res) => {
                        if (res != null) {
                            //Get Rechtech box value here                        
                            let contentBlock: any = res.Description != null ? htmlToDraft(res.Description) : ''
                            let ProposedChangeBlock: any = res.ProposedChange != null ? htmlToDraft(res.ProposedChange) : '';
                            if (ProposedChangeBlock != "") {
                                const ProposedChangeState = ContentState.createFromBlockArray(ProposedChangeBlock.contentBlocks);
                                ProposedChange = EditorState.createWithContent(ProposedChangeState);
                            }
                            if (contentBlock != "") {
                                const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
                                DiscriptionState = EditorState.createWithContent(contentState);
                            }
                            this.setState({
                                RequestFormId: res.Id,
                                Design_Change_Title: res.Title,
                                DCNNumber: res.DCNNumber,
                                OriginatorEmail: res.OriginatorUser != undefined && res.OriginatorUser.EMail,
                                OriginatorName: res.OriginatorUser != undefined && res.OriginatorUser.Title,
                                Originating_Discipline: res.OriginatingDiscipline,
                                OriginatorDate: new Date(res.Date),
                                editorState: DiscriptionState,
                                editorProposedState: ProposedChange,
                                Discipline: res.Discipline,
                                ReasonforChange: res.ReasonforChange == null ? null : res.ReasonforChange,
                               
                                What_are_the_impacts: res.ImpactsDetails,
                                ImpactonDocuments: res.ImapactDocuments == undefined ? [] : res.ImapactDocuments,
                                OtherPotentiallyImpacted: res.AreasPotentiallyImpacted == null ? [] : res.AreasPotentiallyImpacted,
                                Re_Hazop_required: res.IsReHazopRequired,
                                Topsides_HAZOP_LOPA_report: res.TopsidesHAZOP_LOPAreport,
                                DCNStatus: res.DCNStatus,
                                AllDisciplineReviewed:res.AllDisciplineReviewed,
                                ApprovedDisciplineUser: res.ApprovedDisciplineUser,
                                ApproverOrRejectComment: res.ApproverRejectedComment,
                                ApproveOrRejectDate: res.ApprovedOrRejectedDate  == null ? new Date() : new Date(res.ApprovedOrRejectedDate),
                                ImplementationDate:res.ImplementationDate  == null ? new Date() : new Date(res.ImplementationDate),
                                ApproveRejectStatus: res.ApprovedDisciplineStatus,
                                CloseOutApprover: res.CloseOutApprover,
                                CloseOutReviewStatus: res.CloseOutReviewStatus,
                                CloseOutReviewDate: res.CloseOutReviewDate == null ? new Date() : new Date(res.CloseOutReviewDate),
                                CloseOutReOpenComment: res.CloseOutReOpenComment,
                                AccordionActiveKey: (res.DCNStatus == "Move to Proceed" ? '0' : res.DCNStatus == "Move to Approve" ? '1' : res.DCNStatus == "Move to CloseOut"?"2":res.DCNStatus == "Completed" && ["0","1","2"])
                            }, () => {
                                this.getUploadFile();
                                getDisciplineReviewedList(this.props).then((data: any) => {
                                    
                                    if (data.value != null) {
                                        let filterCurrentDCNItem: any = [];
                                        let ReviewedDate: any = [];
                                        filterCurrentDCNItem = data.value.filter((item: any) => item.Title == res.DCNNumber)
                                        if (filterCurrentDCNItem.length > 0) {
                                            filterCurrentDCNItem.map((item: any, index: number) => {
                                                let obj = {
                                                    Id: item.Id,
                                                    Title: item.DisciplineNameItem,
                                                    DisciplineLead: { EMail: item.DisciplineLead },
                                                    SummaryReview: item.FeedBack,
                                                    disciplinesReviewed: item.Reviewed
                                                }
                                                ReviewedDate.push(obj)
                                            })
                                            this.setState({ DisciplineReviewData: ReviewedDate });
                                        }
                                    }

                                })
                            })
                            console.log(res);

                        } else {
                            console.log('recoard failed');

                        }
                    });
                }
            });

    }

    public getUploadFile = async ()=>{
        debugger;
        try {
            // Replace with your library name
            const libraryUrl = encodeURIComponent(this.state.DCNNumber); // Change to your document library name
            const endpointUrl = `${this.props.webURL}/_api/web/GetFolderByServerRelativeUrl('DCNLibrary/${libraryUrl}')/Files?$select=Name,ServerRelativeUrl`;
    
            const response = await this.props.context.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1);
            
            if (response.ok) {
              const data = await response.json();
              this.setState({files:data.value});
            
            } else {
              const errorResponse = await response.json();
              console.log(`Error fetching files: ${errorResponse.error.message}`);
            }
          } catch (fetchError) {
            console.error('Error fetching files:', fetchError);
            
          }
        };
    


    //Discipline Master List
    public GetDisciplineListMasterData = async () => {

        await getDisciplineList(this.props).then((data: any) => {
            if (data.value != null) {
                let disciplinesEmailList: any = [];
                let disciplineReviewData: any = [];
                data.value.map((item: any, index: number) => {
                    if (item.DisciplineLead != undefined) {
                        disciplinesEmailList.push(item.DisciplineLead.EMail)
                    }
                    let obj = {
                        Id: item.Id,
                        DisciplineName: item.Title,
                        DisciplineLeadNameEmail: item.DisciplineLead != undefined ? item.DisciplineLead.EMail : ""
                    }
                    disciplineReviewData.push(obj);

                });

                this.setState({
                    DisciplineList: data.value,
                    DisciplinesEmailList: disciplinesEmailList,
                    DisciplineReviewData: disciplineReviewData
                })
                console.log(data);
            } else {
                console.log('recoard failed');
            }
        });

    }
    // private onGetErrorMessageProjectNumber(value: string): string {   
     
    //     let returnProNoMessage: string = '';
    //     if (value.length === 0) {
    //       this.setState({disableButton:true});
    //       returnProNoMessage = "Request Project Number is required";
    //     }else if(this.state.eventData.title && this.state.eventData.ProjectName && this.state.eventData.ProjectNumber && this.state.eventData.Category && this.state.eventData.Status){
    //       this.setState({disableButton:false});
    //     }    
    //     return returnProNoMessage;
    //   }




    public validation = () => {
debugger;
        let flag = true;
        if (this.state.Design_Change_Title === undefined || this.state.Design_Change_Title === "") {
            this.setState({ Design_Change_Title_Flag: true });
            flag = false;
        }
        if (this.state.OtherPotentiallyImpacted.length == 0) {
            this.setState({ OtherPotentiallyImpacted_Flag: true });
            flag = false;
        }
        if (this.state.ReasonforChange == null) {
            this.setState({ ReasonforChange_Flag: true });
            flag = false;
        }
        if (this.state.files.length == 0) {
            this.setState({ files_Flag: true });
            flag = false;
        }
      
        if (flag == true) {
            this.setState({ isloadRipple: true,isSaveBtnEnableFlag:1 });
        }
        return flag
    }

    //Discipline group member Validation
    public DisciplineValidation=()=>{
        debugger;
        let flag = true;
        let disciplineValidItem;
        let disItem:any=[];
        let disUpdated:any=[];
       
         disciplineValidItem = this.state.DisciplineReviewData.filter((item:any)=> (item.DisciplineLead.EMail === this.props.userEmail && item.SummaryReview !== "" && item.disciplinesReviewed == true));

         
              if(this.state.isDCN_AdministratorMembers){               
                 //this.disciplineGroupValidation(this.state.DisciplineReviewData);
                
                 this.state.DisciplineReviewData.length > 0 && this.state.DisciplineReviewData.map((obj:any)=> {
                     if((obj.SummaryReview ==null || obj.SummaryReview =='')  && obj.disciplinesReviewed == false){
                          disUpdated.push({...obj,disciplinesReviewedSummary_flag:true,disciplinesReviewed_flag:true });
                          flag = false;
                         }else if((obj.SummaryReview ==null ||obj.SummaryReview =='')){
                           disUpdated.push({...obj,disciplinesReviewedSummary_flag:true,disciplinesReviewed_flag:false });
                           flag = false;
                         }else if(obj.disciplinesReviewed == false){
                          disUpdated.push({...obj,disciplinesReviewedSummary_flag:false,disciplinesReviewed_flag:true });
                          flag = false;
                         }
                      }); 
                      this.setState({DisciplineReviewData:_.map(_.merge(_.keyBy(this.state.DisciplineReviewData,'Id'),_.keyBy(disUpdated,'Id')),obj=>obj)})
                     
              }
              else if(disciplineValidItem.length == 0){
                 disItem = this.state.DisciplineReviewData.filter((item:any)=> (item.DisciplineLead.EMail === this.props.userEmail));
                 disItem.length > 0 && disItem.map((obj:any)=> {
                    if((obj.SummaryReview ==null || obj.SummaryReview =='')  && obj.disciplinesReviewed == false){
                         disUpdated.push({...obj,disciplinesReviewedSummary_flag:true,disciplinesReviewed_flag:true });
                         flag = false;
                        }else if((obj.SummaryReview ==null ||obj.SummaryReview =='')){
                          disUpdated.push({...obj,disciplinesReviewedSummary_flag:true,disciplinesReviewed_flag:false });
                          flag = false;
                        }else if(obj.disciplinesReviewed == false){
                         disUpdated.push({...obj,disciplinesReviewedSummary_flag:false,disciplinesReviewed_flag:true });
                         flag = false;
                        }
                     });   
                     this.setState({DisciplineReviewData: _.map(_.merge(_.keyBy(this.state.DisciplineReviewData,'Id'),_.keyBy(disUpdated,'Id')),obj=>obj)})               
                 }

                 
                     
       
        if (flag == true) {
            this.setState({ isloadRipple: true,isSaveBtnEnableFlag:1 });
        }
        return flag
    }

    public disciplineGroupValidation=(groupItem:any)=>{
        let disUpdated:any=[];
        groupItem.length > 0 && groupItem.map((obj:any)=> {
            if((obj.SummaryReview ==null || obj.SummaryReview =='')  && obj.disciplinesReviewed == false){
                 disUpdated.push({...obj,disciplinesReviewedSummary_flag:true,disciplinesReviewed_flag:true })
                }else if((obj.SummaryReview ==null ||obj.SummaryReview =='')){
                  disUpdated.push({...obj,disciplinesReviewedSummary_flag:true,disciplinesReviewed_flag:false })
                }else if(obj.disciplinesReviewed == false){
                 disUpdated.push({...obj,disciplinesReviewedSummary_flag:false,disciplinesReviewed_flag:true })
                }
             }); 
             this.setState({DisciplineReviewData:_.merge(this.state.DisciplineReviewData,disUpdated)})
    } 

    public ApproveValidation=()=>{
        debugger;
        let flag = true;
        if (this.state.ApproveRejectStatus === null) {
            this.setState({ApproveRejectStatus_flag:true});                 
            flag = false;
        }
        if(this.state.ApproveRejectStatus === "Reject" && (this.state.ApproverOrRejectComment == "" || this.state.ApproverOrRejectComment == null)){
           this.setState({ApproverOrRejectComment_flag:true});            
            flag = false;
        }
        if (flag == true) {
            this.setState({ isloadRipple: true,isSaveBtnEnableFlag:1 });
        }

        return flag
    }

    public CloseValidation =()=>{
        debugger;
        let flag = true;
        if (this.state.CloseOutReviewStatus === null) { 
            this.setState({CloseOutReviewStatus_flag:true});              
            flag = false;
        }
        if(this.state.CloseOutReviewStatus === "Open" && (this.state.CloseOutReOpenComment == null || this.state.CloseOutReOpenComment=="")){
            this.setState({CloseOutReOpenComment_flag:true});
            flag = false;
        }
        if (flag == true) {
            this.setState({ isloadRipple: true,isSaveBtnEnableFlag:1 });
        }       
        return flag
    }




    public cancel = () => {
        let url = this.props.webURL + '/Lists/DCNList/AllItems.aspx'
        window.open(url, '_self');
    }
    public close = () => {
        let url = this.props.webURL + '/Lists/DCNList/AllItems.aspx'
        window.open(url, '_self');
    }
    public handleAccordionClick=(activekey:any)=>{
        this.setState({AccordionActiveKey:activekey })
    }


// private onGetErrorMessageTitle=(value: string)=> {    
//     debugger;
//     let returnMessage: string = '';
//     if (value.length === 0) {
//       this.setState({isSaveBtnEnableFlag:1});
//       returnMessage ="This Filed is Required";
//     } else{
//         this.setState({isSaveBtnEnableFlag:0});
//     }    
//     return returnMessage;
//   }


// public _onFileUpload=(
//     ev: React.ChangeEvent<HTMLInputElement>,
// ): void => {  
//     this.setState({file:ev.target.files,showLoader:true,showLoaderlevel:true}); 
// }

// public _DeleteUploadedDoc=(ev: React.ChangeEvent<HTMLInputElement>,): void => {
        
//     //this.updatedData['deletedFileName']=ev.target.parentElement.innerText;
//     //const fileUrl = ev.target.dataset.url;
//     //const filename = ev.target.parentElement.innerText;
// }

    public render(): React.ReactNode {
        debugger;
        const { OrgineterUserId } = this.state.OriginatorId;       
        console.log(this.props.userEmail);
        console.log(this.state.formType);
        return (
            
            <> 
                 {
                   this.state.isloadRipple ? <LoaderRipple /> :
                 <>
                    <Card className='rounded-0 mb-3'>
                        <CardBody>

                            <Card.Title>{OrgineterUserId} Design Change Request  {this.state.DCNNumber != undefined && <span className='float-end fs-6'>DCN No : {this.state.DCNNumber}</span>}</Card.Title>

                            <Form className='row border-bottom pb-3 mb-4'>
                                <Form.Group className="col-lg-4 mb-3">
                                    <TextField
                                        required
                                        name="Design_Change_Title"
                                        label={'Design Change Title'}
                                        value={this.state.Design_Change_Title}
                                        //onGetErrorMessage={this.onGetErrorMessageTitle}
                                        errorMessage={this.state.Design_Change_Title_Flag ? "This field are required." :''}
                                        deferredValidationTime={500}
                                        onChange={this.handleChange}
                                        disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}

                                    />
                                </Form.Group>
                                <Form.Group className="col-lg-4 mb-3">

                                    <PeoplePicker                                        
                                        context={this.props.context}
                                        titleText="Originator"
                                        personSelectionLimit={1}
                                        //defaultSelectedUsers={[this.props.userEmail]}
                                        //defaultSelectedUsers={this.state.formType == "NewForm" ? [this.props.userEmail] : [this.state.OriginatorEmail]}
                                        defaultSelectedUsers={this.state.formType == "NewForm" ? [this.props.userEmail] : [this.state.OriginatorEmail]}
                                        groupName={""} // Leave this blank in case you want to filter from all users 

                                        ensureUser={true}
                                        //required={true}
                                        onChange={this._GetOriginatorName}
                                        //selectedItems={this._GetOriginatorName}
                                        showHiddenInUI={false}
                                        principalTypes={[PrincipalType.User]}
                                        resolveDelay={1000}
                                        disabled={true}
                                        peoplePickerCntrlclassName={'OrignaterPicker'}

                                    />
                                </Form.Group>
                                <Form.Group className="col-lg-4 mb-3">
                                    <Dropdown
                                        title='Originating_Discipline'
                                        selectedKey={this.state.Originating_Discipline}  
                                        
                                        placeholder="Select an option"
                                        label="Originating Discipline"
                                        options={this.state.Originating_DisciplineOptions}
                                        onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => this.onDropdownChange(event, option)}
                                        disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open")  ? false : true))}
                                    />
                                </Form.Group>
                                <Form.Group className="col-lg-4 mb-3">
                                    <DatePicker
                                        placeholder="Select a date..."
                                        ariaLabel="Select a date"
                                        formatDate={this._onFormatDate}
                                        minDate={new Date()}
                                        value={this.state.OriginatorDate == null ? new Date() : this.state.OriginatorDate}
                                        label={'Date'}
                                        onSelectDate={this.onSelectDate}
                                        disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                    />
                                </Form.Group>
                                <Form.Group className="col-lg-4 mb-3" controlId="exampleForm.ControlTextarea1">
                                    <Dropdown
                                        title='Discipline'
                                        selectedKey={this.state.Discipline}
                                        placeholder="Select an option"
                                        label="Approver Discipline"
                                        options={this.state.DisciplineOptions}
                                        onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => this.onDropdownChange(event, option)}
                                        disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                    />
                                </Form.Group>


                                <Card.Title className='mt-2'>Reason for Change</Card.Title>
                                <Row>
                                    {/* <Form.Group className="col-lg-4 mb-3">
                                        <ComboBox
                                            placeholder='Select Reason for Change options'
                                            defaultValue={this.state.ReasonforChange}
                                            selectedKey={this.state.ReasonforChange}
                                            label="Reason for Change"                                            
                                            options={this.state.ReasonChangeOptions}
                                            onChange={(event: React.FormEvent<IComboBox>, item: IComboBoxOption) => this.multiSelectOptions("ReasonforChange", event, item)}
                                            disabled={this.state.formType == "ViewForm" ? true : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                            required
                                            errorMessage={this.state.ReasonforChange_Flag ? "This field are required." : ''}
                                        />
                                    </Form.Group> */}

                                <Form.Group className="col-lg-4 mb-3" controlId="changeReason.ControlTextarea1">
                                    <Dropdown
                                        title='ReasonforChange'
                                        selectedKey={this.state.ReasonforChange}
                                        placeholder="Select an option"
                                        label="Reason for Change"
                                        options={this.state.ReasonChangeOptions}
                                        onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => this.onDropdownChange(event, option)}
                                        disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                        required
                                        errorMessage={this.state.ReasonforChange_Flag ? "This field are required." : ''}
                                    />
                                </Form.Group>
                                </Row>

                                <Row>
                                    <Form.Group className="col-lg-6 mb-3">
                                        <Form.Label>Description</Form.Label>
                                        <Editor
                                            wrapperClassName="DescriptionEditer"
                                            editorClassName="DescriptionEditer-editor"
                                            editorState={this.state.editorState}
                                            onEditorStateChange={this.onEditorStateChange}
                                            readOnly={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                        />
                                    </Form.Group>
                                    <Form.Group className="col-lg-6 mb-3">
                                        <Form.Label>Proposed Change </Form.Label>
                                        <Editor editorState={this.state.editorProposedState} onEditorStateChange={this.onEditorProposedChange}
                                            readOnly={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))} />
                                    </Form.Group>

                                </Row>

                                <Card.Title >Impacts</Card.Title>
                                <Row>
                                    <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">

                                        <TextField
                                            multiline={true}
                                            name="What_are_the_impacts"
                                            label={'What are the impacts?'}
                                            value={this.state.What_are_the_impacts}
                                            //onGetErrorMessage={this.onGetErrorMessageTitle}
                                            errorMessage={this.state.isValidate && this.state.What_are_the_impacts == '' ? "This is a statically set error message" : ''}
                                            onChange={this.handleChange}
                                            disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                            description="(Originator gets input from the disciplines affected to determine impacts to cost, schedule, tradeoffs, etc.)"
                                        />
                                    </Form.Group>


                                </Row>
                                <Row>
                                    <Form.Group className="col-lg-4 mb-3">
                                        <ComboBox
                                            placeholder='Select Impact Documents'
                                            defaultValue={this.state.ImapactDocuments}
                                            selectedKey={this.state.ImapactDocuments}
                                            //defaultSelectedKey={this.state.ImapactDocuments}
                                            label="Impact on Documents"
                                            multiSelect
                                            options={this.state.impoactDocumentOptions}
                                            onChange={(event: React.FormEvent<IComboBox>, item: IComboBoxOption) => this.multiSelectOptions("ImapactDocuments", event, item)}
                                            disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                        />
                                    </Form.Group>
                                    <Form.Group className="col-lg-4 mb-3">
                                        <ComboBox

                                            placeholder='Discipline Review'
                                            defaultValue={this.state.OtherPotentiallyImpacted}
                                            selectedKey={this.state.OtherPotentiallyImpacted}
                                            //defaultSelectedKey={this.state.OtherPotentiallyImpacted}
                                            label="Discipline Review"
                                            multiSelect
                                            required
                                            //onGetErrorMessage={this.onGetErrorMessageProjectNumber}
                                            errorMessage={this.state.OtherPotentiallyImpacted_Flag ? "This field are required." : ''}
                                            options={this.state.OtherAreasPotentiallyImpactedOptions}
                                            onChange={(event: React.FormEvent<IComboBox>, item: IComboBoxOption) => this.multiSelectOptions("OtherPotentiallyImpacted", event, item)}
                                            disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false): (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                        />
                                    </Form.Group>
                                </Row>
                                <Row>
                                    <Col lg={12}>
                                        <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">

                                            <Form.Check // prettier-ignore
                                                name="Re_Hazop_required"
                                                type="switch"
                                                id="Re_Hazop_required_switch"
                                                label="Is a Re-Hazop required?"
                                                defaultChecked={this.state.Re_Hazop_required}
                                                onChange={this.handleSwitchChange}
                                                disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}
                                            />
                                            <Form.Label className='col-12 fs-7 fw-bolder form-label fc-light'>(If Yes - HAZOP will be required, it will be formally documented as part of the Topsides HAZOP/LOPA report.)</Form.Label>
                                            <Form.Label className='col-12 fs-7 fw-bolder form-label fc-light'><a href='https://eu001-sp.shell.com/sites/SPO000428/Shared%20Documents/Hazard%20Analysis%20Form.docx'download="https://eu001-sp.shell.com/sites/SPO000428/Shared%20Documents/Hazard%20Analysis%20Form.docx">Download HAZOP Document</a></Form.Label>
                                            {/* File upload Section */}   
                                            {/* {this.state.DCNNumber && <Form.Label className='col-12 fs-7 fw-bolder form-label fc-light'><a href={this.props.webURL + "/DCNLibrary/" + this.state.DCNNumber} target='_blank' data-interception="off" >Upload Your Documents here..</a></Form.Label>} */}
                                            <Col xs={6} sm={6} md={6} lg={6} >
                                                {(this.state.formType == "NewForm" || (this.state.formType == "EditForm" && this.state.files.length == 0 )) &&
                                                    <>
                                                        <Label>Upload Documents <span className='required'>*</span></Label>
                                                        <FilePond                                                           
                                                            files={this.state.files} allowMultiple={true} maxFiles={10} onupdatefiles={fileItems => {
                                                                this.setState({
                                                                    files: fileItems.map(fileItem => fileItem.file)
                                                                });
                                                            }} />
                                                           {this.state.files_Flag && <><span className='required'>This field are required.</span></> }
                                                    </>
                                                }
                                                {(this.state.formType == "ViewForm" || this.state.formType == "EditForm") && <Label>Files in Document Library</Label>}
                                                {(this.state.formType == "ViewForm" || this.state.formType == "EditForm") && this.state.files.length > 0 && (
                                                    <ul>
                                                        {this.state.files.map((file: any) => (
                                                            <li key={file.ServerRelativeUrl}>
                                                                <a href={file.ServerRelativeUrl} download={file.ServerRelativeUrl} target="_blank" rel="noopener noreferrer">
                                                                    {file.Name}
                                                                </a>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                ) }
                                            </Col>
                                        </Form.Group>
                                        {this.state.Re_Hazop_required &&
                                            <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">
                                                <TextField
                                                    multiline={true}
                                                    name="Topsides_HAZOP_LOPA_report"
                                                    label={'Topsides HAZOP/LOPA report'}
                                                    value={this.state.Topsides_HAZOP_LOPA_report}
                                                    onChange={this.handleChange}
                                                    disabled={this.state.formType == "ViewForm" ? true : this.state.isDCN_AdministratorMembers ? (this.state.DCNStatus == "Completed" ? true : false) : (((this.state.DCNStatus == "" || this.state.DCNStatus == "Move to Re-Open") ? false : true))}

                                                />
                                            </Form.Group>}
                                    </Col>

                                          
                                </Row>
                            </Form>
                        </CardBody>
                    </Card>


                    <Form>
                        {this.state.formType != "NewForm" && this.state.DCNStatus !=="Move to Re-Open" &&
                        <Accordion activeKey={ this.state.AccordionActiveKey}>
                            <Accordion.Item eventKey="0">
                                <Accordion.Header onClick={()=>this.handleAccordionClick("0")}>Discipline</Accordion.Header>
                                <Accordion.Body>
                                    <Row>
                                        <Col lg={12}>
                                            {/* <h5 className='Cardcard-title h5'>Discipline</h5> */}
                                            {this.state.DisciplineReviewData.length > 0 && this.state.DisciplineReviewData.map((item: any, index: number) => {
                                                return (
                                                    <>
                                                        <Card className='rounded-0 mb-3'>
                                                            <CardBody>
                                                                <Row>
                                                                    <Form.Group className="col-lg-6 mb-3">
                                                                        <TextField
                                                                            name="DisciplineName"
                                                                            label={'Discipline Name'}
                                                                            value={item.Title}
                                                                            //disabled={true}
                                                                            disabled={this.state.formType == "ViewForm" ? true :
                                                                                (this.state.isDCN_AdministratorMembers == true ? (this.state.DCNStatus == "Completed" ? true : this.state.AllDisciplineReviewed == true ? true : false ) :                                                                            
                                                                                 (this.state.AllDisciplineReviewed == false ? (this.state.DCNStatus == 'Move to Proceed' && (this.props.userEmail == (item.DisciplineLead != undefined && item.DisciplineLead.EMail) ? false : true)) : true))}
   
                                                                        />
                                                                    </Form.Group>
                                                                    <Form.Group className="col-lg-6 mb-3">
                                                                    <PeoplePicker
                                                                            context={this.props.context}
                                                                            titleText="Discipline Lead"
                                                                            personSelectionLimit={1}
                                                                            defaultSelectedUsers={(item.DisciplineLead !== undefined ? [item.DisciplineLead.EMail] : [])}
                                                                            groupName={""} // Leave this blank in case you want to filter from all users 
                                                                            ensureUser={true}
                                                                            //isRequired={false}
                                                                            //selectedItems={this._getPeoplePickerFocalName(index)}
                                                                            onChange={this._getPeoplePickerFocalName(index)}
                                                                            showHiddenInUI={false}
                                                                            principalTypes={[PrincipalType.User]}
                                                                            resolveDelay={1000}
                                                                            //disabled={true}
                                                                            disabled={this.state.formType == "ViewForm" ? true :
                                                                                (this.state.isDCN_AdministratorMembers == true ? (this.state.DCNStatus == "Completed" ? true : this.state.AllDisciplineReviewed == true ? true : false ) :                                                                            
                                                                                 (this.state.AllDisciplineReviewed == false ? (this.state.DCNStatus == 'Move to Proceed' && (this.props.userEmail == (item.DisciplineLead != undefined && item.DisciplineLead.EMail) ? false : true)) : true))}
   

                                                                        />
                                                                    </Form.Group>
                                                                    <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">

                                                                        <TextField
                                                                            multiline={true}
                                                                            name="SummaryReview"
                                                                            label={'Summary of review/feedback by affected disciplines'}
                                                                            value={item.SummaryReview}
                                                                            //onGetErrorMessage={this.onGetErrorMessageTitle}
                                                                            required
                                                                            errorMessage={item.disciplinesReviewedSummary_flag == true ? "This field are required." : ''}
                                                                            onChange={this._handleReviewNameChange(index)}
                                                                            disabled={this.state.formType == "ViewForm" ? true :
                                                                             (this.state.isDCN_AdministratorMembers == true ? (this.state.DCNStatus == "Completed" ? true : this.state.AllDisciplineReviewed == true ? true : false ) :                                                                            
                                                                              (this.state.AllDisciplineReviewed == false ? (this.state.DCNStatus == 'Move to Proceed' && (this.props.userEmail == (item.DisciplineLead != undefined && item.DisciplineLead.EMail) ? false : true)) : true))}

                                                                        />
                                                                        <Form.Check className='mt-3' // prettier-ignore
                                                                            name="disciplinesReviewed"
                                                                            type="switch"
                                                                            id={"custom-switch_" + index}
                                                                            label="Yes (Reviewed)"
                                                                            defaultChecked={item.disciplinesReviewed}
                                                                            onChange={this._onReviewSwitchChange(index)}
                                                                            required
                                                                            isInvalid={item.disciplinesReviewed_flag ? true : false }                                                                            
                                                                            disabled={this.state.formType == "ViewForm" ? true :
                                                                            (this.state.isDCN_AdministratorMembers == true ? (this.state.DCNStatus == "Completed" ? true : this.state.AllDisciplineReviewed == true ? true : false ) :                                                                            
                                                                             (this.state.AllDisciplineReviewed == false ? (this.state.DCNStatus == 'Move to Proceed' && (this.props.userEmail == (item.DisciplineLead != undefined && item.DisciplineLead.EMail) ? false : true)) : true))}
                                                                        />

                                                                        {/* <Toggle                                                                             
                                                                            label="With inline label and without onText and offText"
                                                                            inlineLabel 
                                                                            onChange={this._onReviewSwitchChange(index)} 
                                                                            disabled={(this.state.AllDisciplineReviewed == false ? (this.state.DCNStatus == 'Move to Proceed' && (this.props.userEmail == (item.DisciplineLead != undefined && item.DisciplineLead.EMail)) ? false : true) : true)}/> */}
                                                                    </Form.Group>

                                                                </Row>

                                                            </CardBody>
                                                        </Card>
                                                    </>

                                                )
                                            })}

                                        </Col>

                                    </Row>

                                </Accordion.Body>
                            </Accordion.Item>
                            
                        { 
                        (this.state.formType == "ViewForm" || this.state.DCNStatus == "Completed" ?  
                            
                            <Accordion.Item eventKey="1">
                            <Accordion.Header onClick={()=>this.handleAccordionClick("1")}>Approval</Accordion.Header>
                            <Accordion.Body>
                                <Row>
                                    <Col lg={12}>

                                        <Card className='rounded-0 mb-3'>
                                            <CardBody>
                                                <Row>
                                                    <Form.Group className="col-lg-6 mb-3">
                                                        <PeoplePicker
                                                            context={this.props.context}
                                                            titleText="Approver Name"
                                                            personSelectionLimit={1}
                                                            
                                                            defaultSelectedUsers={(this.state.DCNStatus =="Completed" ? [this.state.ApprovedDisciplineUser]:[this.state.DCNConfigList.ApproverName.EMail])}
                                                            groupName={""} // Leave this blank in case you want to filter from all users 

                                                            ensureUser={true}
                                                            //isRequired={true}
                                                            //selectedItems={this._getPeoplePickerFocalName}
                                                            required={true}
                                                            onChange={this._getPeoplePickerFocalName}
                                                            showHiddenInUI={false}
                                                            principalTypes={[PrincipalType.User]}
                                                            resolveDelay={1000}
                                                            disabled={true}
                                                        />

                                                    </Form.Group>
                                                    <Form.Group className="col-lg-6 mb-3">
                                                        <Dropdown
                                                            required
                                                            title='ApproveRejectStatus'
                                                            selectedKey={this.state.ApproveRejectStatus}
                                                            placeholder="Select an option"
                                                            label="Approve / Reject Status"
                                                            options={this.state.ApprovalRejectOptions}
                                                            onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => this.onDropdownChange(event, option)}
                                                            
                                                            disabled={true}
                                                        />
                                                    </Form.Group>

                                                    {this.state.ApproveRejectStatus == 'Reject' &&
                                                        <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">
                                                            <TextField
                                                                required
                                                                multiline={true}
                                                                name="ApproverOrRejectComment"
                                                                label={'Reject Comment'}
                                                                value={this.state.ApproverOrRejectComment}                                                                
                                                                onChange={this.handleChange}                                                            
                                                                disabled={true}
                                                            />
                                                        </Form.Group>
                                                    }
                                                    <Form.Group className="col-lg-6 mb-3">
                                                        <DatePicker
                                                            placeholder="Select a date..."
                                                            ariaLabel="Select a date"
                                                            formatDate={this._onFormatDate}
                                                            minDate={new Date()}
                                                            value={this.state.ApproveOrRejectDate == null ? new Date() : new Date(this.state.ApproveOrRejectDate)}
                                                            label={'Approver/Reject Date'}
                                                            onSelectDate={this.onSelectApproveDate}
                                                            disabled={true}
                                                        />
                                                    </Form.Group>

                                                    <Form.Group className="col-lg-6 mb-3">
                                                        <DatePicker
                                                            placeholder="Select a date..."
                                                            ariaLabel="Select a date"
                                                            formatDate={this._onFormatDate}
                                                            minDate={new Date()}
                                                            value={this.state.ImplementationDate == null ? new Date() : new Date(this.state.ImplementationDate)}
                                                            label={'Implementation Date'}
                                                            onSelectDate={this.onSelectImplementationDate}
                                                            disabled={true}
                                                        />
                                                    </Form.Group>

                                                </Row>

                                            </CardBody>
                                        </Card>


                                    </Col>
                                </Row>
                            </Accordion.Body>
                            </Accordion.Item> 
                        
                        :                        
                        (((this.state.isDCN_AdministratorMembers == true && this.state.AllDisciplineReviewed == true || this.state.DCNConfigList.ApproverName.EMail == this.props.userEmail && this.state.AllDisciplineReviewed == true)) || ((this.state.DCNConfigList.ApproverName.EMail == this.props.userEmail && this.state.AllDisciplineReviewed == true )  ||  (this.state.DCNStatus == "Move to Reject" || (this.state.DCNStatus == "Move to CloseOut"))))&& 
                        
                        <Accordion.Item eventKey="1">
                                <Accordion.Header onClick={()=>this.handleAccordionClick("1")}>Approval</Accordion.Header>
                                <Accordion.Body>
                                    <Row>
                                        <Col lg={12}>

                                            <Card className='rounded-0 mb-3'>
                                                <CardBody>
                                                    <Row>
                                                        <Form.Group className="col-lg-6 mb-3">
                                                            <PeoplePicker
                                                                context={this.props.context}
                                                                titleText="Approver Name"
                                                                personSelectionLimit={1}
                                                                defaultSelectedUsers={(((this.state.DCNStatus == "Move to CloseOut" ) && this.state.ApproveRejectStatus) ? [this.state.ApprovedDisciplineUser] : [this.state.DCNConfigList.ApproverName.EMail])}
                                                                groupName={""} // Leave this blank in case you want to filter from all users 

                                                                ensureUser={true}
                                                                //isRequired={true}
                                                                //selectedItems={this._getPeoplePickerFocalName}
                                                                required={true}
                                                                onChange={this._getPeoplePickerFocalName}
                                                                showHiddenInUI={false}
                                                                principalTypes={[PrincipalType.User]}
                                                                resolveDelay={1000}
                                                                disabled={true}
                                                            />

                                                        </Form.Group>
                                                        <Form.Group className="col-lg-6 mb-3">
                                                            <Dropdown
                                                                required
                                                                title='ApproveRejectStatus'
                                                                selectedKey={this.state.ApproveRejectStatus}
                                                                placeholder="Select an option"
                                                                label="Approve / Reject Status"
                                                                options={this.state.ApprovalRejectOptions}
                                                                errorMessage={this.state.ApproveRejectStatus == null ? (this.state.ApproveRejectStatus_flag == true) ? "This field are required" : '' : ""}
                                                                onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => this.onDropdownChange(event, option)}
                                                                disabled={(this.state.DCNStatus == 'Move to CloseOut' || this.state.DCNStatus == 'Completed' || this.state.DCNStatus == "Move to Reject") ? true : false}
                                                            />
                                                        </Form.Group>

                                                        {this.state.ApproveRejectStatus == 'Reject' &&
                                                            <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">
                                                                <TextField
                                                                    required
                                                                    multiline={true}
                                                                    name="ApproverOrRejectComment"
                                                                    label={'Reject Comment'}
                                                                    value={this.state.ApproverOrRejectComment}
                                                                    errorMessage={(this.state.ApproverOrRejectComment == null || this.state.ApproverOrRejectComment == '') ? (this.state.ApproverOrRejectComment_flag ? "This field are required" : ''):""}
                                                                    onChange={this.handleChange}
                                                                    disabled={(this.state.DCNStatus == 'Move to CloseOut' || this.state.DCNStatus == "Move to Reject") ? true : false}
                                                                />
                                                            </Form.Group>
                                                        }
                                                        <Form.Group className="col-lg-6 mb-3">
                                                            <DatePicker
                                                                placeholder="Select a date..."
                                                                ariaLabel="Select a date"
                                                                formatDate={this._onFormatDate}
                                                                minDate={new Date()}
                                                                value={this.state.ApproveOrRejectDate == null ? new Date() : this.state.ApproveOrRejectDate}
                                                                label={'Approver/Reject Date'}
                                                                onSelectDate={this.onSelectApproveDate}                                                               
                                                                disabled={(this.state.DCNStatus == 'Move to CloseOut' || this.state.DCNStatus == "Move to Reject") ? true : false}
                                                            />
                                                        </Form.Group>

                                                        <Form.Group className="col-lg-6 mb-3">
                                                        <DatePicker
                                                            placeholder="Select a date..."
                                                            ariaLabel="Select a date"
                                                            formatDate={this._onFormatDate}
                                                            minDate={new Date()}
                                                            value={this.state.ImplementationDate == null ? new Date() : new Date(this.state.ImplementationDate)}
                                                            label={'Implementation Date'}
                                                            onSelectDate={this.onSelectImplementationDate}
                                                            disabled={(this.state.DCNStatus == 'Move to CloseOut' || this.state.DCNStatus == "Move to Reject") ? true : false}
                                                        />
                                                    </Form.Group>
                                                    <Form.Group className="col-lg-6 mb-3">

                                                    </Form.Group>
                                                    </Row>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>
                                </Accordion.Body>
                            </Accordion.Item> 
                        )
                        }

                        {(this.state.formType=="ViewForm" || this.state.DCNStatus == "Completed"  ? 
                        <Accordion.Item eventKey="2" onClick={()=>this.handleAccordionClick("2")}>
                        <Accordion.Header>Close-Out</Accordion.Header>
                        <Accordion.Body>
                            <Row>
                                <Col lg={12}>
                                    <Card className='rounded-0 mb-3'>
                                        <CardBody>
                                            <Row>
                                                <Form.Group className="col-lg-6 mb-3">
                                                    <PeoplePicker
                                                        context={this.props.context}
                                                        titleText="CloseOutMember Name"
                                                        personSelectionLimit={1}
                                                        defaultSelectedUsers={((this.state.DCNStatus == "Completed") ? [this.state.CloseOutApprover] : [this.state.OriginatorEmail])}
                                                        groupName={""} // Leave this blank in case you want to filter from all users 

                                                        ensureUser={true}
                                                        //isRequired={true}
                                                        //selectedItems={this._getPeoplePickerFocalName}
                                                        required={true}
                                                        onChange={this._getPeoplePickerFocalName}
                                                        showHiddenInUI={false}
                                                        principalTypes={[PrincipalType.User]}
                                                        resolveDelay={1000}
                                                        disabled={true}
                                                    />

                                                </Form.Group>
                                                <Form.Group className="col-lg-6 mb-3">
                                                    <Dropdown
                                                        title='CloseOutReviewStatus'
                                                        selectedKey={this.state.CloseOutReviewStatus}
                                                        placeholder="Select an option"
                                                        label="Open/CloseOut Status"
                                                        options={this.state.OpenCloseOutOptions}
                                                        onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => this.onDropdownChange(event, option)}
                                                        disabled={true}
                                                    />
                                                </Form.Group>
                                                {this.state.CloseOutReviewStatus == 'Open' && <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">
                                                    <TextField
                                                        multiline={true}
                                                        name="CloseOutReOpenComment"
                                                        label={'Close Out Re-open Comment'}
                                                        value={this.state.CloseOutReOpenComment}                                                        
                                                        onChange={this.handleChange}
                                                        disabled={true}                                                       
                                                    />
                                                </Form.Group>
                                                }
                                                <Form.Group className="col-lg-6 mb-3">
                                                    <DatePicker
                                                        placeholder="Select a date..."
                                                        ariaLabel="Select a date"
                                                        formatDate={this._onFormatDate}
                                                        minDate={new Date()}
                                                        value={this.state.CloseOutReviewDate == null ? new Date() : this.state.CloseOutReviewDate}
                                                        label={'Open/CloseOut Date'}
                                                        onSelectDate={this.onSelectCloseOutDate}
                                                        disabled={true}                                                        
                                                    />
                                                </Form.Group>
                                            </Row>
                                        </CardBody>
                                    </Card>
                                </Col>
                            </Row>
                        </Accordion.Body>
                            </Accordion.Item>
                        
                        : (this.state.ApproveRejectStatus == "Approve" || this.state.ApproveRejectStatus == "Reject")  && (this.state.DCNStatus == "Move to CloseOut" || this.state.DCNStatus == "Move to Reject") && (this.state.isDCN_AdministratorMembers== true ? true : (this.state.OriginatorEmail === this.props.userEmail)) &&
                            <Accordion.Item eventKey="2" onClick={()=>this.handleAccordionClick("2")}>
                                <Accordion.Header>Close-Out</Accordion.Header>
                                <Accordion.Body>
                                    <Row>
                                        <Col lg={12}>
                                            <Card className='rounded-0 mb-3'>
                                                <CardBody>
                                                    <Row>
                                                        <Form.Group className="col-lg-6 mb-3">
                                                            <PeoplePicker
                                                                context={this.props.context}
                                                                titleText="CloseOutMember Name"
                                                                personSelectionLimit={1}                                                                
                                                                defaultSelectedUsers={((this.state.DCNStatus == "Completed") ? [this.state.CloseOutApprover] : [this.state.OriginatorEmail])}
                                                                groupName={""} // Leave this blank in case you want to filter from all users 
                                                                ensureUser={true}
                                                                //isRequired={true}
                                                                //selectedItems={this._getPeoplePickerFocalName}
                                                                required={true}
                                                                onChange={this._getPeoplePickerFocalName}
                                                                showHiddenInUI={false}
                                                                principalTypes={[PrincipalType.User]}
                                                                resolveDelay={1000}
                                                                disabled={true}
                                                            />

                                                        </Form.Group>
                                                        <Form.Group className="col-lg-6 mb-3">
                                                            <Dropdown
                                                                title='CloseOutReviewStatus'
                                                                selectedKey={this.state.CloseOutReviewStatus}
                                                                placeholder="Select an option"
                                                                label="Open/CloseOut Status"
                                                                errorMessage={this.state.CloseOutReviewStatus == null ? (this.state.CloseOutReviewStatus_flag == true) ? "This field are required" : '' : ""}
                                                                options={this.state.ApproveRejectStatus =="Approve" ? this.state.OpenCloseOutApprovedOptions : this.state.OpenCloseOutOptions}
                                                                onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => this.onDropdownChange(event, option)}                                                               
                                                                disabled={(this.state.DCNStatus == 'Completed') ? true : false}
                                                            />
                                                        </Form.Group>
                                                        {this.state.CloseOutReviewStatus == 'Open' && <Form.Group className="col-lg-12 mb-3" controlId="exampleForm.ControlInput1">
                                                            <TextField
                                                                multiline={true}
                                                                name="CloseOutReOpenComment"
                                                                label={'Close Out Re-open Comment'}
                                                                value={this.state.CloseOutReOpenComment}
                                                                errorMessage={(this.state.CloseOutReOpenComment == null||this.state.CloseOutReOpenComment == '') ? (this.state.CloseOutReOpenComment_flag ? "This field are required" : '') :""}
                                                                onChange={this.handleChange}
                                                                disabled={(this.state.DCNStatus == 'Completed') ? true : false}                                                       
                                                            />
                                                        </Form.Group>
                                                        }
                                                        <Form.Group className="col-lg-6 mb-3">
                                                            <DatePicker
                                                                placeholder="Select a date..."
                                                                ariaLabel="Select a date"
                                                                formatDate={this._onFormatDate}
                                                                minDate={new Date()}
                                                                value={this.state.CloseOutReviewDate == null ? new Date() :this.state.CloseOutReviewDate}
                                                                label={'Open/CloseOut Date'}
                                                                onSelectDate={this.onSelectCloseOutDate}
                                                                disabled={(this.state.DCNStatus == 'Completed') ? true : false}                                                        
                                                            />
                                                        </Form.Group>
                                                        {this.state.ApproveRejectStatus =="Approve" && <Form.Label className='col-12 fs-7 fw-bolder form-label fc-light'><a href={this.props.webURL + "/DCNLibrary/" + this.state.DCNNumber} target='_blank' data-interception="off" >Upload Your Documents here..</a></Form.Label>}
                                                    </Row>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>
                                </Accordion.Body>
                            </Accordion.Item>
                        )}

                        </Accordion>
                        }
                        <Row className='mt-4'>
                            <Col lg={6} className='ms-auto text-end'>
                                {this.state.formType !="ViewForm" && (this.state.formType == "NewForm") && <Button variant="primary rounded-0" className="my-2 me-2" onClick={this.handleSubmit} disabled={this.state.isSaveBtnEnableFlag == 1 ? true : false}>Submit</Button>}
                                {this.state.formType !="ViewForm" && (this.state.formType != "NewForm" && this.state.DCNStatus == "Move to Re-Open") && <Button variant="primary rounded-0" className="my-2 me-2" onClick={this.handleReOpen} disabled={this.state.isSaveBtnEnableFlag == 1 ? true : false}>Submit</Button>}
                                {this.state.formType !="ViewForm" && this.state.DCNStatus == "Move to Proceed" && (this.state.isDCN_AdministratorMembers== true ? (this.state.AllDisciplineReviewed == true ? false : true ) : (this.state.DisciplineReviewData.filter((item:any) => item.DisciplineLead.EMail == this.props.userEmail).length > 0)) && <Button variant="primary rounded-0" className="my-2 me-2" onClick={this.DisciplineReviewSubmit} disabled={this.state.isSubmit}>Submit</Button>}
                                {this.state.formType !="ViewForm" && this.state.DCNStatus == "Move to Approve" && this.state.AllDisciplineReviewed == true && (this.state.isDCN_AdministratorMembers== true ? true : (this.state.DCNConfigList.ApproverName.EMail || this.state.ApprovedDisciplineUser) == this.props.userEmail) && <Button variant="primary rounded-0" className="my-2 me-2" onClick={this.ApprovalUpdate} disabled={this.state.isSubmit}>Submit</Button>}
                                {this.state.formType !="ViewForm" && (this.state.DCNStatus == "Move to CloseOut" || this.state.DCNStatus == "Move to Reject") && (this.state.ApproveRejectStatus == "Approve" || this.state.ApproveRejectStatus == "Reject")  &&  (this.state.isDCN_AdministratorMembers== true ? true : (this.state.OriginatorEmail || this.state.CloseOutApprover) == this.props.userEmail) && <Button variant="primary rounded-0" className="my-2 me-2" onClick={this.CloseOutUpdate} disabled={this.state.isSubmit}>Submit</Button>}
                               
                                {this.state.formType !="ViewForm" && this.state.DCNStatus != "Completed" && <Button onClick={() => this.cancel()} variant="primary rounded-0">Cancel</Button>}
                                {(this.state.formType == "ViewForm" || this.state.DCNStatus == "Completed") && <Button variant="primary rounded-0" className="my-2 me-2" onClick={this.close}>Close</Button>}
                            </Col>
                        </Row>
                    </Form>
                </>

                }

            </>

        )
    }
}
