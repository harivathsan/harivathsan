/* tslint:disable */
require("./sections.module.css");
const styles = {

};

export default styles;
/* tslint:enable */