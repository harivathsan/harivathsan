import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneToggle
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'SpartaBannerWebPartStrings';
import SpartaBanner from './components/SpartaBanner';
import { ISpartaBannerProps } from './components/ISpartaBannerProps';

export interface ISpartaBannerWebPartProps {
  description: string;
  css: string;
  listName: string;
  banner: string;
  bannerToggle: any;
}

export default class SpartaBannerWebPart extends BaseClientSideWebPart<ISpartaBannerWebPartProps> {

  public render(): void {
    debugger;
    const element: React.ReactElement<ISpartaBannerProps> = React.createElement(
      SpartaBanner,
      {
        description: this.properties.description,
        css: this.properties.css,
        context: this.context,
        listName: this.properties.listName,
        banner: this.properties.banner,
        bannerToggle: this.properties.bannerToggle
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('listName', {
                  label: 'List Name'
                }),
                PropertyPaneTextField('css', {
                  label: '~ Css Path'
                }),
                PropertyPaneTextField('banner', {
                  label: 'Banner'
                }),
                PropertyPaneToggle('bannerToggle', {
                  label: 'Show Banner'
                }),
              ]
            }
          ]
        }
      ]
    };
  }
}


