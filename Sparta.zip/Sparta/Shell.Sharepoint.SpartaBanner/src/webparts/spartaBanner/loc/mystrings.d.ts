declare interface ISpartaBannerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpartaBannerWebPartStrings' {
  const strings: ISpartaBannerWebPartStrings;
  export = strings;
}
