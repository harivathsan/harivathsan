import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface ISpartaBannerProps {
  description: string;
  css: string;
  context: WebPartContext;
  listName: string;
  banner: string;
  bannerToggle: any;
}
