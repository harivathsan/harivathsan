import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import styles from './SpartaBanner.module.scss';
import {
    Container,
    Row,
    Col,
} from "reactstrap";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IListItem } from '../IListItem';

export interface IBannerProps {
    listName: string;
    context: any;
}

export interface IBannerState {
    logURL: string;
    Description: string;
}

class Banner extends React.Component<IBannerProps, IBannerState> {

    //Global Variables
    public readonly state: IBannerState;

    //constructor
    constructor(props: IBannerProps) {
        super(props);

        this.state = {
            logURL: '',
            Description: ''
        };
    }

    //******** Begin Methods********//

    //Begin GetListData
    private async GetListData() {
        try {
            let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.props.listName + "')/Items?$select=Title,Description&$top=1";
            let response = await this.props.context.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1,
                {
                    headers: {
                        'Accept': 'application/json;odata=nometadata',
                        'Content-type': 'application/json;odata=nometadata',
                        'odata-version': ''
                    }
                    //body: body
                })
                .then((responseValues: SPHttpClientResponse): Promise<IListItem> => {
                    return responseValues.json();
                })
                .then((item: IListItem): void => {
                    console.log("Get Items successfully !!!");

                    this.setState({
                        logURL: item['value'][0].Title,
                        Description: item['value'][0].Description

                    });

                }, (error: any): void => {
                    alert("Error in Get Items !!!");
                });
        }
        catch (error) {
            console.log("Error in Get Items Data : " + error);
        }
    }
    //End GetListData

    //******** End Methods********//

    //******** Begin Hanlder********//


    //Begin componentDidMount
    public componentDidMount() {
        //Method to load pop up content dynamically from Banner Info        
        this.GetListData();
    }
    //End componentDidMount


    //Begin Render
    public render() {
        const { logURL, Description } = this.state;
        return (
            <div>
                <Container>
                    <Row>

                        <Col md={2}>
                            <img src={logURL} className={styles.spartaImg} />
                        </Col>
                        <Col md={10}>
                            <p>
                                <div dangerouslySetInnerHTML={{ __html: Description }}></div>
                            </p>
                        </Col>


                    </Row>
                </Container>
            </div>
        );
    }
    //End Render

    //******** End Hanlder********//

}

export default Banner;