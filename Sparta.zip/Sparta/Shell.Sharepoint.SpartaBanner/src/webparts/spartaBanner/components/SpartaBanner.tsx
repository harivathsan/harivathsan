/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Sparta
Project Handled By                 : AI&DS
Module Name						             : Sparta Banner Info
Module Description                 : Display Sparta logo and description.
Author                             : Firdous Ali K.A
Created Date                       : 18th November 2022
Modified Date                      : 18th November 2022
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/
import * as React from 'react';
import styles from './SpartaBanner.module.scss';
import { ISpartaBannerProps } from './ISpartaBannerProps';
import { escape } from '@microsoft/sp-lodash-subset';
import Banner from './Banner';
import { SPComponentLoader } from '@microsoft/sp-loader';

export default class SpartaBanner extends React.Component<ISpartaBannerProps, {}> {

  constructor(props: ISpartaBannerProps) {
    super(props);
    let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
  }

  public render(): React.ReactElement<ISpartaBannerProps> {
    debugger;
    return (
      <div className={styles.spartaBanner}>
        {this.props.bannerToggle == true ? <img className={styles.imgBanner} src={this.props.banner} /> : <Banner context={this.props.context} listName={this.props.listName} />
        }
      </div>
    );
  }
}
