export interface IDisciplineCodes {
    Title: string;
    DisciplineCode: string;
  }