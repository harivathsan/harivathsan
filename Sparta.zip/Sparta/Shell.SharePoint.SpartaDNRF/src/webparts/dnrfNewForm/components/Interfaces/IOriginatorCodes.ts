export interface IOriginatorCodes{
    Title:string;
    CompanyCode:string;
  }