export interface IDocumentTypes {
    Title: string;
    DocumentTypeCodes: string;
}