export interface IDocumentNumbers{
    Title:string;
    DocumentNumber:string;
  }