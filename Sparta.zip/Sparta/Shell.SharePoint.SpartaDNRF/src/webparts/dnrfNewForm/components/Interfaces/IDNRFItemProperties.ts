export interface IDNRFItemProperties{
    [x: string]: any;
    Title:string;
    NameOfProject:string;
    OriginatorCompany:string;
    OriginatorName:string[];
    AreaCode:string;
    Discipline:string;
    DocumentType:string;
    ProjectPhase:string;
    AdditionalInfo:string;
    DocumentNumber:string;
    PlannedDate:string;
  }