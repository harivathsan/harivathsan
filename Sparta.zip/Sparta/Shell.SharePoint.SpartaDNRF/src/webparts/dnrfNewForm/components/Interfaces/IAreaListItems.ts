export interface IAreaListItems {
    Area_x0020_Name: string;
    Title:string;
  }