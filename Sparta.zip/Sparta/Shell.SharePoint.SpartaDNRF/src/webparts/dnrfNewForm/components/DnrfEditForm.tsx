/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Shell.SharePoint.SpartaDNRF
Project Handled By                 : IMS US Capacity Projects
Module Name		                     : DnrfEditForm
Module Description                 : Edit form Component for DNRF
Author                             : Akash Dey
Created Date                       : 22 September, 2022
Modified Date                      : 22 September, 2022
Modified Reason                    : Created the Edit form component
/* ----------------------------------Module Summary-----------------------------------*/

//#region Import
import * as React from 'react';
import { IDnrfNewFormProps } from './IDnrfNewFormProps';
import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from '@microsoft/sp-http';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { ColorPicker, PrimaryButton, DialogFooter, DialogContent, IColor, mergeStyleSets } from 'office-ui-fabric-react';
import styles from './DnrfNewForm.module.scss';
import Utility from './Common/Utility';
import swal from 'sweetalert';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { DatePicker, DayOfWeek, IDatePickerStrings, Toggle } from '@fluentui/react';
import Select from 'react-select';
import { IAreaListItems } from './Interfaces/IAreaListItems';
import { IDisciplineCodes } from './Interfaces/IDisciplineCodes';
import { IOriginatorCodes } from './Interfaces/IOriginatorCodes';
import { IDocumentNumbers } from './Interfaces/IDocumentNumbers';
import { IDocumentTypes } from './Interfaces/IDocumentTypes';
import { IDNRFItemProperties } from './Interfaces/IDNRFItemProperties';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { FilePond, registerPlugin } from 'react-filepond';
import 'filepond/dist/filepond.min.css';
import * as pnp from "sp-pnp-js";
//#endregion Import

//#region Variables
var ItemID;
const DayPickerStrings: IDatePickerStrings = {
  months: [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ],

  shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

  days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

  shortDays: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],

  goToToday: 'Go to today',
  prevMonthAriaLabel: 'Go to previous month',
  nextMonthAriaLabel: 'Go to next month',
  prevYearAriaLabel: 'Go to previous year',
  nextYearAriaLabel: 'Go to next year',
  closeButtonAriaLabel: 'Close date picker',
  monthPickerHeaderAriaLabel: '{0}, select to change the year',
  yearPickerHeaderAriaLabel: '{0}, select to change the month',
};
const firstDayOfWeek = DayOfWeek.Sunday;
const desc = 'dd/mm/yy';
const projectPhaseOptions = [];
//#endregion Variables

//#region Interfaces
export interface IDnrfEditFormStates {
  itemId: string;
  itemDetails: IDNRFItemProperties[];
  uploadEditForm: number;
  folderName: string;
  changeInitiator: string[];
  originators: IOriginatorCodes[];
  originator: string;
  areaCombinedResult: string;
  areaCombineResults: IAreaListItems[];
  disciplineCodes: IDisciplineCodes[];
  disciplineCode: string;
  documentTypes: IDocumentTypes[];
  documentType: string;
  projectPhase: string;
  notes: string;
  docNumbers: IDocumentNumbers[];
  showSuccessMessage: boolean;
  documentTitle: string;
  files: any[];
  ToDelete: any[];
  PlannedDate: any;
  pcapID: string;
  distributionList: string;
  plannedEndDate: any;
  isDList: boolean;
  hasPCAP: boolean;
  docTypes: any[];
  filteredDocTypes: any[];
  reviewers: any[];
  approver: any[];
  IFI: any[];
  docNumber: string;
  isDCCMember: boolean;
}

//#endregion Interfaces

//#region DNRFViewForm Class
export default class DnrfEditForm extends React.Component<IDnrfNewFormProps, IDnrfEditFormStates> {
  //#region Instance Variables

  //#endregion Instance Variables

  //#region Constructor
  constructor(props: IDnrfNewFormProps, state: IDnrfEditFormStates) {
    super(props);

    //Injecting CSS from Site Assets
    let cssPath: string = escape(this.props.cssPath);
    if (cssPath != "" || cssPath != undefined) {
      SPComponentLoader.loadCss(cssPath);
    }

    this.state = {
      itemId: "",
      itemDetails: [],
      uploadEditForm: 1,
      folderName: "",
      changeInitiator: [],
      originators: [],
      originator: "",
      areaCombineResults: [],
      areaCombinedResult: "",
      disciplineCodes: [],
      disciplineCode: "",
      documentTypes: [],
      documentType: "",
      projectPhase: "",
      notes: "",
      docNumbers: [],
      showSuccessMessage: false,
      documentTitle: "",
      files: [],
      ToDelete: [],
      PlannedDate: new Date(),
      pcapID: "",
      distributionList: "",
      plannedEndDate: new Date(),
      isDList: true,
      hasPCAP: false,
      docTypes: [],
      filteredDocTypes: [],
      reviewers: [],
      approver: [],
      IFI: [],
      docNumber: null, isDCCMember: false
    };
    this._onDocumentTitleChange = this._onDocumentTitleChange.bind(this);
    this.getDocumentDetailsfromDNRFList = this.getDocumentDetailsfromDNRFList.bind(this);
    this._onOriginatorChange = this._onOriginatorChange.bind(this);
    this._onAreaCombineResultChange = this._onAreaCombineResultChange.bind(this);
    this._onDisciplineCodeChange = this._onDisciplineCodeChange.bind(this);
    this._onDocumentTypeChange = this._onDocumentTypeChange.bind(this);
    this._onDnrfProjectPhaseChange = this._onDnrfProjectPhaseChange.bind(this);
    this.SaveToDNRFSPList = this.SaveToDNRFSPList.bind(this);
    this.handleChangePlannedDate = this.handleChangePlannedDate.bind(this);
    this.checkCurrentUser = this.checkCurrentUser.bind(this);
  }
  //#endregion Constructor

  //#region Render
  public render(): React.ReactElement<IDnrfNewFormProps> {
    var showDetails = false;
    let areaCombineResultsOptions: any[] = [];
    let disciplineCodeOptions: any[] = [];
    let temDisciplineArray: any = [];
    let documentTypesOptions: any[] = [];
    let dnrfOriginatorOptions: any[] = [];

    if (this.state.areaCombineResults.length > 0) {
      {
        this.state.areaCombineResults.map((item, index) => {
          areaCombineResultsOptions.push({
            value: item.Title + " - " + item.Area_x0020_Name,
            label: item.Title + " - " + item.Area_x0020_Name
          });
        }
        );
      }
    }

    if (this.state.disciplineCodes.length > 0) {
      {
        this.state.disciplineCodes.map((item, index) => {
          disciplineCodeOptions.push({
            value: item.DisciplineCode,
            label: item.DisciplineCode + " - " + item.Title
          });
        }
        );
      }
    }

    // if (this.state.documentTypes.length > 0) {
    //   {
    //     this.state.documentTypes.map((item, index) => {
    //       documentTypesOptions.push({
    //         value: item.DocumentTypeCodes + " - " + item.Title,
    //         label: item.DocumentTypeCodes + " - " + item.Title
    //       });
    //     }
    //     );
    //   }
    // }

    if (this.state.originators.length > 0) {
      {
        this.state.originators.map((item, index) => {
          dnrfOriginatorOptions.push({
            value: item.CompanyCode + " - " + item.Title,
            label: item.CompanyCode + " - " + item.Title
          });
        }
        );
      }
    }

    if (this.state.itemDetails.length > 0) {
      showDetails = true;
    }
    else {
      showDetails = false;
    }
    return (
      <div>
        {showDetails &&
          <div className="row">
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Project ID <span className={styles.mandatory}>*</span></Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].NameOfProject}
              />
            </div>
            <div className={'col-sm-1 col-md-1 col-lg-1 col-xl-1'} style={{ paddingRight: "0px" }}>
              <Label>{"PCAP?"} </Label>
              {/* <TextField
                    className={styles.dropdowns}
                    value={this.state.pcapID}
                    onChange={this._onPCAPChange.bind(this)}
                  /> */}
              <Toggle
                onText="Yes"
                offText="No"
                defaultChecked={this.state.hasPCAP}
                onChange={(e, toggle) => { this.setState({ hasPCAP: toggle }); }}
              ></Toggle>
            </div>
            <div className={'col-sm-3 col-md-3 col-lg-3 col-xl-3'} style={{ paddingLeft: "0px" }}>
              <Label>PCAP ID {this.state.hasPCAP ? <span className={styles.mandatory}>*</span> : ""}</Label>
              <TextField
                className={styles.dropdowns}
                value={this.state.pcapID}
                onChange={this._onPCAPChange.bind(this)}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <PeoplePicker
                context={this.props.context}
                titleText="Reviewers"
                personSelectionLimit={10}
                groupName={""} // Leave this blank in case you want to filter from all users
                ensureUser={true}
                onChange={this._getReviewersPeoplePickerItems.bind(this)}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000}
                
                defaultSelectedUsers={this.state.itemDetails[0].Reviewers!=undefined?this.state.itemDetails[0].Reviewers.map(user => { return user.EMail; }):null}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <PeoplePicker
                context={this.props.context}
                titleText="Originator"
                personSelectionLimit={1}
                groupName={""} // Leave this blank in case you want to filter from all users
                ensureUser={true}
                onChange={this._getChangeInitiatorPeoplePickerItems.bind(this)}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000}
                defaultSelectedUsers={[this.state.itemDetails[0].OriginatorName["EMail"]]}
              //defaultSelectedUsers = {["Vigith-b.nair@shell.com"]}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Document Title <span className={styles.mandatory}>*</span></Label>
              <TextField
                defaultValue={this.state.itemDetails[0].Title}
                onChange={this._onDocumentTitleChange.bind(this)}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <PeoplePicker
                context={this.props.context}
                titleText="Approver"
                personSelectionLimit={1}
                groupName={""} // Leave this blank in case you want to filter from all users
                ensureUser={true}
                onChange={this._getApproverPeoplePickerItems.bind(this)}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000}
                
                defaultSelectedUsers={this.state.itemDetails[0].Approver!=undefined?[this.state.itemDetails[0].Approver["EMail"]]:null}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Areas <span className={styles.mandatory}>*</span></Label>
              <Select
                onChange={this._onAreaCombineResultChange}
                options={areaCombineResultsOptions}
                placeholder="Select an option"
                className={styles.dropdowns}
                defaultValue={{ label: this.state.itemDetails[0].AreaCode, value: this.state.itemDetails[0].AreaCode }}

              />
            </div> 
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Planned Start Date <span className={styles.mandatory}>*</span></Label>
              <DatePicker
                className={styles.dropdowns}
                allowTextInput={false}
                ariaLabel={desc}
                firstDayOfWeek={firstDayOfWeek}
                strings={DayPickerStrings}
                value={this.state.PlannedDate === "" ? new Date(this.state.itemDetails[0].PlannedDate) : this.state.PlannedDate}
                onSelectDate={this.handleChangePlannedDate}
              />
            </div>     
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <PeoplePicker
                context={this.props.context}
                titleText="IFI"
                personSelectionLimit={10}
                groupName={""} // Leave this blank in case you want to filter from all users
                ensureUser={true}
                onChange={this._getIFIPeoplePickerItems.bind(this)}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000}
                
                defaultSelectedUsers={this.state.itemDetails[0].IFI!=undefined?this.state.itemDetails[0].IFI.map(user => { return user.EMail; }):null}
              />
            </div>
            
            
            
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Discipline <span className={styles.mandatory}>*</span></Label>
              <Select
                onChange={this._onDisciplineCodeChange}
                options={disciplineCodeOptions}
                placeholder="Select an option"
                className={styles.dropdowns}
                defaultValue={{ label: this.state.itemDetails[0].Discipline, value: this.state.itemDetails[0].Discipline }}
              />
            </div>
            
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Planned End Date <span className={styles.mandatory}>*</span></Label>
              <DatePicker
                className={styles.dropdowns}
                allowTextInput={false}
                ariaLabel={desc}
                firstDayOfWeek={firstDayOfWeek}
                strings={DayPickerStrings}
                value={this.state.plannedEndDate === "" ? new Date(this.state.itemDetails[0].PlannedEndDate) : this.state.plannedEndDate}
                onSelectDate={this.handleChangePlannedEndDate.bind(this)}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Security Classification</Label>
              <Select
                onChange={this._onDnrfProjectPhaseChange}
                options={projectPhaseOptions}
                placeholder="Select an option"
                className={styles.dropdowns}
                defaultValue={{ label: this.state.itemDetails[0].ProjectPhase, value: this.state.itemDetails[0].ProjectPhase }}
              />
            </div>     
            
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Document Type <span className={styles.mandatory}>*</span></Label>
              <Select
                onChange={this._onDocumentTypeChange}
                options={this.state.filteredDocTypes}
                placeholder="Select an option"
                className={styles.dropdowns}
                defaultValue={{ label: this.state.itemDetails[0].DocumentType, value: this.state.itemDetails[0].DocumentType }}

              />
            </div>
            
            {this.state.isDCCMember ? <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Assigned Document Number <span className={styles.mandatory}>*</span></Label>
              <TextField
                defaultValue={this.state.itemDetails[0].DocumentNumber}
                onChange={this._onDocumentNumberChange.bind(this)}
              />
            </div> : ""}
            <div className={'col-sm-12 col-md-12 col-lg-12 col-xl-12'}>
              <Label>Additional Notes <span className={styles.mandatory}>*</span></Label>
              <TextField
                multiline
                defaultValue={this.state.itemDetails[0].AdditionalInfo}
                onChange={this._onNotes.bind(this)}
              />
            </div>

            <div className="row mt-2">
              {/* <FilePond 
                      files={this.state.files} allowMultiple={true} onupdatefiles={fileItems => {
                        this.setState({
                          files: fileItems.map(fileItem => fileItem.file)
                        });
                }} /> */}
            </div>


            <div className="container">
              <div className="row">
                <div className="d-flex justify-content-end">
                  <PrimaryButton className={styles.formButton} text="Close" onClick={() => Utility.navigateToAllItems(this.props.allItemsPageURL)} />
                  {/* <PrimaryButton className={styles.formButton} text="Submit" onClick = {() => this.SaveToDNRFSPList("No")} />  */}
                  <PrimaryButton className={styles.formButton} text="Submit" onClick={this.SaveToDNRFSPList} />
                </div>
              </div>
            </div>

          </div>}

      </div>
    );
  }
  //#endregion Render

  //#region handlers


  /**
 * Document Title Textfield change handler
 * @param e 
 * @param docTitle 
*/
  public _onDocumentTitleChange(e, docTitle) {
    try {
      this.setState({ documentTitle: docTitle });
    }
    catch (error) {
      console.log("_onDocumentTitleChange-" + error);
    }

  }

  /**
* Document number Textfield change handler
* @param e 
* @param docNo 
*/
  public _onDocumentNumberChange(e, docNo) {
    try {
      this.setState({ docNumber: docNo });
    }
    catch (error) {
      console.log("_onDocumentNumberChange-" + error);
    }

  }


  /**
  * on PCAP change
  * @param e 
  * @param pcap 
  */
  public _onPCAPChange(e, pcap) {
    try {
      this.setState({ pcapID: pcap });
    }
    catch (error) {
      console.log("_onPCAPChange-" + error);
    }

  }
  /**
  * on distribution list chnage
  * @param e 
  * @param dList 
  */
  public _onDListChange(e, dList) {
    try {
      this.setState({ distributionList: dList });
    }
    catch (error) {
      console.log("_onDListChange-" + error);
    }

  }
  public _onDListBlur(Email) {
    if (Email.target.value.length != 0) {
      if (/\S+@shell.com$/.test(Email.target.value)) {
        this.setState({ isDList: true });
      }
      else {
        this.setState({ isDList: false });
      }
    } else { this.setState({ isDList: true }); }
  }
  /**
  * Originator people picker change handler
  * @param people 
  */
  private _getChangeInitiatorPeoplePickerItems(people: any[]) {
    if (people.length > 0) {
      this.setState({ changeInitiator: people[0].id });
    }
    else {
      this.setState({ changeInitiator: [] });
    }
  }
  /**
     * Reviwers Peoplepicker handler
     * @param people 
     */
  private _getReviewersPeoplePickerItems(people: any[]) {
    let users = [];
    if (people.length > 0) {
      people.map(user => {
        users.push(user.id);
      });
    }
    this.setState({ reviewers: users });
  }

  /**
   * IFI Peoplepicker handler
   * @param people 
   */
  private _getIFIPeoplePickerItems(people: any[]) {
    let users = [];
    if (people.length > 0) {
      people.map(user => {
        users.push(user.id);
      });
    }
    this.setState({ IFI: users });
  }

  /**
  * Approver Peoplepicker handler
  * @param people 
  */
  private _getApproverPeoplePickerItems(people: any[]) {
    let users = [];
    if (people.length > 0) {
      people.map(user => {
        users.push(user.id);
      });
    }
    this.setState({ approver: users });
  }
  /**
   * Originator Company change handler
   * @param people 
  */
  private _onOriginatorChange = (originatorSelected) => {
    this.setState({ originator: originatorSelected.value });
  }

  /**
   * Areas dropdown change handler
   * @param areaCombineResult 
  */
  public _onAreaCombineResultChange = (areaCombineResult) => {
    try { this.setState({ areaCombinedResult: areaCombineResult.value }); }
    catch (error) {
      console.log("_onAreaCombineResultChange-" + error);
    }
  }


  /**
   * Discipline dropdown change handler
   * @param disciplineCode 
  */
  public _onDisciplineCodeChange = (disciplineCode) => {
    try {
      let docTOptions = [];
      this.state.docTypes.map(item => {
        let text: string = item.value;
        if (text.indexOf(disciplineCode.value) == 0) {
          docTOptions.push(item);
        }
      });
      this.setState({ disciplineCode: disciplineCode.label, filteredDocTypes: docTOptions });
    }
    catch (error) {
      console.log("_onDisciplineCodeChange-" + error);
    }
  }

  /**
   * Document Type dropdown change handler
   * @param documentType 
  */
  public _onDocumentTypeChange = (documentType) => {
    try { this.setState({ documentType: documentType.value }); }
    catch (error) {
      console.log("_onDocumentTypeChange-" + error);
    }
  }

  /**
   * Project Phase dropdown change handler
   * @param projectPhase 
  */
  public _onDnrfProjectPhaseChange = (projectPhase) => {
    try {
      this.setState({ projectPhase: projectPhase.value });
      if (projectPhase.value === "Confidential") {
        swal("Information", "Please contact Sparta IM team to determine next steps.", "info");
      }
    }
    catch (error) {
      console.log("_onDnrfProjectPhaseChange" + error);
    }
  }

  /**
   * Additional Info Textfield change handler
   * @param e 
   * @param notes 
  */
  public _onNotes(e, notes) {
    this.setState({ notes: notes });
  }

  /**
  * 
  * @param revisionDate 
  */
  private handleChangePlannedDate(plannedDate) {
    this.setState({ PlannedDate: plannedDate });
  }

  /**
  * 
  * @param revisionDate 
  */
  private handleChangePlannedEndDate(plannedeDate) {
    this.setState({ plannedEndDate: plannedeDate });
  }

  /**
   * Function to get Item metadata from List to pre populate Edit Form
   * @param ItemId 
   * @returns 
   */
  private getDocumentDetailsfromDNRFList = async (ItemId): Promise<any> => {
    try {
      this.setState({ itemId: ItemId });
      let endpointUrl = this.props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + this.props.DNRFRequestFormList + "')/items?$select=ID,Title,OriginatorName/ID,OriginatorName/Title,OriginatorName/EMail,NameOfProject,OriginatorCompany,AreaCode,Discipline,DocumentType,ProjectPhase,AdditionalInfo,DocumentNumber,PlannedDate,PlannedEndDate,PCAPid,DistributionList,Reviewers/ID,Reviewers/Title,Reviewers/EMail,IFI/ID,IFI/Title,IFI/EMail,Approver/ID,Approver/Title,Approver/EMail&$filter=ID eq '" + ItemId + "'" + "&$expand=OriginatorName/Title,Reviewers/Title,IFI/Title,Approver/Title");
      console.log("getDocumentDetailsfromDNRFList: ", endpointUrl);
      const itemResults = await this.props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
          if (await response.ok) {
            response.json().then(async (response2) => {
              if (await response2 != null && await response2.value != null && await response2.value.length > 0) {
                this.setState({
                  itemDetails: await response2.value,
                  documentTitle: response2.value[0].Title,
                  changeInitiator: response2.value[0].OriginatorName.ID,
                  originator: response2.value[0].OriginatorCompany,
                  areaCombinedResult: response2.value[0].AreaCode,
                  disciplineCode: response2.value[0].Discipline,
                  documentType: response2.value[0].DocumentType,
                  projectPhase: response2.value[0].ProjectPhase,
                  notes: response2.value[0].AdditionalInfo,
                  pcapID: response2.value[0].PCAPid,
                  //distributionList: response2.value[0].DistributionList,
                  hasPCAP: response2.value[0].PCAPid != null
                });
              }
            });
          }
        });
      return Promise.resolve<any>(itemResults);
    }
    catch (error) { console.log("getDocumentDetailsfromDNRFList-" + error); }
  }

  public async checkCurrentUser(): Promise<any> {
    try {

      const web = new pnp.Web(this.props.context.pageContext.site.absoluteUrl);
      let user = await web.currentUser.get();
      let endpointUrl = this.props.siteUrl.concat(`/_api/web/sitegroups/getByName('Sparta Approvers')/Users?$filter=Id eq ${user.Id}`);
      console.log("checkCurrentUser: ", endpointUrl);
      const results = await this.props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
          if (await response.ok) {
            response.json().then(async (response2) => {
              //console.log({ response2: response2.value });
              this.setState({ isDCCMember: response2.value.length > 0 });
            });
          }
        });
      return Promise.resolve<any>(results);
    }
    catch (e) {
      console.log("checkCurrentUser-" + e);
    }
  }

  /**
   * Validation before submit button click
   * @returns 
  */
  private validateFields(): boolean {
    let validateFields: boolean = false;
    if (this.state.documentTitle === "" || (this.state.hasPCAP && this.state.pcapID == null) || (this.state.isDCCMember && this.state.docNumber == null || this.state.docNumber == "")||this.state.projectPhase==="") {
      swal("Error!", "Please fill all mandatory fields properly!", "error");
      validateFields = false;
    }
    else { validateFields = true; }
    return validateFields;
  }

  /**
   * Function to save form details to list documents to Library
   * @returns 
  */
  private SaveToDNRFSPList(): Promise<any> {
    try {

      if (this.validateFields()) {
        // var selectedCompany = this.state.originator;
        // var selectedArea = this.state.areaCombinedResult;
        // var selectedDiscipline = this.state.disciplineCode;
        // var selectedDocType = this.state.documentType;

        // var newCompanyArray = this.state.originators.filter((el) => { return el.CompanyCode + " - " + el.Title == selectedCompany; });
        // var newAreaArray = this.state.areaCombineResults.filter((el) => { return el.Title + " - " + el.Area_x0020_Name == selectedArea; });
        // var newDisciplineArray = this.state.disciplineCodes.filter((el) => { return el.DisciplineCode + " - " + el.Title == selectedDiscipline; });
        // var newDocTypeeArray = this.state.documentTypes.filter((el) => { return el.DocumentTypeCodes + " - " + el.Title == selectedDocType; });

        // let dnrfFolderName = this.props.description + "-" + newCompanyArray[0].CompanyCode + "-" + newAreaArray[0].Title + "-" + newDisciplineArray[0].DisciplineCode + "-" + newDocTypeeArray[0].DocumentTypeCodes;


        // let listItemEntityType = this.props.listItemEntityType;
        // //let dnrfFolderName = this.state.itemDetails[0].DocumentNumber;
        // //Logic to generate sequence no based on combination of Fields
        // var sequenceNumber = "0001";
        // let tempArr = this.state.docNumbers.filter(element => element.DocumentNumber.substring(0, element.DocumentNumber.lastIndexOf('-')) == dnrfFolderName);
        // if (tempArr.length > 0) {
        //   tempArr = tempArr.sort((a, b) => (a.DocumentNumber < b.DocumentNumber) ? 1 : -1);
        //   sequenceNumber = tempArr[0].DocumentNumber.substring(tempArr[0].DocumentNumber.lastIndexOf('-') + 1, tempArr[0].DocumentNumber.length);
        //   let tempSequenceNumber = Number(sequenceNumber) + 1;

        //   if (tempSequenceNumber.toString().length == 1) {
        //     sequenceNumber = "000" + tempSequenceNumber;
        //   }
        //   else if (tempSequenceNumber.toString().length == 2) {
        //     sequenceNumber = "00" + tempSequenceNumber;
        //   }
        //   else if (tempSequenceNumber.toString().length == 3) {
        //     sequenceNumber = "0" + tempSequenceNumber;
        //   }
        //   else {
        //     sequenceNumber = tempSequenceNumber.toString();
        //   }
        // }

        // if (dnrfFolderName == this.state.itemDetails[0].DocumentNumber.substring(0, this.state.itemDetails[0].DocumentNumber.lastIndexOf('-'))) {
        //   dnrfFolderName = this.state.itemDetails[0].DocumentNumber;
        // }
        // else {
        //   dnrfFolderName = dnrfFolderName + "-" + sequenceNumber;
        // }


        // this.setState({ folderName: dnrfFolderName });
        let endpointUrl = this.props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + this.props.DNRFRequestFormList + "')/items/getbyid(" + ItemID + ")");
        console.log("submitItem: " + endpointUrl);
        const body: string = JSON.stringify({
          __metadata: { type: this.props.listItemEntityType },
          Title: this.state.documentTitle === "" ? this.state.itemDetails[0].Title : this.state.documentTitle,
          NameOfProject: this.props.description,
          OriginatorCompany: this.state.originator === "" ? this.state.itemDetails[0].OriginatorCompany : this.state.originator,
          OriginatorNameId: this.state.changeInitiator.length <= 0 ? this.state.itemDetails[0].OriginatorName["ID"] : this.state.changeInitiator,
          AreaCode: this.state.areaCombinedResult === "" ? this.state.itemDetails[0].AreaCode : this.state.areaCombinedResult,
          Discipline: this.state.disciplineCode === "" ? this.state.itemDetails[0].Discipline : this.state.disciplineCode,
          DocumentType: this.state.documentType === "" ? this.state.itemDetails[0].DocumentType : this.state.documentType,
          ProjectPhase: this.state.projectPhase === "" ? this.state.itemDetails[0].ProjectPhase : this.state.projectPhase,
          AdditionalInfo: this.state.notes === "" ? this.state.itemDetails[0].AdditionalInfo : this.state.notes,
          DocumentNumber: this.state.docNumber === "" ? null : this.state.docNumber,
          PlannedDate: this.state.PlannedDate === "" ? this.state.itemDetails[0].PlannedDate : this.state.PlannedDate,
          PCAPid: this.state.pcapID === "" ? this.state.itemDetails[0].PCAPid : this.state.pcapID,
          DistributionList: this.state.distributionList === "" ? this.state.itemDetails[0].DistributionList : this.state.distributionList,
          PlannedEndDate: this.state.plannedEndDate === "" ? this.state.itemDetails[0].PlannedEndDate : this.state.plannedEndDate,
          //EmailSent:submitToDCC
        });

        const itemResults = this.props.spHttpClient.post(endpointUrl, SPHttpClient.configurations.v1, {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': '',
            'IF-MATCH': '*',
            'X-Http-Method': 'PATCH',
            "Access-Control-Allow-Origin": "*",
          },
          body: body
        }).then((response: SPHttpClientResponse) => {
          if (response.ok) {
            swal("Success!", "Request with Document Number: " + this.state.docNumber + " has been updated successfully", "success")
              .then((value) => {
                if (value) {
                  Utility.navigateToAllItems(this.props.allItemsPageURL);
                }
              });
          }
        });
        return Promise.resolve<any>(itemResults);
      }
    }
    catch (error) {
      console.log("submitItem-" + error);
    }
  }

  /**
   * componentDidMount method
  */
  public async componentDidMount() {
    try {
      let projectPhaseOptionsArr = JSON.parse(this.props.DNRFDocLibrary).projectPhaseOptions.split(',');
      projectPhaseOptionsArr.forEach(element => {
        projectPhaseOptions.push({ value: element, label: element });
      });
      await this.checkCurrentUser();
      let url = new URL(window.location.href);
      var params = new URLSearchParams(url.search);
      if (params.has('itemID')) {
        ItemID = params.get('itemID');
        await this.getDocumentDetailsfromDNRFList(ItemID);
        this.setState({
          areaCombineResults: await Utility.getAreaList(this.props),
          disciplineCodes: await Utility.getDisciplineCode(this.props),
          originators: await Utility.getOriginatorCompany(this.props),
          documentTypes: await Utility.getDocumentType(this.props),
          // docNumbers: await Utility.getDocumentNumbers(this.props),
          PlannedDate: new Date(this.state.itemDetails[0].PlannedDate),
          plannedEndDate: new Date(this.state.itemDetails[0].PlannedEndDate)
        });

        //Sorting the arrays based on Codes
        this.setState({
          areaCombineResults: this.state.areaCombineResults.sort((a, b) => (a.Title > b.Title) ? 1 : -1),
          disciplineCodes: this.state.disciplineCodes.sort((a, b) => (a.DisciplineCode > b.DisciplineCode) ? 1 : -1),
          originators: this.state.originators.sort((a, b) => (a.CompanyCode > b.CompanyCode) ? 1 : -1),
          documentTypes: this.state.documentTypes.sort((a, b) => (a.DocumentTypeCodes > b.DocumentTypeCodes) ? 1 : -1)
        });
        let dtOP = [];
        this.state.documentTypes.map((item, index) => {
          dtOP.push({
            value: item.DocumentTypeCodes + " - " + item.Title,
            label: item.DocumentTypeCodes + " - " + item.Title
          });
        }
        );
        this.setState({ docTypes: dtOP });
        let docTOptions = [];
        this.state.docTypes.map(item => {
          let text: string = item.value;
          if (text.indexOf(this.state.disciplineCode.split(" ")[0]) == 0) {
            docTOptions.push(item);
          }
        });
        this.setState({ filteredDocTypes: docTOptions });

      }
      console.log(this.state.isDCCMember);
    }
    catch (error) {
      console.log("componentDidMount-" + error);
    }
  }

  //#endregion handlers
}
//#endregion DnrfViewForm Class