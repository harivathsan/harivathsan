/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Shell.SharePoint.SpartaDNRF
Project Handled By                 : IMS US Capacity Projects
Module Name		                     : DnrfViewForm
Module Description                 : View form Component for DNRF
Author                             : Akash Dey
Created Date                       : 22 September, 2022
Modified Date                      : 22 September, 2022
Modified Reason                    : Created the View form component
/* ----------------------------------Module Summary-----------------------------------*/

//#region Import
import * as React from 'react';
import { IDnrfNewFormProps } from './IDnrfNewFormProps';
import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from '@microsoft/sp-http';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import styles from './DnrfNewForm.module.scss';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { PrimaryButton } from 'office-ui-fabric-react';
import Utility from './Common/Utility';

//#endregion Import

//#region Variables

//#endregion Variables

//#region Interfaces
interface IDNRFItemProperties {
  PlannedEndDate: string | number;
  DistributionList: string;
  PCAPid: string;
  Title: string;
  NameOfProject: string;
  OriginatorCompany: string;
  OriginatorName: string[];
  AreaCode: string;
  Discipline: string;
  DocumentType: string;
  ProjectPhase: string;
  AdditionalInfo: string;
  DocumentNumber: string;
  PlannedDate: string;
  pcapID: string;
  distributionList: string;
  plannedEndDate: any;
  Reviewers: any[];
  Approver: any;
  IFI: any[];
}

export interface IDnrfViewFormStates {
  itemId: string;
  itemDetails: IDNRFItemProperties[];
  uploadEditForm: number;
  uploadedAttachments: any;
  folderName: string;
}

//#endregion Interfaces

//#region DNRFViewForm Class
export default class DnrfViewForm extends React.Component<IDnrfNewFormProps, IDnrfViewFormStates> {

  //#region Instance Variables
  //#endregion Instance Variables

  //#region Constructor
  constructor(props: IDnrfNewFormProps, state: IDnrfViewFormStates) {
    super(props);

    //Injecting CSS from Site Assets
    let cssPath: string = escape(this.props.cssPath);
    if (cssPath != "" || cssPath != undefined) {
      SPComponentLoader.loadCss(cssPath);
    }

    this.state = {
      itemId: "",
      itemDetails: [],
      uploadEditForm: 1,
      uploadedAttachments: [],
      folderName: "",
    };
    this.getDocumentDetailsfromDNRFList = this.getDocumentDetailsfromDNRFList.bind(this);
  }
  //#endregion Constructor

  //#region Render
  public render(): React.ReactElement<IDnrfNewFormProps> {
    var showDetails = false;
    if (this.state.itemDetails.length > 0) {
      showDetails = true;
    }
    else {
      showDetails = false;
    }
    return (
      <div>
        {showDetails &&
          <div className="row">
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Project ID</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].NameOfProject}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>PCAP ID</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].PCAPid}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Reviewers</Label>
              <TextField
                className={styles.dropdowns} disabled multiline
                defaultValue={this.state.itemDetails[0].Reviewers!=undefined?this.state.itemDetails[0].Reviewers.map(user => { return user.Title; }).toString():null}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Originator</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].OriginatorName!=undefined?this.state.itemDetails[0].OriginatorName["Title"]:null}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Document Title</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].Title}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Approver</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].Approver!=undefined?this.state.itemDetails[0].Approver.Title:null}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Areas</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].AreaCode}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Planned Start Date <span className={styles.columnDesc}>{"(When document will be issued for review)"}</span></Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={new Date(this.state.itemDetails[0].PlannedDate).toLocaleDateString()}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>IFI</Label>
              <TextField
                className={styles.dropdowns} disabled multiline
                defaultValue={this.state.itemDetails[0].IFI!=undefined?this.state.itemDetails[0].IFI.map(user => { return user.Title; }).toString():null}
              />
            </div>

            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Discipline</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].Discipline}
              />
            </div>
            
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Planned End Date <span className={styles.columnDesc}>{"(When document will be complete, issued for use)"}</span></Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={new Date(this.state.itemDetails[0].PlannedEndDate).toLocaleDateString()}
              />
            </div>
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Security Classification</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].ProjectPhase}
              />
            </div>

           
            <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Document Type</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].DocumentType}
              />
            </div>

            
            {this.state.itemDetails[0].DocumentNumber && <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
              <Label>Assigned Document Number</Label>
              <TextField
                className={styles.dropdowns} disabled
                defaultValue={this.state.itemDetails[0].DocumentNumber}
              />
            </div>}

            <div className={'col-sm-12 col-md-12 col-lg-12 col-xl-12'}>
              <Label>Additional Notes</Label>
              <TextField
                className={styles.dropdowns} disabled multiline
                defaultValue={this.state.itemDetails[0].AdditionalInfo}
              />
            </div>

            <div className="row mt-4">
              {/* <Label>Attachments </Label>
            {this.state.uploadedAttachments.map((file, index) => (
                <span id={index} className={styles.attachmentFiles}>
                 <a href={file.path} target="_blank" data-interception="off">{file.fileName}</a> 
                </span>
              ))} */}
            </div>

            <div className="d-flex justify-content-end">
              <PrimaryButton className={styles.formButton} text="Close" onClick={() => Utility.navigateToAllItems(this.props.allItemsPageURL)} />
              {/* <PrimaryButton className={styles.formButton} text="Edit"onClick ={() => Utility.navigateToAllItems(this.props.siteUrl + "/SitePages/" + this.props.description +"-DNRF.aspx?Mode=EditForm&itemID=" + this.state.itemId)} /> */}
            </div>
          </div>}
      </div>
    );
  }
  //#endregion Render

  //#region handlers

  /**
   * Function to get attachments for the corresponding Item
   * @param ItemID 
   * @returns 
  */
  private getDocumentDetailsfromDNRFList = async (ItemID): Promise<any> => {
    try {
      this.setState({ itemId: ItemID });
      let endpointUrl = this.props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + this.props.DNRFRequestFormList + "')/items?$select=ID,Title,OriginatorName/Title,NameOfProject,OriginatorCompany,AreaCode,Discipline,DocumentType,ProjectPhase,AdditionalInfo,DocumentNumber,PlannedDate,PlannedEndDate,PCAPid,DistributionList,Reviewers/Title,IFI/Title,Approver/Title&$filter=ID eq '" + ItemID + "'" + "&$expand=OriginatorName/Title,Reviewers/Title,IFI/Title,Approver/Title");
      console.log("getDocumentDetailsfromDNRFList: ", endpointUrl);
      const itemResults = await this.props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
          if (await response.ok) {
            response.json().then(async (response3) => {
              if (await response3 != null && await response3.value != null && await response3.value.length > 0) {
                this.setState({ itemDetails: await response3.value });
              }
            });
          }
        });
      return Promise.resolve<any>(itemResults);
    }
    catch (error) { console.log("getDocumentDetailsfromDNRFList-" + error); }
  }

  /**
   * componentDidMount method
  */
  public async componentDidMount() {
    try {
      let url = new URL(window.location.href);
      var params = new URLSearchParams(url.search);
      var ItemID;
      if (params.has('itemID')) {
        ItemID = params.get('itemID');
        await this.getDocumentDetailsfromDNRFList(ItemID);
      }
    }
    catch (error) {
      console.log("componentDidMount-" + error);
    }
  }
  //#endregion handlers

}
//#endregion DnrfViewForm Class