import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient} from '@microsoft/sp-http';

export interface IDnrfNewFormProps {
  description: string;
  FormTitle: string;
  DNRFRequestFormList:string;
  context:any;
  siteUrl: string;
  spHttpClient:SPHttpClient;
  areaList:string;
  DNRFRequestsDisciplineList:string;
  DNRFRequestsDocTypeList:string;
  allItemsPageURL:string;
  projectsList:string;
  listItemEntityType:string;
  DNRFDocLibrary:string;
  successMessage:string;
  cssPath:string;
}
