/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Shell.SharePoint.SpartaDNRF
Project Handled By                 : IMS US Capacity Projects
Module Name		                     : Utility
Module Description                 : Reusable Methods
Author                             : Akash Dey
Created Date                       : 22 September, 2022
Modified Date                      : 22 September, 2022
Modified Reason                    : Created the Common Methods 
-------------------------------------Module Summary-----------------------------------**/

//#region Import
import * as React from 'react';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IDnrfNewFormProps } from '../IDnrfNewFormProps';
import * as $ from 'jquery';
import swal from 'sweetalert';
import pnp from 'sp-pnp-js';
//#endregion Import

let Allfiles : FileList;

//#region Class
class Utility {
//#region Methods

  // /**
  //  * function called when onDragEnter event is triggered
  // */
  // public static callJqueryNow=()=>{
  //   //Allfiles = null;
  //   // $('#drop').on('drop dragdrop',function(event){
  //   $('#drop').on('drop dragdrop',(event) =>{
  //     event.preventDefault();  
  //     Allfiles = null;
  //     console.log('dropped');
  //     Allfiles = event.originalEvent.dataTransfer.files;
  //     if(Allfiles.length>10){
  //       swal("Warning!", "Please upload a maximum of 10 files!", "warning")
  //         .then((value)=>{
  //           if(value){
  //             Allfiles = null;
  //           }
  //         });
  //     }
  //     //$('#center').html('<span class="fileName">' + Allfiles.length + " document/s added!" + '</span>');
  //     event.preventDefault();       
  //   });
  //   $('#drop').on('dragenter',function(event){
  //     event.preventDefault();
  //   $(this).css('background-color','white');
  //   });
  //   $('#drop').on('dragleave',function(event){
  //     $(this).css('background-color','#f1f1f1');    
  //   });
  //   $('#drop').on('dragover',function(event){
  //     //$(this).css('background-color','white');
  //     event.preventDefault();
  //   }); 
  //   return Allfiles;
  // }

  /**
     * function called when file uploaded through control
  */
  public static handleFileUploadChange=(selectedFiles: FileList)=>{
    console.log(selectedFiles);
    if(selectedFiles.length>10){
      swal("Warning!", "Please upload a maximum of 10 files!", "warning")
      .then((value)=>{
        if(value){
          Allfiles = null;
        }
      });
    }
    else{    
      Allfiles=selectedFiles;
      //$('#center').html('<span class="fileName">' + Allfiles.length + " document/s added!" + '</span>');
      event.preventDefault();
    }
    return Allfiles;
  }

  /**
   * Function to get Areas from SP List
   * @returns 
  */
  public static getAreaList = async (props) => {
    try {
      //
      let endpointUrl = props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + props.areaList + "')/items?$select=ID,Area_x0020_Name,Title&$orderby=Area_x0020_Name&$top=4999");
      console.log("AreaList: ", endpointUrl);

      let response = await props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1);
      let results = await response.json(); 
      return results.value;
    }
    catch (error) { console.log("getActions-" + error); }
  }

  /**
   * Function to get Disciplines from SP List
  */
  public static getDisciplineCode= async (props) => {
    try {
      //
      let endpointUrl = props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + props.DNRFRequestsDisciplineList + "')/items?$select=Title,DisciplineCode&$orderby=Title&$top=4999");
      console.log("getDisciplineCode: ", endpointUrl);

      let response = await props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1);
      let results = await response.json();  
      return results.value;
    }
    catch (error) { console.log("getDisciplineCode-" + error); }
  }

  /**
   * Function to get Disciplines from SP List
  */
  public static getOriginatorCompany= async (props) => {
      try {
        //
        let endpointUrl = props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + props.projectsList + "')/items?$select=ID,Title,CompanyCode&$orderby=Title&$top=4999");
        console.log("getOriginatorCompany: ", endpointUrl);
  
        let response = await props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1);
        let results = await response.json();  
        return results.value;
      }
      catch (error) { console.log("getOriginatorCompany-" + error); }
  }

  /**
   * Function to get Document types based on discipline selected
  */
  public static getDocumentType= async (props) => {
    try {
      let endpointUrl = props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + props.DNRFRequestsDocTypeList + "')/items?$select=Title,DocumentTypeCodes&$orderby=Title&$top=4999");
      console.log("getDocumentType: ", endpointUrl);
      let response = await props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1);
      let results = await response.json();  
      return results.value;
    }
    catch (error) { console.log("getDocumentType-" + error); }
  }

  /**
     * 
     * @returns 
  */
  public static getDocumentNumbers = async (props) => {
    try {
      

      //PnP Library to read all items from list(more than 5000)
      let results : any = [];
      let items = await pnp.sp.web.lists.getByTitle(props.DNRFRequestFormList).items.select("ID","Title", "DocumentNumber").top(2000).getPaged();
      results = await items.results;
      while (items.hasNext) {
        // this will carry over the type specified in the original query for the results array
        items = await items.getNext();        
        items.results.forEach(element => {
          results.push(element);
        });
        console.log(results);
      }
      

      // let endpointURL = props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + props.DNRFRequestFormList + "')/items?$select=ID,Title,DocumentNumber&$orderby=ID&$top=4999");
      // console.log("getDocumentNumbers: ", endpointURL);
      // let response = await props.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1);
      // let results = await response.json();  
      // return results.value;

      return results;
    }
    catch (error) { console.log("getDocumentType-" + error); }
  }

  /**
   * Funtion to navigate back to List All items page
  */
    public static navigateToAllItems(url) {
      try {
        window.location.href = url;
      }
      catch (error) {
        console.error("navigateToAllItems-" + error);
      }
  
    }


//#endregion Methods
}
//#endregion Class
export default Utility;