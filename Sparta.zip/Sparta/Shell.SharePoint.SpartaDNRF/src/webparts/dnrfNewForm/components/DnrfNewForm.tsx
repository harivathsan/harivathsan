/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Shell.SharePoint.SpartaDNRF
Project Handled By                 : IMS US Capacity Projects
Module Name		                     : DNRFNewForm
Module Description                 : To provide a New form 
Author                             : Akash Dey
Created Date                       : 20 September, 2022
Modified Date                      : 22 September, 2022
Modified Reason                    : Created the New form component
/* ----------------------------------Module Summary-----------------------------------*/
//#region Import
import * as React from 'react';
import styles from './DnrfNewForm.module.scss';
import { IDnrfNewFormProps } from './IDnrfNewFormProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import 'bootstrap/dist/css/bootstrap.min.css';
import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from '@microsoft/sp-http';
import { ColorPicker, PrimaryButton, DialogFooter, DialogContent, IColor, mergeStyleSets, arraysEqual, allowOverscrollOnElement } from 'office-ui-fabric-react';
import { DatePicker, DayOfWeek, IDatePickerStrings } from '@fluentui/react';
import Select from 'react-select';
//import Select from "react-select/creatable";
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert, { AlertProps } from '@material-ui/lab/Alert';
import swal from 'sweetalert';
import DnrfViewForm from '../components/DnrfViewForm';
import DnrfEditForm from '../components/DnrfEditForm';
import { IAreaListItems } from './Interfaces/IAreaListItems';
import { IDisciplineCodes } from './Interfaces/IDisciplineCodes';
import { IOriginatorCodes } from './Interfaces/IOriginatorCodes';
import { IDocumentNumbers } from './Interfaces/IDocumentNumbers';
import { IDocumentTypes } from './Interfaces/IDocumentTypes';
import Utility from './Common/Utility';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { FilePond, registerPlugin } from 'react-filepond';
import 'filepond/dist/filepond.min.css';
import * as pnp from "sp-pnp-js";
import { Toggle } from '@fluentui/react/lib/Toggle';
//#endregion Import

//#region Variables
const loading = () => <div className="animated fadeIn pt-3 text-center">Loading...</div>;
const DayPickerStrings: IDatePickerStrings = {
  months: [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ],

  shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

  days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

  shortDays: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],

  goToToday: 'Go to today',
  prevMonthAriaLabel: 'Go to previous month',
  nextMonthAriaLabel: 'Go to next month',
  prevYearAriaLabel: 'Go to previous year',
  nextYearAriaLabel: 'Go to next year',
  closeButtonAriaLabel: 'Close date picker',
  monthPickerHeaderAriaLabel: '{0}, select to change the year',
  yearPickerHeaderAriaLabel: '{0}, select to change the month',
};
const firstDayOfWeek = DayOfWeek.Sunday;
const desc = 'dd/mm/yy';
const projectPhaseOptions = [];
//#endregion Variables

//#region  Interfaces

interface IDnrfNewFormStates {
  documentTitle: string;
  projectTitle: string;
  isProjectTitleBlank: boolean;
  isDocTitleBlank: boolean;
  originators: IOriginatorCodes[];
  originator: string;
  changeInitiator: string[];
  areaCombinedResult: string;
  areaCombineResults: IAreaListItems[];
  disciplineCodes: IDisciplineCodes[];
  disciplineCode: string;
  documentTypes: IDocumentTypes[];
  documentType: string;
  projectPhase: string;
  notes: string;
  upload: number;
  folderName: string;
  docNumbers: IDocumentNumbers[];
  showSuccessMessage: boolean;
  isformModeNew: boolean;
  isformModeEdit: boolean;
  isformModeView: boolean;
  files: any[];
  plannedDate: any;
  plannedEndDate: any;
  toggleSelected: boolean;
  documentNumber: string;
  isDocNumberBlank: boolean;
  IsDocumentControlGroupMember: boolean;
  pcapID: string;
  hasPCAP: boolean;
  docTypes: any[];
  filteredDocTypes: any[];
  reviewers: any[];
  approver: any[];
  IFI: any[];
}
//#endregion  Interfaces

//#region DnrfNewForm Class
export default class DnrfNewForm extends React.Component<IDnrfNewFormProps, IDnrfNewFormStates> {

  //#region Instance Variables
  private fileInput: React.RefObject<HTMLInputElement>;
  //#endregion Instance Variables

  //#region Constructor
  constructor(props: IDnrfNewFormProps, state: IDnrfNewFormStates) {
    super(props);

    //Injecting CSS from Site Assets
    let cssPath: string = escape(this.props.cssPath);
    if (cssPath != "" || cssPath != undefined) {
      SPComponentLoader.loadCss(cssPath);
    }

    this.state = {
      documentTitle: "",
      isDocTitleBlank: false,
      projectTitle: "",
      isProjectTitleBlank: false,
      originators: [],
      originator: "DNRF - DNRF",
      changeInitiator: [],
      areaCombineResults: [],
      areaCombinedResult: "",
      disciplineCodes: [],
      disciplineCode: "",
      documentTypes: [],
      documentType: "",
      projectPhase: "",
      notes: "",
      upload: 1,
      folderName: "",
      docNumbers: [],
      showSuccessMessage: false,
      isformModeNew: false,
      isformModeEdit: false,
      isformModeView: false,
      files: [],
      plannedDate: new Date(),
      toggleSelected: false,
      documentNumber: "",
      isDocNumberBlank: false,
      IsDocumentControlGroupMember: false,
      pcapID: "",
      plannedEndDate: new Date(),
      hasPCAP: false,
      docTypes: [],
      filteredDocTypes: [],
      reviewers: [],
      approver: [],
      IFI: []
    };
    this.SaveToDNRFSPList = this.SaveToDNRFSPList.bind(this);
    this._onOriginatorChange = this._onOriginatorChange.bind(this);
    this._onAreaCombineResultChange = this._onAreaCombineResultChange.bind(this);
    this._onDisciplineCodeChange = this._onDisciplineCodeChange.bind(this);
    this._onDocumentTypeChange = this._onDocumentTypeChange.bind(this);
    this._onDnrfProjectPhaseChange = this._onDnrfProjectPhaseChange.bind(this);
    this.handleChangePlannedDate = this.handleChangePlannedDate.bind(this);
    this._onToggleChange = this._onToggleChange.bind(this);


    pnp.setup({
      spfxContext: this.props.context
    });

  }
  //#endregion Constructor

  //#region Handlers

  /**
   * Project ID Textfield change handler
  */
  public _onProjectTitleChange(e, Title) {
    try {
      this.setState({ projectTitle: Title });
    }
    catch (error) {
      console.log("_onProjectTitleChange-" + error);
    }

  }

  /**
   * Project ID Textfield Blur handler
   * @param docTitle 
  */
  public _onProjTitleBlur(docTitle) {

    if (docTitle.target.value != "") {
      this.setState({ isProjectTitleBlank: false });
    }
    else {
      this.setState({ isProjectTitleBlank: true });
    }

  }

  /**
   * on PCAP change
   * @param e 
   * @param pcap 
   */
  public _onPCAPChange(e, pcap) {
    try {
      this.setState({ pcapID: pcap });
    }
    catch (error) {
      console.log("_onPCAPChange-" + error);
    }

  }


  /**
   * Document Title Textfield change handler
   * @param e 
   * @param docTitle 
  */
  public _onDocumentTitleChange(e, docTitle) {
    try {
      this.setState({ documentTitle: docTitle });
    }
    catch (error) {
      console.log("_onDocumentTitleChange-" + error);
    }

  }

  /**
 * Document Number Textfield change handler
 * @param e 
 * @param docTitle 
*/
  public _onDocumentNumberChange(e, docNumber) {
    try {
      this.setState({ documentNumber: docNumber });
    }
    catch (error) {
      console.log("_onDocumentNumberChange-" + error);
    }

  }



  /**
   * Document Title Textfield Blur handler
   * @param docTitle 
  */
  public _onDocTitleBlur(docTitle) {
    if (docTitle.target.value != "") {
      this.setState({ isDocTitleBlank: false });
    }
    else {
      this.setState({ isDocTitleBlank: true });
    }
  }

  /**
   * Document Title Textfield Blur handler
   * @param docNumber
  */
  public _onDocNumberBlur(docNumber) {
    if (docNumber.target.value != "") {
      this.setState({ isDocNumberBlank: false });
    }
    else {
      this.setState({ isDocNumberBlank: true });
    }
  }

  /**
   * Originator/Company dropdown change handler
   * @param originatorSelected 
  */
  private _onOriginatorChange = (originatorSelected) => {
    this.setState({ originator: originatorSelected.value });
  }

  /**
   * Originator people picker change handler
   * @param people 
  */
  private _getChangeInitiatorPeoplePickerItems(people: any[]) {
    if (people.length > 0) {
      this.setState({ changeInitiator: people[0].id });
    }
    else {
      this.setState({ changeInitiator: [] });
    }
  }

  /**
   * Reviwers Peoplepicker handler
   * @param people 
   */
  private _getReviewersPeoplePickerItems(people: any[]) {
    let users = [];
    if (people.length > 0) {
      people.map(user => {
        users.push(user.id);
      });
    }
    this.setState({ reviewers: users });
  }

  /**
   * IFI Peoplepicker handler
   * @param people 
   */
  private _getIFIPeoplePickerItems(people: any[]) {
    let users = [];
    if (people.length > 0) {
      people.map(user => {
        users.push(user.id);
      });
    }
    this.setState({ IFI: users });
  }

  /**
  * Approver Peoplepicker handler
  * @param people 
  */
  private _getApproverPeoplePickerItems(people: any[]) {
    let users = [];
    if (people.length > 0) {
      people.map(user => {
        users.push(user.id);
      });
    }
    this.setState({ approver: users });
  }

  /**
   * Areas dropdown change handler
   * @param areaCombineResult 
  */
  public _onAreaCombineResultChange = (areaCombineResult) => {
    try { this.setState({ areaCombinedResult: areaCombineResult.value }); }
    catch (error) {
      console.log("_onAreaCombineResultChange-" + error);
    }
  }

  /**
   * Discipline dropdown change handler
   * @param disciplineCode 
  */
  public _onDisciplineCodeChange = (disciplineCode) => {
    try {
      let docTOptions = [];
      this.state.docTypes.map(item => {
        let text: string = item.value;
        if (text.indexOf(disciplineCode.value) == 0) {
          docTOptions.push(item);
        }
      });
      this.setState({ disciplineCode: disciplineCode.label, filteredDocTypes: docTOptions });
    }
    catch (error) {
      console.log("_onDisciplineCodeChange-" + error);
    }
  }

  /**
   * Document Type dropdown change handler
   * @param documentType 
   */
  public _onDocumentTypeChange = (documentType) => {
    try { this.setState({ documentType: documentType.value }); }
    catch (error) {
      console.log("_onDocumentTypeChange-" + error);
    }
  }

  /**
   * Project Phase dropdown change handler
   * @param projectPhase 
  */
  public _onDnrfProjectPhaseChange = (projectPhase) => {
    try {
      this.setState({ projectPhase: projectPhase.value });
      if (projectPhase.value === "Confidential") {
        swal("Information", "Please contact Sparta IM team to determine next steps.", "info");
      }
    }
    catch (error) {
      console.log("_onDnrfProjectPhaseChange" + error);
    }
  }

  /**
   * Additional Info Textfield change handler
   * @param e 
   * @param notes 
  */
  public _onNotes(e, notes) {
    this.setState({ notes: notes });
  }


  /**
   * 
   * @param revisionDate 
   */
  public handleChangePlannedDate(plannedDate) {
    this.setState({ plannedDate: plannedDate });
  }

  public handleChangePlannedEndDate(plannedEndDate) {
    this.setState({ plannedEndDate: plannedEndDate });
  }

  /**
   * 
   * @returns 
   */
  private _onToggleChange(ev: React.MouseEvent<HTMLElement>, checked?: boolean) {
    this.setState({ toggleSelected: checked });
  }

  /**
  *Load logged in user details
  */
  private async loadUserDetails(): Promise<any> {
    try {
      const web = new pnp.Web(this.props.context.pageContext.site.absoluteUrl);
      return await web.currentUser.get();
    }
    catch (error) {
      console.log("Error in spLoggedInUserDetails : " + error);
    }
  }

  /**
   * 
   * @returns 
   */
  private async checkIfMemberOfDocumentControlGroup(userDetails) {
    try {
      let endpointURL = this.props.siteUrl.concat("/_api/web/sitegroups/getByName('DocumentControlGroup')/Users?$filter=Id eq " + userDetails.Id);
      //let endpointURL = this.props.siteUrl.concat("/_api/web/sitegroups/getByName('DocumentControlGroup')/Users?$filter=Id eq 125");
      console.log("checkIfMemberOfDocumentControlGroup: ", endpointURL);
      let response = await this.props.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1);
      let results = await response.json();
      let boolIsMember = results.value.length > 0 ? true : false;
      return boolIsMember;
    }
    catch (error) {
      console.log("Error in checkIfMemberOfDocumentControlGroup : " + error);
    }
  }
  /**
   * Function to save fomr details to list
   * @returns 
  */
  private SaveToDNRFSPList(): Promise<any> {
    try {
      if (this.validateFields()) {
        // var selectedCompany = this.state.originator;
        // var selectedArea = this.state.areaCombinedResult;
        // var selectedDiscipline = this.state.disciplineCode;
        // var selectedDocType = this.state.documentType;

        // var newCompanyArray = this.state.originators; //.filter((el) => { return el.CompanyCode===selectedCompany + " - " + el.Title; })
        // var newAreaArray = this.state.areaCombineResults.filter((el) => { return el.Title + " - " + el.Area_x0020_Name == selectedArea; });
        // var newDisciplineArray = this.state.disciplineCodes.filter((el) => { return el.DisciplineCode + " - " + el.Title == selectedDiscipline; });
        // var newDocTypeeArray = this.state.documentTypes.filter((el) => { return el.DocumentTypeCodes + " - " + el.Title == selectedDocType; });

        // let listItemEntityType = this.props.listItemEntityType;
        // //let dnrfFolderName = this.props.description.substring(0,3) + "-" + newCompanyArray[0].CompanyCode + "-" + newAreaArray[0].Title + "-" + newDisciplineArray[0].DisciplineCode + "-" + newDocTypeeArray[0].DocumentTypeCodes;
        // let dnrfFolderName = this.props.description + "-" + newCompanyArray[0].CompanyCode + "-" + newAreaArray[0].Title + "-" + newDisciplineArray[0].DisciplineCode + "-" + newDocTypeeArray[0].DocumentTypeCodes;


        // //Logic to generate sequence number based on combination of Fields selected
        // var sequenceNumber = "0001";
        // let tempArr = this.state.docNumbers.filter(element => element.DocumentNumber.substring(0, element.DocumentNumber.lastIndexOf('-')) == dnrfFolderName);
        // if (tempArr.length > 0) {
        //   tempArr = tempArr.sort((a, b) => (a.DocumentNumber < b.DocumentNumber) ? 1 : -1);
        //   sequenceNumber = tempArr[0].DocumentNumber.substring(tempArr[0].DocumentNumber.lastIndexOf('-') + 1, tempArr[0].DocumentNumber.length);
        //   let tempSequenceNumber = Number(sequenceNumber) + 1;

        //   if (tempSequenceNumber.toString().length == 1) {
        //     sequenceNumber = "000" + tempSequenceNumber;
        //   }
        //   else if (tempSequenceNumber.toString().length == 2) {
        //     sequenceNumber = "00" + tempSequenceNumber;
        //   }
        //   else if (tempSequenceNumber.toString().length == 3) {
        //     sequenceNumber = "0" + tempSequenceNumber;
        //   }
        //   else {
        //     sequenceNumber = tempSequenceNumber.toString();
        //   }
        // }

        // dnrfFolderName = this.state.toggleSelected ? this.state.documentNumber.toUpperCase() : dnrfFolderName + "-" + sequenceNumber;

        // this.setState({ folderName: dnrfFolderName });
        let endpointUrl = this.props.siteUrl.concat("/_api/web/Lists/GetByTitle('" + this.props.DNRFRequestFormList + "')/items");
        console.log("submitItem: " + endpointUrl);
        const body: string = JSON.stringify({
          __metadata: { type: this.props.listItemEntityType },
          Title: this.state.documentTitle,
          NameOfProject: this.props.description,
          OriginatorCompany: this.state.originator,
          OriginatorNameId: this.state.changeInitiator,
          //OriginatorNameId: { "results": ["559", "1758"] },
          AreaCode: this.state.areaCombinedResult,
          Discipline: this.state.disciplineCode,
          DocumentType: this.state.documentType,
          ProjectPhase: this.state.projectPhase,
          AdditionalInfo: this.state.notes,
          DocumentNumber: null,
          EmailSent: this.state.toggleSelected ? "No" : "Yes",
          PlannedDate: this.state.plannedDate,
          PCAPid: this.state.pcapID,
          //DistributionList: this.state.distributionList,
          PlannedEndDate: this.state.plannedEndDate,
          ReviewersId: { "results": this.state.reviewers },
          IFIId: { "results": this.state.IFI },
          ApproverId: this.state.approver[0]
        });

        const itemResults = this.props.spHttpClient.post(endpointUrl, SPHttpClient.configurations.v1, {
          headers: {
            'Accept': 'application/json;odata=verbose',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': ''
          },
          body: body
        }).then((response: SPHttpClientResponse) => {
          if (response.ok) {
            response.json().then((response1) => {
              if (response1 != null) {
                swal("Success!", "New Document Number Request created", "success")
                  .then((value) => {
                    if (value) {
                      Utility.navigateToAllItems(this.props.allItemsPageURL);
                    }
                  });
              }
            });
          }
        });
        return Promise.resolve<any>(itemResults);
      }
    }
    catch (error) {
      console.log("submitItem-" + error);
    }
  }

  /**
   * 
   * @returns 
  */
  private validateFields(): boolean {
    let validateFields: boolean = false;
    if (this.state.documentTitle === "" || this.props.description === "" || this.state.originator === "" || this.state.changeInitiator.length <= 0 || this.state.areaCombinedResult === "" || this.state.disciplineCode === "" || this.state.documentType === "" || this.state.plannedDate === "" || this.state.plannedEndDate === "" || (this.state.hasPCAP && this.state.pcapID === "") || this.state.projectPhase==="") {
      swal("Error!", "Please fill all mandatory fields properly!", "error");
      validateFields = false;
    }
    else {
      if (this.state.toggleSelected && this.state.documentNumber === "") {
        swal("Error!", "Please provide Document Number!", "error");
        validateFields = false;
      }
      else if (this.state.toggleSelected && this.state.documentNumber != "") {
        let tempArr = this.state.docNumbers.filter(element => element.DocumentNumber == this.state.documentNumber.toUpperCase());
        if (tempArr.length > 0) {
          swal("Error!", "Document Number already exists!", "error");
          validateFields = false;
        }
        else {
          validateFields = true;
        }
      }
      else {
        validateFields = true;
      }
    }
    return validateFields;
  }

  //#endregion Handlers

  //#region  Render
  public render(): React.ReactElement<IDnrfNewFormProps> {
    let areaCombineResultsOptions: any[] = [];
    let disciplineCodeOptions: any[] = [];
    let temDisciplineArray: any = [];
    let documentTypesOptions: any[] = [];
    let dnrfOriginatorOptions: any[] = [];

    if (this.state.areaCombineResults.length > 0) {
      {
        this.state.areaCombineResults.map((item, index) => {
          areaCombineResultsOptions.push({
            value: item.Title + " - " + item.Area_x0020_Name,
            label: item.Title + " - " + item.Area_x0020_Name
          });
        }
        );
      }
    }

    if (this.state.disciplineCodes.length > 0) {
      {
        this.state.disciplineCodes.map((item, index) => {
          disciplineCodeOptions.push({
            value: item.DisciplineCode,
            label: item.DisciplineCode + " - " + item.Title
          });
        }
        );
      }
    }

    // if (this.state.documentTypes.length > 0) {
    //   {
    //     this.state.documentTypes.map((item, index) => {
    //       documentTypesOptions.push({
    //         value: item.DocumentTypeCodes + " - " + item.Title,
    //         label: item.DocumentTypeCodes + " - " + item.Title
    //       });
    //     }
    //     );
    //     this.setState({docTypes:documentTypesOptions});
    //   }
    // }

    if (this.state.originators.length > 0) {
      {
        this.state.originators.map((item, index) => {
          dnrfOriginatorOptions.push({
            value: item.CompanyCode + " - " + item.Title,
            label: item.CompanyCode + " - " + item.Title
          });
        }
        );
      }
    }

    return (
      <React.Suspense fallback={loading()}>
        <div className="container-fluid">
          <div className="row">
            <div className={`${'col-sm-12 col-md-12 col-lg-12 col-xl-12'} ${styles.dnrfNewForm}`}>
              <div className="col-auto">
                <Snackbar
                  open={this.state.showSuccessMessage}
                  className={styles.snackBar}
                  //autoHideDuration={10000} 
                  onClose={() => { this.setState({ showSuccessMessage: false }); }}>
                  <Alert onClose={() => this.setState({ showSuccessMessage: false })} severity="success">
                    {this.props.successMessage}
                  </Alert>
                </Snackbar>
              </div>
              <h1>{this.props.FormTitle}</h1>
              <hr className={styles.hrClass}></hr>
              {this.state.isformModeNew && <div className="row">
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <Label>Project ID <span className={styles.mandatory}>*</span></Label>
                  <TextField
                    className={styles.dropdowns}
                    disabled
                    defaultValue={this.props.description}
                  />

                </div>
                <div className={'col-sm-1 col-md-1 col-lg-1 col-xl-1'} style={{ paddingRight: "0px" }}>
                  <Label>{"PCAP?"} </Label>
                  {/* <TextField
                    className={styles.dropdowns}
                    value={this.state.pcapID}
                    onChange={this._onPCAPChange.bind(this)}
                  /> */}
                  <Toggle
                    onText="Yes"
                    offText="No"
                    onChange={(e, toggle) => { this.setState({ hasPCAP: toggle }); }}
                  ></Toggle>
                </div>
                <div className={'col-sm-3 col-md-3 col-lg-3 col-xl-3'} style={{ paddingLeft: "0px" }}>
                  <Label>PCAP ID {this.state.hasPCAP ? <span className={styles.mandatory}>*</span> : ""}</Label>
                  <TextField
                    className={styles.dropdowns}
                    value={this.state.pcapID}
                    onChange={this._onPCAPChange.bind(this)}

                  />
                </div>
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <PeoplePicker
                    context={this.props.context}
                    titleText="Reviewers"
                    personSelectionLimit={10}
                    groupName={""} // Leave this blank in case you want to filter from all users
                    ensureUser={true}
                    onChange={this._getReviewersPeoplePickerItems.bind(this)}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}

                  />
                </div>
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <PeoplePicker
                    context={this.props.context}
                    titleText="Originator"
                    personSelectionLimit={1}
                    groupName={""} // Leave this blank in case you want to filter from all users
                    ensureUser={true}
                    onChange={this._getChangeInitiatorPeoplePickerItems.bind(this)}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}
                    defaultSelectedUsers={[this.props.context.pageContext.user.email]}
                  />
                </div>
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <TextField
                    label="Document Title "
                    required={true}
                    value={this.state.documentTitle}
                    onChange={this._onDocumentTitleChange.bind(this)}
                    onBlur={this._onDocTitleBlur.bind(this)}
                    errorMessage={this.state.isDocTitleBlank ? "Field cannot be blank" : ""}
                  />
                </div>
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <PeoplePicker
                    context={this.props.context}
                    titleText="Approver"
                    personSelectionLimit={1}
                    groupName={""} // Leave this blank in case you want to filter from all users
                    ensureUser={true}
                    onChange={this._getApproverPeoplePickerItems.bind(this)}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}

                  />
                </div>
                
               
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <Label>Areas <span className={styles.mandatory}>*</span></Label>
                  <Select
                    onChange={this._onAreaCombineResultChange}
                    options={areaCombineResultsOptions}
                    placeholder="Select an option"
                    className={styles.dropdowns}
                  />
                </div>
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <Label>Planned Start Date <span className={styles.columnDesc}>{"(When document will be issued for review)"}</span><span className={styles.mandatory}>*</span></Label>
                  <DatePicker
                    className={styles.dropdowns}
                    allowTextInput={false}
                    ariaLabel={desc}
                    firstDayOfWeek={firstDayOfWeek}
                    strings={DayPickerStrings}
                    //value={this.state.plannedDate}
                    onSelectDate={this.handleChangePlannedDate}
                  />
                </div>
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <PeoplePicker
                    context={this.props.context}
                    titleText="IFI"
                    personSelectionLimit={10}
                    groupName={""} // Leave this blank in case you want to filter from all users
                    ensureUser={true}
                    onChange={this._getIFIPeoplePickerItems.bind(this)}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}

                  />
                </div>
                
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>

                  <Label>Discipline <span className={styles.mandatory}>*</span></Label>
                  <Select
                    onChange={this._onDisciplineCodeChange}
                    options={disciplineCodeOptions}
                    placeholder="Select an option"
                    className={styles.dropdowns}
                  />
                </div>
                
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <Label>Planned End Date <span className={styles.columnDesc}>{"(When document will be complete, issued for use)"}</span><span className={styles.mandatory}>*</span></Label>
                  <DatePicker
                    className={styles.dropdowns}
                    allowTextInput={false}
                    ariaLabel={desc}
                    firstDayOfWeek={firstDayOfWeek}
                    strings={DayPickerStrings}
                    //value={this.state.plannedEndDate}
                    onSelectDate={this.handleChangePlannedEndDate.bind(this)}
                  />
                </div>
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <Label>Security Classification <span className={styles.mandatory}>*</span></Label>
                  <Select
                    onChange={this._onDnrfProjectPhaseChange}
                    options={projectPhaseOptions}
                    placeholder="Select an option"
                    className={styles.dropdowns}
                  />
                </div>

                
                <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                  <Label>Document Type <span className={styles.mandatory}>*</span></Label>
                  <Select
                    onChange={this._onDocumentTypeChange}
                    options={this.state.filteredDocTypes}
                    placeholder="Select an option"
                    className={styles.dropdowns}
                  />
                </div>
                
                {this.state.IsDocumentControlGroupMember &&
                  <React.Fragment>
                    <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                      <Toggle label="Document Control only – Maintenance" onText="On" offText="Off" onChange={this._onToggleChange} />
                    </div>
                    <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}>
                      {this.state.toggleSelected &&
                        <TextField
                          label="Document Number "
                          required={true}
                          value={this.state.documentNumber}
                          onChange={this._onDocumentNumberChange.bind(this)}
                          onBlur={this._onDocNumberBlur.bind(this)}
                          errorMessage={this.state.isDocNumberBlank ? "Field cannot be blank" : ""}
                        />
                      }
                    </div>
                    <div className={'col-sm-4 col-md-4 col-lg-4 col-xl-4'}></div>
                  </React.Fragment>
                }

                <div className={'col-sm-12 col-md-12 col-lg-12 col-xl-12'}>
                  <TextField
                    label="Notes"
                    multiline
                    autoAdjustHeight
                    value={this.state.notes}
                    onChange={this._onNotes.bind(this)}
                  />
                </div>

                <div className="row mt-2">
                  {/* <FilePond 
                      files={this.state.files} allowMultiple={true} onupdatefiles={fileItems => {
                        this.setState({
                          files: fileItems.map(fileItem => fileItem.file)
                        });
                }} /> */}
                </div>

                <div className="container">
                  <div className="row">
                    <div className="d-flex justify-content-end">
                      <PrimaryButton className={styles.formButton} text="Close" onClick={() => Utility.navigateToAllItems(this.props.allItemsPageURL)} />
                      {/* <PrimaryButton className={styles.formButton} text="Submit" onClick={() => this.SaveToDNRFSPList("No")} />  */}
                      <PrimaryButton className={styles.formButton} text="Submit" onClick={this.SaveToDNRFSPList} />
                    </div>
                  </div>
                </div>
              </div>}

              {/* View Form */}
              {this.state.isformModeView && <div className="row">
                <DnrfViewForm description={this.props.description} FormTitle={this.props.FormTitle}
                  DNRFRequestFormList={this.props.DNRFRequestFormList} context={this.props.context}
                  siteUrl={this.props.siteUrl} spHttpClient={this.props.spHttpClient}
                  areaList={this.props.areaList} DNRFRequestsDisciplineList={this.props.DNRFRequestsDisciplineList}
                  DNRFRequestsDocTypeList={this.props.DNRFRequestsDocTypeList} allItemsPageURL={this.props.allItemsPageURL}
                  projectsList={this.props.projectsList} listItemEntityType={this.props.listItemEntityType}
                  DNRFDocLibrary={this.props.DNRFDocLibrary} successMessage={this.props.successMessage}
                  cssPath={this.props.cssPath}>
                </DnrfViewForm>

              </div>}

              {/* Edit Form */}
              {this.state.isformModeEdit && <div className="row">
                <DnrfEditForm description={this.props.description} FormTitle={this.props.FormTitle}
                  DNRFRequestFormList={this.props.DNRFRequestFormList} context={this.props.context}
                  siteUrl={this.props.siteUrl} spHttpClient={this.props.spHttpClient}
                  areaList={this.props.areaList} DNRFRequestsDisciplineList={this.props.DNRFRequestsDisciplineList}
                  DNRFRequestsDocTypeList={this.props.DNRFRequestsDocTypeList} allItemsPageURL={this.props.allItemsPageURL}
                  projectsList={this.props.projectsList} listItemEntityType={this.props.listItemEntityType}
                  DNRFDocLibrary={this.props.DNRFDocLibrary} successMessage={this.props.successMessage}
                  cssPath={this.props.cssPath}>
                </DnrfEditForm>

              </div>}

            </div>
          </div>
        </div>
        {/* </div> */}
      </React.Suspense>
    );
  }
  //#endregion  Render

  /**
   * ComponentDidMount
  */
  //#region  componentDidMount
  public async componentDidMount() {
    try {
      let userDetails = await this.loadUserDetails();
      this.setState({ IsDocumentControlGroupMember: await this.checkIfMemberOfDocumentControlGroup(userDetails) });
      let projectPhaseOptionsArr = JSON.parse(this.props.DNRFDocLibrary).projectPhaseOptions.split(',');
      projectPhaseOptionsArr.forEach(element => {
        projectPhaseOptions.push({ value: element, label: element });
      });
      this.setState({ changeInitiator: userDetails.Id });
      let url = new URL(window.location.href);
      var params = new URLSearchParams(url.search);
      var formMode;
      if (params.has('Mode')) {
        formMode = params.get('Mode');
      }

      if (formMode.toLowerCase() == "new") {
        this.setState({ isformModeNew: true });
      }
      else if (formMode.toLowerCase() == "editform") {
        this.setState({ isformModeEdit: true });
      }
      else {
        this.setState({ isformModeView: true });
      }

      //Load DropDown values only for New and Edit Form
      if (formMode.toLowerCase() != "view") {
        this.setState({
          areaCombineResults: await Utility.getAreaList(this.props),
          disciplineCodes: await Utility.getDisciplineCode(this.props),
          originators: await Utility.getOriginatorCompany(this.props),
          documentTypes: await Utility.getDocumentType(this.props),
          // docNumbers: await Utility.getDocumentNumbers(this.props)
        });

        //Sorting the arrays based on Codes
        this.setState({
          areaCombineResults: this.state.areaCombineResults.sort((a, b) => (a.Title > b.Title) ? 1 : -1),
          disciplineCodes: this.state.disciplineCodes.sort((a, b) => (a.DisciplineCode > b.DisciplineCode) ? 1 : -1),
          originators: this.state.originators.sort((a, b) => (a.CompanyCode > b.CompanyCode) ? 1 : -1),
          documentTypes: this.state.documentTypes.sort((a, b) => (a.DocumentTypeCodes > b.DocumentTypeCodes) ? 1 : -1)

        });
        let dtOP = [];
        this.state.documentTypes.map((item, index) => {
          dtOP.push({
            value: item.DocumentTypeCodes + " - " + item.Title,
            label: item.DocumentTypeCodes + " - " + item.Title
          });
        }
        );
        this.setState({ docTypes: dtOP });
      }
    }
    catch (error) {
      console.log("componentDidMount-" + error);
    }
  }
  ////#endregion ComponentDidMount

}
//#endregion DnrfNewForm Class

class Alert extends React.Component<AlertProps, {}> {
  constructor(props: AlertProps, state: {}) {
    super(props);
  }
  public render() {
    return <MuiAlert elevation={6} variant="filled" {...this.props} />;
  }
}