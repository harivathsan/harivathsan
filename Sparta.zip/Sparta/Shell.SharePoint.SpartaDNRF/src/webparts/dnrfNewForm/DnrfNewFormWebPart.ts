import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'DnrfNewFormWebPartStrings';
import DnrfNewForm from './components/DnrfNewForm';
import { IDnrfNewFormProps } from './components/IDnrfNewFormProps';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient} from '@microsoft/sp-http';

export interface IDnrfNewFormWebPartProps {
  description: string;
  FormTitle:string;
  DNRFRequestFormList:string;
  context:WebPartContext;
  siteUrl:string;
  spHttpClient:SPHttpClient;
  areaList:string;
  DNRFRequestsDisciplineList:string;
  DNRFRequestsDocTypeList:string;
  allItemsPageURL:string;
  projectsList:string;
  listItemEntityType:string;
  DNRFDocLibrary:string;
  successMessage:string;
  cssPath:string;
}

export default class DnrfNewFormWebPart extends BaseClientSideWebPart<IDnrfNewFormWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IDnrfNewFormProps> = React.createElement(
      DnrfNewForm,
      {
        description: this.properties.description,
        FormTitle: this.properties.FormTitle,
        DNRFRequestFormList: this.properties.DNRFRequestFormList,
        context: this.context,
        siteUrl:this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        areaList: this.properties.areaList,
        DNRFRequestsDisciplineList: this.properties.DNRFRequestsDisciplineList,
        DNRFRequestsDocTypeList: this.properties.DNRFRequestsDocTypeList,
        allItemsPageURL:this.properties.allItemsPageURL,
        projectsList:this.properties.projectsList,
        listItemEntityType: this.properties.listItemEntityType,
        DNRFDocLibrary: this.properties.DNRFDocLibrary,
        successMessage: this.properties.successMessage,
        cssPath:this.properties.cssPath
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [                
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('FormTitle', {
                  label: "Please provide the Form Title"
                }),
                PropertyPaneTextField('DNRFRequestFormList', {
                  label: "Please provide DNRF Request Form List"
                }),
                PropertyPaneTextField('areaList', {
                  label: "Please provide Area List Name"
                }),
                PropertyPaneTextField('DNRFRequestsDisciplineList', {
                  label: "Please provide Discipline List Name"
                }),
                PropertyPaneTextField('DNRFRequestsDocTypeList', {
                  label: "Please provide Documemt Type List Name"
                }),
                PropertyPaneTextField('allItemsPageURL', {
                  label: "Please provide List All Items View URL"
                }),
                PropertyPaneTextField('projectsList', {
                  label: "Please provide Projects List"
                }),
                PropertyPaneTextField('listItemEntityType', {
                  label: "Please provide DNRF List Item Entity type"
                }),
                PropertyPaneTextField('DNRFDocLibrary', {
                  label: "Please provide Doc Library Details"
                }),
                PropertyPaneTextField('successMessage', {
                  label: "Please provide success Message"
                }),
                PropertyPaneTextField('cssPath', {
                  label: "~CSS Path"
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
