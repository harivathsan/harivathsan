declare interface IDnrfNewFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DnrfNewFormWebPartStrings' {
  const strings: IDnrfNewFormWebPartStrings;
  export = strings;
}
