import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters,
  RowAccessor
} from '@microsoft/sp-listview-extensibility';
import { SPComponentLoader } from "@microsoft/sp-loader";
import { Dialog } from '@microsoft/sp-dialog';
import * as strings from 'DnrfListViewCommandSetCommandSetStrings';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IDnrfListViewCommandSetCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  sampleTextTwo: string;
}

const LOG_SOURCE: string = 'DnrfListViewCommandSetCommandSet';
var UATid = "947ad4aa-cb27-41c1-8adb-9d6c0c155c33";
var PRODid = "83b5d6a7-4f5c-4305-8c29-f0d882e08b7e";
export default class DnrfListViewCommandSetCommandSet extends BaseListViewCommandSet<IDnrfListViewCommandSetCommandSetProperties> {

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized DnrfListViewCommandSetCommandSet');

    //PROD List GUIDs
    //BJSA => 0dce076f-8819-4dda-b915-5acb7aa8d2c1
    //GDM  => d813c007-cc70-4ec3-a45f-4cd084a217f9
    //Injecting CSS to hide OOTB buttons
    //if (this.context.pageContext.list.title.toLowerCase() == "bjsa document number request form" || this.context.pageContext.list.title.toLowerCase() == "gdm document number request form"){
    if (this.context.pageContext.list.id.toString() == UATid || this.context.pageContext.list.id.toString() == PRODid) {
      SPComponentLoader.loadCss("../SiteAssets/DNRF/DNRFHideBtn.css");
    }
    return Promise.resolve();
  }

  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {
    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');
    const compareTwoCommand: Command = this.tryGetCommand('COMMAND_2');
    // var listName = this.context.pageContext.list.title.toLowerCase();

    // compareOneCommand.visible = (event.selectedRows.length === 1 && (listName == "bjsa document number request form" || listName == "gdm document number request form"));
    // compareTwoCommand.visible = (event.selectedRows.length === 0 && (listName == "bjsa document number request form" || listName == "gdm document number request form"));

    var listGUID = this.context.pageContext.list.id.toString();

    compareOneCommand.visible = (event.selectedRows.length === 1 && (listGUID == UATid || listGUID == PRODid));
    compareTwoCommand.visible = (event.selectedRows.length === 0 && (listGUID == UATid || listGUID == PRODid));

  }

  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void {
    //var listName = this.context.pageContext.list.title.toLowerCase();
    var listGUID = this.context.pageContext.list.id.toString();
    switch (event.itemId) {
      case 'COMMAND_1':
        const selectedRow: RowAccessor = event.selectedRows[0];
        selectedRow.getValueByName('ID');
        if (listGUID == UATid || listGUID == PRODid) {
          window.location.href = this.context.pageContext.web.absoluteUrl + "/SitePages/DNRF.aspx?Mode=EditForm&itemID=" + selectedRow.getValueByName('ID');
        }
        // else if (listGUID == "823ba1da-ba86-435d-a1aa-1ff8018d8709" || listGUID == "d813c007-cc70-4ec3-a45f-4cd084a217f9") {
        //   window.location.href = this.context.pageContext.web.absoluteUrl + "/SitePages/GDM-DNRF.aspx?Mode=EditForm&itemID=" + selectedRow.getValueByName('ID');
        // }

        break;
      case 'COMMAND_2':
        if (listGUID == UATid || listGUID == PRODid) {
          window.location.href = this.context.pageContext.web.absoluteUrl + "/SitePages/DNRF.aspx?Mode=New";
        }
        // else if (listGUID == "823ba1da-ba86-435d-a1aa-1ff8018d8709" || listGUID == "d813c007-cc70-4ec3-a45f-4cd084a217f9") {
        //   window.location.href = this.context.pageContext.web.absoluteUrl + "/SitePages/GDM-DNRF.aspx?Mode=New";
        // }

        break;
      default:
        throw new Error('Unknown command');
    }
  }
}
