declare interface IDnrfListViewCommandSetCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'DnrfListViewCommandSetCommandSetStrings' {
  const strings: IDnrfListViewCommandSetCommandSetStrings;
  export = strings;
}
