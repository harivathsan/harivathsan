import * as React from 'react';
import styles from './SpartaRecognition.module.scss';
import { ISpartaRecognitionProps } from './ISpartaRecognitionProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Button, Label, Input, UncontrolledTooltip } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { sp } from "@pnp/sp";
import { PermissionKind } from "@pnp/sp/security";
import "@pnp/sp/profiles";
import ReactQuill from "react-quill";
import 'react-quill/dist/quill.snow.css';
import { Web } from 'sp-pnp-js';
import * as pnp from 'sp-pnp-js';
import swal from 'sweetalert';
import { SPComponentLoader } from '@microsoft/sp-loader';
import Select from 'react-select';

const info = "data:image/svg+xml;base64,PHN2ZyBpZD0iR3JvdXBfMjE5MCIgZGF0YS1uYW1lPSJHcm91cCAyMTkwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIHZpZXdCb3g9IjAgMCAxMCAxMCI+DQogIDxkZWZzPg0KICAgIDxjbGlwUGF0aCBpZD0iY2xpcC1wYXRoIj4NCiAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGVfMjE1MyIgZGF0YS1uYW1lPSJSZWN0YW5nbGUgMjE1MyIgd2lkdGg9IjEwIiBoZWlnaHQ9IjEwIiBmaWxsPSJub25lIi8+DQogICAgPC9jbGlwUGF0aD4NCiAgPC9kZWZzPg0KICA8ZyBpZD0iR3JvdXBfMjE4OSIgZGF0YS1uYW1lPSJHcm91cCAyMTg5IiBjbGlwLXBhdGg9InVybCgjY2xpcC1wYXRoKSI+DQogICAgPGNpcmNsZSBpZD0iRWxsaXBzZV8yIiBkYXRhLW5hbWU9IkVsbGlwc2UgMiIgY3g9IjQuNSIgY3k9IjQuNSIgcj0iNC41IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLjUgMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEiLz4NCiAgICA8cGF0aCBpZD0iUGF0aF8zMjkiIGRhdGEtbmFtZT0iUGF0aCAzMjkiIGQ9Ik01LjU3NiwyLjZhLjU3Ni41NzYsMCwxLDEtLjU4NC0uNTc2LjU3OS41NzksMCwwLDEsLjU4NC41NzZNNC41Niw0LjE3M2guODhWNy45NzlINC41NloiLz4NCiAgPC9nPg0KPC9zdmc+DQo=";
//#region State Interface
export interface ISpartaRecognitionStates {
  spContext: any;
  from: any[];
  fromEmail: any[];
  To: any[];
  ToName: string;
  manager: any[];
  managerEmail: string[];
  recognitionValues: string;
  SelectedRecognition: any[];
  RecognitionValue: any[];
  Message: string;
  Validated: boolean;
  fieldDisabled: boolean;
  insertSuccess: boolean;
  insertFailed: boolean;
  CurrentUserHasPermission: boolean;
  newForm: boolean;
  nominationCategories: any[];
}
//#endregion State Interface

export default class SpartaRecognition extends React.Component<ISpartaRecognitionProps, ISpartaRecognitionStates> {
  //#region Constructor
  constructor(props) {
    super(props);
    this.state = {
      spContext: this.props.context,
      from: [],
      fromEmail: [],
      To: [],
      ToName: "",
      manager: [],
      managerEmail: [],
      recognitionValues: "",
      SelectedRecognition: [],
      RecognitionValue: [],
      Message: "",
      Validated: false,
      fieldDisabled: false,
      CurrentUserHasPermission: true,
      insertSuccess: false,
      insertFailed: false,
      newForm: true,
      nominationCategories: [],
    };
    sp.setup(this.state.spContext);
    this.onSelectFrom = this.onSelectFrom.bind(this);
    this.onSelectTo = this.onSelectTo.bind(this);
    this.onSelectManager = this.onSelectManager.bind(this);
    this.getRecognitionValueDetails = this.getRecognitionValueDetails.bind(this);
    this.GetCurrentUser = this.GetCurrentUser.bind(this);
    this.GetManager = this.GetManager.bind(this);
    this.handleChangeMessage = this.handleChangeMessage.bind(this);
    this.OnSelectCheckbox = this.OnSelectCheckbox.bind(this);
    this._submit = this._submit.bind(this);
    this.validateFields = this.validateFields.bind(this);
    this.newForm = this.newForm.bind(this);
    let cssPath: string = escape(this.props.cssPath);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
  }
  //#endregion Constructor

  public render(): React.ReactElement<ISpartaRecognitionProps> {
    return (
      <div className="container-fluid">
        <div className="row">
          <div className={`${'col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0'} ${styles.spartaRecognition}`}>
            {/* //The banner */}

            <div className={`col-sm-12 col-md-12 col-lg-12 col-xl-12 ${styles.topBanner}`}>
              <div className={styles.headerIMG}>
                <img src={this.props.HeaderImage}></img>
              </div>
              <div className={`col-sm-8 col-md-8 col-lg-8 col-xl-8 ${styles.bannerTextArea}`}>
                <Label className={styles.headerText} >{this.props.HeaderText}</Label>
                <Label className={styles.headerDescription} >{this.props.HeaderDescription}{' '}<img id="info-toolTip" className={styles.info} src={info}></img></Label>
                <UncontrolledTooltip
                  placement="bottom"
                  autohide={false}
                  target="info-toolTip" >
                  <Label className={styles.headerDescription} >{this.props.HeaderTooltip}</Label>
                </UncontrolledTooltip>
              </div>
            </div>



            {/* //the Form */}
            {this.state.newForm ?
              <div className={`col-sm-12 col-md-12 col-lg-12 col-xl-12 ${styles.form}`}>
                <div className="row">
                  <div className={'col-sm-6 col-md-6 col-lg-6 col-xl-6'}>
                    <Label className={styles.formLabel} >From{" "}<Label className={styles.star}>*</Label></Label>
                    <PeoplePicker
                      context={this.state.spContext}
                      personSelectionLimit={1}
                      groupName={""}
                      defaultSelectedUsers={this.state.fromEmail}
                      showtooltip={true}
                      onChange={this.onSelectFrom}
                      showHiddenInUI={false}
                      principalTypes={[PrincipalType.User]}
                      resolveDelay={1000}
                      required={true}
                      ensureUser={true} />
                  </div>
                  <div className={'col-sm-6 col-md-6 col-lg-6 col-xl-6'}>
                    <Label className={styles.formLabel} >To{" "}<Label className={styles.star}>*</Label></Label>
                    <PeoplePicker
                      context={this.state.spContext}
                      personSelectionLimit={100}
                      groupName={""}
                      showtooltip={true}
                      onChange={this.onSelectTo}
                      showHiddenInUI={false}
                      principalTypes={[PrincipalType.User]}
                      resolveDelay={1000}
                      required={true}
                      ensureUser={true} />
                  </div>
                  <div className={'col-sm-6 col-md-6 col-lg-6 col-xl-6'}>
                    <Label className={styles.formLabel} >Line Manager{" "}<Label className={styles.star}>*</Label></Label>
                    <PeoplePicker
                      context={this.state.spContext}
                      personSelectionLimit={100}
                      groupName={""}
                      defaultSelectedUsers={this.state.managerEmail}
                      showtooltip={true}
                      onChange={this.onSelectManager}
                      showHiddenInUI={false}
                      principalTypes={[PrincipalType.User]}
                      resolveDelay={1000}
                      required={true}
                      disabled={this.state.fieldDisabled}
                      ensureUser={true} />
                  </div>
                  <div className={'col-sm-6 col-md-6 col-lg-6 col-xl-6'}>
                    <Label className={styles.formLabel} >Nomination Categories{" "}<Label className={styles.star}>*</Label></Label>
                    {/* <div className={styles.checkboxArea}>
              {this.state.RecognitionValue.map((item,key)=>{
                        return(
                          <Label className={styles.checkbox}><Input type="checkbox"  name={item.Title} value={item.Title} onChange={this.OnSelectCheckbox}></Input>{" "}{item.Title}</Label>
                        );}
              )}
             
              </div> */}
                    <Select
                      onChange={this.onChangeCategories.bind(this)}
                      options={this.state.nominationCategories}
                      placeholder="Select Categories"
                      isMulti
                      className={styles.dropdowns}>
                    </Select>
                  </div>

                  <div className={'col-sm-12 col-md-12 col-lg-12 col-xl-12'}>
                    <Label className={styles.formLabel} >Description{" "}<Label className={styles.star}>*</Label></Label>
                    <ReactQuill
                      theme='snow'
                      onChange={this.handleChangeMessage}
                      style={{ minHeight: '45px' }}
                    />
                  </div>
                  <div className={`col-sm-12 col-md-12 col-lg-12 col-xl-12 ${styles.buttonArea}`}>
                    <Button className={styles.SubmitButton} disabled={!this.state.Validated} onClick={this._submit}>Send</Button>
                    <Button className={styles.ResetButton} onClick={this.newForm}>Reset</Button>
                    {
                      !this.state.CurrentUserHasPermission ?
                        <Label className={styles.errorMessage}>You do not have permission to submit recognition for your colleague. Please contact: {this.props.contactPerson}</Label>
                        : ""
                    }
                  </div>

                </div>
              </div> : ""
            }

          </div>
        </div>
      </div>

    );
  }


  //#region Methods
  /**
  * component did mount
  */
  public async componentDidMount() {
    let userDetails = await this.GetCurrentUser();
    const web = new pnp.Web(this.props.context.pageContext.site.absoluteUrl);
    const perms2 = await web.currentUserHasPermissions(PermissionKind.AddListItems);

    this.setState({ fromEmail: [userDetails.Email], CurrentUserHasPermission: perms2 });
    this.setState({ from: [userDetails.Id] });
    this.getRecognitionValueDetails();
  }

  /**
   * Gets current user details
   * @returns 
   */
  private async GetCurrentUser(): Promise<any> {
    try {
      const web = new pnp.Web(this.props.context.pageContext.site.absoluteUrl);
      return await web.currentUser.get();
    }
    catch (error) {
      console.log("Error in spLoggedInUserDetails : " + error);
    }
  }

  public onChangeCategories(items:any[]) {
    let values=[];
    items.map(item=>{
      values.push(item.value);
    });
    let text="";
    values.map((category) => {
      text += category + ', ';
    });
    text = text.slice(0, -2);
    this.setState({ SelectedRecognition: values, recognitionValues: text }, () => this.validateFields());
  }
  /**
 * gets Recognition values details  from Recognition values list
 * @returns 
 */
  public async getRecognitionValueDetails(): Promise<any> {
    return this.props.spHttpClient.get(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.recognitionValuesList}')/items?$select=Title&$orderby=Order`,
      SPHttpClient.configurations.v1)
      .then(
        (response: SPHttpClientResponse) => {
          response.json().then((responseJSON) => {
            this.setState({ RecognitionValue: responseJSON.value });
            let optionValues = [];
            responseJSON.value.map(item => {
              optionValues.push({ value: item.Title, label: item.Title });
            });
            this.setState({ nominationCategories: optionValues });
            console.log("Recognition values: ", optionValues);
          });
          return response.json();
        },
        (error: any): void => {
          alert("Recognition Values List Does not exist");
        });
  }

  /**
  * On select Form people picker
  * @param items 
  */
  public onSelectFrom(items: any[]) {
    let arr1 = [];
    // let email=[];
    // let name="";
    if (items.length > 0) {
      items.forEach(element => {
        arr1.push(element.id);
        // email=element.secondaryText;
      });
    }
    this.setState({ from: arr1 }, () => this.validateFields());
  }

  /**
   * on select Recipient People picker
   * @param items 
   */
  public async onSelectTo(items: any[]) {
    let arr1 = [];
    let loginName = [];
    let email = "";
    let name = "";
    if (items.length > 0) {
      this.setState({ manager: [], managerEmail: [] });
      items.forEach(element => {
        arr1.push(element.id);
        loginName.push(element.loginName);
        name += element.text + ', ';
      });
      this.GetManager(loginName);
    }
    else {
      this.setState({ manager: [], managerEmail: [] });
    }
    this.setState({ To: arr1, ToName: name.slice(0, -2) }, () => this.validateFields());
  }

  /**
  * Gets recipient's manager details
  * @param value 
  * @returns 
  */
  private async GetManager(value: any[]): Promise<any> {
    this.setState({ fieldDisabled: true });
    let Manager = [];
    let ManagerID = [];
    await value.map(async (item) => {
      this.setState({ fieldDisabled: true });
      const profile = await sp.profiles.getPropertiesFor(item);//gets details of recipient
      //const profile = await sp.profiles.getPropertiesFor(value[0]);
      var props = {};
      profile.UserProfileProperties.forEach((prop) => {
        props[prop.Key] = prop.Value;
      });
      profile.userProperties = props;

      const mProfile = await sp.profiles.getPropertiesFor(profile.userProperties.Manager);//gets details of recipient's manager's  details
      var mProps = {};
      mProfile.UserProfileProperties.forEach((prop) => {
        mProps[prop.Key] = prop.Value;
      });
      mProfile.userProperties = mProps;
      Manager.push(mProfile.userProperties["WorkEmail"]);//captures manager's email
      //this.setState({fieldDisabled:false});
      try {
        let web;
        if (this.props.topSiteURL === "" || this.props.topSiteURL === undefined || this.props.topSiteURL == null) {
          web = new Web(this.props.siteUrl);
        }
        else {
          web = new Web(this.props.topSiteURL);
        }
        await web.siteUsers.getByEmail(mProfile.userProperties["WorkEmail"]).get().then(user => {
          ManagerID.push(user.Id);//captures manager's ID
          // let managerIDs=this.state.manager.slice();
          // let managerEmails=this.state.managerEmail.slice();
          let managerIDs = this.state.manager.slice();
          let managerEmails = this.state.managerEmail.slice();
          if (managerIDs.indexOf(user.Id) === -1) {
            managerIDs.push(user.Id);
            managerEmails.push(mProfile.userProperties["WorkEmail"]);
          }
          this.setState({ manager: managerIDs, managerEmail: managerEmails });
        });
      }
      catch (e) {
        console.log('Error getting Id of user by Email ', e);
      }
      finally {
        this.setState({ fieldDisabled: false }, () => this.validateFields());
      }
    });
    // this.setState({manager:ManagerID,managerEmail:Manager,fieldDisabled:false},()=>this.validateFields());

  }

  /**
    * On select Line Manager people picker
    * @param items 
    */
  public async onSelectManager(items: any[]) {
    let arr1 = [];
    let email = "";
    if (items.length > 0) {
      items.forEach(element => {
        arr1.push(element.id);
        email = element.secondaryText;
      });
    }
    this.setState({ manager: arr1 }, () => this.validateFields());
  }

  /**
 * On Select Checkbox of Recognition Values
 * @param e 
 */
  public OnSelectCheckbox(e) {
    let Recognition = this.state.SelectedRecognition;

    if (e.target.checked) {
      Recognition.push(e.target.defaultValue);
    }
    else {
      var index = Recognition.indexOf(e.target.defaultValue);
      if (index !== -1) {
        Recognition.splice(index, 1);
      }
    }

    let text = "";
    Recognition.map((item) => {
      text += item + ', ';
    });
    text = text.slice(0, -2);

    this.setState({ SelectedRecognition: Recognition, recognitionValues: text }, () => this.validateFields());
  }


  /**
     * Handle changes in text multi line textbox
     * @param e 
     * @param text 
     */
  public handleChangeMessage(e, text) {
    if (text.ops.length === 1 && text.ops[0].delete != undefined) {
      this.setState({ Message: "" }, () => this.validateFields());
    }
    else {
      this.setState({ Message: e }, () => this.validateFields());
    }


  }

  /**
   * Validate Fields
   */
  public validateFields() {
    if (this.state.from.length === 0 || this.state.To.length === 0 || this.state.manager.length === 0 || this.state.recognitionValues === "" || this.state.Message === "") {
      this.setState({ Validated: false });
    }
    else {
      this.setState({ Validated: true });
    }
  }

  /**
   * Submits the form
   */
  public _submit = async (): Promise<void> => {
    const body: string = JSON.stringify({
      __metadata: { type: `SP.Data.${this.props.metadataType}` },
      FromId: this.state.from[0],
      ToId: { "results": this.state.To },
      LineManagerId: { "results": this.state.manager },
      Description: this.state.Message,
      RecognizedFor: this.state.recognitionValues,
    });
    console.log("body: ", body);
    this.props.context.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items`,
      SPHttpClient.configurations.v1,
      {
        headers: {
          'Accept': 'application/json;odata=verbose',
          'Content-type': 'application/json;odata=verbose',
          'odata-version': ''
        },
        body: body
      })
      .then((response: SPHttpClientResponse): void => {
        if (response.ok) {
          response.json().then((response1) => {
            if (response1 != null) {
              swal("Success", `You have Recognised ${this.state.ToName}`, "success")
                .then((value) => {
                  if (value) {
                    this.newForm();
                  }
                });


            }
          });
        }
        else {
          swal("Error!", "Failed", "error");
        }
      }, (error: any): void => {
        alert("ERROR");
      });

    this.setState({ Validated: false });
  }

  /**
   * Renders New Form
   */
  public async newForm() {
    await this.setState({ newForm: false }, async () => await this.validateFields());
    this.setState({
      To: [],
      ToName: "",
      manager: [],
      managerEmail: [],
      recognitionValues: "",
      SelectedRecognition: [],
      Message: "",
      Validated: false,
      newForm: true
    }, () => this.validateFields());
  }
  //#endregion Methods
}
