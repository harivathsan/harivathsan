declare interface ISpartaRecognitionWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpartaRecognitionWebPartStrings' {
  const strings: ISpartaRecognitionWebPartStrings;
  export = strings;
}
