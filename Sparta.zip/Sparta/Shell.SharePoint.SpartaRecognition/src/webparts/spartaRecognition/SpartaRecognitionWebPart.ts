import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'SpartaRecognitionWebPartStrings';
import SpartaRecognition from './components/SpartaRecognition';
import { ISpartaRecognitionProps } from './components/ISpartaRecognitionProps';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient} from '@microsoft/sp-http';

export interface ISpartaRecognitionWebPartProps {
  description: string;
  context:WebPartContext;
  siteUrl: string;
  spHttpClient:SPHttpClient;
  listName:string;
  metadataType:string;
  recognitionValuesList:string;
  HeaderText:string;
  HeaderDescription:string;
  HeaderTooltip:string;
  HeaderImage:string;
  topSiteURL:string;
  contactPerson:string;
  cssPath:string;
}

export default class SpartaRecognitionWebPart extends BaseClientSideWebPart<ISpartaRecognitionWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ISpartaRecognitionProps> = React.createElement(
      SpartaRecognition,
      {
        description: this.properties.description,
        listName:this.properties.listName,
        siteUrl:this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        context: this.context,
        recognitionValuesList:this.properties.recognitionValuesList,
        metadataType:this.properties.metadataType,
        HeaderText:this.properties.HeaderText,
        HeaderDescription:this.properties.HeaderDescription,
        HeaderTooltip:this.properties.HeaderTooltip,
        HeaderImage:this.properties.HeaderImage,
        topSiteURL: this.properties.topSiteURL,
        contactPerson:this.properties.contactPerson,
        cssPath:this.properties.cssPath
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('listName', {
                  label: "Enter Recognition List Name"
                }),
                PropertyPaneTextField('metadataType', {
                  label: "Enter List MetaData Type"
                }),
                PropertyPaneTextField('topSiteURL', {
                  label: "[Prod]Enter Top Site URL"
                }),
                PropertyPaneTextField('recognitionValuesList', {
                  label: "Enter Recognition Values List Name"
                }),
                PropertyPaneTextField('HeaderText', {
                  label: "Enter the Header text"
                }),
                PropertyPaneTextField('HeaderDescription', {
                  label: "Enter the Header Description text"
                }),
                PropertyPaneTextField('HeaderTooltip', {
                  label: "Enter the Header Tooltip text"
                }),
                PropertyPaneTextField('HeaderImage', {
                  label: "Enter the Header Image URL"
                }),
                PropertyPaneTextField('contactPerson', {
                  label: "Enter the Contact person details"
                }),
                PropertyPaneTextField('cssPath', {
                  label: "Enter the CSS Path"
                }),
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
