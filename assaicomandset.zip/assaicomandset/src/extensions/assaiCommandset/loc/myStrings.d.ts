declare interface IAssaiCommandsetCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'AssaiCommandsetCommandSetStrings' {
  const strings: IAssaiCommandsetCommandSetStrings;
  export = strings;
}
