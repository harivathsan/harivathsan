/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Assai Distribution Form
Project Handled By                 : AI&DS
Module Name						             : Assai Distribution Form Command Set
Module Description                 : Custom New,Edit and View Button
Author                             : Firdous Ali K.A
Created Date                       : 22nd October 2024
Modified Date                      : 22nd October 2024
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/
import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';
import { SPPermission } from '@microsoft/sp-page-context';
import { SPComponentLoader } from '@microsoft/sp-loader';
import * as strings from 'AssaiCommandsetCommandSetStrings';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IAssaiCommandsetCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  sampleTextTwo: string;
}

const LOG_SOURCE: string = 'AssaiCommandsetCommandSet';

export default class AssaiCommandsetCommandSet extends BaseListViewCommandSet<IAssaiCommandsetCommandSetProperties> {

  //Global Variable
  private canCreate: boolean = false;
  private canEdit: boolean = false;
  private canView: boolean = false;
  //private listTitle: string = null;
  private listID:any = null;
  //private CONST_LIST_NAME: string = 'assaidistributionform';
  private CONST_LIST_ID:any = '8674e523-65da-49da-b562-9bbe04358589';

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized AssaiCommandsetCommandSet');
    console.log("Begin Assai CommandSet");
    this.canCreate = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.addListItems);
    this.canEdit = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.editListItems);
    this.canView = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.viewListItems);
    //this.listTitle = this.context.pageContext.list.title;
    this.listID = this.context.pageContext.list.id;
    
    //if (this.listTitle.toLowerCase() === this.CONST_LIST_NAME) {
    if (this.listID["_guid"]=== this.CONST_LIST_ID) {
      var pathofcss = this.context.pageContext.web.absoluteUrl + '/SiteAssets/DRFcss/DRFHideBtn.css';
      SPComponentLoader.loadCss(pathofcss);
    }
    return Promise.resolve();
  }

  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {
    const NewItem: Command = this.tryGetCommand('New Item');
    const EditItem: Command = this.tryGetCommand('Edit Item');
    const ViewItem: Command = this.tryGetCommand('View Item');

    //f (this.listTitle.toLowerCase() === this.CONST_LIST_NAME) {
   if (this.listID["_guid"]=== this.CONST_LIST_ID) {
      //Create Access
      if (NewItem) {
        if (this.canCreate) {
          NewItem.visible = event.selectedRows.length === 0;
          console.log("Is User has Create access: " + this.canCreate);
        } else {
          NewItem.visible = false;
        }
      }
      //Edit Access
      if (EditItem) {
        if (this.canEdit) {
          EditItem.visible = event.selectedRows.length === 1;
          console.log("Is User has Edit access: " + this.canEdit);
        } else {
          EditItem.visible = false;
        }
      }
      //View Access
      if (ViewItem) {
        if (this.canView) {
          ViewItem.visible = event.selectedRows.length === 1;
          console.log("Is User has View access: " + this.canView);
        } else {
          ViewItem.visible = false;
        }
      }
    }//End If Library
    else {
      NewItem.visible = false;
      ViewItem.visible = false;
      EditItem.visible = false;
    }
  }//onListViewUpdated

  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void {
    const itemID: number = event.selectedRows.length > 0 ? event.selectedRows[0].getValueByName('ID') : null;
    console.log(event.itemId);
   // if (this.listTitle.toLowerCase() === this.CONST_LIST_NAME) {
      if (this.listID["_guid"]=== this.CONST_LIST_ID) {
      switch (event.itemId) {
        case 'New Item':
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/AssaiDistributionForm.aspx?Mode=New`);
          break;
        case 'Edit Item':
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/AssaiDistributionForm.aspx?itemID=${itemID}&Mode=EditForm`);
          break;
        case 'View Item':
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/AssaiDistributionForm.aspx?itemID=${itemID}&Mode=View`);
          break;
      }
    }
    console.log("End Assai CommandSet");
  }//onExecute

}//End Class
