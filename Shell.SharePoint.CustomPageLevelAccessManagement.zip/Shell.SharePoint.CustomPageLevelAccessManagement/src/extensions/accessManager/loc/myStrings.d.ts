declare interface IAccessManagerApplicationCustomizerStrings {
  Title: string;
}

declare module 'AccessManagerApplicationCustomizerStrings' {
  const strings: IAccessManagerApplicationCustomizerStrings;
  export = strings;
}
