define([], function() {
  return {
    "Title": "AccessManagerApplicationCustomizer"
  }
});