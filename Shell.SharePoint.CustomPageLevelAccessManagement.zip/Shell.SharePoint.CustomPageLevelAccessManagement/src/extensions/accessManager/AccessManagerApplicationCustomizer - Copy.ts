import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer
} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'AccessManagerApplicationCustomizerStrings';
import * as pnp from "sp-pnp-js"; 
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';

const LOG_SOURCE: string = 'AccessManagerApplicationCustomizer';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IAccessManagerApplicationCustomizerProperties {
  // This is an example; replace with your own property
  testMessage: string;
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class AccessManagerApplicationCustomizer
  extends BaseApplicationCustomizer<IAccessManagerApplicationCustomizerProperties> {

  @override
  public async onInit(): Promise<void> {
    Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);

    let message: string = this.properties.testMessage;
    if (!message) {
      message = '(No properties were provided.)';
    }

    //Dialog.alert(`Hello from ${strings.Title}:\n\n${message}`);

    //Get logged in user details
    let userDetails = await this.GetLoggedInUserDetails();

    //Get Reference Indicator
    let refIndicator = await this.GetReferenceIndicator(userDetails.Email);

    //Get list data
    let listData = await this.GetListData();

    let currentUrl =document.location.href;  
    currentUrl = "https://eu023-sp.shell.com/sites/SPOAA0342/nert/SitePages/DNRF.aspx";
    let filteredData = listData.filter((i)=> i.Title.toLowerCase() == currentUrl.toLowerCase());    

    //if length of filteredData > 0, that means current site url exists in the config list 
    if(filteredData.length > 0){
      if(filteredData[0].ReferenceIndicators == refIndicator){
        Dialog.alert("Access granted");      
      }
      else{
        Dialog.alert("Access Denied");   
        //Navigate to custom access denied page!!
        window.location.href = "https://www.google.com";   
      }
    }    
    return Promise.resolve();
  }

  /**
   * 
   * 
   */
  public async GetLoggedInUserDetails() {
    try {  
      const web = new pnp.Web(this.context.pageContext.site.absoluteUrl);  
      return await web.currentUser.get();   
    } 
    catch (error) {  
      console.log("Error in GetLoggedInUserDetails : " + error);  
    }  
  }

  /**
   * 
   */
  public async GetReferenceIndicator(email){
    try{
      //let endpointURL = "https://eu023-sp.shell.com/sites/SPOAA0342/nert/_api/SP.UserProfiles.PeopleManager/GetMyProperties";                             
      let endpointURL = "https://eu023-sp.shell.com/sites/SPOAA0342/nert/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(AccountName=@v)?@v='" + "i:0%23.f|membership|" + email + "'" ;
      let response = await this.context.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1);
      let results = await response.json();  
      let items = results.UserProfileProperties; 
      items = items.filter((i) => i.Key =="EF-LOBCode");
      return items[0].Value;
    }
    catch(error){
      console.log("Error in GetReferenceIndicator : " + error); 
    }
  }

  /**
   * 
   */
  public async GetListData(){
    try{
      let endpointURL = "https://eu023-sp.shell.com/sites/SPOAA0342/nert/_api/web/lists/getbytitle('Page%20Level%20Custom%20Access%20Management')/Items/";
      let response = await this.context.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1);
      let results = await response.json();  
      let items = results.value;
      return items;
    }
    catch(error)
    {
      console.log("Error in GetListData : " + error); 
    }
  }
}
