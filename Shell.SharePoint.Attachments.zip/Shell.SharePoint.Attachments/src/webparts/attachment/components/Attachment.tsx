import * as React from 'react';
import styles from './Attachment.module.scss';
import { IAttachmentProps } from './IAttachmentProps';
import { escape } from '@microsoft/sp-lodash-subset';
import Upload from './Upload';

export default class Attachment extends React.Component<IAttachmentProps, {}> {
  public render(): React.ReactElement<IAttachmentProps> {
    return (
      <div className={ styles.attachment }>
        <Upload {...this.props}/>
      </div>
    );
  }
}
