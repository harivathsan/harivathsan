import { SPHttpClient } from '@microsoft/sp-http';

export interface IAttachmentProps {
  description: string;
  listName: string;
  spHttpClient: SPHttpClient;  
  siteUrl: string;
}
