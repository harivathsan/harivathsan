import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import {
    Container,
    Row,
    Col,
    Button,
    Form,
    FormGroup,
    Label,
    Input,
} from "reactstrap";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
// Import React FilePond
import { FilePond, registerPlugin } from "react-filepond";
// Import FilePond styles
import "filepond/dist/filepond.min.css";
import FilePondPluginImageExifOrientation from "filepond-plugin-image-exif-orientation";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";

// Register the plugins
registerPlugin(FilePondPluginImageExifOrientation, FilePondPluginImagePreview);

export interface IUploadProps {
    spHttpClient: any;
    siteUrl: any;
    listName: string;
}

export interface IUploadState {
    files: any;
}

export interface IListItem {
    Title?: string;
    Id: number;
}

class Upload extends React.Component<IUploadProps, IUploadState> {
    public readonly state: IUploadState;
    private pond: any;

    constructor(props: IUploadProps) {
        super(props);
        this.state = {
            files: []
        };
    }

    private handleInit = () => {
        console.log("FilePond instance has initialised", this.pond);
    }

    private onupdatefilesHandler = (fileItems: any) => {

        // Set currently active file objects to this.state
        this.setState({
            files: fileItems.map(fileItem => fileItem.file)
        }, () => {
            console.log('Filename:' + this.state.files);
        });

    }
    private getFileBuffer = (uploadedFiles) => {
        let promised = new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.onload = (e) => {
                resolve(e.target.result);
            };
            reader.onerror = (e) => {
                reject(e.target.error);
            };
            //reader.readAsArrayBuffer(uploadedFiles[0]);
            reader.readAsArrayBuffer(uploadedFiles);
        });

        return promised;
    }

    private submitHandler = () => {
        //alert("item submitted");
        this.insertItem();
    }

    private async attachFilesToSpList(uploadedFile:any,itemID:any) {
        try {

            let endpointURL = this.props.siteUrl+"/_api/web/lists/getbytitle('"+this.props.listName+"')/Items("+itemID+")/AttachmentFiles/add(FileName='"+uploadedFile.name+"')";
            let response = await this.props.spHttpClient.post(endpointURL, SPHttpClient.configurations.v1,
                {
                    headers: {
                        'Accept': 'application/json;odata=nometadata',
                        'Content-type': 'application/json;odata=nometadata',
                        'odata-version': ''
                    },
                    body:uploadedFile
                });
                let results = await response.json();    

        } catch (error) {
            console.log("Error in AttachFilesToSpList : " + error);
        }
    }

    private insertItem = () => {
        const body: string = JSON.stringify({
            'Title': `Item ${new Date()}`
        });

        this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items`,
            SPHttpClient.configurations.v1,
            {
                headers: {
                    'Accept': 'application/json;odata=nometadata',
                    'Content-type': 'application/json;odata=nometadata',
                    'odata-version': ''
                },
                body: body
            })
            .then((response: SPHttpClientResponse): Promise<IListItem> => {
                return response.json();
            })
            .then((item: IListItem): void => {
                alert(`ID: ${item.Id} successfully created`);
                const uploadedFiles = this.state.files;
                for (let index = 0; index < uploadedFiles.length; index++) {
                    const uploadedFile = uploadedFiles[index];
                    this.getFileBuffer(uploadedFile).then(() => {
                        /*
                        //upload the file                
                        this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items(${item.Id})/AttachmentFiles/add(FileName='${uploadedFiles[index].name}')`,
                            SPHttpClient.configurations.v1,
                            {
                                headers: {
                                    'Accept': 'application/json;odata=nometadata',
                                    'Content-type': 'application/json;odata=nometadata',
                                    'odata-version': ''
                                },
                                body: uploadedFiles[index]
                            }).then((response) => {
                                console.log(uploadedFiles[index]);
                                console.log("Uploaded file");
                                console.log(response);
                            });
                            */
                           this.attachFilesToSpList(uploadedFile,item.Id);
                    });
                }//End For
            }, (error: any): void => {
                console.log('Error Message:' + error);
            });
    }
    public render() {
        return (
            <div>
                <h2>File Attachment Demo</h2>
                <Container>
                    <Row>
                        <Col xs="12" sm="12" md="12" lg="12">
                            <FilePond
                                ref={ref => (this.pond = ref)}
                                files={this.state.files}
                                allowMultiple={true}
                                allowReorder={true}
                                maxFiles={3}
                                //name="files" {/* sets the file input name, it's filepond by default */}
                                oninit={() => this.handleInit()}
                                // onupdatefiles={fileItems => {
                                //     // Set currently active file objects to this.state
                                //     this.setState({
                                //         files: fileItems.map(fileItem => fileItem.file)
                                //     });
                                // }}
                                onupdatefiles={fileItems => this.onupdatefilesHandler(fileItems)}
                                labelIdle='<span class="filepond--label-action">Browse to Upload the File</span>'
                            />
                        </Col>
                    </Row>
                    <Row>
                        <Col xs="12" sm="12" md="12" lg="12">
                            <button onClick={this.submitHandler}> Submit</button>
                        </Col>
                    </Row>
                </Container>
            </div>
        );
    }
}

export default Upload;
