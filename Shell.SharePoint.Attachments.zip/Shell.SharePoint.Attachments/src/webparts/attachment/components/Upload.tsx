import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import {
    Container,
    Row,
    Col,
    Button,
    Form,
    FormGroup,
    Label,
    Input,
} from "reactstrap";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
// Import React FilePond
import { FilePond, registerPlugin } from "react-filepond";
// Import FilePond styles
import "filepond/dist/filepond.min.css";
import FilePondPluginImageExifOrientation from "filepond-plugin-image-exif-orientation";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";

// Register the plugins
registerPlugin(FilePondPluginImageExifOrientation, FilePondPluginImagePreview);

export interface IUploadProps {
    spHttpClient: any;
    siteUrl: any;
    listName: string;
}

export interface IUploadState {
    files: any;
    uploading: boolean;
    idVal: number;
    listAttachmentFiles: any;
}

export interface IListItem {
    Title?: string;
    Id: number;
    AttachmentFiles?: any;
}

class Upload extends React.Component<IUploadProps, IUploadState> {
    public readonly state: IUploadState;
    private pond: any;

    constructor(props: IUploadProps) {
        super(props);
        this.state = {
            files: [],
            uploading: false,
            idVal: null,
            listAttachmentFiles: 0
        };
    }

    private handleInit = () => {
        console.log("FilePond instance has initialised", this.pond);
    }

    private onupdatefilesHandler = (fileItems: any) => {

        // Set currently active file objects to this.state
        this.setState({
            files: fileItems.map(fileItem => fileItem.file)
        }, () => {
            console.log('Filename:' + this.state.files);
        });

    }
    private getFileBuffer = (uploadedFiles) => {
        let promised = new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.onload = (e) => {
                resolve(e.target.result);
            };
            reader.onerror = (e) => {
                reject(e.target.error);
            };
            //reader.readAsArrayBuffer(uploadedFiles[0]);
            reader.readAsArrayBuffer(uploadedFiles);
        });

        return promised;
    }

    private submitHandler = () => {
        //alert("item submitted");
        this.insertItem();
    }

    private insertItem = () => {
        var groupColl: any = [];
        groupColl.push('Group01');
        groupColl.push('Group03');
        groupColl.push('Group05');


        this.setState(
            {
                uploading: true
            }
        );
        const body: string = JSON.stringify({
            'Title': `Item ${new Date()}`,
            'Group':groupColl
        });

        this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items`,
            SPHttpClient.configurations.v1,
            {
                headers: {
                    'Accept': 'application/json;odata=nometadata',
                    'Content-type': 'application/json;odata=nometadata',
                    'odata-version': ''
                },
                body: body
            })
            .then((response: SPHttpClientResponse): void => {
                response.json().then(async (item: IListItem): Promise<void> => {
                    //alert(`ID: ${item.Id} successfully created`);
                    const uploadedFiles = this.state.files;
                    for (let index = 0; index < (uploadedFiles.length); index++) {
                        const uploadedFile = uploadedFiles[index];
                        await this.getFileBuffer(uploadedFile).then(async () => {
                            //upload the file                
                            await this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items(${item.Id})/AttachmentFiles/add(FileName='${uploadedFiles[index].name}')`,
                                SPHttpClient.configurations.v1,
                                {
                                    headers: {
                                        'Accept': 'application/json;odata=nometadata',
                                        'Content-type': 'application/json;odata=nometadata',
                                        'odata-version': ''
                                    },
                                    body: uploadedFiles[index]
                                }).then((result) => {
                                    //console.log(uploadedFiles[index]);
                                    //console.log("Uploaded file");
                                    console.log(result);
                                    alert(` ${uploadedFiles.length}  Attachment successfully Attached`);
                                    //
                                });
                        });
                    }//End For
                    //alert(` ${uploadedFiles.length}  Attachment successfully Attached`);
                    this.setState(
                        {
                            uploading: false,
                            files: []
                        }
                    );
                }, (error: any): void => {
                    console.log('Error Message:' + error);
                });
            });

    }

    private getAttachmentItem = () => {
        const { idVal } = this.state;
        alert('Get List Attachments !!!' + idVal);
        try {
            this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items(${idVal})?$select=AttachmentFiles,Title&$expand=AttachmentFiles`,
                SPHttpClient.configurations.v1,
                {
                    headers: {
                        'Accept': 'application/json;odata=nometadata',
                        'Content-type': 'application/json;odata=nometadata',
                        'odata-version': ''
                    }
                })
                .then((response: SPHttpClientResponse): void => {
                    response.json().then(async (item: IListItem): Promise<void> => {
                        alert(`ID: ${item.AttachmentFiles.length} successfully created`);


                        try {

                            var fileDetails: any = [];

                            for (let index = 0; index < item.AttachmentFiles.length; index++) {
                                let fileItem = "https://eu023-sp.shell.com" + item.AttachmentFiles[index].ServerRelativeUrl;
                                fileDetails.push(fileItem);
                            }
                        } catch (error) {
                            console.log(error);
                        }

                        //alert(fileDetails);

                        this.setState({
                            listAttachmentFiles: item.AttachmentFiles,
                            files: [
                                {
                                    source: "https://eu023-sp.shell.com/sites/SPOAA0342/ls/AttachmentList/Attachments/72/Decision Tree - Filing for Engineering Support.pptx"
                                },
                                {
                                    source: "https://eu023-sp.shell.com/sites/SPOAA0342/ls/AttachmentList/Attachments/72/New Section 1.one"
                                }
                            ]
                        });



                        /*
                         this.setState({
                             listAttachmentFiles: item.AttachmentFiles,
                             files: [fileDetails.slice(0, -1)]                            
                         });
                         */
                    }, (error: any): void => {
                        console.log('Error Message:' + error);
                    });
                });
        } catch (error) {
            console.log('Error Message:' + error);
        }
    }

    private changeHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
        this.setState({
            idVal: parseInt(event.currentTarget.value)
        });
    }
    public render() {
        const { idVal, listAttachmentFiles } = this.state;
        return (
            <div>
                <h2>File Attachment Demo</h2>
                <Container>
                    <Row>
                        <Col xs="12" sm="12" md="12" lg="12">
                            <FilePond
                                ref={ref => (this.pond = ref)}
                                files={this.state.files}
                                allowMultiple={true}
                                allowReorder={true}
                                maxFiles={5}
                                //name="files" {/* sets the file input name, it's filepond by default */}
                                oninit={() => this.handleInit()}
                                onupdatefiles={fileItems => this.onupdatefilesHandler(fileItems)}
                                labelIdle='<span class="filepond--label-action">Browse to Upload the File</span>'
                            />
                        </Col>
                    </Row>
                    <Row>
                        <Col xs="12" sm="4" md="4" lg="4">
                            <button onClick={this.submitHandler} disabled={this.state.uploading} >Submit Attachments</button>
                            {
                                this.state.uploading ? <img src="https://eu023-sp.shell.com/sites/SPOAA0342/ls/SiteAssets/Loading/Loading.gif" height={50} /> : ""
                            }

                        </Col>
                        <Col xs="12" sm="4" md="4" lg="4">
                            <input type='text' value={idVal} onChange={this.changeHandler} />
                        </Col>
                        <Col xs="12" sm="4" md="4" lg="4">
                            <button onClick={this.getAttachmentItem}>Get Attachement For ID</button>
                        </Col>
                    </Row>
                    <Row>
                        <Col xs="12" sm="12" md="12" lg="12">
                            <h2>Show Attachment Files</h2>
                            <ul>
                                {
                                    listAttachmentFiles.length > 0 ? listAttachmentFiles.map(
                                        (listAttachmentFile: any) => (
                                            <li>FileName:{listAttachmentFile.FileName} url:{listAttachmentFile.ServerRelativeUrl}</li>
                                        )
                                    ) : ''
                                }
                            </ul>
                        </Col>
                    </Row>
                </Container>
            </div>
        );
    }
}

export default Upload;
