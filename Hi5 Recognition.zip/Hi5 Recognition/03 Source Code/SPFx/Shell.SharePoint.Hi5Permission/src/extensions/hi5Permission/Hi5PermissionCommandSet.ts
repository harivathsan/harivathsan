/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Hi5 Recognition
Project Handled By                 : AI&DS Projects
Module Name		                     : Hi5 Permission
Module Description                 : Hide New,Edit and Delete For Contribute access 
Author                             : Firdous Ali K.A
Created Date                       : 4th September 2023
Modified Date                      : 4th September 2023
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/
import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';
import { SPPermission } from '@microsoft/sp-page-context';
import { SPComponentLoader } from '@microsoft/sp-loader';
import * as strings from 'Hi5PermissionCommandSetStrings';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IHi5PermissionCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  sampleTextTwo: string;
}

const LOG_SOURCE: string = 'Hi5 PermissionCommandSet';

export default class Hi5PermissionCommandSet extends BaseListViewCommandSet<IHi5PermissionCommandSetProperties> {
  //Global Variable
  private fullControl: boolean = false;
  private listTitle: string = null;
  private LIST_NAME: string = "hi5 recognition";

  //Begin Methods

  //End Methods

  //Begin Handler

  //Beging Init
  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized Hi5PermissionCommandSet');
    console.log("Hi5 PermissionCommandSet");
    this.fullControl = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.manageWeb);
    this.listTitle = this.context.pageContext.list.title;

    return Promise.resolve();
  }
  //End Init

  //Begin onListViewUpdated
  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {

    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');
    compareOneCommand.visible = false;

    if (this.listTitle.toLowerCase() === this.LIST_NAME) {
      if (event.selectedRows.length > 0 || event.selectedRows.length === 0) {
        if (!this.fullControl) {
          SPComponentLoader.loadCss("https://eu023-sp.shell.com/sites/SPOAA0342/hi5/SiteAssets/CSS/custompermission.css");
        }
      }//End If
    }
  }
  //End onListViewUpdated


  //End Handler




}//End Class
