declare interface IHi5PermissionCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'Hi5PermissionCommandSetStrings' {
  const strings: IHi5PermissionCommandSetStrings;
  export = strings;
}
