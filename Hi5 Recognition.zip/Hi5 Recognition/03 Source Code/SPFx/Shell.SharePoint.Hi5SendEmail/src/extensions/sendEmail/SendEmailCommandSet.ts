/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Hi5 Recognition
Project Handled By                 : AI&DS Projects
Module Name		                     : Hi5 Send Email
Module Description                 : To appreciation Email to Colleague 
Author                             : Firdous Ali K.A
Created Date                       : 31st August 2023
Modified Date                      : 31st August 2023
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/
import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';
import { SPPermission } from '@microsoft/sp-page-context';
import { SPComponentLoader } from '@microsoft/sp-loader';
import * as strings from 'SendEmailCommandSetStrings';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { sp } from "@pnp/sp";

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface ISendEmailCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  sampleTextTwo: string;
}

const LOG_SOURCE: string = 'SendEmailCommandSet';

export default class SendEmailCommandSet extends BaseListViewCommandSet<ISendEmailCommandSetProperties> {

  //Global Variable
  private fullControl: boolean = false;
  private listTitle: string = null;
  private LIST_NAME: string = "hi5 recognition";

  //Begin Methods

  //Begin Format EmailBody
  private formatEmailBody = (recipientName: string, actionDemonstrated: string, linkageBehavior: string, recognizeName: string) => {
    const icon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHsAAABUCAYAAACiPUicAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAEDmSURBVHhe7b0HnF5lmTZ+vb3MzDu9pPeEFFpoISEQaqiLFAkr4qKLKGDXtaNiAdGP/fmta0NdURFchBVBRenN0IRQQkivk0xv77zz9vJd133mZF4mk2Rg/e//+31yh8Mp7zlPua+7Ps9zznhKJLxNfxfkHd6/TX8H9DbYf0f0Nth/R/Q22H9H9DbYf0f0Nth/R/Q/nHoVh/dvhSSXeefQyA+w5dZ4j13YS6NOD04qhA+VrH1uG/0j5djvzm8la4f3zdfxlqmMZyXW/d+ouEyzyztKUgeHt1QyZ5dEhUIOyWSCR7xXv3NXFAZl9+ezZJuuqbiy684FlbXvVixleEt27zbym44L9nwmF0e+mOBZhse8j9eKLDLPn9O5InIllsO7i7r+JjaVrV2R/wqsU/9YpJXv9qGYGeJBhr+kkSrxTv02BhUK7DufGVOFdG0cG4vfuyEvHqj/OuGmisvuHUpkbJ/N6AFgcFDtHJvKNFuFiYj/8JU30LBEpdNJhMNB1lmE1+NIufOsniOrcgX4/X52VuxyfvP6fMO/63xsylM4PKxDm3fUbUUKD4oeeEM6U+fIAF+APOAFtdWnh3ldVKxw2mqaOE4a1pgChlicBMYLH2LwqQvitdrjTTl1qBGliNMd9lHAetjo8v761LZyfrr8eStUSrMCdpLCjECQjKJQ50oIhMNUwjQiFWEqXxrRSBg5Sn0gIF6PTeMCO5nMIloRRDabRTDoxRA1W4D4uEmSVYHfLyRUhnF6+NjpaJ7SmUkXUVFRw3OHXK10tYDyYSSw9+55vcTOeUyodJH359PwBskAL5lLAXCuU5o9QiVMZrSwYSzUI+aPk0oEx+5PmWaXWJEfdaZQSNOylJIsmkALbA/vLVayDgLO6kt293A7DkC6L5vNkG9e453H4+OmZwVOEelMmnwMkacqy+Gbs2f9ZFKJfPbwdwcfCRfLYEHS5KqqKl4/OI0LbGldJpsiWOwgmfHoY49i7ryZZEjeGq1nJc3SeL8/iFAkatdGGi2StPP5UWXvj1Rnib4gnxlEMBAlE9hRMxD8odhKgW+Dp1Kdl0YTDGN4NR9c5FyTNoyXPAJO1iHF5glsAlJiH6zpLCvTw6YP8neZSPGnksyfwt5H2H9CXbaJnXk2Xsc+WjTH+rkklyRS29Te8r3IOS7QahaLshoEuFDA4EAcQ0NJNoetyxZYtg85gj958hREopVmSVWneO/shzVnFL0pM57JpHDvfXdT05NYdsJxGOjtQCwWo7YH+ZuYTjzYQVkAkSPFXkQiEYRDlQiFqdm65vHD5yczvAFKs2PySpRWmV5X0h1SQ1hukW0qkPnihS+BTN9f0b77GfS0v47KcJ5mbYDCTstTaEB9w7vgj4ZR0L3jpGI+zOfJYF8SBa/T9mAhiGCRPjrZhvZda1BdOUjO9LF+6n4ujDlLr4O/YqrEgq0c0e7Rmq5z/StSO80S0gUVCKC76bogSKVSdJFp46MA0zUJTI5WtYLKI77mKQCycsFAGM+/uAZ9fX246qqrWQuFjP9Q8rNtOcNjLBo7Gh91JZ3JUrIGUF9fg1NPPwlf+tIX0dzUiD/94ffYtm0bNb6CWh1GKBRCTU0N5s+fb43TubZoNAp/wMvOZYlbHmwzfb6zV4cpywjIDYjhvKZzXUchj4qwtMXH8mrZ2CgyQxv58F8Q9b1GMDahqZrBWnIQ6SJ9Vmk2mhZ9jwpEgZG5HS+VHPdS8lGzvbIK9NolBqGlXqLejT3P34ZocDuZ3IkAhS2X9eKvbZ9Cw5TzUFtbi+7ubmOwwBFoLkt1Xk5FWipXAdxN97hWQMBLUVRGIpEgz4ewc+s2K1/XB3ltztxZuOAdF2HXnt34xjduxLsvvwKr3vmPtLw5hILRYSGRwuxL4wY7HCZYbOwV730XLr10FWbPmoV7777HgFRDtW9ra8OMGTNMALTJl6jhooqqCCZMqiP4PlRWxigUMTKqHlOmTCGjZIYk4QSeGi6mmHRzXyqk+TuDkHQAyTgNQ2kHdmy+BUcflkVtcCsC+V4lYUjQCuc889A478fsldzN2NI9FpUKDOoYpBV8BNon319imazM08VgohUdL95OodtCGehCRJWRP/esuQIzFlxuIGuTRslKaS9BFYAyp+KNC2yOQVZHRwf97CDi8TgGBgbsWNrc2dlp11SWFETKo+OGujpUVKo/9CQMxtraduP88y9AR1cXfvSjH1MAUrj99l9T++nCaBUVA6musejgYA8LZ7GURX9/D6659v143z9fgTmz5uLXv7jTwNq8ebOZarfjMkfTp083wGXm1ZFZs6dh5+6tpt2SUt2jTR0Uc6qrq62Rel6WYhaFadLEFhrJrAlHKFqPoKceufQGtO+8Bacs8yDb9QT8+ZQZ/jgNQc47E/Vzfs42E2ivwJY7UMfL96JR12jGdVz0MZ0b5pNPmm1gb0fni79GVWgTmdWDsCojfx7YeA1qp5xvbRbIPT09Bpr6JI0U6C6A0lK5vnSqQH5No2KE+RzzeMYVoVCEW8CeratroIJUYM+edirJEAGPMrXqp9AwN6iuRN9AL8uK4/LLL0dndy9++MNbCHYSP//5baiJNbBhAbMO+wPb9xXS8PG+NAx0Pk8/RtO2p20XHnn0TzjuuKNpMsLYtnkXO9lLMKrYcC/a2zvYOQYyfDBDa+D3Byi9cbuWSmURCVXTb1XQZFfRJMYQCdeikiBWx5pt03EFN10vFUMYGixg945e9Han0dmTwI7tA9ixbR269qzG/OkBRHI98GYZmdNB52kR8p5JiDasIm7srEXXklqBWr4f65rSKkX4DKwoOtJrb5HCYnqQQbJ1CwUtyZ+H4Feem63Cgy/UYUtrBrt37zYzK7BdLZU1E9giCYIUQVaurlaAOJG0oxghu7+3t49A19vzW2m2HWvoIeh70N8XZx27ECcfG5uakBhK4KijFiOVzuCZZ55lWz1Yevxy1Nc1sr0CWW5BNe9L+4qA+jeKJCmSQgVoMrU+vxd5mlcU02AAjqC/iOeeeQInLD0a9bUVOGvlyVi/7iXkswk0NcQIoh/btmxgRzZh546t6GjfjcRgP/1zliBXkAkxghxCrCqKGkqwNp17mYYEGOWXuE/l40gXBuELFqi0CsrS1DQ2v6AtxnYFiTmP2TZdLvF4vBvFmTxSYMZAiowS2JY9yPdRiApER5EwIwlep4CYEJAHjIxDDJbi/YPWloCPADL2iISiiIYraFor2fcqxCqrbYtG+DuLTafi6Olus62PQW5vTzva23ZSwDPkRwQvrXkOU6e04IzTV9Dd1eEfzrvQFKmnp49VO4GbXIQsos/n52+dbM/YEXg5jUuzJSkl5rFdXR14/IlHcNyS49jwCB7600OYPXuWpWIXXngBOrs6eU8n1m9Yj7PPPgurV/+FT5NJjLrOP/8cnL5yBY44chHmHTITEyc1obqGARcFQqNniaE+xAd70dHZil2t27B9xyYe72bwNYTegW70DbWT6TS1+T30269gyZH18GXaCbSyAEbiXkaz/hpUNZ5POAiibYpSD755GSwaEdwSMwUBzZq4pyn3dWKw468IhHbzWoJWSTdm8cruBehPVpt/le+Vyd64cZNt27fvwM6du8yqyYRLewVMDYV6ztyZOPzwQ7H8xGVYunQJ3dsMNDU3sO/9WLduLZqaGijIGbS0NLGcrejq7GdgTPMeqyQ/2uGl/C1atJDKVsRTTz1NsINYtPAwxlBzxWqj/Wn22D57H5Jc5wniWnz5K5/Ghz/yIfqIajz0+4cs+n7hhRfwjne8A3/84x/NZ8hELV68GBs2bLDGT5w40Xx7VW2llSUqr1bHCshkQbTpXH4vOZhEPudBX7wPPakO7NmdRrJvDYLp+3HtZdPREqJP1TAm896UJ4FEcA7qF95GjyPVHpF0d+zljeS0Q+SjhRHJIhTp70ulCPwaEZPP9r2Othd/yRRvA3zFPkRlCPjTl395GDa3t2DSpElk/mFobGy0oErmWsGqG2G7AZrOldHongxdjxvUqt/y64pjHn/sCWppO2OjfqxcuRJPP/0saqsnWtuWHH807rzrTvruKK699lr670HceONNCAQjePdlV+Ccs9/BDoiXbLbaOAbtvSzWO5sDrDYzbzzXKFkuXUI2xVxRzKBURehvWhlIbNm2A3Pmzcf6TRuRSCURjDDH5b/1m9Zj7vy5eODhB1DXWMfrNLNMD3L0NT5plIb2JKYsK5tKM9qN2D5WUcn8nT6susYYOGXKJAv2Dj3kcJx+2ll47+X/jOMWLEJjtM5psHrgLSJAACKOm6QEa2POrk0/675hyjGdswvcvMz1C6bVDNCo0R4vXYQnw2d4TYk6+y3u+ViOr0htlxXXxssnnnAMvnTdx/HOi8/ESScejckT6zFpAvvpJwcZNEZCXgz0ddLUDyKXiSOT7qVZD/N60KKCAF3TUHyAcUkfTX0QW8m/oxcfyWf6MG/OHPJgwOrqoZnv6W2nCe+m7w+ZhVAcIGERZSk4g4MDLJGdlwW2q2OTge3e4Mi6/q8r6pVL0jg/C2ZuzJ8DPBZJStetW4d58+Zhy5YtuOyyy3DllVcaSJJWpVCHHHKIafhrNFGKsuVrFIiIent7cc011+DZZ5/FL37xC4vqv/Od79AVdNk1mb+NGzdasBOntCvoSw4xeMlQIDNCllaAPZAiM2zgJh/Mywwmy8kBnH3gVsg6gutFCJ68nxqsUTjl5H7rdVHP2uibSRE3EfeyFKpMFTDvVxtluhVN725tswi6lfu2PZ145ukXGEWnLfDaubMVv/71nQwud5lGChhZv0DQZymVeKT5hs1bNuKee+7Bqaeegu3bdto9c+bMw1VXvR9hKko6k0QoHKBJrze+7EtvRHEscntzQJIJ0iaT44b2MrUCrYkRon4TIK+++qqZX0Wmzc3NlnrpN/mt7du3WyMFtspQiiITeOqpp+Kcc84x5kliW1paLA2bPHkyXnrpJezYsQPPP/+8gS5heOCBB8zkufn7mKTASmPM2li/NuefFxXM7cORKAppWplkBl4GUAYif3OCM8fXO6zRpos6fyNt2LAZL7/8GjZt3IZHH30CL7+0lnFMDPff/yADT5nsDHIUrNV/eRaXrrqMwekO67cUQWmYeKG9+XK6wqVLl+Lqq6823rr827Rpk/Fc0bxiA/Fcz7mR/pulcYEtUiNUiQu2SI2tY9IvEogCQ+BK49WJhoYGa+TMmTNx5plnmo8SyafLDGm4Tz5K5U6YMMHKUmcEvO6VJdAm/y+hWrNmjdWtOlTu/sjx0S5YwySNlUNjwPfy6qfxy5/+DD/7yU+x4+VX7GdT2LLNFRKVYUKgQ5EpUBETWibhkceewkOPPI4jFh+L7l6N+AQwYdJk+nk/1q3fhEhFjG7Dg+raRpxw4il435XvR3dfL8IVUSSVj1Ng6xobrPxOpm/JTBqz581lxuFkIANUJimANgHtjk2If2+Fxg22nL5AUaWuZgtQjQiJBJQAcQMP7SUYrqnXuRoqqdU1+WGVoWBEgiLN1286F5ivv/468/dKy2MlVAp8NDQprVc7gtyPRQ5Q9IplWm0ICWgvNSJISzPQRR+5FpvWv8w4oZ+/O7GJQ5rVdomddtMz0/4RkrWSi5JWyh3pWP2QaZepdXLmrZg/f4FprPqhPkuY89RW9UMDTuKBG6D95je/sZxdZSrC1z36TdZSv4vERz3zVmjcYIsErgu2SI1VBwWerqkhMq86lnZqL4AOP/xw01BJqIRC5cg8C9QPfehDZqY0KrRkyRKsWLHC7lEHp02bZp2///77rd5ly5bZuQkSfx+TiLZM8UjXBB3B1BSo5sH9WYQDOVRFSqgIFbhnbMLfPLxPAZ1ZgP3OmA2Xybb4Ax6CWk1ZKBLUjehizvzCi88x85hAXzuLfQpiwcJ5WHHycnz2c5+yVKq+oc545g66uO5MPDz++ONNKJ544gmrQpZOAiOeCXwBLz6LDxL+t0LjAlvYig+SNlUoZmuT/3EH7AWmGiWg1CBJt87lxzVmLuDVSQEtUidUhjohwZCvlhRrmFQdFeh65qqrrsJ73/teTJ061SyGUhLVpXKKw2VJaFilMU9l6rKu5bNkip8nYWq3bwivP/NHfOG9Z+L3v/03eApbEfDtwL9/9+PIx3fyYQ3Y0K/nGQgF/chp1DDAjqs8ClBeFYgRitBZZFVtBEuXH42LV52Ld156Pk49YzmOP+EonHbmCfCHczhhxdFomVSHVLYPsVqaXV8a8QSjb2YsNXW1NOMp+Ji0+8mHnDS9tgaPE+iFixYhHI1gcCiBSy5dZZbgsMOY5tFFih/qlzAQDyQkIgmOrEW5ix2LxgW2+ilrONp8SPIUicv8Cgj5UQVQAkZ+RT5bQMrXCoT/KQqGK5BNJ+CvYl7vKeClh/+Aj73nEvzklu8QYI21k0H5foRDeba1Dh+55r148oH7MLB7A4GKIEUzH4gxviAwb6QRdml0z8c0y89A3utjKkVB0cIObSVakCwFLZGgS2K+Vihq8YczuSEeCiR3kkhASfBl5sVD7VevXm116F4piviqYFVjFVIglwS8SCC7xweicYGtSXQFpa7kaNOxGixQH374YTPV8l3SUPnd4447Do899hgWLFhgJvqtmp43S8yc+f8BBKv8+MFNn8VHLj8PD/7xDsycXI2ZBHZiYxQ1sQCioSI1f8iGbZcdMRsP3n0r/vUrn8K1l67EYOc2BnL05RWaICn35yOUzTFYygzRDKeQTMUJjDM2USg688lKkyLMn4eooVrJI9A11CxgBbKsoe5zNVHKMHfuXFx44YX4j//4D3NdsoqKyr///e9j9uzZ9oxcnngvcp+V0un4YICPE2yn8NFga6/GS5N/+tOf2vSmfNAJJ5yAT3/607jooouwatUqk0wJwP8MkempTlx16Slo27UWLQ1h9HbuoJ/WoGoRg31JtO/oQzFXiZC/CYMDIVrwPlSV4qjxpzB3Ug1u+bebgChN5PAoioZOS/TjCv7Ya17zUksZaTNPjydyBJvJmi9K8D3o7knwniDWvb4dr63biqaWKXhq9QtIpYFMroAtTEfFzd3tbRhkZrB521aLxhWhZwt59MUHMIka/OXrr8fKs88yy3j22WerY3tdqEy7gHXNuNyfVsT8TcAuJxWozTVHOpb/kORJGpVbf/SjH8VnPvMZ873y6RIK+fL/ESIoHgZHfgJVGfEjSVM6ZVILhgYHsH3rTixbejKOPWY5knEt9yli8RHLkU4MoammArEoTS2FIjMUR7F9Dwt7o9tySAz10ExTcOJJ9PYMoL8vQQuRpkAPoqO9FwG/FgNqLCCLQp4pVD+j6YyWGsEEXwoinokv4qPiD/HRnR0TD2W+Fcx94AMfMEURyOK3jvWstWQYXDdSF412teU0LrDdArR3KxBpCk6N0NbcNMFWqAjcH/7whzjmmGNM4hTEadGDQ/uawzdHbkfcckaXx+7oltQQKis81KR+TJrchO7+AaSzQQZKM7Dk4n9GbeNkdNH05Xn7osVHYkd7N4YYeCXTBYKUx+QJLXRND1KpxUQNuRbgL2XhZz80CifSLKCsmxhdzPEeNiWfySNNd+UniGEGec0NjQgy557K3Lu5oZnCF8XsGbPpRmKY2DwRk1omsK7J1Ngo8ixDFiQ9lLRnG+pqTFBvuOEGW4Ykk1+iCZBAKBhz2iAstAJIFujAWi0aF9iuuVAgJsAFbpiBjGZjNMUmHySQ1RiZcEmugFajtBJVK1HMADL6TNPXabWBxsrz9HNVNdVmxkLRCkau9HdkSCbPlKimltGqM3ig+lSWJhnzhZwtcSI/6QelFdrThPkCtqQJ3gh6dnYRKLaHprk/0YWSP4jO/jA+8YWfUBiYQTCq8jdE0V3oQftgJ05Z9W70IIJCkIJZqrC2v7DmBVbMSnxsXD6FcCmNgPw3Tbeue4MlzJwxASeecDymEcxDZs/BHKaKZ516KlP5ApYdu5jATqRGD2HFScsoREk0xGpRokD4Sz4M9sbxxGN/wUSa+SwtgIAo5ChMskzsp8UeFLCp0ybvdZnigdbtCXytRJVZ1zUFdppZFJUr42gaF9ju86pUhWlztFzLYfXjGyuQcPj9XjNZaoyCM2mABu3dtEnmSEIhc6XBE/kh7ZXeab9p42aLVJ0mlmvwfrTaNE7t8GHbxm1oZCqjCYYMhSuZzuPYpachMGk+paoWeQpoiXlysIKBVCyCk845H6VoDD0DecQHFT170cd2aETMiAD4lKPLagyPv+dyKQvQtmxeb/0Y6Os3oX/99XXo7uzA5i3r0T/Qg80b1+FPf/oT+rq70KppT963bcs2Bl9rMWXiZDzyyCM2/11JYRe/pLlkHevJM4CkYrg0alDHcCBvHP4f3F+Lxg82Oyrmu2a73DdYxWWbLIDAVcNdH6VnBKKA1jX5IwmLUjcBLUFSVDmUSKKvt99igIEBZ8LkTRHBaN/dzfSJgVOcaQ2DpRA1cUoLY4Z0H2+ghmp0rcg+5APMzCLwVbVgxcoLcPYFl+G0sy/m8flYsvwMBvV68yVIHQugoHlu8cEGXQpmav/y2BOojVXb6J+HdTz6+GNI5jKoqK3Gpm3b8UemoY2TJ6N/aBBRLUzs70UoErYcWvGMBlBOPPFEExJpqZREvHDPNSC1P9K94qk0XptLZbDsQ+MCW6RCpKVu4a7/1jaaNKAioDX2rXvVaNcU61wgx+MJi9zb2jrw0EOP4Oabb7aI/ne/+x1+9atfUfPjB+zsgUg+NOBj5Mp/+UzWpijbWrcwnCVQ6QEUqTFemr2QP4RouIod8+DEM87D8Sv/AcvPfQeWnHkuLlj1j0CsnqX5bAVMSf00sLWapWgDL0qVNJevyPqJp57CwkMPR1NzC3KFIuOCBpx/0YW0EsA7LrgIPbRkTUxLtSZc/FF8oxGzvu4em97ds6vV/LWmfSO0fho3TxwgXXVxGI3B3whsJ2p0K9mfZovkv5UySHI1PiyTLa2V1LqRo0bOpOl33323+cjzzjvPRs00EKMRoy9+8Ysm3W+FFMzIxEVDNI3yz4wRNmxYg9SWl4FKWSb6/kza8ZFkfiYrx88IlwGavd6jLVKDLK0MdYjgMghy+SnNJgmU2poY5hHwJUuOxSEL5qOZgZ3m8xPMvSdNnYZwZRUK5FUXTfe0WbMRqowiGI1YaqWJD42jq4/i5dq1a22eYefOncY/8UvKsT9ygdbeJUFSjstoGjfYon199r6arXN1QOPa8s8aFNCokCZJolGtVPGWDbAQEAYXhx56KO757e/w2/+6h8eHUyDyNmYuf/5WaNacOWyrjhgVhwK2Ti4R78Adt/+I1+KIVfhQRX/toR/OpBVA8gY+kKVFsGhR4DM69wa0hNfDSxo5J6usq06mXUHLlWHy7E5ZKmUaoHmurI6hxJggVk+zHe/Hnu5OxAl+Z2+fBZ4d9N07W3fZSJhybgEqvlZR8DVOoXUBmgkUv+oaZFnGJvF5bM3+b4KtNd1eRqUyxeqUGie/q0p0rAqk9e51nUs6NXEh7ZW5k8nWS3+RSIWBzltNmnftbGXa1oJ/+qf3UpqHsHDhQpx77rksJ4KnnlqNXbt27ZVed+/WpXrYJGYBPB62OrTRmLNiKXLsc5qMTCQHEQjRdDZ40brrBdzwoVV48P7/ZMcTqCKWO7eudd4n8BYRrKumytJHMzbJKDhU4URYa05ZAyviKesUPzM0uTEGVZsYkOlNDeUKazeuR4jZRYqm/n99/3vwUrNjNN2gNvfTonUz11ckH41V2Ri5wLXFCBQazZplafk0v68pYfFLI2aKbdRXkfitvmsvLBQL6Tdzl3I1bFe5po+mcYFtpI6SyqXozZICDzVQDXYXPYgUjClnlwmX+ZKp16ichl41OyZQFZC4ALvH+6W+bmR4Xy8DLM0lq169aqycO6B3upjyRanNBUbTq//yMH75o+8g1d3OzlGjM4PwVVfS59N0u2Z0eHGDc8zbuMkFmI9lf2TJtNypkXnzX19ag/+673c476KLcPVHP4prP/ZxfPWb38TOPW342g3fsKnXQChoaaj6qX5Ly1WmS6pJEf/ByOWfeDIeGhfYkhaNj6tQHauSAzJ7PySQFNGrk/JPmbRePIgzp66369r0QkBnZ7dZEL8vaC7Ajea1qQ1mdvdH6hF96ee//q/oSwbRl/Azn4+hrn6iBYNh+vCIN4iw148wAQ15Mmjd8DQ+edUl+Oo/vxOfvvJS7HzuUXiZW/uVblGnFeAZGLax/9wrwk/TbEeZ74oXeQVeTY34w4N/xvLTTsNPf3Ub/vF9V+CYFSfiI5/9LNZu24KrPvxhmngv4nyOTER/fMCEvl+ayTJVbjnG8iiqciwq54NiIXvXi3QAxR4f2BIgFe6CLXqrYPt9AQT8lGxG5Jo8Uerxs5/8GAsWLGKZTj3y82tfXWfPyNTpOVkD7R3BK9rxWGRz2b5KVE44BN/6zi1obUvAH6jH9h1d9N/VKBYocGkPFZhpJNO0MNtTSx8+a2ItJtRFURUs4uZvfpUBGlMbe+d6eHZcvCzjvEDx23g0XTwtgLS1q7fHSa3SNPH02Uq/Vp51jq0ErayptbVy0coKVNKMy8+rr0X6cQnxmyU9Kx5I8eT3dX4wGjfYrp/872h2nj5bgyZ6XqavoqIK9913H4444gjcddddOPLII9G2pwMvv/SqLVJ45plncNJJJ5nvUmckweqgGOWasNFEMcCgFkaWKlFVPx+33PUkPnP99/HJT96IpoZ5iDPVTg16CWQM1dEGYhpBumcHakMZdG17DTOaKzCpPoL7fn4LCmnl+VkCrRGt4f7KpJOvhYyusT7yRXFKnvyI1dXSH1cjUkVhI7hHHncM1rzyMtZv3YwXXnoJDzMP7xuMI03LJqHQOjtlIgpSy2k8nBU/yjVbeBwM8HGB/bcipVvKv9UwTYcKxI997GP41re+heXLl1lU/vgTj2Lrts3o6e3Cp/7lE2RkwIIVveYr8+9otrM86g0kX2yqR2Hk//VWI8M3JHsYFFXVo/6IY/CeL9+AVe+5CnUt06l9RQwk8xhM5Rks0f8yAq9rjFEL2xGrLuHBP98FX0zr3CgYBboRex3I1UBGwvS5RbZBrscEMZmxYVMPE+snH34U55x2Bp598kl0d7Rj3csv4awzTkNzbS3yjB+yjM7DsgRdnbZoQZ8tkckW7QuXIHIFewQu1TliZd0U7cBiMm6wg2S6m/tJu1SZzI+Ac/2pjgWmJM69x7UC+j1HCVSkW8WUTFuUOdH0qZPxlS99EXf/5j/NnOfICL0FMkCTWMilMBDvHTZXfoSCSoXoP73O3LGW9zLxgId1eiIsPz9kaXCEbiIS0PvMWabLMdabQi7F/N4TxtzTz8NRp52DUnUDOlMFLDzmBMRzUaS9Fchp4UEojXi2i5rXjx0vaREBLUSwBX696ZkmFCGmncyx4xrzjwSRJHhVkUrEwlG8/MwLuHDleZjZMAm7Xt+ApQsPxyIGmlde8k6Esxm8f9WliLB91aEwhgb6UV9Xg24GkxGlBfJK2ihP4pn8t9bXh4NOdiPL6sQuzhCueOyafwmc3zA4sMV9U5qtglxpcvdjkcyK60fcTVqpdEarKqWpGh3SNTVaI0bf/va3ceO3bsRpp5+CpcuX4uJVF/M+Z7kwXaMDrJigxf3GEGds3tZ8W/TETnIvH5jSMCvvC4f5DBkQCFegyMAsS9OrdwI6mOJ1J9KafcH8w47G1JmHYU9XAoNDWRT0HHlfyCewfgPjhlKAAkQNL0mz2RBKk7TQG+R1BlsSxCIjc+V6FcGwBX7nnnEmfv+b/4KHKVU1rz3x5wdw122/0FykjdzpozglRu/KEKSV8vmCaDRM1i3TajHA1W6HxFOlwyK96+4GaOLL/mj/iI0mliFfKc1VRerk/sgF2NV2N5r2+n0IVkQsJ61uqEOWHU9S4j1BP3oo6b3MQydOnYKJ06agtaON+a8iaXddmfthHr3mGtpbtnJsW3yoj8qwHj+1plJoZemcvRq8GUQx1YNgTosUxYwKBBnlixLJrE18XPvlH+Ddl36MJriZFqCG/tjHeGIKXn11B+/SVxmG2WSf4mCEzr3MuJ+A1zY4mYTa16hZQCKm+fEbr/8aFi86DMuOPhYfuvID+MZ1X7E3aTTuIEVRH7SXsB9IcfZH4kO5z9a5aH+xjOhN1SJNFENdIA9E+l2NUeViRk9fL6hXNMtxKlQEnV1diDAy9VAAtOCusaVZLXXyUD5Xz5w7ncvutRDai8qti0jTm3bO/1RX3oCnyS46QGOgFam+TjP1YX30JuexHFkBV4h1610pFCNYMO8IpJIUnkIYhWLU9rksGVfSpvpkOVSjw1S1Rxou4ffT1PjYhhDbrbJLDBCz6QyaCX6ydwDxrh5MnzCJ0bvfBpX07RN9YEAm2d07UIy1jU3iiatwLo8ORvsvbQxywRYdSBol5a5AaK/nND4uoDQUqMBGa8lTNOf9jM41LPryK6/Yfdt37LB7Vb5ybbcjbiCksgWqyjIpVofVJr+TJWgK8er3vAefef+78OFVZ+NfPv4B3P6LHwD93c59FCYvAzyvxsVoslUe4vS/zPVLzI30naRS0ccAj1pYVSNpMrzttaAyyvM59UParbaqr0rFzNLwt7qqarTv2m2THFFam9at25Gmf3f5oX657k5u7c2Sy1/R3xxslWWBwLApPRDYIt0jQNQQpVmawYozwEvTbMcTg+bv9OE6MauqOmaaH6uptr3yUP2mnFR1uuVob+CQdGwddBpGCXM0PiimE8iaCi9i0QIDtSS627fS1imNkm/VG5Q5Bpx0B2EFnmRY1Eer32bH8oNyN2wgJk2e6tRFoPWBHddtKudWXRKucsHTJsDrmHZ1dnSgvroGRWYFvnwRUY0t8BnxQjx0XZu7fyvkPufy5GA0LrA1pi23JQl0x8RVgdtJdUDHGpaUT3KBcc/VIc3waLTo2GOPtUYeddRRloppbZqGCzW4ov0ZZ5xhdahM1accVHWYuSSTtEkjVIbqYGVOI7mTxlQ11mD2rAmMdItobvKhsZYxA3pw/eevQX6PBmr6GVD3USC6Gax10SDEke14GTfd/EmC2k3BIxP9TMeySRx3wrEEOIdMkekSnBU2WkBSLDjj0GrnEINICaW0V8FhyD5MV0BtZQxeguwrMJagvddIm77ppjdi9d0YfahO5ry3t99MueYCBEc6rXUAFXaPrquv6rt4oD6Lt6pXgi6+igf6XUqh7UA0bs0ei1SRKlfFqlDAqkGa7VKDFNA5gycVNhny+OOP23MaMNEyWa3SuOOOOwxALZ+VOX/66aftuguqylT5SvskYMrNdU3n+6NDjzwMW7b3st4IEgn671IWtTVhfOOrn+NxEk0NUWRTGUvz6mpC+M6/3Yju3lYcethcbNm2EwOJAVTVVGHS7FksjVqtb69ZHu+SI3yuwKmfGhxRm3Wu8XxZMrVVo4ESdMUvar8A0nXxRMoggXfLcBVI08Pin4Rdv4vHule/yTqYRVMrKAAinWtzz/dH4wJbFRQpkW5lKlTH7oyMBkikVe6rPTqWlurdJneZkdaWH79kCf58/5/Q1robCw6Zj5WnnW7zwvKzE5qakRpKEgBKMrXkmdVPY+f2HQa+ZoFUhwRHdYix+yX26JRL/xE9jNP6hwIIVcSQpSYOxjsxfUYtvvnx9+Ge/7wNMydUYu6kWtzxk3+nD49j8pQmrH3tFTRPrEdFZTVuuOlmqbgVKRNe0LrvYW7pkxr64KV4IRDVLs1j727bYy6grr4ebR3taJ40EauffQZFugZlFdWxWuNjU2Oz7aPU4LY97dizu81W6NTW1Nm3auhIbN5gCt2IZhwFuupyhUFK4Gq69hIGbbrnQDROsJ35a+fYecTVNp3rywqSdL358fnPf97e0dbKE0m0BOK1117DuWefgzBN3D+cdx4WH34EgpLw+CAuf9dl2LZ1K8449TRMmzoVS445FnNmz0YLNSKTdCRfiyAk2eq0pk7F4BiFaWxi+7wBzD/0UOzuSKNvABS8iTS1VRgc6CNDq1BJhiYHhpCKJxWOIZ/JIeSrRE1sAhLxAtauHYCvgtmBL8byqK3DbCrtVRy5L4cf0lQxXAKtyR2lZMo6olWV6O3vQ4deouexMgt9u0xar2Hg9evX48UXXzRh1qoVCbS7Lk+vMjvvap9qizhcKyDLoWPxRORqsoRA298EbJXpSpUKdDVb0bI6qfeIZXplsj784Q/juuuus3e2NAyqlwUkDJK8Pn1Zib7JW6TZp78KUXMGeG3O9Jk2P5wdStm5/J2uTZ04yTReY+ZavSLTpsUCMoNFljc20a9lvfjkF7+LL3zpR5gx8wRs3tqHwUQOvQO99Kd0DaEqhJluVXjD8KZzzK8ZEA5VYefWJK5496dw6x8fYaBSxU3DpcyzTSSGibygjtmheKAvSPz1r3/FixR0Afrq2rW4+7f/ZWDf8/v7MGfBIbjjrjsRra1GNp8zK6D+6FUe8eg9zByUoYg/4rGWDmsIWa8p33bbbfje976HBx980ICWm5NfllCNpdkHo/2ALYkZ/ZNSj+F0hyTN1vDcwEA/K6fJamm00S815tZbb7UFdeeff74tUJA2KgBpJlCdbZ2opGn1MGgp5OlruA8HyHTmoBVh5t0Eq621DYVswZYqy/d1M0+Va0gk9LpOEjGmREP6AsOIqo0QL3n0DbRwPepnLsT7rv44rvzgJ+EJx5ApBNHex2wgzZuCtfAE69GXKNg4+dQ5h+J/3XEvpp10NgWC5pu5b6qfwkFglZOLlFerfO3TjO6zuYyla50dPdi1cyeBDGLHzi0466yVaN/TgUsuuRT1tTWMV2ahj6nfrBnT7WsKEhJ9BUnWUIsqpTDSXE3tPvXUU7jsMudjep/73BdsZaqUSAsUpFzir/PChZsBOP7a+SrygWkMsHVJm0JP95hFM8jR5L5JM/NQfXajUExzy9jXjU45ZQVN1DZcddWVWLbseFs4qMace855bFwDWplzZil8tp6LHNP6cO3d9eI6TmvYkdreNGGi3ZfJ6UM6STIjRvOmj7BqNC7EDjsfZdWxvIsiXIGg5cvSDqVNGtiw78KGqrFgyQpcd/OP8Y0f34ljT70IiE1H3FuHnQMlNMxajK/fcitWXfNR1l1BoDX8ypwsm0CkkqBn+8gJ5uWhgL1UIHZI3sNM3fTy3strNmLZ0tOw8oyzcfRRC7FixRLUVFfZJ7KG4syrCzkctXghhdv5LqmicGU3irTV7oaGJjuvYhrw85//Eldc8T5byfP1r99Ai7mFfGvHmSvPpUJ10Y1l+Jzf3jPTMKu+FpmjNXG+Cu0u6HDwGovKfnE016HhXu39Wa+uEA5KkSNNGqLXu9jUNGrt0UcvNol7/PFHbcryggsuMmnVd7vmzJmDLkqsvvyj11oUhcvsK/qURMokS8JdU6RyRvZZVETpaweHLLhxTZmAVnpyINIQpwSGCQqPaY4FoCeCsy75Jyw6+kQM5QKUhQoct/wsXtdgC001LULBF0JBY+42iCLTyMBHK1jIC81Hl4b9omK3vv4ezJgxB/U1zjq0XCZNv+98iMCEkbGDRtcCPA/6nTVjelyg7NnTij//+c90Ac/ZS/gy5c8//6xlLS+99KK9J/fIIw9ZuqoVPHo5QOVKw2VR1T5h4Wi1EzwfjFw0D0oyo2qsfI4qcXy33kjMYOrUmaZ1Rx11HL785evNxPb1DXLTx2K8WL36OWu0lgUtWDgLU6c1IxBkY71ZWoYkBhgp61ybBjtG9l5jqMyWOw+u4EWRua0i3Cuco2h4VU35ZrbXHC8tAzVeL9qVeBzwVzruYPT97iY1Jqlul3SoYFHLprTJvAoIBaQCXeQES87mJeBarNHc0oBkapDRfhg1tYwJKERNzfU4+ZQT7euRxxy72K7pvoce/jN+c9evqTBdFsytPPN0W3kqXkjo5f4kULJkysmVnx8MznGDrULVYVWkvTbTuvgQzVYdU4Uc04cU06tlZGYBs2bOQW9PPxnmRYS+WC/Ry6fVMlBR/qsZH4FVWRml2dJrLBpCzFKjNYQ4stdaNKVaYqgsgOrX/f3UBIcMweEduzM8M/UGQbCcafg30nFs42c/8wV87OOfwfzDjtp7fX/kAq2de6xMRNZLGqVxAwmzNmUfskwSGO2dY2mgx0CTDMi/6gtJl1xyMSPrKgpME3PrDuuX+KLPVy5gYDdt2hTrt96kGRqikFRETegdgJ1RTFc4ZQkPRgfuZRmp0SrcTTV07AycOClBR0enSXdzsyQ9ZulBLOZ8GkLP6hNRalBiKG4pRio9ZI22lCLgWAy906y9PgWlTeVrae1dmi6kZuijet/97neNwTUNDFL2M53nMsDdPNpLGshwBJm6NExAy6x5mDRtFlDBNEbFjHpG57btBdrZG/FYAdTXv/41/OEP91k7f/azn9niQX1r1HkfSzNzemtDkx3OB3y1klRxRnd3Ly3UFALcY8fy2a5AyI/LnytOmTZthvFUplvP67iyirGO4hKSMBAv1F4H7APDOW6wVag6rAqdjnv3Bk+KkrUX0OqMTLte/HPMTJHaXIf4QMIWF4oZGiLUXue7d7eho72Lwd0u7NzRakKhb4a5x1WV1QT5fnzta18z4BU3hMMMfpgzG43WYiO2dXjb20FqL3WB6VQexQyZxeCvkCGYKQV0w/fsh1ygbTd8rK8HS8teeeUV3HLLLbj33nttIEnCq9eB1B99z8yO2R+dv7Z2PbZu2WHfSnvs0SdZrRZf+BnJ70Fz00S2kf7dH2a2UYumxgkUmqAty5ISlEpF8qvXQNcQsgB2NJuP0aSLzwejcYNt0k5SBSIxQDGB0gKBpiDi+edfYLB2tHV6yZKlpsGqQhI6a9ZsBll1TMmmYNLEqby/BQ31zWjkvoqd02/V1fXWUdvrPFZjAqOX0VesOMXG1ZWb9vZ1o4ISvg/I0lzSfhTeqJjVEC8BZrrnY0ZgKyEOYsbHIvnmiy++2N5i0XKq5cuXUwijFl03NbUMm3XuG5uH9y045JBFqKttxmGHLsaihUeyXj/dHc311FmYPm023WDWvqX21JPP4thjlhJ459MljY315soUr0iDFS+IhIGLiwVoOjxA353xwIOQzIYCNO0Ftsyy9pJumfVNmzaYxK1YcSLN2h/sYy/yRdde+2F85StfoiZ3U7vr9wYvapi7qSyRxoMlMMrLZT3knx966CG0NDbg+BOWmwn363WaxPM47IxqJPWyHIM4yxCkmvxP6aCGMZ33soaB1w/DR0Y+L4IEhXmdnSpqd+8QmRZrM6F2hEB9FIMrGBNqClP3aFH/9TffgznTTsfuPWswY940fOITn8DGzRsYdIbx0Y98Gl20WKWS3FUGIZZRXT2Zwhsyt6c+iode7xorT+7rqMVLcevPfk2efQW//MVtBvTrr6/F0cccjpdefhGnrzyNrXEWc4jfapfADvM+xUzDXd4vjUuk1ShJlPaqRCA5X/3Xd84C9pVcDT489dSTBK0d5513NkF7FT/4wb/b5xn1V28UbOntzu6uXvR09+3dFMRpr2BPK0tnzphtL/bfd+8f8O7L3mNarwBPWq469RcI9EnIQIByqpRoHzV2QLJpyDGlnD5ZH7Xx5m0r6tPTB2ISOSgwnE2njjC0tu40TVP6KV/sMv/qq6/FBz94Dfv+Axv7lmlWDq0+SGGUa8vUK+VUkCfrp+xCwiTA9S2am266ydJUWQt99jJaEcbJJ59k96guPe8qnCyf+itfr6YdiMYFtjoordZeUiWSRD3x5GN4bd2rtlZL39bM5QlqIYuf/PQWXLLqYsyeMxPbd2y1YGv37lZqbh0am+r3bvr0srvp88wzZ01HVazC9meedYalXWKg8mx1VO5BDGFWiYB93GY0qTvqcXm3ZOppRejbyzcTEm76Vorj998ciR8CTDxRG6WFGu3TdSnGBz9wjY0xyALIqjXSnKvPNbUV7GPYtlh1BLV1lahv0PdZkogP9tj1Y487EkcuXoTv/O9v2zfV9KUkzQ8oALz99tst3ZPCmSXzaH2BrCUbNaZwj5B9gtq5h0zg/x02Of8fEZQiXn1lDa7/6nX46Mc+hOlTphJ0j31VQMOgSqc02qOUSoGapE7pQozaKC2U2VJKIjOuRooZknBtYpgYpGck6fJN7u/6/uem17di5uxD0LqbkS4FyptZg384ag9WHs/IPdDDpmWZVgfhpdZkfQsROOJ37Dzvs+GzEbKhTpJ6O8IT9bPofG66FLCvLpQ0YOEdhL8Y4E+DTMt3o3/t7QzonqQZ70UgJ4sC3P3CQtx692ZMrF/K8hrNjMcTe2zxxdRp8zFl0mzUMu4YHOyiZkcRYYQdq9MfztGXlJhtkG/hSMiidn/AZ2++6J23OPmlGbGWCc02GOVnwCaXpnRMYz2xWBWvBdhqL9raunDjjTeTdyV85tPXYdnxx4+ANgLeXtr7vfGxhMK535H6V175KyPi6w1sfRZaKzKkhe73u9z8Ur5X55qdEbgqXr5YftuxCqpJJcvsuBqodMfZ65qGAKUxOUbNVdFq+0iNl4zJMpAK5Nehb8O3sXg205HSLqqYxmDpWmhRkr5DET3styxGYMtEkyV8xjRZQRj3DtgOyCNg63fNVoUINu2GN4NgQW2NM1VrQ9+rdxDs1agMdrN+NpRtvOeVY3HECdcwsm8h85swmEygoTlmphqeKLMPfVY7ahpbpW+qFUvI5BPkgdNntcMVcimAANWzshCu4Cv4FZA611Cw7unp77PoW8FgO8H+5k03k19Fgv0FLFu6zMoeC2jRQT4uL4ZoK2H1M0/gm9+8gT5FqzeY5zKHViNcE+ZuOpepFbA6li+TIOiaGqx1XxpqVRBsf9+L9+maBmLcP/+kvTquJbohinO+yOsBgp+v4vk2dG3731g8q5NYrEeEHSsRmHTIi7hnPmoP+Q0FUZ+nZEzBdmru2ZYUDQMrxrrHe8EeVvuiTyaee96vvwXiBbOJQDuruRfZxGqE/G2wHIBt/P26kzH90FVoqJtBodYyo4hElf+kdbQKfFo+1cO4QjKtQFJ9deIdZ3jTBG94kzUrt3ja7Fp+5O99aUszsEyn8vT1A2ZVNZn0zDPP4dP/8jksXarv2WjVqnVnHxoB24V8r1SIGSL2jPTQI3/CnXf+2v4YiSrX4IiCDpfcYkSS2PLzkSr0XpMzCifBkCDIAogJOnYCDmd9lqQ4EghC4YcCj1LUj3SyEt7CNubGd+LwWR3w9jxHsaFmF6qQjupPrC3AhDm/Yv1aM+y0ezRZgDWKvDLZYoAvTwMgd6bXg5Ql6BXbTqQ3/xGZxHOI+NsR9FIA8l481XY5PLFjEQpWoJiPUgD0hgiF1xtCjlUrYBoa0lea0jZxoRFBvXeuryK5Gq3N5ZX2otHtCwRH+OiskyeSDPo0WCO+6dNbWrx5xhkr8Y7zL7RrjhDvS+MCO5VO4bHHH8LTT/+F/rnGCpTUCTA9PnoTYCL33JViabB7zb3uaJrzhoPIva7OewsemmppCu8PeinRTPWwEwtmvo6j5vai2buD3UqR+TFkqOL9mIfmefpTT7y2H7BzMrOjKEBfLTNf9OdMqzWBEtQrNSUC62vHwOu/R3boBaZ6HYh6aEbpt3+z9hRs7aolH5T61DP1kQvSi4sRS+0ETMmWMpGxZllkqikYbJbbx3JeiAT06E2aPXLuDGh5PVp75iiV1sPJ5Ovrx5e881LDRdo9Fh3AjLtga1/COuZ7v//DvRaMyZxIKlWxqLwIHbvAidzflKbpuZGGu7NAzmIIN7J1NwkUf4U/y8CJTfBGFTBVYajvVRwyYwsmVW1GjFpeWcqCWR0SrHIAU9Ay93tIF1JktFW7D5W3zaViKmy9LEizKSQyxyEyMkSfXRvpxfaND6CUegWV4R5E6c/1ebS/9F+Knf11dEdMuWwyhRYpRA1nQUqH1O9Ciffa2xrS3gJ9eA1/HxHycsBlzVxS/13SF5nsXDEHyYlz6JrobzQ270yCZHDyilNtxcv4NHtMEgv0zZEMEolB3HrrfyASdbRZ0bbDOA3ZqTNqoBrvTrtJs9zfnA5pUF+gOx3WUhp3waLyda2u1H2OYFizWH2g4Mzs+DTLVYwgM/g6aiqew9TaPYiVWgk2y8gAQxTmwWIME+b+K/LUsL3TlMOBmbuXcI2+lk87lqjgy5l/F0MM7NIgYoFu7Nz0IEqZdagKD9ofcSuyvkc7zkYqMI8RdZXNokmr7VtsLFbapXIcvsuiOWlrSYsi6HisY8O8cYAZbheP5dvfuHcGcViD7Z1juhlvwNyCgNa1y951uQV0BwJ77KujSMGSgNLy36FEiimXJs4VPTKQ4rGmNx3zxMaoM2SimwNKynWvTJjyZY2na+xcf+9Dfk33acJA06KaVNFUnRYnCGtjgP42Jrc8/XA6q/efJXxJhKv0NkmEG++hHFjAp68D6+9pmiaRuZT+0XsDWN0u2/sDDJ5COfiCGdv8wRw3RsDBgkXT+hti+WIOCsQpp8gSq3icGYM3wjbqnS81QIsHBLqHCqGZvKi9s+2Olum6hNzljT40oIhacY8WK2jyQ3+PVL5YfHPbJk02uWfZ4rN4rtEyHWstgXCRRtuctwG9f1KPD0JOyK9KV5x0is2nqmJFgWqwOqPGqTNipkyTKnWvqcG6V9G27rfAQpP6FAJ73spQ3qlx4Ih1WMyQIEjI4gwE0+kEO5fFULIXQ5k4du/pQG8/hcVDrfIy5YP+4hB9Lv27vg6sNqlML3PU0Xv9GQeVXb437ZMGmRZKk3TuAOdIEU2shzxgW4temmhvFXr7Uva90sSgomb1j6kVQShSqBKJpKMUWoFDCyFBk+Ba/2iu1X+VLb7kadnEGymNLIKuiYfim8gO+bxlMFIetkE+WUGygNZ3a84959wx3dNoGocZHyGNjvmphao8mUpg8+ZN9oGb1tZWmwFSUQratP5MgKtjOtd0p1Iv+RjnurRdm3uNEmxyp6aQwTLn/GeWbG+gFUAuPYhAWOPr29C3bTVefPJhlNJxBLw5ZBmU5RDDzPnvR7JYQUEgKLzTKW1kL0aOvmapL4MpWy5M0MXoANO5kJYSxbdj6+tPoiJEfx1WfEAh9zbi5A/eyWfcrxlJ0GSNHHclS6WSZWFo85xbuE8lGZFTINw0SpsBTIHQmISEW0OhOtZev8sS6lz8E1/1/ZmjFh/FOGaYL6b96gmbs3c/toYfBGyHHOl0omwdm0/ieSQyElS4ZF3kPaNJWj8ShIi7YoJMlEFgEuxolEye2yRZBQpZjj5Ugqu+KMJlRAz9gXSZZTnMgGPqtQoFhencszBq6bhp+G9zlyg0KtJSG8YK1ihvAki0wv5Yuv62tqeaDaqjhDTyfkdDqXJWDHXS9i7pTGBbMEbg9XcAvaOAEUlv90f6+rHuFe+dZ0aCOpdGQHbLGdtgl4Fd3tB9b5ZPjUZlzocvkPS3OVWBTJQ01q1MEqpj9zcn+ND9mpnRdc34sBaayOFHjK9OGxxBcDpE48UbNSMp12zMo+/0e5OMq5QaUYMUqockAARCk3jpWgKjQsv7cxDS+9d6hFotMdVwiv5OmBXBABAe/WWfXu4pdSUCXahnO2iGafJFjpDSjQ33xSPTP0zlIudjgcO37CUz2SSXRyL13QSEW3kaJbejRonX7nMuz0Xlx2PRuMDWLapII2BvpPJnnPvkg8rTCF1zqhgBfbxkj7H9Vov+x8c1MuYBI1CdlMLcdF0v7WvKkkymCYeB4ETV6n75XjT6mkdCo2OZcu71XRbGevautdVbYL7t0Ydr+XuulmAy5RIGKqCMnBpV5sgPbp1GNL20ZQbKaGBcBRGP3L0oHk8iFtPHAt9Ie2EbpoMBLRq3ZkuQVJ6VqSe416PllehcJlwmp5wkhfpNEjmaVK7z276NlVksIM2qfDwOca9BCoGqtmpJrQ9BTXVqBajBpHbrO2tsILVUd+lK+d5HrRt9TbmU8usiwVbXigzvvcWwAe43xCVMWjAgOGuZOzMoVRXD/NAzo8nKHUU5WjbFBwLSBXUsciFx+EvxYGFmLHSZjyhjUcwj2k8RY9K4fPb/n0Rbwf8LFhcal43uNVG5eXSv7eXNG/ai0de0fEk04nOdskfKVBvcOIQR/xt+G5vcusrpYM/8f03/14P9Nv3taEQN3qb/5+ltsP9uCPg/BysJJtZjyGQAAAAASUVORK5CYII=";
    const emailBody =
      "<table style='border: none;width:600px;margin-left:10px;border-collapse:collapse;'>" +
      "<tbody>" +
      "<tr>" +
      "<td style='width: 102.25pt;border: 1pt solid windowtext;background: rgb(189, 214, 238);padding: 0in 5.4pt;height: 49.35pt;vertical-align: top;'>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='color:black;'><img width='105' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAABgCAIAAABDv8H9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABZFSURBVHhe7V15rB1XfZ45s9/t3efn5yWLEzts6h8slaj6X1Uo/FFQA7SA2qpS6wYCJAFEHBKTkJhAHNs4ZDFpDEmArqi0akVQF6lq1T+gKQkJiyhSFOIsJiXO2+4y+3JOv9/MeTcvfttdZp6dKp+er+ecmTlv5jvf+S1nztyn/vvPFpVXAsTTT2gzs7y1TZZfCWDy//Me/snDiq7LwisEFZKrCh7d/GGWxrI8GdIwVNir5C5DqIzVatnpp2V5AqiK4ETuK2acFaj2cs2P3Oh95XZVCFmeAFkcl04u+kz5xSmWpbJcNirWQnu7Wa8rCy/I4tgQQoXBVUu+WnH6lP/VI6KyAVEtuUJR7atv8e++WZbHBbSvO45QVVkuA3AG/btvaVz/RZgvWVU2KlYu+J2eZbrOOvOyPB4E12xbKZXc9NQTjU8c4vUpWa4A1ZML8X7kxnT+jCyPB841xymRXOb3wj+/S9u9R5arQeXkAurs7ugv72F+X5bHQBzpto1+ksXJAD/mHTlQ/8StXDdlVTXYCnI50+z912ZzE7g1nul/eI3cnhwvPk+9tOOColQdtoJcQNt1UXj/URaHsjwieHNa3fMaWZgMLIn8ew7Vrj9e1jjYAFtELrdqzkdvlIVziuj4p+39n+L1lixXiS0il3DhXm7acvscgYVe6nnaJa+T5YrxipkVKwVwZWocctOR5Yqxhco9DwA7u2XMAhuRy7JEfeE0JeCvYixsqFyV9Y4f9G++kvFM1ryKUbARuYhPp459gxlG/+B+RDCy9lUMjc0dGsyCeP6ZzrEbth15kDsNWfsqhsDmDo2C7Qv3Th86sXDdH7PuZPMv/1/AIn+YJyzDRgtiesfMsa8v3XyVeuYXsuqVAFVwxhOWRarCZdXEUOf+98zH3i+6S7K8PkaLc1ma9G/6kD0zY1x7DBZZ1p6vAKft/zrhe50g9DTdEO8+OmHKq/Is/dL1/Wef3Xb4ft5sy9r1MaxyC3DdaB5+IFxYSJ/6mawaCywLceeMxyUK6iywxG99986UZ5mqGXZDUbXkoRvVqMfSELvwKY8bGsjugluvSjxv213fHIZZYMwMTRVipOcC5BVXqOain9ybpmkWR0w35n71Ks5KnvpjWdz87peEqnheH7+cMeZ5fhJHO7bv1A0jCN3Qc/V3f4GbdXnCZlAXXujffqDxqS8oF1wqq4bAaModYBRmBUS684cnWBpAsJDqW+3T9amdVm2KmZbCtNnHsUvqiBQdeziyKI4HdGTre3cyTfN9t2A2iuI0SWa276g1W2EcpFxopiWGEy/jqXju572jn2597t6RmAUqn1tgItv75F8HQT9LE0VwDM+Yq6ZutNrbAq8DNamqKrJ07s1XKpzveeYfA7fnev3g168RRm14E0kUxK7CdFW3ph69j2VZ3+1kMAm5CHq9vuM4O3fudt1eFIWohPEUb79e2JuMbub13Ns+af/Jp/R9b+DayKsmKicXUt335N+kWRoFPSopitvrhWF00SWv0QzN7S4U958lyfzcwu49e51aze0t+n6gGk7v164qTtkA6Bk1Daf++95OZ951Pctp7N51QRgFkC1aRttoCiZo9+6LIOF+vyPQwfBMaSJ+66CwN3uA9stnlTRVLr5MFkfEmGZheAiFPb3v92Dp1PwhK27XqdUxWJeWXmRMs+warDfqddOs1etL8y+qqmYapm2ZIvZZ7OdtrAuVJ9MP39N8+Muu72ZCFarWnmpnnC8zq0ZRgo5st7cZhuX7fU55PPUWF0r4L7epsav6i2riFa2tgd2XjM0sUDm5BFVXFdW0atgElYZp1GpOv7MUeC6EptFwQ7WoN+pRGHj9rolKXbMs0374Htjroo3VgG3d9sifpUnkBx5GRhAEzVYLPZebWgLajKLIsu1mcyoMfei36GDOuev5uqq2HznJ/vMO7x8OKr1fVjE/VQm5uNDdj92587E7WdxHGH/Z/H+kSaybDijGXtyz7diGYXaXYBOYYUG8dBbTGCzj0sIc7LJumJoGh2fXHj6BFmj3KqiJn4ZBEAUgK44TjPr21HSWpXFMVhUIghC7Zma2Q7BR5OH34ix8+r5vmtbOXRegnGawpYb77ZuVCianqlKuYTlMN3f89Oszj9z57I+/57tdGAEMd+zC7em6btlWEPiB75qWo2kG9IRdtXotjgO/37WsuspUw8DlCZjUvMmXQRVp+/v3JfBLnJNCw6jZaBkmxr7LWG7EsyxKonq9UXNqYRgMnBsihywTs7M7wPiyCVZwNeUuiihQCbnw8rpZA5vYVnWytt1OJwpd00FcKeUDkWqa1lmcwz2DdITNqIc1qNVqVKkZum5qqgrjYH3vbngtancFVHjIKIjzuTqMfci82ZpK4yihGpItSMRAmZqaTghUiSPRE4gW2u1py7I9Fw6WWhI8c1ozsNd5sUxUpdxnXvsHGKdgTGNqqz0F4bh9Eq+mm0StEBrIM43Q94LABbm5eAkgF5Y3V3QNHGkaesdUk5dFvohApr9/LxwX2sFHFMdOvYb2cj/GcBYlKHFcrzUsy0IfrJBthEEzNdUOAi8r7IBQsjhU3naAtstGVeRCvEyFFdVx/7ifRqvZ63TjKLCdZuE4YA0RdUFkvaV5cE65fz5CsQ21dhfmYDlALahCH5gQL39pLSLCVNgOOLGcxwSfzcYUQtcEoXQ+LMAsNkBiCjFHIboZRfzGMIqnp7fjEJBLRyoi4ymslWJU8uynKnLBrQHLsDzWTNNErtDvdmB4EZbltkHRsaWbgeeBdJhL5FLgBUwhJkMgEcdQmYXDNA0W3F4p3plHTyKWKjoD3NkICCwH8QDOBaDTJIkxAtA6nBs4Lc6K4gR+DFYYzOa/iCpBvv3uQ1XYBKBC5Z667AOaToMULECa9Xq9213MstiCeHMbinqnZsOxuL0O6MO4zmUnwDmMBmI1it5wLsSL2ILCBhIvbGTQW8yIHSRiWZryGgJnRSTLE6wwsWgE4RdJNZSyRQ16CyYYAoeY86tCgAB7myJbKU4sHZUpl6DCLMDOFpGWYcLaKm53CWZ3YHlNy6JIqN9N44Rs63KigVgCMoeWMWZxNsSLsKz5yEkwe+mz3wGveToAHlPYHNtGjBEXCs3pTiFbjJVBJRosrC3qERTzXPIF3Xa9hXGBYhWokFySlmENhAOibMvqLi2KLDWRmOWmAbdtOw6Gse/1dMNhGtloqrQtWEPfg1ur42SYXqg5S8L2D+7tz50ehA5FnGAYBiwvijiRyM3SRqOF3wubIK1tnk006g2MmDyVyE/ObYL+zoPIIWW5bFRJrsJO7X0/RJrfIchFkmYhm0AMZJgOo7dH4Os5yBUqg5GF6cgr6VTSrKa5va4OWYEMtIXIQdchcK+3VDix/EgF8QDahynANlqDWpHZ2baDGhCNSpJtGGH01OstGOhBBgyW6cKqXMZQIbk54PANSswKD4bg1TD7vQ7oI/Hm9oIY1bQwoPlWuDXcMKrxCfEGPnkew7Agc/QN9Isd4JjaytFsInvWut0FzilyALkJwjKHQmz4N3mQomD4N5tNHAlCi5rCJhi1ptAqXEVaLbmCAluDYh1yIAIkIvENPS+JQzirQqcgDu4KkSliW9x0Liuaa7SRWjm211tAOIVKXCjFZegoTUeMlx8JW0xefkAZgDDONHRECzgLRwPIJnA6DAU6ALKlJnKN8yTR33ZtoeKKUDG5ivrUpe8DwcUtgQ9IF0Ped/vw0xjmYFxwmrKZmZ0RPEH0mgdYuR2AeGvI3BAXEI/4B+GiGZhYhhOL9vNdsnGYZk1zanUw67q9gW+ElaWIz7TQB8XxQJZx2HfFpLmk6lC1WQDAhgWDWWgNJgBhA5J9r78I+1vwAjKRctAGcXgWXlIWZWs4jGI1C0OiaHA18lq5C/mbaRmQM+XKMSwv1WOs0ESSXVPyOLosYGyyJGJuZ/DUvfLJcuC1z3wr8vtxREYQN8czDsKQvRV7RwIluzS4Rez1Vrq1kYDgwe/37HfdotRnZNUoYEhMzjyfzr2QLs6rsHiwUbgOXY/+/kGj0TDqdX3/dWJmF46U5Iqf/8/C0RtElrWuuNbcuVub3aU4NYFoFLaSxiJ6fJzbKMB4vPepb/leZzAqx4dQIoRamZIEXjruOvUE9jgI7PccFsZYZuH0U6pTQyhOtNIwyH8A3VBMG7ZpwJUkl94iLMSM45JYhH7ywDF/fj7p9wVyIBygqtsf/Cc6YHQwke17+u/8/iJcysphPgZwcspFnHA4wCTo4z/q+hGBmBf3b1x+e3URboF1zQLUiohcoVc3cSWMBjOS0XEB8V78xF9F4foPVEZBhBCWK3HgptE4ywM91zXf+Wm1tVuWK8O6XQdGuaZz0+amww1rEmYLUDowuVnIxYvQGBu6aSPwGKtNwSqbT1iJLYgWCELVkU5ohpy0nQTgkqaDwDIlH/qoRgFpG9MMBVl19dgyctmpS95XPKOcHKBW1yjvo9EwonhpGoxpkK4sV4ktIpdAs+Y0aSuLEwBcIltDQyocdJ4sDA90hP52JGZbgS0kl+Yeid+cnEnB8lRYqArSvOEDBlwAfIlaq/Bl6pXYOnK5qqVJaBhmCdFuDrg1MJzPAg9teJFE/cY14uXr/phI8zW8Ma1mS0NsyB0TYysytAG01N/33ENIfIup7glB2VqCCJFHbhfpz1n6BeNFLw6oR5GWiP3mdaJGX/GUx5q0fG32sa/iemj6ERZGcMH5/Fs/yvUS3kcsU7kkAZENflYv5sCQzNJYN2yyfBMDuiVCSLz5nO8KgEdEBXGS4AchMbapGCd91289+W1cGMui3Y+fnH30vpkffCWIgm6/2+ktLS7NeWHA0Nq/3qryEvRbmnJxxa859bfkiJdNKmP6k3sux43yZdcMxi9+4i8Mw3Z7cySdiZFmPKZlITyi5R1Sp0mSFGttBvZnoGLbtqba25r04i/YT4MwiKIAuwZHYiNNU/SJ+Y4D6tSkr7WXqFwRekvdxef7nTP9zhxNeqXR604/9Nrnvo30rDgCZvf0ZR/MsoSVtORfpyle2kDAi8+CWdf1MManplrFT45mvt3ctm221WyjW8MoWuoshKGfz3DSiQBZBgTCMAzIS5efGU+CMm0urebkyfbH74V+aT5bEbbTspwmLjqJo6f2fQDR7o5Hv0QLPUaMnzYAUuE0E1kS0VROknm0Dsx0HHsgxhUQjcY0PGoQuCufU4BWfOJoDjkEXhQEdnPauPzw5M/by3dooHjH4yfQ+yx/xGvYNdtpws6iJgk9cIB7KMWhFcDoDxPYgMzrLHp9l2las9lYi9mXgL0FoQXoqQRGU+QbTkt9xw1UZdbhHvKdE6GqaIEl3vYfnQS/uBOEorYzBbdjmBYsHQxuGoUQjDx0YgQR+av+0nwUhvV6fSVxGwPXhhMDz8V12r/zecVwSuF0gKriXG7U59/yMZGvOIIJ8/oLvrsYeN3A79L6/TJvQTpQ0zAajcaQzNJV5QtP/X4PXW6/74sjvSUwJKqNcxGWz/74pFo8iMRQxQ89Byu5R/2Ioi3wBBnKqs2Qkh2I4jBovPc24UzL2rJRlXILcN2Ze+OHYW2xDbHAH5fOLECZcN64LG8I9HGSpJEfwEA1PnhXdcwCI9yqfAAXI0ccJcAuHgJu5GAmxSjWW8AUxFGEAeT87h2VLloANiGX2Aw95vfVpbn4yCc71++f+/jvRz96RO4eAlzV594kxXvOgQQBgHjhvoRc3bM5WOTDb8jCKFjD5pIwvZ6AWfrG8WBhIQ0C6/I/MndeoF9ymaCl4SoCGXnocGA8mf0hgl90ZMkeo0AQ0wKx2OvBR8mqtQBOkTtkSWoh+2pfKGs3AzLP/sH9tNjvuqOjfjfhWuQuzfk/+YG560J9zz5h10r5HklEZrM/uT/PLMpH4dDCfndj60MPfaMYYa393tvFKPMy9PD7+Wf6d9/izMyYV39u+K/NqjZaGICJbPbxE1WIVyYRaRLKdxzWRjFxk6Wp9c7rxps0gIT5s08GXz3qXHGdtusiXmvKHeujBFUOA65qc2+6EvqS5fJA0zO0MpRWOa4HhBJpmuVpoWDNHbJ2RGAEq5e+vvGF+9Ged/QAf/KnzNuoO4EtIhdAWDYPz1Y2vxknY5rmL0Gsh5xZqDu1f/uzw/uxNcGZpu57Q/3mL2MUukeuTX/48Aa+buvIBZC2qZomVrw6MjlgFjJaBLauKwOrSZog/tJNc7z1S6vBNUO97FcaN93NavXV09YDbCm5wJm3XM00AyZSlidDkk/mwk9R7rcWuKAcN/L6huWY7z0ma0sCt2rs9W8E0bK8Clvk0M4C0uKZx05o9ELl+P6NFuMnPA6CJPJXhwlgG0Y2iREjJPa7PqvUytHsSNhq5RaA/V146yehX56M/zQFskUMsJ5skSzk32EROe+57ZwwC5wb5RYoHhHu+PFJuHM4JXLIlJ5srmUckWYiQuLge0TuKqA1WAMYWusdYwZepeDcKLeAoOVo5otv/kiWRLphmXaD1kgPAS6UJEOEENEfj1jH2hLwC4abzakI5/J3S6iarhm1xnS9uc2uNVWV3qOUu9YCxF1EVkhk6WHo+rk4Y8z/zq3E8TlCJeRivMutYSC46TR004JNsEi8m5kFmhbO35+kZ3FrH4x6xmgOBD0AiyNrtxzlk8swXG+9ivU3/8K4AYijnLJhFn6BKkgSxzE9J3ct7lBf7KIFjau+TmAl1KW50WZQR0HJ5LLI7x78U4xZ0Rh+Agk8yMugXGBzf0ar8HAYvWm1vswLfpGzKNlGMXX24i87N+xn8URftrUeyiSX+f2lg1c0rz1sHzo52lzaMkdE7hCDOOeWYgta/7AWv4XZAGgeLtno1QlkAVMHDnduuhKykFXloTRyWXehc+OH25+9S9l1sawaEvRUbZnc4ZZigP9iNQijxc9rkAtgN/0wzX9ok78MJHbtmbr+WOfgFZtOxIyKcshVz/yic+jq9ufvE9PjzTkNCBra+eTc5fzJirNAT+vyGU6kKps6WDGzq33oy6TfCf+G0MsxKbnkNZ55wr3jM+0jD/LGUF8feTZoCMtNzukZzDp0vQyMSKWAgS5hTe4KmwvTrJsbm90CvLWtfdtXOp+7RnnhOVk1MSYil/HMv+lD0dfuaB5+YPw3UogCXAYRJD3/EOwWkqUT1+EWnQSLvGx2h/JXvNaCRHrHP5Mc/vimYh8GkynX7Vrtdu3QfRP9BaGX7kKFdNemajWIWlw+DXxZswrUAWR2GQ+6smozQCLt2x+gJ4c/fUxWTYCJyMVQYgeOT/wtxSuzrGH1si6jK0DhAthXVf+fDw+vRG7Y7SNf06ZLmOuZTLmlQXJFecRwyM0pEUb/r890wS8zYHZHyBS4YSkX7pWFCXBekJvbXELxQGw4XUq8JPpVQFPUBwRNRPILHrcS5wO5Z2W9IzALQJcbnIK9ObkwuxP8qbtxcV4olyZZcnsgaB5gWMuwjI1uoWAWQW/0b8c3eNhVEc4LcvOxPSqnQwGWgYIxMKzpI5ndUnAekAurQOOahrbg8ktXSsSyZVCHjHZLxLkn95KnvjlIIvgor3lsGCa8hGWPp/Jwq33aeaBcej9Pbo6EDeKEl0H2AS3LyctbBUX5P697lGzK45C7AAAAAElFTkSuQmCC' alt='image'></span></p>" +
      "</td>" +
      "<td colspan='2' style='width: 427.95pt;border-top: 1pt solid windowtext;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-image: initial;border-left: none;background: rgb(189, 214, 238);padding: 0in 5.4pt;height: 49.35pt;vertical-align: top;'>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><strong><span style='font-size:12px;color:#C00000;'>&nbsp;</span></strong></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><strong><span style='font-size:21px;color:#C00000;'>You&rsquo;ve got a High Five</span></strong></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><strong><span style='font-size:21px;color:#C00000;'>Well Done!! You received a Reward!!</span></strong><strong><span style='font-size:21px;font-family:Arial,sans-serif;color:#C00000;'>&nbsp;</span></strong></p>" +
      "</td>" +
      "</tr>" +
      "<tr>" +
      "<td colspan='3' style='width: 530.25pt;border-top: none;border-left: 1pt solid windowtext;border-bottom: none;border-right: 1pt solid windowtext;padding: 0in 5.4pt;height: 10.3pt;vertical-align: top;'>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'>&nbsp;</p>" +
      "</td>" +
      "</tr>" +
      "<tr>" +
      "<td colspan='2' style='width: 320.7pt;border-top: none;border-left: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-right: none;padding: 0in 5.4pt;height: 20.9pt;vertical-align: top;'>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>Dear <em><span style='color:#4472C4;'>" + recipientName + "</span></em>,</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>&nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>You have received a reward for <em><span style='color:#4472C4;'>" + actionDemonstrated + "</span></em>,</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>demonstrating your contribution towards <em><span style='color:#4472C4;'>" + linkageBehavior + "</span></em>.&nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>&nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>Thank you for your efforts!</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>&nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>As a token of appreciation we are adding a reward of $20 to your Hi Five recognition. Our admin team will connect with you.</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>&nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'>Regards,</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:19px;'><em><span style='color:#4472C4;'>" + recognizeName + "</span></em> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:16px;'>&nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:7px;'>&nbsp;</span></p>" +
      "</td>" +
      "<td style='width: 209.5pt;border-top: none;border-left: none;border-bottom: 1pt solid windowtext;border-right: 1pt solid windowtext;padding: 0in 5.4pt;height: 20.9pt;vertical-align: top;'>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'><span style='font-size:16px;'>&nbsp;</span></p>" +
      "<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:0in;line-height:normal;font-size:15px;font-family:Calibri,sans-serif;'>" +
      "<img src='" + icon + "' style='width: 109px; height: 93.6811px;'></p>" +
      "</td>" +
      "</tr>" +
      "</tbody>" +
      "</table>";

    return emailBody;
  }
  //End Format EmailBody

  //Begin sendEmail
  private async sendEmail(to: any, cc: any, itemID: any, rewardCount: number, body: any) {
    try {
      let htmlData: any = undefined;
      const siteUrl = this.context.pageContext.web.absoluteUrl;
      const emailUrl = siteUrl + '/_api/SP.Utilities.Utility.SendEmail';
      const reqOptions: any = {
        headers: {
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose",
          "odata-version": "3.0",
        },
        body: JSON.stringify({
          'properties': {
            '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
            'To': { 'results': to },
            'CC': { 'results': cc },
            'Body': body,
            'Subject': 'Test Email'
          }
        })
      };
      await this.context.spHttpClient.post(emailUrl, SPHttpClient.configurations.v1, reqOptions)
        .then((response: SPHttpClientResponse) => {
          console.log(`Status code: ${response.status}`);
          console.log(`Status text: ${response.statusText}`);
          if (response.status === 200 && response.ok) {
            response.json().then((responseJSON: JSON) => {
              console.log("ResponseJSON:" + responseJSON);
              //swal("Email Send Successfully!!!");
              Dialog.alert(`Email Send Successfully!!!`);
              this.updateListItem(itemID, rewardCount);
            });
          } else {
            //console.log("Error Msg:" +response.statusMessage);
            //alert("Email Not Send");
            Dialog.alert(`Email Not Send`);
            //swal("Oops!", "Email is not sent,Something went wrong!", "error");
          }
        })
        .catch((err) => {
          console.log(err);
        });
    } catch (error) {
      console.log('sendEmail function :' + error.message);
    }//End 

  }//End sendEmail

  //Begin Update ListItem
  private async updateListItem(itemID: any, rewardCount: any) {
    let list = sp.web.lists.getByTitle(this.listTitle);
    const response = await list.items.getById(itemID).update({
      RewardCount: rewardCount
    });
    console.log(response);
  }
  //End Update ListItem
  private async CreateItem() {
    //Dialog.alert(`Create item`);
    let list = sp.web.lists.getByTitle("Test");
    list.items.add({Title:"test01"});
    Dialog.alert("created item");
  }

  //End Methods

  //Begin Handlers

  //Begin onInit
  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized SendEmailCommandSet');
    console.log("Hi5 Recognition CommandSet");
    this.fullControl = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.manageWeb);
    this.listTitle = this.context.pageContext.list.title;
    // other init code may be present  
    sp.setup({
      spfxContext: this.context
    });
    return Promise.resolve();
  }
  //End onInit

  //Begin onListViewUpdated
  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {

    const SendEmail: Command = this.tryGetCommand('Send Email');
    const NewItem: Command = this.tryGetCommand('New Item');

    if (this.listTitle.toLowerCase() === this.LIST_NAME) {

      //FullControl Access
      if (SendEmail) {
        if (this.fullControl) {
          SendEmail.visible = event.selectedRows.length > 0;
          NewItem.visible = event.selectedRows.length === 0;
          console.log("Is User has Create access: " + this.fullControl);
          /*
          if (event.selectedRows.length > 1) {            
            let rewardCount: number = parseInt(event.selectedRows[event.selectedRows.length - 1].getValueByName('RewardCount'));
            if (rewardCount >= 2) {
              let userName: number = event.selectedRows[event.selectedRows.length - 1].getValueByName('RecognizedUser')[0].title;
              // Dialog.alert(`Hello from ${strings.Title}:\n\n${message}`);
              Dialog.alert(` ${userName} already recieved 2 awards`);
              //swal("Already recieved 2 awards");
              //alert(`Already recieved 2 awards`);
            }            
            for (let index = 0; index < event.selectedRows.length; index++) {
              let rewardCount: number = parseInt(event.selectedRows[index].getValueByName('RewardCount'));
              if (rewardCount >= 2) {
                let userName: number = event.selectedRows[index].getValueByName('RecognizedUser')[0].title;
                // Dialog.alert(`Hello from ${strings.Title}:\n\n${message}`);
                //Dialog.alert(`Already recieved 2 awards`);
                swal("Already recieved 2 awards");
                //alert(`Already recieved 2 awards`);
              }
            }//End For
            
          }
          */
        } else {
          SendEmail.visible = false;
        }
      }
    } else {
      SendEmail.visible = false;
    }
  }
  //End onListViewUpdated

  //Begin onExecute
  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void {
    // const itemID: number = event.selectedRows.length > 0 ? event.selectedRows[0].getValueByName('ID') : null;
    /*
    if (this.listTitle.toLowerCase() === this.LIST_NAME) {
      if (event.selectedRows.length > 0) {
        //var emailFrom: string[] = new Array();
        var emailTo: string[] = new Array();
        var emailCC: string[] = new Array();
        for (let index = 0; index < event.selectedRows.length; index++) {
          //const element = event.selectedRows[index].getValueByName('ID'); 
          const rewardCount: number = parseInt(event.selectedRows[index].getValueByName('RewardCount'));
          if (rewardCount < 2) {
            const itemID = event.selectedRows[index].getValueByName('ID');
            const userTo = event.selectedRows[index].getValueByName('RecognizedUser')[0].title;
            const userCC = event.selectedRows[index].getValueByName('LineManager')[0].title;
            const userrecognize = event.selectedRows[index].getValueByName('GivingRecognition')[0].title;
            const actionDemonstrated = event.selectedRows[index].getValueByName('ActionDemonstrated');
            const linkageBehavior = event.selectedRows[index].getValueByName('Title');
            //emailFrom.push(userFrom);
            emailTo.push(userTo);
            emailCC.push(userCC);
            const emailBody = this.formatEmailBody(userTo, actionDemonstrated, linkageBehavior, userrecognize);
            this.sendEmail(emailTo, emailCC, itemID, rewardCount + 1, emailBody);
          }
        }//End For        
      }//End If
    }//End If   
    */
    switch (event.itemId) {
      case 'New Item':
        this.CreateItem();
        break;
    }
  }//End onExecute

  //End Handlers

}//End Class
