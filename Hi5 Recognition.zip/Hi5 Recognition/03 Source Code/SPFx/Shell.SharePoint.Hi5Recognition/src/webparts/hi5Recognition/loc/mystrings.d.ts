declare interface IHi5RecognitionWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'Hi5RecognitionWebPartStrings' {
  const strings: IHi5RecognitionWebPartStrings;
  export = strings;
}
