import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart, WebPartContext } from '@microsoft/sp-webpart-base';

import * as strings from 'Hi5RecognitionWebPartStrings';
import Hi5Recognition from './components/Hi5Recognition';
import { IHi5RecognitionProps } from './components/IHi5RecognitionProps';
import { SPHttpClient} from '@microsoft/sp-http';
import { sp } from "@pnp/sp";

export interface IHi5RecognitionWebPartProps {
  regionList: string;
  description: string;
  context: WebPartContext;
  siteUrl: string;
  spHttpClient:SPHttpClient;
  listName:string;
  metadataType:string;
  recognitionValuesList:string;
  HeaderText:string;
  HeaderDescription:string;
  HeaderTooltip:string;
  HeaderImage:string;
  topSiteURL:string;
  contactPerson:string;
  cssPath:string;
  peoplepickerlistname:string;
}

export default class Hi5RecognitionWebPart extends BaseClientSideWebPart<IHi5RecognitionWebPartProps> {

  protected onInit(): Promise<void> {

    return super.onInit().then(_ => {
  
      // other init code may be present
  
      sp.setup({
        spfxContext: this.context
      });
    });
  }

  public render(): void {
    const element: React.ReactElement<IHi5RecognitionProps> = React.createElement(
      Hi5Recognition,
      {
        description: this.properties.description,
        listName:this.properties.listName,
        siteUrl:this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        context: this.context,
        recognitionValuesList:this.properties.recognitionValuesList,
        regionList:this.properties.regionList,
        metadataType:this.properties.metadataType,
        HeaderText:this.properties.HeaderText,
        HeaderDescription:this.properties.HeaderDescription,
        HeaderTooltip:this.properties.HeaderTooltip,
        HeaderImage:this.properties.HeaderImage,
        topSiteURL: this.properties.topSiteURL,
        contactPerson:this.properties.contactPerson,
        cssPath:this.properties.cssPath,
        peoplepickerlistname:this.properties.peoplepickerlistname
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('listName', {
                  label: "Enter Recognition List Name"
                }),
                PropertyPaneTextField('peoplepickerlistname', {
                  label: "Enter peoplepicker Listname"
                }),
                PropertyPaneTextField('metadataType', {
                  label: "Enter List MetaData Type"
                }),
                PropertyPaneTextField('topSiteURL', {
                  label: "[Prod]Enter Top Site URL"
                }),
                PropertyPaneTextField('recognitionValuesList', {
                  label: "Enter Recognition Values List Name"
                }),
                PropertyPaneTextField('regionList', {
                  label: "Enter region Values List Name"
                }),
                PropertyPaneTextField('HeaderText', {
                  label: "Enter the Header text"
                }),
                PropertyPaneTextField('HeaderDescription', {
                  label: "Enter the Header Description text"
                }),
                PropertyPaneTextField('HeaderTooltip', {
                  label: "Enter the Header Tooltip text"
                }),
                PropertyPaneTextField('HeaderImage', {
                  label: "Enter the Header Image URL"
                }),
                PropertyPaneTextField('contactPerson', {
                  label: "Enter the Contact person details"
                }),
                PropertyPaneTextField('cssPath', {
                  label: "Enter the CSS Path"
                }),
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
