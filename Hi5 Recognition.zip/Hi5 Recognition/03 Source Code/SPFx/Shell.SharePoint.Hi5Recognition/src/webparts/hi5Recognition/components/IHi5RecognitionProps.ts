import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient} from '@microsoft/sp-http';
export interface IHi5RecognitionProps {
  description: string;
  context:WebPartContext;
  siteUrl: string;
  spHttpClient:SPHttpClient;
  listName:string;
  peoplepickerlistname:string;
  metadataType:string;
  recognitionValuesList:string;
  regionList:string;
  HeaderText:string;
  HeaderDescription:string;
  HeaderTooltip:string;
  HeaderImage:string;
  topSiteURL:string;
  contactPerson:string;
  cssPath:string;
}
