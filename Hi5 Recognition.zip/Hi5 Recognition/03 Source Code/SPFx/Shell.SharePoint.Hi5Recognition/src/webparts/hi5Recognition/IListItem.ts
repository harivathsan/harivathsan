export interface IListItem{
    // fileName?:string;
    // fileUrl:string;
    // created:string;
    // createdBy:string;
    // modified:string;
    // modifiedBy:string;  
username:string;
}