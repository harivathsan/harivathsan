/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Hi5 Recognition
Project Handled By                 : AI&DS Projects
Module Name		                     : Hi5Recognition
Module Description                 : To provide a recognition form
Author                             : Firdous Ali K.A
Created Date                       : 11th August 2023
Modified Date                      : 11th August 2023
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/

import * as React from 'react';
import styles from './Hi5Recognition.module.scss';
import './fonts.css';
import { IHi5RecognitionProps } from './IHi5RecognitionProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Col, Row, Button, Label, Input, UncontrolledAlert, UncontrolledTooltip, FormGroup } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { sp } from "@pnp/sp";
//import '@pnp/sp/profiles';
//import { PermissionKind } from 
import ReactQuill, { Quill } from "react-quill";
import 'react-quill/dist/quill.snow.css';
import { Web } from 'sp-pnp-js';
import * as pnp from 'sp-pnp-js';
import swal from 'sweetalert';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { IListItem } from '../IListItem';
import { SPPermission } from '@microsoft/sp-page-context';
import { TooltipHost } from "office-ui-fabric-react/lib/Tooltip";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {Dropdown} from "office-ui-fabric-react/lib/Dropdown";

const info = "data:image/svg+xml;base64,PHN2ZyBpZD0iR3JvdXBfMjE5MCIgZGF0YS1uYW1lPSJHcm91cCAyMTkwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIHZpZXdCb3g9IjAgMCAxMCAxMCI+DQogIDxkZWZzPg0KICAgIDxjbGlwUGF0aCBpZD0iY2xpcC1wYXRoIj4NCiAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGVfMjE1MyIgZGF0YS1uYW1lPSJSZWN0YW5nbGUgMjE1MyIgd2lkdGg9IjEwIiBoZWlnaHQ9IjEwIiBmaWxsPSJub25lIi8+DQogICAgPC9jbGlwUGF0aD4NCiAgPC9kZWZzPg0KICA8ZyBpZD0iR3JvdXBfMjE4OSIgZGF0YS1uYW1lPSJHcm91cCAyMTg5IiBjbGlwLXBhdGg9InVybCgjY2xpcC1wYXRoKSI+DQogICAgPGNpcmNsZSBpZD0iRWxsaXBzZV8yIiBkYXRhLW5hbWU9IkVsbGlwc2UgMiIgY3g9IjQuNSIgY3k9IjQuNSIgcj0iNC41IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLjUgMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEiLz4NCiAgICA8cGF0aCBpZD0iUGF0aF8zMjkiIGRhdGEtbmFtZT0iUGF0aCAzMjkiIGQ9Ik01LjU3NiwyLjZhLjU3Ni41NzYsMCwxLDEtLjU4NC0uNTc2LjU3OS41NzksMCwwLDEsLjU4NC41NzZNNC41Niw0LjE3M2guODhWNy45NzlINC41NloiLz4NCiAgPC9nPg0KPC9zdmc+DQo=";
export interface IHi5RecognitionState {
  spContext: any;
  requestor: any[];
  requestorEmail: any[];
  recognizedUser: any[];
  recognizedUserName: string;
  manager: any[];
  managerEmail: any[];
  recognitionValues: string;
  Regionvalues: string;
  region: any[];
  helpText:any[];
  SelectedRecognition: any[];
  RecognitionValue: any[];
  Message: string;
  cc: any[];
  ccName: string;
  Validated: boolean;
  fieldDisabled: boolean;
  insertSuccess: boolean;
  insertFailed: boolean;
  CurrentUserHasPermission: boolean;
  newForm: boolean;
  arr: [];
  today: any;
  priorDate: any;
  username: boolean;
  recognizedUseremail:any[];
  recoginition:boolean;
  checkedbutton :boolean;
  dropdownValue:any;
  dropdrownselected:any;
}

export default class Hi5Recognition extends React.Component<IHi5RecognitionProps, IHi5RecognitionState> {
  public reactQuillRef: any;
  
  //Begin Constructor
  constructor(props) {
    super(props);
    this.reactQuillRef = React.createRef();

    this.state = {
      today: new Date(),
      priorDate: [],
      spContext: this.props.context,
      arr: [],
      requestor: [],
      requestorEmail: [],
      recognizedUser: [],
      recognizedUserName: "",
      manager: [],
      managerEmail: [],
      recognitionValues: "",
      Regionvalues: "",
      region: [],
      helpText:[],
      SelectedRecognition: [],
      RecognitionValue: [],
      cc: [],
      ccName: "",
      Message: "",
      Validated: false,
      fieldDisabled: false,
      CurrentUserHasPermission: true,
      insertSuccess: false,
      insertFailed: false,
      newForm: true,
      username: false,
      recognizedUseremail:[],
      recoginition:false,
      checkedbutton:false,
      dropdownValue:[],
      dropdrownselected:[]
    
    };
    sp.setup(this.state.spContext);
    this.onSelectRecognizedUser = this.onSelectRecognizedUser.bind(this);
    this.onSelectRequestor = this.onSelectRequestor.bind(this);
    this.onSelectManager = this.onSelectManager.bind(this);
    this.getRecognitionValueDetails = this.getRecognitionValueDetails.bind(this);
    this.region = this.region.bind(this);
    this.helpText=this.helpText.bind(this);
    this.GetCurrentUser = this.GetCurrentUser.bind(this);
    this.GetManager = this.GetManager.bind(this);
    this.handleChangeMessage = this.handleChangeMessage.bind(this);
    this.OnSelectCheckbox = this.OnSelectCheckbox.bind(this);
    this.onSelectCC = this.onSelectCC.bind(this);
    this._submit = this._submit.bind(this);
    this.validateFields = this.validateFields.bind(this);
    this.newForm = this.newForm.bind(this);
    this.getFieldsValues = this.getFieldsValues.bind(this);
    let cssPath: string = escape(this.props.cssPath);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
    
  }//End Constructor

  //Begin Methods
  /**
   * Gets recipient's manager details
   * @param value 
   * @returns 
   */
  private async GetManager(value: string): Promise<any> {
    debugger;
    this.setState({ fieldDisabled: true });
    try {
      const profile = await sp.profiles.getPropertiesFor(value);//gets details of recipient
      var props = {};
      profile.UserProfileProperties.forEach((prop) => {
        props[prop.Key] = prop.Value;
      });
      profile.userProperties = props;

      const mProfile = await sp.profiles.getPropertiesFor(profile.userProperties.Manager);//gets details of recipient's manager's  details
      var mProps = {};
      mProfile.UserProfileProperties.forEach((prop) => {
        mProps[prop.Key] = prop.Value;
      });
      mProfile.userProperties = mProps;
      let Manager = [];
      let ManagerID = [];
      Manager.push(mProfile.userProperties["WorkEmail"]);//captures manager's email
      //this.setState({fieldDisabled:false});

      try {
        let web;
        if (this.props.topSiteURL === "" || this.props.topSiteURL === undefined || this.props.topSiteURL == null) {
          web = new Web(this.props.siteUrl);
        }
        else {
          web = new Web(this.props.topSiteURL);
        }
        await web.siteUsers.getByEmail(mProfile.userProperties["WorkEmail"]).get().then(user => {
          ManagerID.push(user.Id);//captures manager's ID
          this.setState({ manager: ManagerID });
          this.setState({ managerEmail: Manager });

        })/* .catch(reject => console.error('Error getting Id of user by Email ', reject)) */;
      }
      catch (e) {
        console.log('Error getting Id of user by Email ', e);
      }
      finally {
        this.setState({ fieldDisabled: false }, () => this.validateFields());
      }

    } catch (error) {
      console.log("Error in GetManager" + error.message);
    }//End

  }

  /**
  * Validate Fields
  */
  public validateFields() {
    debugger;
    if (this.state.requestor.length === 0 || this.state.recognizedUser.length === 0 || this.state.manager.length === 0 || this.state.recognitionValues === "" || this.state.Message === "" || this.state.Message ==="<p><br></p>"||this.state.Message === "<h2><br></h2>" || this.state.Message === "<h3><br></h3>" || this.state.Message === "<h1><br></h1>" || this.state.Message === "<h4><br></h4>" || this.state.Regionvalues === "") {
      this.setState({ Validated: false });
    }
    else {
      this.setState({ Validated: true });
    }
  }

  /**
   * Gets current user details
   * @returns 
   */
  private async GetCurrentUser(): Promise<any> {
    try {
      const web = new pnp.Web(this.props.context.pageContext.site.absoluteUrl);
      return await web.currentUser.get();
    }
    catch (error) {
      console.log("Error in spLoggedInUserDetails : " + error);
    }
  }

  /**
 * gets Recognition values details  from Recognition values list
 * @returns 
 */
  public async getRecognitionValueDetails(): Promise<any> {
    return this.props.spHttpClient.get(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.recognitionValuesList}')/items?$select=Title,ToolTip&$orderby=Order`,
      SPHttpClient.configurations.v1)
      .then(
        (response: SPHttpClientResponse) => {
          response.json().then((responseJSON) => {
            this.setState({ RecognitionValue: responseJSON.value });
            console.log("Recognition values: ", responseJSON.value);
          });
          return response.json();
        },
        (error: any): void => {
          alert("Recognition Values List Does not exist");
        });
  }
  public async region(): Promise<any> {
    debugger;
    return this.props.spHttpClient.get(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.regionList}')/items?$select=Title&$orderby=Order0`,
      SPHttpClient.configurations.v1)
      .then(
        (response: SPHttpClientResponse) => {
          response.json().then((responseJSON) => {
            this.setState({ region: responseJSON.value });
            console.log("Recognition values: ", responseJSON.value);
          });
          return response.json();
        },
        (error: any): void => {
          alert("Recognition Values List Does not exist");
        });
  }
  public async helpText(): Promise<any> {
    debugger;
    return this.props.spHttpClient.get(`${this.props.siteUrl}/_api/web/lists/getbytitle('Help Text')/items?$select=Title,Value&$orderby=ID`,
      SPHttpClient.configurations.v1)
      .then(
        (response: SPHttpClientResponse) => {
          response.json().then((responseJSON) => {
            this.setState({ helpText: responseJSON.value });
            console.log("Recognition values: ", responseJSON.value);
          });
          return response.json();
        },
        (error: any): void => {
          alert("Recognition Values List Does not exist");
        });
  }
  //End Methods

  //Begin Handler


  /**
   * Submits the form
   */
  public _submit = async (): Promise<void> => {
    debugger;
    const body: string = JSON.stringify({
      __metadata: { type: `SP.Data.${this.props.metadataType}` },
      //__metadata: { type: 'SP.Data.Hi5RecognitionItem' },
      Title: this.state.recognitionValues,
      ActionDemonstrated: this.state.Message,
      RecognizedUserId: this.state.recognizedUser[0],
      LineManagerId: this.state.manager[0],
      GivingRecognitionId: this.state.requestor[0],
      Region: this.state.Regionvalues,
      OtherPersonToBeInformedId: { '__metadata': { 'type': 'Collection(Edm.Int32)' }, results: this.state.cc.length == 0 ? [] : this.state.cc },
      vpship:this.state.dropdrownselected
      //ActionDemonstrated: this.state.Message,      
      //Title: this.state.recognitionValues,     

    });
    console.log("body: ", body);
    this.props.context.spHttpClient.post(`${this.props.siteUrl}/_api/web/Lists/GetByTitle('${this.props.listName}')/items`,
      SPHttpClient.configurations.v1,
      {
        headers: {
          'Accept': 'application/json;odata=verbose',
          'Content-type': 'application/json;odata=verbose',
          'odata-version': ''
        },
        body: body
      })
      .then((response: SPHttpClientResponse): void => {
        if (response.ok) {
          response.json().then((responseVal) => {
            if (responseVal != null) {
              swal({
                text: `You have Recognised ${this.state.recognizedUserName}`,
                icon: "success",
                dangerMode: false,
                closeOnClickOutside: false,
                closeOnEsc: false
              }).then((value) => {
                if (value) {
                  this.newForm();
                }
              });
            }
          });
        }
        else {
          swal("Error!", "Failed", "error");
        }
      }, (error: any): void => {
        alert("ERROR");
      });

    this.setState({ Validated: false });
  }

  /**
   * Renders New Form
   */
  // public async newForm() {
  //   await this.setState({ newForm: false }, async () => await this.validateFields());
  //   this.setState({
  //     recognizedUser: [],
  //     recognizedUserName: "",
  //     manager: [],
  //     managerEmail: [],
  //     recognitionValues: "",
  //     Regionvalues: "",
  //     SelectedRecognition: [],
  //     cc: [],
  //     ccName: "",
  //     Message: "",
  //     Validated: false,
  //     newForm: true
  //   }, () => this.validateFields());
  // }

  public async newForm() {
    debugger;
    this.setState({
      newForm: false
    }, () => this.setState({
      recognizedUser: [],
      recognizedUserName: "",
      recognizedUseremail:[],
      manager: [],
      managerEmail: [],
      recognitionValues: "",
      Regionvalues: "",
      SelectedRecognition: [],
      cc: [],
      ccName: "",
      Message: "",
      Validated: false,
      newForm: true,
      dropdrownselected:[]
    }));

  }
  /**
  * on select Recipient People picker
  * @param items 
  */
  public async onSelectCC(items: any[]) {
    let arr1 = [];
    let loginName = "";
    let email = "";
    let name = "";
    if (items.length > 0) {
      items.forEach(element => {
        arr1.push(element.id);
        loginName = element.loginName;
        // email=element.secondaryText;
        name = element.text;
      });
    }
    this.setState({ cc: arr1, ccName: name }, () => this.validateFields());
  }

  /**
   * Handle changes in text multi line textbox
   * @param e 
   * @param text 
   */
  
  public handleChangeMessage(e, text) {
    // const regex = /(<([^>]+)>)/gi;
    // const result = e.replace(regex, "")
    // console.log(result)
    //  if(result.length>10){
    //   alert("please stop writing")
    //  }
      if (text.ops.length === 1 && text.ops[0].delete != undefined) {
      this.setState({ Message: "" }, () => this.validateFields());
    }
    else {
      this.setState({ Message: e }, () => this.validateFields());
    }
    //(this.state.Message === "" || this.state.Message ==="<p><br></p>"||this.state.Message === "<h2><br></h2>" || this.state.Message === "<h3><br></h3>" || this.state.Message === "<h1><br></h1>" || this.state.Message === "<h4><br></h4>")?        this.setState({ Message: "" }, () => this.validateFields())    :      this.setState({ Message: e }, () => this.validateFields());

    
  } 
   
  public handleonpaste= (event) => {
    debugger;
    event.preventDefault();
  }
  public checkCharacterCount = (event) => {
  debugger;
      //const unprivilegedEditor = this.reactQuillRef.current.makeUnprivilegedEditor;
  
      if (event.currentTarget.innerText.length > 249 && event.key !== 'Backspace')
  
        event.preventDefault();
  
    }
  /**
  * On Select Checkbox of Recognition Values
  * @param e 
  */
  public OnSelectCheckbox(e) {
    let Recognition = this.state.SelectedRecognition;

    if (e.target.checked) {
      Recognition.push(e.target.defaultValue);

    }
    else {
      var index = Recognition.indexOf(e.target.defaultValue);
      if (index !== -1) {
        Recognition.splice(index, 1);
      }
    }

    let text = "";
    Recognition.map((item) => {
      text += item + ', ';
    });
    text = text.slice(0, -2);
    
  
    this.setState({ SelectedRecognition: Recognition, recognitionValues: text,}, () => this.validateFields());
    if(this.state.SelectedRecognition.length>=2){
      this.setState({ recoginition :true},() => this.validateFields());
    }
  }

  //Recongnized User
  private onSelectRequestor(items: any[]) {
    debugger;
    let arr1 = [];
    //let email=[];
    // let name="";
    if (items.length > 0) {
      items.forEach(element => {
        arr1.push(element.id);
        //email.push(element.secondaryText);
      });
    }
    if (items.length == 0) {
      this.setState({ requestor: arr1 }, () => this.validateFields());
    }
    else {
      this.setState({ requestor: arr1 }, () => this.validateFields());
    }
  }

  /**
   * on select Recipient People picker
   * @param items 
   */
  public async onSelectRecognizedUser(items: any[]) {
    debugger;
    let Userid = [];
    let loginName = "";
    let email = [];
    let name = "";
    if (items.length > 0) {
      items.forEach(element => {
        Userid.push(element.id);
        loginName = element.loginName;
        email = element.secondaryText;
        name = element.text;
      });
      this.GetListData(Userid, loginName);
      //this.GetManager(email);
      this.setState({ recognizedUser: Userid, recognizedUseremail: email  }, () => this.validateFields());

    }
    else{
      this.setState({ recognizedUser: [], recognizedUserName: "" ,recognizedUseremail:[]}, () => this.validateFields());

    }
  }

  /**
      * On select Line Manager people picker
      * @param items 
      */
  public async onSelectManager(items: any[]) {
    let arr1 = [];
    let email = [];
    if (items.length > 0) {
      items.forEach(element => {
        arr1.push(element.id);
        email = element.secondaryText;
      });
    }
    this.setState({ manager: arr1, managerEmail: email }, () => this.validateFields());
  }
  private onRadioButtonChanged = (event: React.ChangeEvent<HTMLInputElement>) => {
    debugger;
    console.log(`radioBtn onchange event handler ${event.currentTarget.value}`);
    this.setState({
      Regionvalues: event.currentTarget.value,
    }, () => this.validateFields());
  }

  private async GetListData(Userid, loginName) {

    var date = new Date();
var priorDate = new Date(date.getFullYear(), date.getMonth(), 1);
    debugger;
    try {
      //let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.state.listName + "')/Items?$filter=Title eq '" + filterTxt + "'";
      //let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.state.libName + "')/Items?$Select=ID,BaseName,FileLeafRef,FileRef,Created,Author/Title,Modified,Editor/Title&$expand=Author/Title,Editor/title&$filter=Title eq '" + filterTxt + "'";
      let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.props.peoplepickerlistname + "')/Items?$Select=Created,RecognizedUser/Id,Created&$expand=RecognizedUser&$filter=(Created le datetime'" + (date.toISOString()) + "') and (Created ge datetime'" + (priorDate.toISOString()) + "') and RecognizedUser/Id eq '" + (Userid) + "'";
      let response = await this.props.context.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1,
        {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=nometadata',
            'odata-version': ''
          }
          //body: body
        })
        .then((responseValues: SPHttpClientResponse): Promise<IListItem> => {
          return responseValues.json();
        })
        .then((item: IListItem): void => {
          debugger;
          console.log("Get Items successfully !!!");
          if (item['value'].length >= 5) {
            this.setState({
              username: true,
              recognizedUser: [],
              recognizedUserName: '',
              recognizedUseremail:[]
            }, () => this.validateFields());
          }
          else {
            this.setState({
              username: false}, () => this.validateFields());
            this.GetManager(loginName);
          }

        }, (error: any): void => {
          //alert("Error in Get Items !!!");
        });
    }
    catch (error) {
      console.log("Error in Get Items Data : " + error);
    }
  }
  
  private getFieldsValues = () => {
    try {
      this.props.spHttpClient
        .get(
          `${this.props.siteUrl}/_api/web/lists/getbytitle('Hi5 Recognition')/fields?$filter=EntityPropertyName eq 'vpship'`,
          SPHttpClient.configurations.v1,
          {
            headers: {
              Accept: "application/json;odata=nometadata",
              "odata-version": " ",
            },
          }
        )
        .then(
          (response: SPHttpClientResponse): Promise<{ value: any }> => {
            if (response.ok) {
              return response.json();
            } else {
              console.log("Error in Getting Field Values");
            }
          }
        )
        //.then((response: { value: { Choices: string[] }[] }): void => {
        .then((responseVal: any): void => {
          let len: number = responseVal.value[0].Choices.length;
          let itemChoice: string[] = responseVal.value[0].Choices;
          let itemColl = [];
          if (len > 0) {

            for (let index = 0; index < len; index++) {
              itemColl.push({ key: itemChoice[index], text: itemChoice[index] });
            }//End for

            this.setState({
              dropdownValue: itemColl
            });
          }
        });
    } catch (error) {
      console.log("Error in Getting Field Values function" + error);
    }
  }
  
  


  public async componentDidMount() {
    let userDetails = await this.GetCurrentUser();
    const web = new pnp.Web(this.props.context.pageContext.site.absoluteUrl);
    //const perms2 = await web.currentUserHasPermissions(PermissionKind.AddListItems);
    const perms2 = new SPPermission(this.props.context.pageContext.web.permissions.value).hasPermission(SPPermission.addListItems);
    debugger;
    this.setState({ requestorEmail: [userDetails.Email], CurrentUserHasPermission: perms2 });
    this.setState({ requestor: [userDetails.Id] });
    this.getRecognitionValueDetails();
    this.region();
    this.helpText();
    this.getFieldsValues();
  }

  //Begin Render
  public render(): React.ReactElement<IHi5RecognitionProps> {

    return (
      
      <div className={`${'container-fluid'} ${styles.hi5Recognition}`}>
        <Row>
          <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.BannerBgColor}>
            <Row>
              <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                <img className={styles.logo} src={this.props.siteUrl + "/SiteAssets/images/logo.png"} />
                <span className={styles.BannerText}>Thank your colleagues for their contributions</span>
              </Col>
              <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                <img className={styles.bannerImg} src={this.props.siteUrl + '/SiteAssets/images/BannerImage.png'} />
              </Col>
            </Row>
          </Col>
        </Row>
        <Row className={styles.ContentSection} style={{ backgroundImage: "url(" + this.props.siteUrl + "/SiteAssets/images/MicrosoftTeams-image.png)" }}>
          <Col xs={11} sm={11} md={11} lg={11} xl={11} className={styles.ContentArea}>
            <h5>We would like to share our appreciation</h5>
            <Row>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Name of the colleague you would like to appreciate <span className={styles.star}>*</span>
                    {this.state.recognizedUseremail.length == 0 ? <span className={styles.info}>
                    {<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'NAME OF THE COLLEAGUE YOU WOULD LIKE TO APPRECIATE')[0].Value:""}>
                        <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                      </TooltipHost>}</span>: <span className={styles.verfied}><img className={styles.verfieds} src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}
                  </label>
                  {this.state.username === true ? <h5 className={styles.alerts}>This User Exceeded This Month Limit Please Select Other user</h5> : ""}
                  <PeoplePicker
                    context={this.state.spContext}
                    placeholder={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'NAME OF THE COLLEAGUE YOU WOULD LIKE TO APPRECIATE')[0].Value:""}
                    personSelectionLimit={1}
                    groupName={""}
                    showtooltip={true}
                    defaultSelectedUsers={this.state.recognizedUseremail.length==0?[]:undefined}
                    selectedItems={this.onSelectRecognizedUser}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}
                    isRequired={true}
                    ensureUser={true}
                  />
                </Col>}

              </Col>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Mention the line manager of your colleague<span className={styles.star}>*</span>
                    {this.state.managerEmail.length == 0 ? <span className={styles.info}>
                    {<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'MENTION THE LINE MANAGER OF YOUR COLLEAGUE')[0].Value:""}>
                        <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                      </TooltipHost>}
                    </span> : <span className={styles.verfied}><img className={styles.verfieds} src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}

                  </label>
                  {this.state.managerEmail.length > 0 ? <PeoplePicker
                    context={this.state.spContext}
                    personSelectionLimit={1}
                    placeholder={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'MENTION THE LINE MANAGER OF YOUR COLLEAGUE')[0].Value:""}
                    groupName={""}
                    defaultSelectedUsers={this.state.managerEmail}
                    showtooltip={true}
                    selectedItems={this.onSelectManager}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}
                    isRequired={false}
                    disabled={this.state.fieldDisabled}
                    ensureUser={true} /> : <PeoplePicker
                    context={this.state.spContext}
                    personSelectionLimit={1}
                    placeholder={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'MENTION THE LINE MANAGER OF YOUR COLLEAGUE')[0].Value:""}
                    groupName={""}
                    defaultSelectedUsers={this.state.managerEmail}
                    showtooltip={true}
                    selectedItems={this.onSelectManager}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}
                    isRequired={true}
                    disabled={this.state.fieldDisabled}
                    ensureUser={true} />
                  }</Col>
                }

              </Col>
            </Row>

            <Row className='mt-5'>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Which behaviours did your colleague demonstrate? <span className={styles.star}>*</span>
                    {this.state.SelectedRecognition.length == 0 ? <span className={styles.info}>{<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'WHICH BEHAVIOURS DID YOUR COLLEAGUE DEMONSTRATE?')[0].Value:""}>
                        <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                      </TooltipHost>}
                    
                    </span> : <span className={styles.verfied}><img className={styles.verfieds} src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}

                  </label>
                  <span className={styles.TextMsg}>Select one or more attributes that you would like to appreciate</span>
                  
                  <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.checkBoxControl}>
                    {this.state.RecognitionValue.map((item, key) => {
                          return(
                            <span title={item.ToolTip} className={styles.checkboxLabel}>
                          <Input type="checkbox" name={item.Title} value={item.Title} onChange={this.OnSelectCheckbox} defaultChecked={this.state.SelectedRecognition.length>0?item.Title==this.state.SelectedRecognition[key]:false} disabled={this.state.SelectedRecognition.length==2?(this.state.SelectedRecognition[0]==item.Title?false:this.state.SelectedRecognition[1]==item.Title?false:true):false}></Input>{" "}{item.Title}
                          </span>
                          );
                        })}
                  </Col>
                  <label className={styles.alert}>Note : Select Only 2 Option </label>

                
                </Col>}

              </Col>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Write a note mentioning the action or efforts you would like to recognise<span className={styles.star}>*</span>
                    {this.state.Message == "" ? <span className={styles.info}>{<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'WRITE A NOTE MENTIONING THE ACTION OR EFFORTS YOU WOULD LIKE TO RECOGNISE')[0].Value:""}>
                        <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                      </TooltipHost>}
                    </span> : <span className={styles.verfied}><img className={styles.verfieds} src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}
                  </label>
                  <div onPaste={this.handleonpaste}>
                  <ReactQuill 
                   ref={this.reactQuillRef}
                   onKeyDown={this.checkCharacterCount}
                    theme='snow'
                    onChange={this.handleChangeMessage}
                    style={{ height: '160px' }}
                  /></div>
                  <label className={styles.alert}>Note : Maximum 250 Characters Are Allowed</label>
                </Col>}

              </Col>
            </Row>

            <Row className='mt-5'>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Your name <span className={styles.star}>*</span>
                    {/*this.state.requestor.length == 0 ? <span className={styles.info}><img src={this.props.siteUrl + "/SiteAssets/images/info.svg"} title={this.state.helpText.length>0?this.state.helpText[4].Value:""}/></span> : <span className={styles.verfied}><img src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}
                    {/* {this.state.requestorEmail.length == 0  ? <span className={styles.info}><img src={this.props.siteUrl+"/SiteAssets/images/info.svg"}/></span> :<span className={styles.verfied}><img src={this.props.siteUrl+"/SiteAssets/images/verfied.svg"}/></span>} */}
                                        {this.state.requestor.length == 0 ? <span className={styles.info}>{<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'YOUR NAME')[0].Value:""}>
                        <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                      </TooltipHost>}
                    </span> : <span className={styles.verfied}><img className={styles.verfieds}src={this.props.siteUrl + "/SiteAssets/images/verfied.svg" } /></span>}

                  </label>
                  <PeoplePicker
                    context={this.state.spContext}
                    personSelectionLimit={1}
                    placeholder={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'YOUR NAME')[0].Value:""}
                    groupName={""}
                    defaultSelectedUsers={this.state.requestorEmail}
                    showtooltip={true}
                    selectedItems={this.onSelectRequestor}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}
                    isRequired={true}
                    ensureUser={true}
                  />

                </Col>}

              </Col>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Region <span className={styles.star}>*</span>
                    {this.state.Regionvalues == "" ? <span className={styles.info}> 
                    {<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'REGION')[0].Value:""}>
                    <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                  </TooltipHost>}
                </span>: <span className={styles.verfied}><img className={styles.verfieds} src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}
                  </label>
                  <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.radioBoxControl}>
                    {this.state.region.map((item, key) => {
                      return (
                        <span className={styles.radioboxLabel}>
                          <Input type="radio" checked={this.state.Regionvalues == item.Title} name={item.Title} value={item.Title} onChange={this.onRadioButtonChanged}></Input>{" "}{item.Title}</span>
                      );
                    }
                    )}
                  </Col>

                </Col>}

              </Col>
            </Row>

            <Row className='mt-5'>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Mention any other person to be informed of your appreciation
                    {this.state.ccName == "" ? <span className={styles.info}>
                    {<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'MENTION ANY OTHER PERSON TO BE INFORMED OF YOUR APPRECIATION')[0].Value:""}>
                    <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                  </TooltipHost>}
                </span>: <span className={styles.verfied}><img className={styles.verfieds} src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}
                  </label>
                  <PeoplePicker
                    context={this.state.spContext}
                    personSelectionLimit={10}
                    placeholder={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'MENTION ANY OTHER PERSON TO BE INFORMED OF YOUR APPRECIATION')[0].Value:""}
                    groupName={""}
                    showtooltip={true}
                    selectedItems={this.onSelectCC}
                    showHiddenInUI={false}
                    principalTypes={[PrincipalType.User]}
                    resolveDelay={1000}
                    isRequired={true}
                    ensureUser={true} />
                </Col>
                }

              </Col>
              <Col xs={6} sm={6} md={6} lg={6} xl={6} >
                {this.state.newForm && <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.controllBg}>
                  <label>Vpship <span className={styles.star}></span>
                    {this.state.dropdrownselected == "" ? <span className={styles.info}> 
                    {<TooltipHost content={this.state.helpText.length>0?this.state.helpText.filter(item => item.Title.toUpperCase() === 'VPSHIP')[0].Value:""}>
                    <Icon iconName="Info" aria-label="Info tooltip" className={styles.infos}/>
                  </TooltipHost>}
                </span>: <span className={styles.verfied}><img className={styles.verfieds} src={this.props.siteUrl + "/SiteAssets/images/verfied.svg"} /></span>}
                  </label>
                  <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                   <Dropdown 
                   options={this.state.dropdownValue} 
                   onChange={(e,item)=>{this.setState({dropdrownselected:item.text});}} 
                   
                   placeholder={'Select an option'}
                   />
                  </Col>

                </Col>}

              </Col>
            </Row>

            <Row className='mt-4'>
              <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.buttonSection}>

                <Button className={styles.clearForm} onClick={this.newForm}>Clear Form</Button>
                <Button className={styles.submit} disabled={!this.state.Validated} onClick={this._submit}>Submit</Button>
                {/* {
                  !this.state.CurrentUserHasPermission ?
                    <Label className={styles.errorMessage}>You do not have permission to submit recognition for your colleague. Please contact: {this.props.contactPerson}</Label>
                    : ""
                } */}
              </Col>
            </Row>

          </Col>
        </Row>

      </div>
    );
  }

}//End Class



