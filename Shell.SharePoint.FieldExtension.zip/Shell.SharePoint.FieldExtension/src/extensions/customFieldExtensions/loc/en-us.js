define([], function() {
  return {
    "Title": "CustomFieldExtensionsFieldCustomizer"
  }
});