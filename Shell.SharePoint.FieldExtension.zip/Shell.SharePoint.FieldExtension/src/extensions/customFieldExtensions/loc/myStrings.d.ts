declare interface ICustomFieldExtensionsFieldCustomizerStrings {
  Title: string;
}

declare module 'CustomFieldExtensionsFieldCustomizerStrings' {
  const strings: ICustomFieldExtensionsFieldCustomizerStrings;
  export = strings;
}
