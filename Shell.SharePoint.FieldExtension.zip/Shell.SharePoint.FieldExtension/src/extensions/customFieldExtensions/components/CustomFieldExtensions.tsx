import { Log } from '@microsoft/sp-core-library';
import { override } from '@microsoft/decorators';
import * as React from 'react';
import Commments from './Comments';
import styles from './CustomFieldExtensions.module.scss';
import * as $ from 'jquery';

export interface ICustomFieldExtensionsProps {
  text: string;
}

const LOG_SOURCE: string = 'CustomFieldExtensions';

export default class CustomFieldExtensions extends React.Component<ICustomFieldExtensionsProps, {}> {
  @override
  public componentDidMount(): void {
    //debugger;
    Log.info(LOG_SOURCE, 'React Element: CustomFieldExtensions mounted');
    console.log("Begin Apply Padding");
    $("div[data-automation-key='ReviewComments']").css('padding-top', '0px');
    console.log("End Apply Padding");
  }

  @override
  public componentWillUnmount(): void {
    Log.info(LOG_SOURCE, 'React Element: CustomFieldExtensions unmounted');
  }

  @override
  public render(): React.ReactElement<{}> {    
     console.log("Begin Render");
     
      let rawComments = this.props.text.split(";");
      let comment = "";
      let reviewerName = "";
      let reviewDate = "";
      let divComment = null;
      divComment = (
        <div>
          {
            rawComments.map((rawComment, index) => {

              if (rawComment.split(":").length == 3) {
                comment = rawComment.split(":")[2];
                reviewerName = rawComment.split(":")[1].split("(")[0];
                reviewDate = rawComment.split(":")[1].split("(")[1].replace(")", "");
                return (
                  <Commments review={comment} reviewername={reviewerName} reviewdate={reviewDate} />
                );
              }
              if (rawComment.split(":").length == 2) {
                comment = rawComment.split(":")[1];
                reviewerName = rawComment.split(":")[0].split("(")[0];
                reviewDate = rawComment.split(":")[0].split("(")[1].replace(")", "");
                return (
                  <Commments review={comment} reviewername={reviewerName} reviewdate={reviewDate} />
                );
              }


            })
          }
        </div>
      );

      return (
        <div className={styles.cell}>
          {/* { this.props.text } */}
          {divComment}
        </div>
      );   

      console.log("End Render");
  }//End Render
}
