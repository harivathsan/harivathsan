import * as React from 'react';

const comments = (props) => {
  return (
    <div>
      <p><b>Reviewed By:</b>{props.reviewername} on {props.reviewdate}</p>
      <p><b>Comment:</b>{props.review}</p>
    </div>
  );
};
export default comments;