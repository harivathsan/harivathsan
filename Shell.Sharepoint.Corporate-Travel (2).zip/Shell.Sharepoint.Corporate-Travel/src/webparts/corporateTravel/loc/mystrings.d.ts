declare interface ICorporateTravelWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CorporateTravelWebPartStrings' {
  const strings: ICorporateTravelWebPartStrings;
  export = strings;
}
