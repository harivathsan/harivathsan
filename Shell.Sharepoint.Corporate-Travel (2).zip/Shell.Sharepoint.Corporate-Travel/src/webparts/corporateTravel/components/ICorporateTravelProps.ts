import { SPHttpClient } from '@microsoft/sp-http';
export interface ICorporateTravelProps {
  spHttpClient: SPHttpClient;
  siteurl: string;
  description: string;
  country:string;
  Textcolor:string;
  CountryArray: Array<string>[];
  TravelArray: Array<string>[];
  countryNavigation :Array<string>[];
  TravelNavigation: Array<string>[];
  selected : Array<string>[];
  selectedTravel : Array<string>[];
  selectedAZSearch : Array<string>[];
  AlertArray :Array<string>[];
  GlobalNavArray: Array<string>[];
  GlobalNavigation: Array<string>[];
  AZDropdownArray: Array<string>[];
  AZDropdown: Array<string>[];
  ImageLinkArray:Array<string>[];
  buttonVisibility:string;
  TopTextArray:Array<string>[];
  
}
