import * as React from 'react';
import styles from './CorporateTravel.module.scss';
import { ICorporateTravelProps } from './ICorporateTravelProps';
import 'bootstrap/dist/css/bootstrap.min.css';
//import { Carousel } from 'react-responsive-carousel';
import * as $ from 'jquery';
import { Typeahead } from 'react-bootstrap-typeahead'; // ES2015
import 'react-bootstrap-typeahead/css/Typeahead.css';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import 'bootstrap';
import 'react-responsive-tabs/styles.css';
//import Modal from 'react-awesome-modal'; 
export default class CorporateTravel extends React.Component<ICorporateTravelProps, {}> {
  public state: ICorporateTravelProps;
  constructor(props, context) {
    super(props);
    this.state = {
      spHttpClient: this.props.spHttpClient,
      siteurl: this.props.siteurl,
      description: this.props.description,
      Textcolor: '',
      buttonVisibility:'',
      country: '',
      CountryArray: [],
      TravelArray: [],
      countryNavigation: [],
      TravelNavigation: [],
      selected: [],
      selectedTravel: [],
      selectedAZSearch: [],
      AlertArray: [],
      GlobalNavArray: [],
      GlobalNavigation: [],
      AZDropdownArray: [],
      AZDropdown: [],
      ImageLinkArray: [],
      TopTextArray:[],

    };
    this.openTab = this.openTab.bind(this);
  }
  public componentDidMount() {
   // alert("Loading Production Backup Code");
    this._renderListData("A-Z-Links");
    this._renderListData("TravelBrief");
    this._renderListData("Travel-Book");
    this._renderListData("Global-Navigation");
    this._renderListData("ImageLinks");
    this._renderListData("Homepage");
    this._TravelAlerts();
    
    //this.GetContentFooter();
    
    document.getElementById("tab1").style.backgroundColor = "#fbce07";
    document.getElementById("tab2").style.backgroundColor = "#efefef";
    document.getElementById("tab3").style.backgroundColor = "#efefef";
    document.getElementById("Concerns").style.display = "none";
    document.getElementById("Help").style.display = "none";  
    this.highlighttabs();
    //$("#navbarTogglerDemo01 .rbt-input-main form-control .rbt-input").addClass("test") ;
  }

  //Function to Tab
  private openTab(evt, TabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName(`${styles.tablinks}`);
    for (i = 0; i < tablinks.length; i++) {

      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(TabName).style.display = "block";

    if (TabName == 'Feedback') {
      document.getElementById("tab1").style.backgroundColor = "#fbce07";
      document.getElementById("tab2").style.backgroundColor = "#efefef";
      document.getElementById("tab3").style.backgroundColor = "#efefef";
    }
    else if (TabName == 'Concerns') {
      document.getElementById("tab1").style.backgroundColor = "#efefef";
      document.getElementById("tab2").style.backgroundColor = "#fbce07";
      document.getElementById("tab3").style.backgroundColor = "#efefef";
    }
    else if (TabName == 'Help') {
      document.getElementById("tab1").style.backgroundColor = "#efefef";
      document.getElementById("tab2").style.backgroundColor = "#efefef";
      document.getElementById("tab3").style.backgroundColor = "#fbce07";
    }
  }
  //Function to Tab end

  //Function to render typeahead dropdown values   
  private _renderListData(value): void {
    var sectionValue = value;
    var NewISiteUrl = this.props.siteurl;
    var NewSiteUrl = NewISiteUrl.replace("SitePages", "");
    var restUrl;
    if (value == "A-Z-Links"|| value == "Travel-Book" || value == "TravelBrief") {
      restUrl = `${NewSiteUrl}/_api/web/lists/getbytitle('Country')/items?$filter=(Section eq '` + sectionValue + `')&$select=Country,Navigation,LID,ImageSrc,Color,BookNowButton,ID&$top=2000&$orderby=Country asc`;
    } else {
      restUrl = `${NewSiteUrl}/_api/web/lists/getbytitle('Country')/items?$filter=(Section eq '` + sectionValue + `')&$select=Country,Navigation,LID,ImageSrc,Color,BookNowButton,ID,Heading,Heading2&$top=2000`;
    }
    //var restUrl =`${NewSiteUrl}/_api/web/lists/getbytitle('Country')/items?$filter=(Section eq '`+sectionValue+`')&$select=Country,Navigation,LID,ImageSrc,Color,ID,BookNowButton&$top=2000`;
    $.ajax({
      url: restUrl,
      method: "GET",
      dataType: "json",
      headers: { "Accept": "application/json; odata=verbose" },
      async: false,
      success: function (AZData) {
        if (value == "A-Z-Links") {
          this.setState({ AZDropdownArray: AZData.d.results });
        }
        else if (value == "TravelBrief") {
          let sortedarray = AZData.d.results.sort();
          this.setState({ TravelArray: sortedarray });
        }
        else if (value == "Travel-Book") {
          this.setState({ CountryArray: AZData.d.results });

        }
        else if (value == "ImageLinks") {
          this.setState({ ImageLinkArray: AZData.d.results });
        }
        else if (value == "Homepage") {
          this.setState({ Textcolor: AZData.d.results[0].Color });
          this.setState({ buttonVisibility: AZData.d.results[0].BookNowButton });
          this.setState({TopTextArray:AZData.d.results});
        }
        else if (value == "Global-Navigation") {
          for (var i = 0; i < AZData.d.results.length; i++) {
            var item = AZData.d.results[i];
            var listURL = "";
             if (i != AZData.d.results.length - 1) {
              listURL = `<li class=nav-item id="` + item["LID"] + `"><a class=nav-link onclick= window.open("` + item["Navigation"].Url + `") href="#">` + item["Navigation"].Description + `</a> </li><span class="pipelinestlye">|</span>`;
            } else {
              listURL = `<li class=nav-item id="` + item["LID"] + `"><a class=nav-link onclick= window.open("` + item["Navigation"].Url + `") href="#">` + item["Navigation"].Description + `</a> </li>`;
            }
            $("#Navi").append(listURL);
          }
          this.setState({ GlobalNavigation: AZData.d.results });
        }
      }.bind(this),
      error: (AZData) => {
        console.log(AZData);
      }
    });
  }
  //Funtion for Header Text highlight
  private highlighttabs(): void {
    var pageurl = window.location.href;

    if (pageurl.indexOf("workbench") != -1) {
      $("#Home").css({ "font-weight": 'bold' });
      $("#Home a").css({ "color": 'black !important' });
    }
    if (pageurl.indexOf("Corporate-Travel") != -1) {
      $("#Home").css({ "font-weight": 'bold' });
      $("#Home a").css({ "color": 'black !important' });
    }
  }
  //Function to render typeahead dropdown values ends
  //Function to Navigate on click of typeahead
  private SearchNavigate(val): void {
    var searchval = val;
    var NewISiteUrl = this.props.siteurl;
    var NewSiteUrl = NewISiteUrl.replace("SitePages", "");
    var searchSelected;
    if (searchval == "A-Z-Links") {
      searchSelected = this.state.selectedAZSearch;
    }
    else if (searchval == "TravelBrief") {
      searchSelected = this.state.selectedTravel;
    }
    else if (searchval == "Travel-Book") {     
       searchSelected = this.state.selected;      
    }
    var navRestURL = `${NewSiteUrl}/_api/web/lists/getbytitle('Country')/items?$filter=((Section eq '` + searchval + `')and(Country eq '` + searchSelected + `'))&$select=Country,Navigation,ID&$top=2000`;
    $.ajax({
      url: navRestURL,
      method: "GET",
      dataType: "json",
      headers: { "Accept": "application/json; odata=verbose" },
      async: false,
      success: function (AZSerachData) {
        //console.log(AZSerachData);
        if (searchval == "A-Z-Links") {
           this.setState({ AZDropdown: AZSerachData.d.results });                
                // variable for the map the navigation for A-Z Links search
                var navurlAZ = AZSerachData.d.results[0].Navigation.Url;
                if (navurlAZ != null){
                  window.open(navurlAZ);
                    //this.navigate(navurlAZ);
                }                 
          }
        else if (searchval == "TravelBrief") {
          this.setState({ TravelNavigation: AZSerachData.d.results });
            // variable for the map the navigation while booking country travel briefs
            var navurlTravel = AZSerachData.d.results[0].Navigation.Url;

                if (navurlTravel != null){
                  window.open(navurlTravel);
                    //this.navigate(navurlAZ);
                }
        }
        else if (searchval == "Travel-Book") {                  
          this.setState({ countryNavigation: AZSerachData.d.results });
          var buttonvalue1 = this.state.buttonVisibility; 
             if(buttonvalue1 != "not-allowed" )
             {
           // variable for the map the navigation while booking from Book Now
               var navurl = AZSerachData.d.results[0].Navigation.Url;
                if (navurl != null){
                  window.open(navurl);
                    //this.navigate(navurlAZ);
                }
            }
        }
        this.setState({ AZDropdown: AZSerachData.d.results });
      }.bind(this),
      error: (AZSerachData) => {
       // console.log(AZSerachData);
      }
    });
  }
  /*Function to get Travel alerts*/
  private _TravelAlerts(): void {
    var reactHandler = this;
    var NewISiteUrl = this.props.siteurl;
    var NewSiteUrl = NewISiteUrl.replace("SitePages", "");
  // console.log(NewSiteUrl);
    var restUrl = `${NewSiteUrl}/_api/web/lists/getbytitle('Alerts')/items?&$select=News,ID,Title`;
    $.ajax({
      url: restUrl,
      method: "GET",
      dataType: "json",
      headers: { "Accept": "application/json; odata=verbose" },
      async: false,
      success: (data) => {

        var marq1 = "";
        for (var i = 0; i < data.d.results.length; i++) {
          var item = data.d.results[i];
          marq1 = marq1 + ` <b class="co">` + item["Title"] + ` :</b> ` + item["News"];
        }
        $("#marq").append(`<marquee>` + marq1 + `</marquee>`);
        this.setState({ AlertArray: data.d.results });
      },
      error: (data) => {
        console.log(data);
      }

    });
  }
  
  /*Function to hide ribbon for mordern page */
  public HideDivs() {
    // $( "nav[role^='webPartContainer']" ).css({ display: 'none' }); 
    $("div[class^='commandBarWrapper']").css({ display: 'none' });
    $("div[class^='commentsWrapper']").css({ display: 'none' });
    $("div[class^='contentBox_']").css({ display: 'none' });
    $("div[class^='Nav']").css({ display: 'none' });
    $("div[class^='CanvasZone']").css({ "max-width": '100%' });
    $("div[id^='SuiteNavPlaceHolder']").css({ display: 'none' });
  }
  /*Function to hide ribbon for mordern page end */
  public render(): React.ReactElement<ICorporateTravelProps> {
    const { selected, selectedTravel, selectedAZSearch } = this.state;

    // variable for the fecthing the country list for Book Now
    var optionsNav = this.state.CountryArray.map((item, i) => {
      var countryList = item["Country"];
      return countryList;
    });
   
   let uniArrEvent=optionsNav.filter((item, index) => {
    return optionsNav.indexOf(item) === index;
   });
   optionsNav=uniArrEvent;
    //Variable for fetching the ImageURL
    var topimagesrcURL = this.state.ImageLinkArray.map((item, i) => {
      var sourceurl = item["ImageSrc"];
      return sourceurl;
    });
    var topimageNavigation = this.state.ImageLinkArray.map((item, i) => {
      var sourcenavigation = item["Navigation"].Url;
      return sourcenavigation;
    });

    var optionsAZSearch = this.state.AZDropdownArray.map((item, i) => {
      var AZ = item["Country"];
      return AZ;
    });
    // variable for the fecthing the country Travel brief
    var optionsNavTravel = this.state.TravelArray.map((item, i) => {
      var travel = item["Country"];
      return travel;
    });   
    /*css for the hiding the ribbon in MUI*/
    $("nav[role^='navigation']").css({ display: 'none' });
    $("div[class^='contentBox_']").css({ display: 'none' });
    $("div[class^='commentsWrapper']").css({ display: 'none' });
    $("div[class^='mainRow']").css({ display: 'none' });
    $("div[class^='mainHeader']").css({ display: 'none' });
    $("div[class^='removeFocusOutline']").css({ display: 'none' });
    $("div[class^='spNav']").css({ display: 'none' });
    $("div[class^='SPCanvas']").css({ "max-height": '0px' });
    $("div[class^='CanvasZone']").css({ "padding-right": '0px' });
    $("div[id^='SuiteNavPlaceHolder']").css({ display: 'none' });

    window.setTimeout(this.HideDivs, 2000);
    /*css for the hiding the ribbon in MUI*/
    return (
      <div className={styles.corporateTravel}>
        <div className={styles.container}>
          <div className={styles.topheader}>
            <div className={`row`}>
              <div className={`col-sm-1 ${styles.shellstyle}`}>
              {/* https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/Pecten-Small.png */}
                <a title="Homepage" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/Corporate-Travel-Home.aspx')} href="#">
                  <img className={styles.shellLogo} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/Pecten-Small.png"></img>
                </a>
              </div>
              <div className={`col-sm-11`}>
                <div className={`row`}>
                  <h3 className={styles.headstyle}>CORPORATE TRAVEL</h3>
                  <h6 className={styles.subheadstyle}>SEAMLESS AND SAFE</h6></div>
              </div>
            </div>
            <nav className="navbar sticky-top navbar-expand-lg navbar-light bg-light">
              <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarTogglerDemo01">
                <ul className="navbar-nav mr-auto mt-2 mt-lg-0" id="Navi">
                </ul>
                <div className="form-inline my-2 my-lg-0">
                  <Typeahead
                    labelKey="A-Z-Links"
                    onChange={(AZsearch) => this.setState({ selectedAZSearch: AZsearch })}
                    onKeyDown={(e) => {
                      if (e.keyCode === 13) {
                        e.preventDefault(); // Suppress the keystroke.                                    
                        this.SearchNavigate("A-Z-Links");
                      }
                    }}
                    options={optionsAZSearch}
                    placeholder="Travel A-Z "
                    selected={selectedAZSearch}
                    className={styles.fontAwesome} />
                  <button className={`btn btn-outline-warning my-2 my-sm-0 `} type="submit" onClick={() => this.SearchNavigate("A-Z-Links")}><span><img className={styles.icon2} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/search-element-icon-white.png"></img></span></button>
                </div>
              </div>
            </nav>
          </div>
          <div className={styles.row}>
            <div className={`col-sm-12 ${styles.yammerpadding}`}>
              <div>
                <a onClick={() => window.open(topimageNavigation[topimageNavigation.length - 1])}><img src={topimagesrcURL[topimagesrcURL.length - 1]} width="100%"></img></a>
              </div>
              <div className={styles.banner}>
                <br />              
                <div className={styles.gridContainerHeader}>
                  <div className={styles.rowtable}>
                  </div>
                  <br /><br />
                   <div className={styles.noteText1} style={{ color: this.state.Textcolor }}>
                    {this.state.TopTextArray.map(function (item, i) {
                       let headertext2 = item["Heading2"] == null ? "" : item["Heading2"];
                       
                          return (<>
                            {                              
                               <div dangerouslySetInnerHTML={{ __html: headertext2 }} />                              
                            }
                           </>);
                        })}
                      </div>
                  <div className={`row`}>
                    <div className={`col-sm-1 ${styles.inputalignment}`}></div>
                    <div className={`col-sm-2 ${styles.locationicon}`}>
                      <img className={styles.thumbnailimgloction} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/locationimage.png"></img>
                    </div>
                    <div className={`col-sm-6 ${styles.inputalignment} ${styles.tooltip1}`}>
                    {/* Code change by AI&DS team */}
                    <span className={styles.tooltiptext1}><b className={styles.tooltiptextstyle}>BEFORE YOU PROCEED!</b><br />Do you have a <b>travel profile?</b> If no,<a className={styles.tooltiplinktext} onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/Accept-the-Data-Privacy-Statement-and-Create-Your-Travel-Profile.aspx')}href="#">click here.</a></span>
                      {/* <span className={styles.tooltiptext1}><b className={styles.tooltiptextstyle}>BEFORE YOU PROCEED!</b><br />Do you have a <b>travel profile?</b> If no,<a className={styles.tooltiplinktext} onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Pages/Your-Online-Booking-Tool.aspx')}href="#">click here.</a><br />For <b>international travel bookings</b> and <b>domestic flights</b>, do you have a <b>Pre-Trip Approval ID (PTA ID)?</b> If no,<a className={styles.tooltiplinktext} onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/PTAHomePage.aspx')}href="#">click here.</a></span> */}
                      <Typeahead
                        labelKey="Destination"
                        onChange={(destinationSelected) => this.setState({ selected: destinationSelected })}
                        onKeyDown={(e) => {
                            var buttonvalue = this.state.buttonVisibility;
                          if(buttonvalue != "not-allowed" ){
                            if (e.keyCode === 13) {
                              e.preventDefault(); // Suppress the keystroke.                                    
                              this.SearchNavigate('Travel-Book');
                            }
                        }
                        }}
                        options={optionsNav}
                        placeholder="Base Location"
                        selected={selected}
                        className={styles.fontAwesome} />
                    </div>
                  
                    <div className={`col-sm-1 ${styles.inputalignment}`}><button type="submit" className={styles.button} style={{ cursor: this.state.buttonVisibility }} onClick={() => this.SearchNavigate('Travel-Book')}><b>Book Now</b></button></div>
                    <div className={`col-sm-2 ${styles.inputalignment}`}></div>
                    <br />
                    <div className={styles.noteText1} style={{ color: this.state.Textcolor }}>
                    {this.state.TopTextArray.map(function (item, i) {
                       let headertext1 = item["Heading"] == null ? "" : item["Heading"];
                       
                          return (<>
                            {                              
                               <div dangerouslySetInnerHTML={{ __html: headertext1 }} />                              
                            }
                           </>);
                        })}
                      </div>
                    {/* <div className={styles.noteText1} style={{ color: this.state.Textcolor }}>

                      <b>Need to cancel a booking?</b><br />
                      <p className={styles.noteText2} style={{ color: this.state.Textcolor }}>Bookings can’t be cancelled online currently. Please contact <a className={styles.noteTextLink} style={{ color: this.state.Textcolor }} href="#" onClick={() => window.open('https://eu023-sp.shell.com/sites/SPOAA0223/MUIRMB9/SitePages/Travel-Agency-and-Contacts.aspx')}>your agency</a> directly.</p>
                      
                    </div> */}
                  </div>
                </div>
                <br />
              </div>
            </div>
          </div>
          <div className={`row ${styles.subheader}`}>
            <div className={`col-sm-2 ${styles.floatAlert}`} ><span className={`${styles.subHeading}`}><img src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/Travel.png" className={styles.imgstyle} /><a onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/Travel-Alerts.aspx')} href="#"><div className={styles.tooltip}><b>Travel Alert</b><span className={styles.tooltiptext}><b>Alphabetical listing of active Travel Alerts and Advisories</b></span></div></a></span></div>
            {/* <Carousel autoPlay infiniteLoop interval={5000} stopOnHover={false}  showThumbs={false} showArrows={true} showIndicators={false} showStatus={false} > 
                    { _travelalerts }
                </Carousel>  */}
            <div className={`col-sm-10`} id="marq"></div>
          </div>
          <div className={styles.gridContainer}>
            <div className={`row`}>
              <div className={`col-sm-4 ${styles.levelcontainer}`} >
                <img className={styles.thumbnailimg} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/56.jpg"></img>
                <a href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/Corporate-Travel-Planning.aspx')}><div className={styles.overlay}>
                  <div className={`row ${styles.rowMargin}`}><div className={`col-sm-11 ${styles.overlaycontent}`}>PLAN YOUR TRIP</div><div className={`col-sm-1 ${styles.overlaycontent}`}>&#10095;<br /><br /><br /></div><p className={styles.paracontent}>Prepare for your business trip</p></div></div></a>
              </div>
              <div className={`col-sm-4 ${styles.levelcontainer}`} >
                <img className={styles.thumbnailimg} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/57.jpg"></img>
                <a href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/During-Trip.aspx')}><div className={styles.overlay}>
                  <div className={`row ${styles.rowMargin}`}>
                    <div className={`col-sm-11 ${styles.overlaycontent}`}>DURING YOUR TRIP</div>
                    <div className={`col-sm-1 ${styles.overlaycontent}`}>&#10095;<br /><br /><br /></div>
                    <p className={styles.paracontent}>Be conscious of your surroundings and pro-actively mitigate (HSSE) risks and issues</p></div></div></a>
              </div>
              <div className={`col-sm-4 ${styles.levelcontainer}`} >
                <img className={styles.thumbnailimg} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/58.jpg"></img>
                <a href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/After-Trip.aspx')}> <div className={styles.overlay}>
                  <div className={`row ${styles.rowMargin}`}><div className={`col-sm-11 ${styles.overlaycontent}`}>AFTER YOUR TRIP</div><div className={`col-sm-1 ${styles.overlaycontent}`}>&#10095;<br /><br /><br /></div><p className={styles.paracontent}>Provide us with feedback and manage your expenses</p></div></div></a>
              </div>
            </div>
          </div>
          <div className={styles.gridContainerlevel1}>
            <div className={`row ${styles.level2row}`}>
              <div className={`col-sm-12 ${styles.yammergrid}`} >
                <div className={`row ${styles.headertravelBreif}`}>
                  <div className={`col-sm-12 ${styles.TravelBriefHeader}`}>
                    <span className={styles.travelbriefspan}><b>COUNTRY TRAVEL BRIEFS</b></span>
                    <br />
                  </div>
                </div>
                <div className={`row ${styles.headertravelBreif}`}>
                  <div className={`col-sm-1 ${styles.travelBrief}`}>
                    <img className={styles.thumbnailimgisos} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/isos.png"></img>
                  </div>
                  <div className={`col-sm-9 ${styles.inputalignment}`}>
                    <Typeahead
                      labelKey="Destination"
                      onChange={(st) => this.setState({ selectedTravel: st })}
                      onKeyDown={(e) => {
                        if (e.keyCode === 13) {
                          e.preventDefault(); // Suppress the keystroke.                                    
                          this.SearchNavigate("TravelBrief");
                        }  
                      }}
                      options={optionsNavTravel.sort()}
                      placeholder="Country"
                      selected={selectedTravel}
                      className={styles.fontAwesome} />
                  </div>
                  <div className={`col-sm-2 ${styles.inputalignment}`}>
                    <button type="submit" className={styles.button} onClick={() => this.SearchNavigate("TravelBrief")}><b>Submit</b></button>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <div className={styles.tabrow}>
            <div className={styles.gridContainer}>
              <div className={styles.tab}>
                <div className={styles.tablinks} id="tab1" onClick={() => this.openTab(event, `Feedback`)}>Supplier and other feedback</div>
                <div className={styles.tablinks} id="tab2" onClick={() => this.openTab(event, `Concerns`)} >Issues or Concerns</div>
                <div className={styles.tablinks} id="tab3" onClick={() => this.openTab(event, `Help`)} >Global Helpline</div>
              </div>
              <div className={styles.tabscontainer}>
                <div id="Feedback" className="tabcontent">
                  <div className={styles.tabgridContainer}>
                    <div className={`row`}>
                      <div className={`col-sm-12 ${styles.tabsalignment2}`}>
                        <span className={styles.feedbacksec}><b>Your Services</b></span>
                        <div className={styles.tabgridContainer}>
                          <div className={`row`}>
                            <p className={styles.yourservicepara}>If you have feedback or questions about our supplier service, please select the relevant option on the right.</p>
                            <br />
                          </div>
                        </div>
                        <div className={`row ${styles.reportsec}`}>
                          <div className={`col-sm-6 ${styles.tabsalignment2}`}>
                            <div className={`row ${styles.ratingoutline}`}>
                              <div className={`col-sm-11 ${styles.tabsalignment2} ${styles.formsection}`}>
                                {/*<span><b>GTAP > CWP</b></span>*/}
                                <a href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/CWT%20Feedback/Item/newifs.aspx?List=8c01dfc6-05a2-4bfa-8620-ff8235aa13b5&Web=4b9c91c4-722d-464c-8da5-288ad849fea2')}>
                                  <p className={styles.tabstext}>I booked with CWT</p></a>
                              </div>
                              <div className={`col-sm-1 ${styles.tabsalignment2} ${styles.formsection}`}>&nbsp;&nbsp;&nbsp;&#10095;</div>
                              <p className={styles.subptagtext}>feedback about CWT / a supplier booked through CWT</p>
                            </div>

                          </div>
                          <div className={`col-sm-6 ${styles.tabsalignment2}`}>
                            <div className={`row ${styles.ratingoutline}`}>
                              <div className={`col-sm-11 ${styles.tabsalignment2} ${styles.formsection}`}>
                                {/*<span><b>LTAP</b></span>*/}
                                <a href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FAAFAA4985%2FCorporateandHR%2FCorporateTravel%2FShared%20Documents%2FLocal%20Travel%20Agency%20Contacts%2Epdf&parent=%2Fsites%2FAAFAA4985%2FCorporateandHR%2FCorporateTravel%2FShared%20Documents')}>
                                  {/* <a href="#"onClick={()=>window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Pages/How-to-Get-a-Travel-Profile.aspx')}> */}
                                  <p className={styles.tabstext}>I booked with a local agency (click here to review list)</p></a>
                              </div>
                              <div className={`col-sm-1 ${styles.tabsalignment2} ${styles.formsection}`}>&nbsp;&nbsp;&nbsp;&#10095;</div>
                              <p className={styles.subptagtext}>feedback about the agency /a supplier booked through the agency</p>
                            </div>

                          </div>
                        </div>
                        {/* Second row */}
                        <div className={`row ${styles.reportsec}`}>
                          <div className={`col-sm-2 ${styles.tabsalignment2}`}> </div>
                          <div className={`col-sm-8 ${styles.tabsalignment2}`}>
                            <div className={`row ${styles.ratingoutline}`}>
                              <div className={`col-sm-11 ${styles.tabsalignment2} ${styles.formsection}`}>
                                {/*<span><b>SI RE</b></span>*/}
                                <a href="#" onClick={() => window.open('mailto:SI-RE-Travel@shell.com')}>
                                  <p className={styles.tabstext}>I have feedback for the travel team</p></a>
                              </div>
                              <div className={`col-sm-1 ${styles.tabsalignment2} ${styles.formsection}`}>&nbsp;&nbsp;&nbsp;&#10095;</div>
                              <p className={styles.subptagtext}>for anonymous feedback, go to the Issues or Concerns tab – Report Harassment</p>
                            </div>

                          </div>
                          <div className={`col-sm-1 ${styles.tabsalignment2}`}></div>
                          <div className={`col-sm-1 ${styles.tabsalignment2}`}></div>

                        </div>


                      </div>
                    </div>
                  </div>
                </div>
                <div id="Concerns" className="tabcontent">
                  <div className={styles.tabgridContainer}>
                    <div className={`row`}>
                      <div className={`col-sm-6 ${styles.tabsalignment}`}>
                        <span className={styles.feedbacksec}><b>A Physical Incident</b></span>
                        <div className={styles.tabgridContainer}>
                          <div className={`row`}>

                            <div className={`col-sm-2 ${styles.tabsalignment2}`}><img className={styles.thumbnailimgform} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/issue.jpg"></img></div>
                            <div className={`col-sm-10 ${styles.tabsalignment2}`}>
                              <div className={styles.issueSec}>
                                <p>For a slip, trip, fall or near miss during your trip, please click here.</p>
                              </div>
                              <div className={styles.tabbutton}>
                                 {/* Code change by AI&DS team */}
                              <a className={styles.issuebutton} href="#" onClick={() => window.open('https://eu2.spheracloud.net/first-report/672DAC94962644FCB727/Accidents/login')}>
                                {/* <a className={styles.issuebutton} href="#" onClick={() => window.open('http://fountain.europe.shell.com/IMPACT/enterprise/incident/FirstReport.asp')}> */}
                                  Report an Incident</a><span>&#10095;</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={`col-sm-6 ${styles.tabsalignment2}`}>
                        <span className={styles.feedbacksec}><b>Feedback</b></span>
                        <div className={styles.tabgridContainer}>
                          <div className={`row`}>

                            <div className={`col-sm-2 ${styles.tabsalignment2}`}><img className={styles.thumbnailimgform2} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/incident.jpg"></img></div>
                            <div className={`col-sm-10 ${styles.tabsalignment2}`}>
                              <div className={styles.issueSec}><p>If you have concerns about the behavior, integrity or other moral matters concerning your travel facilitators (drivers, airport staff, hotel staff etc.), please click here.</p></div>
                              <div className={styles.tabbutton}>
                                <a className={styles.issuebutton} href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/Corporate-Travel-Reports.aspx')}> Report Feedback</a><span>&#10095;</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                  <div>
                  </div>
                </div>
                <div id="Help" className="tabcontent">
                  <div className={styles.tabgridContainer}>
                    <div className={`row`}>
                      <div className={`col-sm-12 ${styles.tabsalignment2}`}>
                        <span className={styles.feedbacksec}><b>Global HelpLine</b></span>
                        <div className={styles.tabgridContainer}>
                          <div className={`row`}>
                            <div className={`col-sm-1 ${styles.tabsalignment2}`}><img className={styles.thumbnailimgform} src="https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/Travel/Help.png"></img></div>
                            <div className={`col-sm-10 ${styles.tabsalignment2}`}>
                              <div className={styles.issueSec}><p>Concerned about the behavior, integrity or other moral matters concerning your Shell travel party, hosts, colleagues, please click here.</p></div>
                              <div className={styles.tabbutton1}>
                                {/* https://shell.alertline.eu/gcs/welcome */}
                                {/* http://fountain.europe.shell.com/IMPACT/enterprise/incident/FirstReport.asp */}
                                <a className={styles.helpbutton} href="#" onClick={() => window.open('https://shell.alertline.eu/gcs/welcome')}>Report</a><span>&#10095;</span>
                              </div>
                            </div>
                            <div className={`col-sm-1 ${styles.tabsalignment2}`}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.gridContainer}>

            <div className={`row ${styles.level4row}`}>
              <div className={`col-md-12 ${styles.yammerpadding}`}>
                <div className={styles.widgets_title}>
                  <h3 className={styles.YammerTitle}>CORPORATE TRAVEL YAMMER FEED</h3>
                </div>
                <div>
                  <iframe className={styles.documentIframe} src="https://www.yammer.com/embed-feed?feedType=group&feedId=162718&config%5Buse_sso%5D=false&config%5Bheader%5D=false&config%5Bfooter%5D=false"></iframe>
                </div>
                <div className={styles.widgets_footer}>
                  <a className={styles.widgets_footer_btn} href="#" onClick={() => window.open('https://www.yammer.com/shell.com/#/threads/inGroup?type=in_group&feedId=162718')}>
                    View All
                                </a>
                </div>
              </div>
            </div>
          </div>

          <div className={`row ${styles.rowMargin}`}>
            <div className={`col-md-12 ${styles.blockColfoot}`}>
              <p className={styles.foot}>
                <b>
                  <a className={styles.foot} href="#" onClick={() => window.open('mailto:SI-RE-Travel@shell.com')}>Contact us</a><span className={styles.pipefooter} >|</span><a className={styles.foot} href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAAAA0446/Health/Pages/TRAVEL-HEALTH.aspx')}>Health </a><span className={styles.pipefooter}>|</span><a className={styles.foot} href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAFAA4985/CorporateandHR/CorporateTravel/SitePages/Safety-Tips-and-Training.aspx')}>Safety</a><span className={styles.pipefooter}>|</span><a className={styles.foot} href="#" onClick={() => window.open('https://eu001-sp.shell.com/sites/AAAAA6822/SitePages/CS%20MySecurity.aspx')}>Security</a><span className={styles.pipefooter}>|</span><a className={styles.foot} href="#" onClick={() => window.open('https://app.powerbi.com/groups/me/apps/93a20138-77a5-4aa5-8e57-24c2c2f9a3bc/reports/2b6e71d8-05b4-4a97-8982-fd0a5ab896bc/ReportSectioncf68454d2d62cc89e8ed')}>Environment</a>
                </b>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
