import * as React from 'react';
import { IPropertyPaneCustomFieldProps, PropertyPaneFieldType } from '@microsoft/sp-property-pane';
import { SwatchColorPicker, IColorCellProps } from '@fluentui/react/lib/SwatchColorPicker';
//import { useId } from '@fluentui/react-hooks';
import * as ReactDOM from 'react-dom';

export interface IPropertyPaneSwatchColorPickerProps {
  label: string;
  selectedColor: string;
  onColorChanged: (color: string) => void;
  colorCells: IColorCellProps[];
  show:boolean
}

export interface IPropertyPaneSwatchColorPickerInternalProps extends IPropertyPaneCustomFieldProps, IPropertyPaneSwatchColorPickerProps {}

export class PropertyPaneSwatchColorPicker implements IPropertyPaneSwatchColorPickerInternalProps {
  public type: PropertyPaneFieldType = PropertyPaneFieldType.Custom;
  public targetProperty: string;
  public properties: IPropertyPaneSwatchColorPickerProps & IPropertyPaneCustomFieldProps;
  private elem: HTMLElement;

  constructor(targetProperty: string, properties: IPropertyPaneSwatchColorPickerProps) {
    this.targetProperty = targetProperty;
    this.properties = {
      key: targetProperty,
      ...properties,
      onRender: this.render.bind(this),
    };
  }
  show: boolean;
    onRender: (domElement: HTMLElement, context?: any, changeCallback?: (targetProperty?: string, newValue?: any) => void) => void;
    key: string;
    context?: any;
    label: string;
    selectedColor: string;
    onColorChanged: (color: string) => void;
    colorCells: IColorCellProps[];

  public render(elem: HTMLElement): void {
    if (!this.elem) {
      this.elem = elem;
    }

   // Check the show property before rendering the SwatchColorPicker
   if (this.properties.show) {
    const element = React.createElement(SwatchColorPicker, {
      columnCount: 5,
      cellShape: 'circle',
      colorCells: this.properties.colorCells,
      selectedId: this.properties.selectedColor,
      onColorChanged: (id: string, color: string) => this.properties.onColorChanged(color),
    });

    ReactDOM.render(element, this.elem);
  } else {
    ReactDOM.unmountComponentAtNode(this.elem);
  }
  }
  public onDispose(): void {
    if (this.elem) {
      ReactDOM.unmountComponentAtNode(this.elem);
    }
  }
}
