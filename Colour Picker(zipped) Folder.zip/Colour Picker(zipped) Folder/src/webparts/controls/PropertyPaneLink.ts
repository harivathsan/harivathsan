import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { IPropertyPaneField, PropertyPaneFieldType,  IPropertyPaneCustomFieldProps } from '@microsoft/sp-property-pane';

export interface IPropertyPaneLinkProps {
  text: string;
  onClick: () => void;
}

export interface IPropertyPaneLinkInternalProps extends IPropertyPaneCustomFieldProps, IPropertyPaneLinkProps {}
export class PropertyPaneLink implements IPropertyPaneField<IPropertyPaneLinkProps> {
  public type: PropertyPaneFieldType = PropertyPaneFieldType.Custom;
  public targetProperty: string;
  public properties: IPropertyPaneLinkProps;

  private elem: HTMLElement;

  constructor(targetProperty: string, properties: IPropertyPaneLinkProps) {
    this.targetProperty = targetProperty;
    this.properties = properties;
  }

  public render(elem: HTMLElement): void {
    if (!this.elem) {
      this.elem = elem;
    }

    const element = React.createElement('a', {
      href: '#',
      onClick: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
        event.preventDefault();
        this.properties.onClick();
      }
    }, this.properties.text);

    ReactDOM.render(element, this.elem);
  }
}