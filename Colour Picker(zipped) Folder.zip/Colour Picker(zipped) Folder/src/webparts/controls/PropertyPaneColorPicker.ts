
import * as React from 'react';
//import * as ReactDom from 'react-dom';
import { IPropertyPaneCustomFieldProps, PropertyPaneFieldType } from '@microsoft/sp-property-pane';
import { ColorPicker, IColor, getColorFromString,  } from '@fluentui/react';
import * as ReactDOM from 'react-dom';

export interface IPropertyPaneColorPickerProps {
  label: string;
  selectedColor: string;
  onColorChanged: (color: string) => void;
  show: boolean;
  //onPropertyPaneFieldChanged: (targetProperty: any, oldValue: any, newValue: any)=> void;
}
  
  export interface IPropertyPaneColorPickerInternalProps extends IPropertyPaneCustomFieldProps, IPropertyPaneColorPickerProps {}
  
  export class PropertyPaneColorPicker implements IPropertyPaneCustomFieldProps {
    public type: PropertyPaneFieldType = PropertyPaneFieldType.Custom;
    public targetProperty: string;
    public properties: IPropertyPaneColorPickerProps & IPropertyPaneCustomFieldProps;
    private elem: HTMLElement | null = null;
  
    constructor(targetProperty: string, properties: IPropertyPaneColorPickerProps) {
      this.targetProperty = targetProperty;
      this.properties = {
        key: targetProperty, // Ensure the key is set here
        ...properties,
        onRender: this.render.bind(this),
      };
    }
      onRender: (domElement: HTMLElement, context?: any, changeCallback?: (targetProperty?: string, newValue?: any) => void) => void;
      key: string;
      context?: any;
  
    public render(elem: HTMLElement): void {
      if (!this.elem) {
        this.elem = elem;
      }
  
     
    //Check the show property before rendering the color picker
    if (this.properties.show) {
      const color = getColorFromString(this.properties.selectedColor) || getColorFromString('#ffffff')!;
      const element = React.createElement(ColorPicker, {
        color: color,
        onChange: (ev: any, colorObj: IColor) => this.properties.onColorChanged(colorObj.str),
        alphaType: 'alpha',
        showPreview: true,
      });

      ReactDOM.render(element, this.elem);
    } else {
      ReactDOM.unmountComponentAtNode(this.elem);
    }
  }

  
    public onDispose(): void {
      if (this.elem) {
        ReactDOM.unmountComponentAtNode(this.elem);
      }
    }
  }
  

