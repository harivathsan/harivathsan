import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneButton,
  PropertyPaneTextField,
  //PropertyPaneToggle
  //IPropertyPaneCustomFieldProps,
  //PropertyPaneFieldType
} from '@microsoft/sp-property-pane';
//import { PropertyPaneColorPickerField } from './components/PropertyPaneColourPicker';
import { PropertyPaneColorPicker } from '../controls/PropertyPaneColorPicker';
import { PropertyPaneSwatchColorPicker } from '../controls/PropertyPaneSwatchColorPicker';
//import { PropertyPaneLink } from '../controls/PropertyPaneLink';

//pnp
//import { PropertyFieldColorPicker, PropertyFieldColorPickerStyle } from '@pnp/spfx-property-controls/lib/PropertyFieldColorPicker';

//import { ColorPicker } from '@fluentui/react';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'PocWebPartStrings';
import Poc from './components/Poc';
import { IPocProps } from './components/IPocProps';
//import { Label } from '@fluentui/react';

// export interface IPocWebPartProps {
//   description: string;
// }
export interface IPocWebPartProps {
  description: string;
  buttonColor: string;
  textColor: string;
  bgcolor:string;
  color:string;
}

export default class PocWebPart extends BaseClientSideWebPart<IPocWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private showColorPicker: boolean = false;
  private showSwatchColorPicker: boolean = false;

  

  public render(): void {
    const element: React.ReactElement<IPocProps> = React.createElement(
      Poc,
      {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        buttonColor: this.properties.buttonColor,
        textColor: this.properties.textColor,
        bgcolor: this.properties.bgcolor,
        color: this.properties.color
      }
    );
    

    ReactDom.render(element, this.domElement);
  }
  

  protected onInit(): Promise<void> {
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void {
    if (propertyPath === 'buttonColor' && newValue !== oldValue) {
      this.properties.bgcolor= newValue;
      this.context.propertyPane.refresh();
      this.render();
    }
    if (propertyPath === 'textColor' && newValue !== oldValue) {
      this.properties.bgcolor= newValue;
      this.context.propertyPane.refresh();
      this.render();
    }
    // if (propertyPath === 'showColorPicker' && oldValue !== newValue) {
    //   this.context.propertyPane.refresh();
    // }
    // if (propertyPath === 'showColorPicker') {
    //   this.showColorPicker = newValue;
    //   this.context.propertyPane.refresh();
    //   this.render();
    // }
    super.onPropertyPaneFieldChanged(propertyPath, oldValue, newValue);
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
  // let colorPickerField : any

  //  if(this.showColorPicker ){ 
  //     colorPickerField = new PropertyPaneColorPicker('color', {
  //     label: 'Select Color',
  //     selectedColor: this.properties.buttonColor,
  //     onColorChanged: (color: string) => {
  //       this.properties.buttonColor = color;
  //       this.properties.bgcolor = this.properties.buttonColor;
  //       this.context.propertyPane.refresh();
  //       this.render();
  //     }
  //   }) };
    const colorCells = [
      { id: 'a', label: 'black', color: 'black' },
      { id: 'b', label: 'cyan', color: '#038387' },
      { id: 'c', label: 'blueMagenta', color: '#8764b8' },
      { id: 'd', label: 'magenta', color: '#881798' },
      { id: 'e', label: 'white', color: '#ffffff' },
      { id: 'f', label: 'orange', color: '#ca5010' },
    ];

    
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('bgcolor', {
                  label: "Background Color",
                  value: this.properties.bgcolor,
                  
                }),

                  PropertyPaneButton('toggleColorPicker', {
                  text: this.showColorPicker ? 'Hide Color Picker' : 'Show Color Picker',
                  //href: "#",
                  onClick: ()=>{ this.showColorPicker = !this.showColorPicker;

                  this.context.propertyPane.refresh();
                }
                  
                  
                }),
                //colorPickerField,
                 new PropertyPaneColorPicker('color',{
                  show: this.showColorPicker,
                  label:  'Select Color',
                  selectedColor: this.properties.buttonColor,
                  onColorChanged: (color: string) => {
                    this.properties.buttonColor = color;
                    this.properties.bgcolor = this.properties.buttonColor
                    this.context.propertyPane.refresh(); // Refresh the property pane to update the text field
                    this.render();
                    

                  }

                 }),

                PropertyPaneTextField('color', {
                  label: "Text Color",
                  value: this.properties.color,
                }),
                PropertyPaneButton('toggleColorPicker', {
                  text: this.showSwatchColorPicker ? 'Hide Text Color Picker' : 'Show  Text Color Picker',
                  //href: "#",
                  onClick: ()=>{ this.showSwatchColorPicker = !this.showSwatchColorPicker;

                  this.context.propertyPane.refresh();
                }
            }), 

                new PropertyPaneSwatchColorPicker('color', {
                  show: this.showSwatchColorPicker,
                  label: "Select Color",
                  selectedColor: this.properties.textColor,
                  onColorChanged: (color: string) => {
                    this.properties.textColor = color;
                    this.properties.color = this.properties.textColor
                    this.context.propertyPane.refresh();
                    this.render();
                  },
                  //disabled: this.showColorPicker,
                  colorCells: colorCells
                })

              ]
            }
          ]
        }
      ]
    };
  }
  // private _validateColor(value: string): string {
  //   const isValidColor = /^#[0-9A-F]{6}$/i.test(value);
  //   return isValidColor ? '' : 'Invalid color code. Please enter a valid hex color code.';
  // }
 

}
