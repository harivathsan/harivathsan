import * as React from 'react';
import styles from './Poc.module.scss';
import type { IPocProps } from './IPocProps';
//import { escape } from '@microsoft/sp-lodash-subset';

export default class Poc extends React.Component<IPocProps, {}> {
  public render(): React.ReactElement<IPocProps> {
    

    return (
      <section >
        <div className={styles.welcome}>
          <button style={{backgroundColor: this.props.bgcolor, color: this.props.textColor}}> 
            {this.props.description}
            {/* <h3 style={{color: this.props.textColor}}></h3> */}
          </button>
        </div>
     
      </section>
    );
  }
}
