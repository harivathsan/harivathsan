/* tslint:disable */
require("./Poc.module.css");
const styles = {
  poc: 'poc_c5d44272',
  teams: 'teams_c5d44272',
  welcome: 'welcome_c5d44272',
  welcomeImage: 'welcomeImage_c5d44272',
  links: 'links_c5d44272'
};

export default styles;
/* tslint:enable */