import { IPropertyPaneCustomFieldProps, PropertyPaneFieldType } from '@microsoft/sp-property-pane';
export interface IPropertyPaneColorPickerProps {
    label: string;
    selectedColor: string;
    onColorChanged: (color: string) => void;
}
export interface IPropertyPaneColorPickerInternalProps extends IPropertyPaneCustomFieldProps, IPropertyPaneColorPickerProps {
}
export declare class PropertyPaneColorPicker implements IPropertyPaneColorPickerInternalProps {
    type: PropertyPaneFieldType;
    targetProperty: string;
    properties: IPropertyPaneColorPickerProps;
    onRender: any;
    key: string;
    label: string;
    selectedColor: string;
    onColorChanged: (color: string) => void;
    private elem;
    constructor(targetProperty: string, properties: IPropertyPaneColorPickerProps);
    render(elemen: unknown, elem: HTMLElement): void;
    onDispose(): void;
}
export declare function PropertyPaneColorPickerField(targetProperty: string, properties: IPropertyPaneColorPickerProps): IPropertyPaneCustomFieldProps;
//# sourceMappingURL=PropertyPaneColourPicker.d.ts.map