import { IPropertyPaneCustomFieldProps, PropertyPaneFieldType } from '@microsoft/sp-property-pane';
export interface IPropertyPaneColorPickerProps {
    label: string;
    selectedColor: string;
    onColorChanged: (color: string) => void;
    show: boolean;
}
export interface IPropertyPaneColorPickerInternalProps extends IPropertyPaneCustomFieldProps, IPropertyPaneColorPickerProps {
}
export declare class PropertyPaneColorPicker implements IPropertyPaneCustomFieldProps {
    type: PropertyPaneFieldType;
    targetProperty: string;
    properties: IPropertyPaneColorPickerProps & IPropertyPaneCustomFieldProps;
    private elem;
    constructor(targetProperty: string, properties: IPropertyPaneColorPickerProps);
    onRender: (domElement: HTMLElement, context?: any, changeCallback?: (targetProperty?: string, newValue?: any) => void) => void;
    key: string;
    context?: any;
    render(elem: HTMLElement): void;
    onDispose(): void;
}
//# sourceMappingURL=PropertyPaneColorPicker.d.ts.map