import { IPropertyPaneCustomFieldProps, PropertyPaneFieldType } from '@microsoft/sp-property-pane';
import { IColorCellProps } from '@fluentui/react/lib/SwatchColorPicker';
export interface IPropertyPaneSwatchColorPickerProps {
    label: string;
    selectedColor: string;
    onColorChanged: (color: string) => void;
    colorCells: IColorCellProps[];
    show: boolean;
}
export interface IPropertyPaneSwatchColorPickerInternalProps extends IPropertyPaneCustomFieldProps, IPropertyPaneSwatchColorPickerProps {
}
export declare class PropertyPaneSwatchColorPicker implements IPropertyPaneSwatchColorPickerInternalProps {
    type: PropertyPaneFieldType;
    targetProperty: string;
    properties: IPropertyPaneSwatchColorPickerProps & IPropertyPaneCustomFieldProps;
    private elem;
    constructor(targetProperty: string, properties: IPropertyPaneSwatchColorPickerProps);
    show: boolean;
    onRender: (domElement: HTMLElement, context?: any, changeCallback?: (targetProperty?: string, newValue?: any) => void) => void;
    key: string;
    context?: any;
    label: string;
    selectedColor: string;
    onColorChanged: (color: string) => void;
    colorCells: IColorCellProps[];
    render(elem: HTMLElement): void;
    onDispose(): void;
}
//# sourceMappingURL=PropertyPaneSwatchColorPicker.d.ts.map