import { IPropertyPaneField, PropertyPaneFieldType, IPropertyPaneCustomFieldProps } from '@microsoft/sp-property-pane';
export interface IPropertyPaneLinkProps {
    text: string;
    onClick: () => void;
}
export interface IPropertyPaneLinkInternalProps extends IPropertyPaneCustomFieldProps, IPropertyPaneLinkProps {
}
export declare class PropertyPaneLink implements IPropertyPaneField<IPropertyPaneLinkProps> {
    type: PropertyPaneFieldType;
    targetProperty: string;
    properties: IPropertyPaneLinkProps;
    private elem;
    constructor(targetProperty: string, properties: IPropertyPaneLinkProps);
    render(elem: HTMLElement): void;
}
//# sourceMappingURL=PropertyPaneLink.d.ts.map