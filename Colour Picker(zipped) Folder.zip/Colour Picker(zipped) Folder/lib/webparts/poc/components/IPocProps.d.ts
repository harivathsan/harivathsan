export interface IPocProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    buttonColor: string;
    textColor: string;
    bgcolor: string;
    color: string;
}
//# sourceMappingURL=IPocProps.d.ts.map