declare const styles: {
    poc: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Poc.module.scss.d.ts.map