import * as React from 'react';
import type { IPocProps } from './IPocProps';
export default class Poc extends React.Component<IPocProps, {}> {
    render(): React.ReactElement<IPocProps>;
}
//# sourceMappingURL=Poc.d.ts.map