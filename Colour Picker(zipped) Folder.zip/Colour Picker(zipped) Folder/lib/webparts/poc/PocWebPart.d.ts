import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface IPocWebPartProps {
    description: string;
    buttonColor: string;
    textColor: string;
    bgcolor: string;
    color: string;
}
export default class PocWebPart extends BaseClientSideWebPart<IPocWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    private showColorPicker;
    private showSwatchColorPicker;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=PocWebPart.d.ts.map