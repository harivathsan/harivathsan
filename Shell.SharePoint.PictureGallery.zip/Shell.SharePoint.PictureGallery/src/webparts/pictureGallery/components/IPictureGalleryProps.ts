export interface IPictureGalleryProps {
  description: string;
}
