declare const styles: {
    caurosal: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    BannerSection: string;
    animateBG_dd732eed: string;
    BannerContent: string;
    text_line: string;
    question: string;
    ans: string;
    links: string;
    dropdown_menu: string;
};
export default styles;
//# sourceMappingURL=Caurosal.module.scss.d.ts.map