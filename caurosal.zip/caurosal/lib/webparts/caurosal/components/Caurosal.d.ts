import * as React from 'react';
import type { ICaurosalProps } from './ICaurosalProps';
export default class Caurosal extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement<ICaurosalProps>;
}
//# sourceMappingURL=Caurosal.d.ts.map