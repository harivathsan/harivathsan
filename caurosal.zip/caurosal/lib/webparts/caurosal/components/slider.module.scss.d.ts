declare const styles: {
    carouselComponent: string;
    titleText: string;
    carouselItem: string;
    carouselImage: string;
    carouselTexts: string;
    carouselLinks: string;
    buttonArrow: string;
};
export default styles;
//# sourceMappingURL=slider.module.scss.d.ts.map