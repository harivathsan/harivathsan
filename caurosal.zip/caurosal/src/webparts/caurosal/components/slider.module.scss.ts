/* tslint:disable */
require("./slider.module.css");
const styles = {
  carouselComponent: 'carouselComponent_5fdca69c',
  titleText: 'titleText_5fdca69c',
  carouselItem: 'carouselItem_5fdca69c',
  carouselImage: 'carouselImage_5fdca69c',
  carouselTexts: 'carouselTexts_5fdca69c',
  carouselLinks: 'carouselLinks_5fdca69c',
  buttonArrow: 'buttonArrow_5fdca69c'
};

export default styles;
/* tslint:enable */