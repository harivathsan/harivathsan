/* tslint:disable */
require("./Caurosal.module.css");
const styles = {
  caurosal: 'caurosal_644a33e1',
  teams: 'teams_644a33e1',
  welcome: 'welcome_644a33e1',
  welcomeImage: 'welcomeImage_644a33e1',
  BannerSection: 'BannerSection_644a33e1',
  animateBG_dd732eed: 'animateBG_dd732eed_644a33e1',
  BannerContent: 'BannerContent_644a33e1',
  text_line: 'text_line_644a33e1',
  question: 'question_644a33e1',
  ans: 'ans_644a33e1',
  links: 'links_644a33e1',
  dropdown_menu: 'dropdown_menu_644a33e1'
};

export default styles;
/* tslint:enable */