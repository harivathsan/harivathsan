import * as React from 'react';
import type { ICaurosalProps } from './ICaurosalProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { SPComponentLoader } from '@microsoft/sp-loader';



export default class Caurosal extends React.Component<any,any> {
  constructor(props: any) {
    super(props);
    //importing Global CSS
    let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
    this.state={
      NewsCarouselItems:[],

    }
  }
  

  public render(): React.ReactElement<ICaurosalProps> {

    return (
      <>               
      

      </>
    );
  }
}
