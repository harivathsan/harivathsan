define([], function() {
  return {
    "Title": "HidecontrolsApplicationCustomizer"
  }
});