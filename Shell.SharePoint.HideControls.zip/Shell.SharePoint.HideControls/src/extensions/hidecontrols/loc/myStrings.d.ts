declare interface IHidecontrolsApplicationCustomizerStrings {
  Title: string;
}

declare module 'HidecontrolsApplicationCustomizerStrings' {
  const strings: IHidecontrolsApplicationCustomizerStrings;
  export = strings;
}
