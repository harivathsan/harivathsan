import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer
} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';
import { SPComponentLoader } from "@microsoft/sp-loader";

import * as strings from 'HidecontrolsApplicationCustomizerStrings';

const LOG_SOURCE: string = 'HidecontrolsApplicationCustomizer';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IHidecontrolsApplicationCustomizerProperties {
  // This is an example; replace with your own property
  testMessage: string;
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class HidecontrolsApplicationCustomizer
  extends BaseApplicationCustomizer<IHidecontrolsApplicationCustomizerProperties> {

  @override
  public onInit(): Promise<void> {
    /*
    Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);

    let message: string = this.properties.testMessage;
    if (!message) {
      message = '(No properties were provided.)';
    }
    
    Dialog.alert(`Hello from ${strings.Title}:\n\n${message}`);
    */
    console.log("Begin Hide Controls");

    try {
      SPComponentLoader.loadCss("https://eu001-sp.shell.com/sites/AAAAB1741/SiteAssets/css/hidequicklaunch.css");
    } catch (error) {
      console.log("Error Hiding Controls" + error.message);
    }
    console.log("End Hide Controls");
    return Promise.resolve();
  }
}
