declare interface IHighFiveWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HighFiveWebPartStrings' {
  const strings: IHighFiveWebPartStrings;
  export = strings;
}
