/* ----------------------------------Module Summary-----------------------------------
Project Name                       : High Five
Project Handled By                 : IMS US Capacity Projects
Module Name		                     : HighFive
Module Description                 : To provide a solution to insert data to SharePoint from Front End
Author                             : Vigith B Nair
Created Date                       : 26th Feb 2021
Modified Date                      : 26th Feb 2021
Modified Reason                    : Created the Child component
/* ----------------------------------Module Summary-----------------------------------*/

//#region Import
import * as React from 'react';
import styles from './HighFive.module.scss';
import { IHighFiveProps } from './IHighFiveProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { TextField, MaskedTextField, PrimaryButton } from 'office-ui-fabric-react';
import { SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions} from '@microsoft/sp-http'; 
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { Dropdown, DropdownMenuItemType, IDropdownOption, IDropdownStyles } from 'office-ui-fabric-react/lib/Dropdown';
//#endregion Import

const dropdownStyles: Partial<IDropdownStyles> = { dropdown: { width: 300 } };

//Hardcoded values for POC, Need to update
const BehaviourDropDownOptions = [
  { key: '0', text: 'Accountable to deliver on commitments' },
  { key: '1', text: 'Care and support colleagues' },
  { key: '2', text: 'Own the business'},
  { key: '3', text: 'Transparent about challenges and risks' },
  { key: '4', text: 'Courage to have fierce conversations' },
  { key: '5', text: 'Facts first, emotions at the end' },
];

const RecognitionDropDownOptions = [
  { key: '0', text: 'Authenticity' },
  { key: '1', text: 'Performance' },
  { key: '2', text: 'Collaboration'},
  { key: '3', text: 'Growth' },
];


//#region  Interfaces
export interface IHighFiveState{
  selectedTitle:string;
  selectedToPeoplePicker : any[];
  selectedFromPeoplePicker: any[];
  selectedLineManagerPeoplePicker: any[];
  selectedBehaviour : string[] | number[];
  selectedDescription: string;
  selectedRecognition: string[] | number[];
}
//#endregion Interfaces

//#region HighFive Class
export default class HighFive extends React.Component<IHighFiveProps, IHighFiveState> {
  //#region Constructor
  constructor(props:IHighFiveProps, state : IHighFiveState){
    super(props);
    this.state = {
      selectedTitle:"",
      selectedToPeoplePicker : [],
      selectedFromPeoplePicker: [],
      selectedLineManagerPeoplePicker: [],
      selectedBehaviour :[],
      selectedDescription:"",
      selectedRecognition :[]

    }
    this.handleTitleChange = this.handleTitleChange.bind(this);
    this.getToPeoplePicker = this.getToPeoplePicker.bind(this);
    this.getFromPeoplePicker = this.getFromPeoplePicker.bind(this);
    this.getLineManagerPeoplePicker = this.getLineManagerPeoplePicker.bind(this);
    this.handleDescriptionChange = this.handleDescriptionChange.bind(this);
  }
  //#endregion Constructor

  //#region Render Method Start
  public render(): React.ReactElement<IHighFiveProps> {

    return (
      <div className={ styles.highFive }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>
              <span className={ styles.title }>High Five</span>
              {/* <p className={ styles.subTitle }>Customize SharePoint experiences using Web Parts.</p>
              <p className={ styles.description }>{escape(this.props.description)}</p> */}
              {/* <a href="https://aka.ms/spfx" className={ styles.button }>
                <span className={ styles.label }>Learn more</span>
              </a> */}            
            <div>
              <TextField required={true} placeholder="Please enter Title here" value={this.state.selectedTitle} onChanged={this.handleTitleChange} />
            </div>
                      
            <br></br>
            <div>
                    <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        showHiddenInUI={false}
                        selectedItems={this.getToPeoplePicker}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={1000} placeholder={"Enter To email address"} />       
            </div>
            <br></br>
            <div>
                    <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        showHiddenInUI={false}
                        selectedItems={this.getFromPeoplePicker}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={1000} placeholder={"Enter From email address"} />       
            </div>
            <br></br>
            <div>
                    <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        showHiddenInUI={false}
                        selectedItems={this.getLineManagerPeoplePicker}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={1000} placeholder={"Enter Line Manager email address"} />       
            </div>

            <br></br>

            <Dropdown
              placeholder="Select Behaviours"
              onChanged={this.onChangedBehaviour.bind(this)}             
              multiSelect
              options={BehaviourDropDownOptions}
              styles={dropdownStyles}
            />

            <br></br>

            <Dropdown
              placeholder="Select Recognition For"
              onChanged={this.onChangedRecognition.bind(this)}             
              multiSelect
              options={RecognitionDropDownOptions}
              styles={dropdownStyles}
            />

            <br></br>

            <div>
              <TextField multiline={true} placeholder="Please enter Description here" value={this.state.selectedDescription} onChanged={this.handleDescriptionChange} />
            </div>

            <br></br>

            <div>
              <PrimaryButton text="Insert" onClick={()=>this.handleInsertButtonClick()}></PrimaryButton>              
            </div>

            </div>
          </div>
        </div>
      </div>
    );
  }
  //#endregion Render Method end

  //#region Handlers
  private onChangedBehaviour(option: IDropdownOption, index?: number): void { 
    let newselectedkeys:any[]=[...this.state.selectedBehaviour];
    if (option.selected) {
      newselectedkeys.push(option.text as string);
    }
    else {
      // Remove the item from the selected keys list
      const itemIdx = newselectedkeys.indexOf(option.text as string);
      if (itemIdx > -1) {
        newselectedkeys.splice(itemIdx, 1);
      }
    }
    this.setState({selectedBehaviour:newselectedkeys})
  
  }

  private onChangedRecognition(option: IDropdownOption, index?: number): void { 
    let newselectedkeys:any[]=[...this.state.selectedRecognition];
    if (option.selected) {
      newselectedkeys.push(option.text as string);
    }
    else {
      // Remove the item from the selected keys list
      const itemIdx = newselectedkeys.indexOf(option.text as string);
      if (itemIdx > -1) {
        newselectedkeys.splice(itemIdx, 1);
      }
    }
    this.setState({selectedRecognition:newselectedkeys})
  
  }

  private async handleInsertButtonClick() {
    let selectedBehaviors ="";
    for(var i=0;i<this.state.selectedBehaviour.length;i++){
      selectedBehaviors += this.state.selectedBehaviour[i] + ",";
    }   
    selectedBehaviors = selectedBehaviors.substring(0,selectedBehaviors.length-1)
    
    let selectedRecognitionFor ="";
    for(var j=0;j<this.state.selectedRecognition.length;j++){
      selectedRecognitionFor += this.state.selectedRecognition[j] + ",";
    }   
    selectedRecognitionFor = selectedRecognitionFor.substring(0,selectedRecognitionFor.length-1)
    
    if(this.state.selectedTitle){
      const body: string = JSON.stringify({
        __metadata:
              {
                  // Format of the "type" is: SP.Data.<<ListName>>ListItem
                  type: "SP.Data.HighFiveItem"
              },
              // Title: "New Title"
              "Title": this.state.selectedTitle,
              'ToId' : this.state.selectedToPeoplePicker[0].id,
              'FromId' : this.state.selectedFromPeoplePicker[0].id,
              'LineManagerId' : this.state.selectedLineManagerPeoplePicker[0].id,
              "Behaviors" : { "__metadata": { "type": "Collection(Edm.String)" }, "results": [selectedBehaviors] },
              //"Behaviors" : { "__metadata": { "type": "Collection(Edm.String)" }, "results": [this.state.selectedBehaviour[0]] },
              //"RecognitionFor": { "__metadata": { "type": "Collection(Edm.String)" }, "results": [this.state.selectedRecognition[0]] },
              "RecognitionFor": { "__metadata": { "type": "Collection(Edm.String)" }, "results": [selectedRecognitionFor] },
              "Description":this.state.selectedDescription,              
      });
            
      let response = await this.props.spHttpClient
          .post(this.props.siteUrl + "/_api/web/lists/getByTitle('High Five')/items",
          SPHttpClient.configurations.v1,
          {
              headers: {  
                'Accept': 'application/json;odata=nometadata',  
                'Content-type': 'application/json;odata=verbose',  
                'odata-version': ''  
              },
              body:body
          });
          if(response.ok){
            let options = await response.json();
            alert("Item Inserted to the list!!")
            this.sendEmail();
            window.location.reload()    ;
            console.log(options);
          }
          else{
            alert("Error!")
          }
    }

    else
    {
      alert("Please provide Title to proceed!")
    }
    
  }

  private handleTitleChange(titleSelected){
    this.setState({selectedTitle:titleSelected})
  }

  private handleDescriptionChange(descriptionSelected){
    this.setState({selectedDescription:descriptionSelected})
  }


  private getToPeoplePicker(items: any[]){ this.setState({selectedToPeoplePicker : items})}

  private getFromPeoplePicker(items: any[]){ this.setState({selectedFromPeoplePicker : items})}

  private getLineManagerPeoplePicker(items: any[]){ this.setState({selectedLineManagerPeoplePicker : items})}

  private sendEmail () {
    try{
      const siteUrl = this.props.siteUrl;
      const emailUrl = siteUrl + '/_api/SP.Utilities.Utility.SendEmail';

      const reqOptions: any = {
        headers: {
            "Accept": "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "odata-version": "3.0",
        },
        body: JSON.stringify({
            'properties': {
                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                'To': { 'results': [this.state.selectedToPeoplePicker[0].secondaryText] },
                'CC': { 'results': [this.state.selectedLineManagerPeoplePicker[0].secondaryText] },
                'Body': '<div><p><span style="background-color: rgb(247,218,100)">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This is an autogenerated email from High Five App &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>' + 
                '</span><b><i>This is Body Content...<i></b></div>',
                'Subject': 'New Item Created in High Five list by ' + this.state.selectedFromPeoplePicker[0].text
            }
        })
    };
    this.props.spHttpClient.post(emailUrl, SPHttpClient.configurations.v1, reqOptions)
                .then((response: SPHttpClientResponse) => {
                    console.log(`Status code: ${response.status}`);
                    console.log(`Status text: ${response.statusText}`);
                    response.json().then((responseJSON: JSON) => {
                        console.log("ResponseJSON:" + responseJSON);
                        alert("Email Send Successfully!!!");
                    });
                })
                .catch((err) => {
                    console.log(err);
                });

    }
    catch{

    }  
  }

  //#endregion Handlers
}
//#endregion HighFive Class