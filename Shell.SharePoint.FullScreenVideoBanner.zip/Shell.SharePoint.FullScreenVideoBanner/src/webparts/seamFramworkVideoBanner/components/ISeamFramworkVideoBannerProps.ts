export interface ISeamFramworkVideoBannerProps {
  description: string;
}
