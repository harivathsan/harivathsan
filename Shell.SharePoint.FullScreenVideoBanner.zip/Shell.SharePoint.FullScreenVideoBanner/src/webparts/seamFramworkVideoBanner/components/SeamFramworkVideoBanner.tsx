import * as React from 'react';
import './SeamFramworkVideoBanner.scss';
import styles from './SeamFramworkVideoBanner.module.scss';
import { ISeamFramworkVideoBannerProps } from './ISeamFramworkVideoBannerProps';
import { escape } from '@microsoft/sp-lodash-subset';

export default class SeamFramworkVideoBanner extends React.Component<ISeamFramworkVideoBannerProps, {}> {
  public render(): React.ReactElement<ISeamFramworkVideoBannerProps> {
    debugger;
    return (
      <div className={styles.fullScreenBanner}>
        <video className={styles.video} poster="https://eu001-sp.shell.com/sites/SPO000766/Shared%20Documents/vidoeBg.jpg" autoPlay muted loop>
          <source src="https://eu001-sp.shell.com/sites/SPO000766/_layouts/15/stream.aspx?id=%2Fsites%2FSPO000766%2FShared%20Documents%2F5_Powering_Progress_Ident.mp4" type="video/mp4" />
        </video>
        <div className={styles.videoquote}>
          <p>Fridolaben rasi fusi grasibader ingemeinheit zumtgewankt.</p>
        </div>
      </div>

    );
  }
}
