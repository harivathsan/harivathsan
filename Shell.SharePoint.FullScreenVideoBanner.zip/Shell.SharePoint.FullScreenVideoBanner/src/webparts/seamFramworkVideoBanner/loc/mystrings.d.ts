declare interface ISeamFramworkVideoBannerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SeamFramworkVideoBannerWebPartStrings' {
  const strings: ISeamFramworkVideoBannerWebPartStrings;
  export = strings;
}
