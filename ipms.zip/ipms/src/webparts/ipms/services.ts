import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { masterapi } from '../constant/apiconfig';
import { StringFormat } from './utils';
import * as _ from 'lodash';

export const getListAllItem = (props:any,listName:string) => { 
    debugger;
    let listname = StringFormat(masterapi.list,listName);  
    let url = props.context.pageContext.web.absoluteUrl + listname + masterapi.allItem; 
    let listdata = props.context.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {           
            return await response.json().then((res) => {                  
                    if (res != null) {  
                        return res.value;
                    } else {
                        console.log('recoard failed');
                    }
                });            
        });
        return Promise.resolve<any>(listdata);
  }



// // Menu Function to fetch all unique Titles & SubMenus
// export const fetchUniqueTitlesAndSubMenus = async (props:any,listName:string) => {
//     const titlesUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Title,SubMenu`;
   
//     try {
//       const response = await fetch(titlesUrl, {
//         method: "GET",
//         headers: {
//           "Accept": "application/json;odata=verbose",
//           "Content-Type": "application/json;odata=verbose"
//         }
//       });
//       const data = await response.json();   
//       const uniqueTitleSubMenuPairs = Array.from(
//         new Set<string>(data.d.results.map((item: { Title: string; SubMenu: string }) => `${item.Title}|${item.SubMenu}`))
//       ).map((pair: string) => {
//         const [Title, SubMenu] = pair.split("|");
//         return { Title, SubMenu };
//       });   
//       return uniqueTitleSubMenuPairs;      
//     } catch (error) {
//       console.error("Error fetching Titles:", error);
//       return [];
//     }
//   };
   
//   // Function to fetch SubSubMenus for a given Title & SubMenu
//   export const fetchSubSubMenus = async (props:any,listName:string,Title, SubMenu) => {
//     const encodedTitle = encodeURIComponent(Title);
//     const encodedSubMenu = encodeURIComponent(SubMenu);
   
//     const subMenuUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${listName}')/items?$filter=Title eq '${encodedTitle}' and SubMenu eq '${encodedSubMenu}'&$select=SubSubMenu,SubSubMenuLink`;
   
//     try {
//       const response = await fetch(subMenuUrl, {
//         method: "GET",
//         headers: {
//           "Accept": "application/json;odata=verbose",
//           "Content-Type": "application/json;odata=verbose"
//         }
//       });
//       const data = await response.json();
   
//       // Extract unique SubSubMenu values
//       const uniqueSubSubMenus = Array.from(
//         new Set(data.d.results.map(item => item.SubSubMenu))
//       ).map(subsubmenu => {
//         return {
//           subSubMenu: subsubmenu,
//           subsubmenulink: ""
//         };
//       });
   
//       return uniqueSubSubMenus;
//     } catch (error) {
//       console.error(`Error fetching SubSubMenus for ${Title} - ${SubMenu}:`, error);
//       return [];
//     }
//   };


//   export const getMenuList = async (props:any,listName:string) => {
//     //const listName = "Menu List";
//     debugger;
//     const apiUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Title,MainMenuLink,SubMenu,SubMenuLink,SubSubMenu,SubSubMenuLink,OrderByMainMenu,OrderBySubMenu,OrderBySubSubMenu&$orderby=OrderByMainMenu,OrderBySubMenu,OrderBySubSubMenu`;
   
//     try {
//       const response: SPHttpClientResponse = await props.context.spHttpClient.get(apiUrl, SPHttpClient.configurations.v1);
//       const data = await response.json();
   
//       // Grouping data
//       const menuMap = new Map();
   
//       data.value.forEach((item: any) => {
//         debugger;
//         let { Title, MainMenuLink, SubMenu, SubMenuLink, SubSubMenu, SubSubMenuLink } = item;
   
//         if (!menuMap.has(Title)) {
//           menuMap.set(Title, {
//             Title,
//             MainMenuLink,
//             SubMenu: [],
//           });
//         }
   
//         let menuItem = menuMap.get(Title);
   
//         // Handle SubMenu
//         if (SubMenu && SubMenuLink) {
//           let subMenuItem = menuItem.SubMenu.find((sub: any) => sub.SubMenu === SubMenu);
//           if (!subMenuItem) {
//             subMenuItem = { SubMenu, SubMenuLink, SubSubMenu: [] };
//             menuItem.SubMenu.push(subMenuItem);
//           }

//           // Handle SubSubMenu (Ensure Grouping)
//           if (SubSubMenu && SubSubMenuLink) 
//             { 
//                 if (!subMenuItem.SubSubMenu.some((subsub: any) => subsub.SubSubMenu === SubSubMenu)) {
//                     subMenuItem.SubSubMenu.push({ SubSubMenu, SubSubMenuLink }); 
//                 } 
//             }
   
//         //   // Handle SubSubMenu
//         //   if (SubSubMenu && SubSubMenuLink) {            
//         //     subMenuItem.SubSubMenu.push({ SubSubMenu, SubSubMenuLink });
//         //   }
//         }
//       });
//    debugger;
//       return Array.from(menuMap.values());
//     } catch (error) {
//       console.error("Error fetching menu list:", error);
//       return [];
//     }
//   };
   

  export const getMenuList = async (props:any,listName:string) => {
    //const listName = "Menu List";
    const apiUrl = `${props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Title,MainMenuLink,SubMenu,SubMenuLink,SubSubMenu,SubSubMenuLink,OrderByMainMenu,OrderBySubMenu,OrderBySubSubMenu&$orderby=OrderByMainMenu,OrderBySubMenu,OrderBySubSubMenu`;
   
    try {
      const response: SPHttpClientResponse = await props.context.spHttpClient.get(apiUrl, SPHttpClient.configurations.v1);
      const data = await response.json();
   
      // Main Menu Mapping
      const menuMap = new Map();
   
      data.value.forEach((item: any) => {
        let { Title, MainMenuLink, SubMenu, SubMenuLink, SubSubMenu, SubSubMenuLink } = item;
   
        // Create Main Menu Entry if not exists
        if (!menuMap.has(Title)) {
          menuMap.set(Title, {
            Title,
            MainMenuLink,
            SubMenu: new Map() // Store SubMenus in a Map for uniqueness
          });
        }
   
        let menuItem = menuMap.get(Title);
   
        // Handle SubMenu (Ensure Unique SubMenu)
        if (SubMenu && SubMenuLink) {
          if (!menuItem.SubMenu.has(SubMenu)) {
            menuItem.SubMenu.set(SubMenu, {
              SubMenu,
              SubMenuLink,
              SubSubMenu: []
            });
          }
   
          let subMenuItem = menuItem.SubMenu.get(SubMenu);
   
          // Handle SubSubMenu (Ensure Grouping)
          if (SubSubMenu && SubSubMenuLink) {
            if (!subMenuItem.SubSubMenu.some((subsub: any) => subsub.SubSubMenu === SubSubMenu)) {
              subMenuItem.SubSubMenu.push({ SubSubMenu, SubSubMenuLink });
            }
          }
        }
      });
   
      // Convert SubMenu Map to an array
      return Array.from(menuMap.values()).map(menu => ({
        ...menu,
        SubMenu: Array.from(menu.SubMenu.values())
      }));
   
    } catch (error) {
      console.error("Error fetching menu list:", error);
      return [];
    }
  };
  