/* tslint:disable */
require("./pmfstructure.module.css");
const styles = {
  pmf: 'pmf_a0e8629e',
  heading: 'heading_a0e8629e'
};

export default styles;
/* tslint:enable */