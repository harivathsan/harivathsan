/* tslint:disable */
require("./pmf.css");
const styles = {

};

export default styles;
/* tslint:enable */