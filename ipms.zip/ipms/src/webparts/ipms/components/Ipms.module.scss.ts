/* tslint:disable */
require("./Ipms.module.css");
const styles = {
  ipms: 'ipms_8c479e56',
  logo: 'logo_8c479e56',
  topNav: 'topNav_8c479e56',
  h_line: 'h_line_8c479e56',
  mainNav: 'mainNav_8c479e56',
  active: 'active_8c479e56',
  carouselSection: 'carouselSection_8c479e56',
  carouselleftarrow: 'carouselleftarrow_8c479e56',
  carouselrightarrow: 'carouselrightarrow_8c479e56',
  clickHere: 'clickHere_8c479e56',
  tilesSection: 'tilesSection_8c479e56',
  tiles: 'tiles_8c479e56',
  tilesContent: 'tilesContent_8c479e56',
  tablesection: 'tablesection_8c479e56',
  footerSection: 'footerSection_8c479e56',
  footerlist: 'footerlist_8c479e56'
};

export default styles;
/* tslint:enable */