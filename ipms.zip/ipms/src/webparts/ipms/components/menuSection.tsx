import * as React from 'react';
import { NavLink } from 'react-router-dom';
import{Row,Col} from 'react-bootstrap';
import styles from './Ipms.module.scss';

export default class MenuSection extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);  
     this.state={}
  }//End Constructor

 
  public render(): React.ReactElement {
    debugger;
    return (
      <>
       <hr className={styles.h_line}/> 
         <Row>
          <Col lg={12} className={`${styles.mainNav} border-right-1`}>
          {this.props.menuItems.length>0 && <ul>
             {this.props.menuItems.length>0 && this.props.menuItems.map((m_item,index)=>{
              debugger;
                return(
                  <li key={index}>
                    <NavLink to={`${m_item.MainMenuLink}`} className={({isActive})=>(isActive? styles.active:'noActive')}>{m_item.Title}</NavLink>
                  </li> 
                )
              })}
          </ul> }              
            
          </Col>
         </Row>
       
    </>
     
     
      
    );
  }
}
