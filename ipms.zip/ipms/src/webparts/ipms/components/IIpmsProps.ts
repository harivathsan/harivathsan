import { SPHttpClient } from '@microsoft/sp-http';
export interface IIpmsProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  css: string;
  listName:any;
  spHttpClient: SPHttpClient;
  webURL:any;
  context:any;
  homelistName:string,
  pmflistName:string,
  projectStandardsList:string,
  expectedPracticeMapsList:string,
}
