import * as React from 'react';
import styles from './Ipms.module.scss';
export default class Header extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);    
     this.state={}
  }//End Constructor
  public render(): React.ReactElement {
   
    return (
   
    <nav className="navbar navbar-expand-lg bg-white navbar-light sticky-top border-0 border-bottom-5 p-0">
    <a href="index.html" className="navbar-brand d-flex align-items-center">
        <img src={`${this.props.webURL}/SiteAssets/Images/logo.svg`} className={`${styles.logo} d-inline-block align-top m-3 mb-0`}
        alt="Integrated Project Management System (IPMS)"/>
        <h5 className="m-0 fw-bolder">
          Integrated Project Management System (IPMS)
        </h5>
        </a>
          <button
            type="button"
            className="navbar-toggler"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarCollapse">
              <div className={`${styles.topNav} navbar-nav ms-auto py-3 py-lg-0`}>
              <a href="index.html" className="nav-item nav-link ps-4 pe-4 pb-4 pt-4">Relevant Links</a>
              <a href="about.html" className="nav-item nav-link ps-4 pe-4 pb-4 pt-4">DCAF</a>
              <a href="service.html" className="nav-item nav-link ps-4 pe-4 pb-4 pt-4">DDP</a>
              <a href="service.html" className="nav-item nav-link ps-4 pe-4 pb-4 pt-4">Get Help</a>
              </div>
        </div>
      
      </nav>
    
    
    );
  }
}
