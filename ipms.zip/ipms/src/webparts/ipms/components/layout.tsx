import * as React from 'react';
import { Col,Container,Row } from 'react-bootstrap';
import { HashRouter, Route, Routes } from 'react-router-dom';
import Header from './header';
import Home from '../pages/home';
import HowToApplyThePMF from '../pages/howToApplyThePmf';
import ProjectStandards from '../pages/projectStandards';
import ExpectedPracticeMaps from '../pages/expectedPracticeMaps';
import PMFStructure from '../pages/pmfStructure'
import MenuSection from './menuSection';
import FooterSection from './footer';
import {getMenuList} from "../services";

export default class Layout extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state={
          menuItems:[]
        }
    }
    componentDidMount(): void {
       getMenuList(this.props,'Menu List').then((items)=>{            
            if(items.length>0){
              this.setState({menuItems:items});              
            }             
          }).catch((error)=>{
              console.log(error);
          })
    } 
  public render(): React.ReactElement<any> {   
    return (
        
        <HashRouter>
          <Row>
            <Col sm={12} md={12} lg={12} xl={12} className={'p-0'}>
               <Header {...this.props}/>
               <MenuSection {...this.props} {...this.state}/>     
            </Col>
          </Row>
          <Row className='pb-5'>
            <Col sm={12} md={12} lg={12} xl={12}>
              <Routes>
                    <Route path="/" element={<Home {...this.props}/>}/>
                    <Route path="/how-to-apply-the-pmf" element={<HowToApplyThePMF {...this.props}/>}/>                    
                    <Route path="/project-standards" element={<ProjectStandards {...this.props}/>}/>                    
                    <Route path="/expected-practice-maps" element={<ExpectedPracticeMaps context={this.props.context} spHttpClient={this.props.context.spHttpClient}/>}/>                    
                    <Route path="/library" element={<Home {...this.props}/>}/>   
                    <Route path="/pmfStructure" element={<PMFStructure {...this.props}/>}/>   
                
              </Routes>
            </Col>            
          </Row>  
          <Row>
          <Col sm={12} md={12} lg={12} xl={12} className={'p-0'}>
          <Container className={'p-0 border border-top-1 border-bottom-0 border-end-0 border-start-0'}>
          <FooterSection {...this.props} {...this.state}/>
          </Container>
        
          </Col>
          </Row>         
                   
        </HashRouter>
       
    );
  }
}
