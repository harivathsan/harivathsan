import * as React from 'react';
import{Row,Col} from 'react-bootstrap';
import styles from './Ipms.module.scss';

export default class FooterSection extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);
    this.state={}
  }//End Constructor



  public render(): React.ReactElement {
    
    return (
      
     
         <Row className={`${styles.footerSection}`}>
          <Col lg={4} className={`border border-top-0 border-bottom-0 border-start-0 border-end-1 pb-5 pt-5 ps-3`}>
          <h4>More in Home</h4>
          {this.props.menuItems.length>0 && <ul className={styles.footerlist}>
             {this.props.menuItems.length>0 && this.props.menuItems.map((m_item,index)=>{
              debugger;
                return(
                  <li key={index}>
                    <a href={`${this.props.context.pageContext.web.absoluteUrl}/SitePages/IPMS.aspx#${m_item.MainMenuLink}`}>{m_item.Title}</a>
                  </li> 
                )
              })}
          </ul> }
              
            
          </Col>
         </Row>
       
  
     
     
      
    );
  }
}
