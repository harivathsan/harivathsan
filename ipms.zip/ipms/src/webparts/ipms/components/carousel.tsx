import * as React from 'react';
import{Carousel} from 'react-bootstrap';
import styles from './Ipms.module.scss';
export default class CarouselSection extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);
      this.state={
        selectedIndex:0
     }
  }//End Constructor
  handleSelect=(selectedIndex:any) => {
    this.setState({selectedIndex:selectedIndex});
  };
  public render(): React.ReactElement {
   
    return (
      
      
      <Carousel  className={`${styles.carouselSection} mb-5`} prevIcon={<img alt="" className={styles.carouselleftarrow} src={'https://eu023-sp.shell.com/sites/SPOAA0342/shellipms/SiteAssets/Images/left-arrow.png'}/>}  nextIcon={<img alt="" className={styles.carouselrightarrow} src={'https://eu023-sp.shell.com/sites/SPOAA0342/shellipms/SiteAssets/Images/right-arrow.png'}/>} activeIndex={this.state.selectedIndex} onSelect={this.handleSelect}>
        {this.props.carouselItems.length>0 && this.props.carouselItems.map((item:any,index:number)=>{
          return(
           
            <Carousel.Item key={index}>
            <img alt="item.Image.Description" src={item.Image.Url}/>
            <Carousel.Caption>
            <h2><a href={item.Link}>{item.Title}</a></h2>
            <p dangerouslySetInnerHTML={{ __html: item.Description }}></p>
            </Carousel.Caption>
            </Carousel.Item>
           
            
          )
        })}
       
      </Carousel>
  
       
       
    );
  }
}
