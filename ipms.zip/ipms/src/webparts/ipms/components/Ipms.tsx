import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './shellBrand.css';
import styles from './Ipms.module.scss';
import { SPComponentLoader } from '@microsoft/sp-loader'; 
import type { IIpmsProps } from './IIpmsProps';
import{Container} from 'react-bootstrap';
//import { escape } from '@microsoft/sp-lodash-subset';
import Layout from './layout';

export default class Ipms extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);
    //importing Global CSS
    let cssPath: string = this.props.css;
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
     
  }//End Constructor
  public render(): React.ReactElement<IIpmsProps> {
    return (
      <Container fluid className={styles.ipms}>
          <Layout {...this.props}/>
      </Container>
    );
  }
}
