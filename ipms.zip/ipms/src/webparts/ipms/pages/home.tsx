import * as React from 'react';
import styles from '../components/Ipms.module.scss';
import{Row,Col,Table, Container} from 'react-bootstrap';
import CarouselSection from '../components/carousel';
import {getListAllItem} from "../services"

export default class Home extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);      
     this.state={
      homelist:[],
      carouselItems:[],
      homeContent:[],
      hometiles:[],
      homeTable:[]
     }
  }//End Constructor

async componentDidMount() {
    await getListAllItem(this.props,this.props.homelistName).then((items)=>{
       debugger;
       if(items.length>0){
        let carousels = items.filter((item: { ObjectType: string; })=>item.ObjectType == "Carousel");
        let homeContent = items.filter((item: { ObjectType: string; })=>item.ObjectType == "Text");
        let tiles = items.filter((item: { ObjectType: string; })=>item.ObjectType == "Tiles");
        let homeMenuTable = items.filter((item: { ObjectType: string; })=>item.ObjectType == "Table")
        this.setState({
              homelist:items,
              carouselItems:carousels,
              homeContent:homeContent,
              hometiles:tiles,
              homeTable:homeMenuTable
            })
       }
      
    });
 }

  public render(): React.ReactElement {
   debugger;
    return (
      <>          
        {this.state.homelist.length>0 &&
          <>
          <Row>
             <Col sm={12} md={12} lg={12} xl={12} className='p-0'> 
                {this.state.carouselItems.length>0 && <CarouselSection {...this.props} {...this.state}/> }
            </Col>           
            </Row>
            <Container>
            <Row className='mt-5'>
                <Col md={3} lg={3} xl={3} className='mt-5'>
                 {this.state.homeContent.length >0 && <img className='img-fluid' src={this.state.homeContent[0].Image.Url} alt='' style={{objectFit:'contain'}}/> }
                </Col>
                <Col md={9} lg={9} xl={9} className='mt-5'>
                {this.state.homeContent.length >0 && <p dangerouslySetInnerHTML={{ __html: this.state.homeContent[0].Description }}></p>}
               </Col> 
            </Row>
            <Row>
              <Col sm={12} md={12} lg={12} xl={12} className={styles.clickHere}>
                {this.state.homeContent.length >0 && <h2 dangerouslySetInnerHTML={{ __html: this.state.homeContent[1].Description }}></h2>}
              </Col>
            </Row>
            <Row>
                <Col md={12} lg={12} xl={12} className={`${styles.tablesection} mt-3`}>
                  <h3> Project Management Framework</h3>
                  <Table striped bordered hover>
                <thead>
                  <tr> 
                      {this.state.homeTable.length >0 &&this.state.homeTable.map((h_item:any,index:any)=>{
                        return(
                            <th key={index}>{h_item.Title}</th>                         
                              )
                      })}     
                    
                   
                  </tr>
                </thead>
                <tbody>
                  <tr>  
                  {this.state.homeTable.length >0 &&this.state.homeTable.map((d_item:any,index:any)=>{
                        return(
                            <td key={index} dangerouslySetInnerHTML={{ __html: d_item.Description }}></td>                         
                              )
                      })}          
                   
                  </tr>
                  
                </tbody>
              </Table>
                </Col>
            </Row>
            <Row className={`${styles.tilesSection} g-3 mt-5`}>
                <h1 className='text-center'>You May Also Be Interested In</h1>
                {this.state.hometiles.length >0 && this.state.hometiles.map((t_item:any,index:any)=>{
                  return(
                 <Col md={4} lg={3} xl={3} className={`${styles.tiles}`} key={index}>
                  <img className='img-fluid' src={t_item.Image.Url} alt=''/>
                  <div className={`${styles.tilesContent}`}>
                    <a href={t_item.Link}>{t_item.Title}</a>
                  </div>
                </Col>
                  )
                })}
            </Row>
            </Container>
            
         </>         
         }
      </>
    );
  }
}
