import * as React from 'react';
import{Row,Col} from 'react-bootstrap';

import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient } from "@microsoft/sp-http";

import { ICommonMethods } from '../../../common/ICommonMethods';
import { CommonMethods } from '../../../common/CommonMethods';

interface IExpectedPracticeMaps{
  context: WebPartContext;
  spHttpClient: SPHttpClient;
}
interface IExpectedPracticeMapsState{
  Phases: any[]
  EPMappings: any[]
}

export default class ExpectedPracticeMaps extends React.Component<IExpectedPracticeMaps, IExpectedPracticeMapsState> {
  private commonMethods: ICommonMethods; 
  //Begin Constructor
  
  constructor(props: IExpectedPracticeMaps) {
    super(props);
    this.state = {
      Phases:[],
      EPMappings:[]
    }
    this.commonMethods = new CommonMethods(props.context, props.spHttpClient);
  }//End Constructor



  public render(): React.ReactElement {
   
    return (
         <Row>
             <Col md={12} lg={12} xl={12}> 
             ExpectedPracticeMaps
            </Col>
         </Row>
    );
  }

  public async componentDidMount(): Promise<void> {
    const epMappings: any[] = await this.commonMethods.GetSPLargeListDataFilter("EP Mappings", "ID, Title, Phase/Id, Phase/Title, PhaseType, PhaseSubType, Category/Id, Category/Title ,Control/Id, Control/Title", "Phase,Category,Control", "");
    const phases: any[] = await this.commonMethods.GetSPLargeListDataFilter("ORS Phases", "*", "", "");

    this.setState({
      Phases: phases,
      EPMappings: epMappings
    });
  }
}
