import * as React from 'react';
import{Row,Col} from 'react-bootstrap';


export default class ProjectStandards extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);   
     this.state={}
  }//End Constructor
  public render(): React.ReactElement {
   
    return (
         <Row>
             <Col md={12} lg={12} xl={12}> 
             ProjectStandards
            </Col>
         </Row>
    );
  }
}
