import * as React from 'react';
import{Row,Col} from 'react-bootstrap';


export default class HowToApplyThePMF extends React.Component<any, any> {
   //Begin Constructor
   constructor(props: any) {
    super(props);
    //importing Global CSS   
     this.state={
          listItems:[]
     }
  }//End Constructor
  public render(): React.ReactElement {
   
    return (
         <Row>
             <Col md={12} lg={12} xl={12}>   
              How To Apply the PMF                 
            </Col>
         </Row>
    );
  }
}
