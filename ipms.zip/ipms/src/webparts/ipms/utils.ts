import * as _ from "lodash";
export const StringFormat = (...params) => {
    let str = '';
    if (params.length) {
        str = params[0];
        let key;
        params.shift();
        for (key in params) {
            str = str.replace(new RegExp("\\{" +  key + "\\}", "gi"), params[key]);
        }
    }
    return str;
};