import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'IpmsWebPartStrings';
import Ipms from './components/Ipms';
import { IIpmsProps } from './components/IIpmsProps';

export interface IIpmsWebPartProps {
  description: string;
  css: string;
  listName:string;
  context:any;
  webURL:string;
  homelistName:string;
  pmflistName:string;
  projectStandardsList:string;
  expectedPracticeMapsList:string;
}

export default class IpmsWebPart extends BaseClientSideWebPart<IIpmsWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';

  public render(): void {
    const element: React.ReactElement<IIpmsProps> = React.createElement(
      Ipms,
      {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        webURL: this.context.pageContext.web.absoluteUrl,
        css: this.properties.css,
        listName:this.properties.listName,       
        homelistName:this.properties.homelistName,
        pmflistName:this.properties.pmflistName,
        projectStandardsList:this.properties.projectStandardsList,
        expectedPracticeMapsList:this.properties.expectedPracticeMapsList,
        context:this.context
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onInit(): Promise<void> {
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
      if (this.properties.homelistName === undefined) {
        this.properties.homelistName = "Home List";
      }     
      if (this.properties.projectStandardsList === undefined) {
        this.properties.projectStandardsList = "Project Standards";
      }
      if (this.properties.expectedPracticeMapsList === undefined) {
        this.properties.expectedPracticeMapsList = "EP Mappings";
      }
      if (this.properties.pmflistName === undefined) {
        this.properties.pmflistName = "";
      }
      if (this.properties.listName === undefined) {
        this.properties.listName = "";
      }
    });
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('css', {
                  label: "~Css"
                }),

                PropertyPaneTextField('homelistName', {
                  label: "~Home listName"
                }),
                PropertyPaneTextField('pmflistName', {
                  label: "~PMF listName"
                }),
                PropertyPaneTextField('projectStandardsList', {
                  label: "~Project Standards List"
                }),
                PropertyPaneTextField('expectedPracticeMapsList', {
                  label: "~Expected Practice Maps List"
                }),
                PropertyPaneTextField('listName', {
                  label: "~listName"
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
