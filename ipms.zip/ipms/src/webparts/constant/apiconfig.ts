export const masterapi = {
    list:"/_api/web/Lists/GetByTitle('{0}')" ,
    allItem:'/items',
};
export const homepapi={
    
    listParam:"/items?$select=File/Name,File/ServerRelativeUrl,Category_x0020_Type,Level_x0020_1_x0020_Category/Title,Level_x0020_2_x0020_Category/Title,Geography/Title,Report_x0020_Type,Published_x0020_Month_x0020_and_x0020_Year&$orderby=Published_x0020_Month_x0020_and_x0020_Year desc&$expand=Level_x0020_1_x0020_Category&$expand=Level_x0020_2_x0020_Category&$expand=Geography&$expand=File&$top=6",
}