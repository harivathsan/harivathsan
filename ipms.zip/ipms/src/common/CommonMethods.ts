
import { ICommonMethods } from './ICommonMethods';
import { WebPartContext } from '@microsoft/sp-webpart-base';

import { SPFx } from '@pnp/sp';
import { Web } from '@pnp/sp/webs';

import "@pnp/sp/fields";
import "@pnp/sp/content-types";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";
import "@pnp/sp/site-groups/web";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IFieldSchema, RenderListDataOptions } from './CommonProperties';
 

export class CommonMethods implements ICommonMethods {

    private context: WebPartContext;
    private spHttpClient: SPHttpClient;
    constructor(context: WebPartContext, spHttpClient: SPHttpClient) {
        this.context = context;
        this.spHttpClient = spHttpClient;
    }

    public async GetSPLargeListData(listName: string, selectQuery:string, expandQuery?:string): Promise<any[]> {
        const destinationWeb = Web(this.context.pageContext.web.absoluteUrl).using(SPFx(this.context));
        let items: any[] = [];
        let skip = 0;
        let batch;
        let batchSize = 100;
        if(expandQuery){
            do {
                batch = await destinationWeb.lists.getByTitle(listName).items.select(selectQuery).expand(expandQuery).top(batchSize).skip(skip)();
                items = items.concat(batch);
                skip += batchSize;
            } while (batch.length === batchSize);
        }
        else{
            do {
                batch = await destinationWeb.lists.getByTitle(listName).items.select(selectQuery).top(batchSize).skip(skip)();
                items = items.concat(batch);
                skip += batchSize;
            } while (batch.length === batchSize);
        }
       

        return items;
    }

    public async GetSPLargeListDataFilter(listName: string, selectQuery:string, expandQuery?:string, filterQuery?:string): Promise<any[]> {
        const destinationWeb = Web(this.context.pageContext.web.absoluteUrl).using(SPFx(this.context));
        let items: any[] = [];
        let skip = 0;
        let batch;
        let batchSize = 100;
        if (expandQuery && filterQuery) {
            do {
                batch = await destinationWeb.lists.getByTitle(listName).items.select(selectQuery).expand(expandQuery).filter(filterQuery).top(batchSize).skip(skip)();
                items = items.concat(batch);
                skip += batchSize;
            } while (batch.length === batchSize);
        }
        else if (expandQuery) {
            do {
                batch = await destinationWeb.lists.getByTitle(listName).items.select(selectQuery).expand(expandQuery).top(batchSize).skip(skip)();
                items = items.concat(batch);
                skip += batchSize;
            } while (batch.length === batchSize);
        }
        else if (filterQuery) {
            do {
                batch = await destinationWeb.lists.getByTitle(listName).items.select(selectQuery).filter(filterQuery).top(batchSize).skip(skip)();
                items = items.concat(batch);
                skip += batchSize;
            } while (batch.length === batchSize);
        }
        else {
            do {
                batch = await destinationWeb.lists.getByTitle(listName).items.select(selectQuery).top(batchSize).skip(skip)();
                items = items.concat(batch);
                skip += batchSize;
            } while (batch.length === batchSize);
        }
       

        return items;
    }
 
    public getFieldSchemas(listName: string): Promise<IFieldSchema[]> {
        return new Promise<IFieldSchema[]>((resolve, reject) => {
            const restAPI = `${this.context.pageContext.web.absoluteUrl}/_api/web/Lists/GetByTitle('${listName}')/RenderListDataAsStream`;
            this.spHttpClient.post(restAPI, SPHttpClient.configurations.v1, {
                body: JSON.stringify({
                    parameters: {
                        RenderOptions: RenderListDataOptions.clientFormSchema,
                        ViewXml: '<View><ViewFields><FieldRef Name="ID"/></ViewFields></View>',
                    }
                })
            }).then((response: SPHttpClientResponse) => {
                if (response.ok) {
                    return response.json();
                } else {
                    reject(response);
                }
            }).then((data) => {
                const form = data.ClientForms.New;
                resolve(form[Object.keys(form)[0]]);
            }).catch((error) => {
                reject(error);
            });
        });
    }

    public async GetSPListItemData(listName: string, selectQuery: string, expandQuery: string, itemID: number): Promise<any> {
        const destinationWeb = Web(this.context.pageContext.web.absoluteUrl).using(SPFx(this.context));
        const lstItem = await destinationWeb.lists.getByTitle(listName).items.getById(itemID).select(selectQuery).expand(expandQuery)();
        return lstItem;
    }

    public async SaveItem(listName: string, itemBody: any, itemId?: number): Promise<number> {
        const destinationWeb = Web(this.context.pageContext.web.absoluteUrl).using(SPFx(this.context));
      
        let itemID = 0;
        if (itemId && itemId > 0) {
            await destinationWeb.lists.getByTitle(listName).items.getById(itemId).update(itemBody);
            itemID = itemId;
        }
        else {
            const item = await destinationWeb.lists.getByTitle(listName).items.add(itemBody);
            itemID = item.Id;
        }
        return itemID;
    }

   

    public getManager(): Promise<void> {
        return this.spHttpClient.get(this.context.pageContext.web.absoluteUrl + "/_api/SP.UserProfiles.PeopleManager/GetUserProfilePropertyFor(accountName='i:0%23.f|membership|" + this.context.pageContext.user.email+"',propertyName='Manager')", SPHttpClient.configurations.v1)
            .then((response: SPHttpClientResponse) => {
                if (response.ok) {
                    return response.json();
                }
                else {
                }
            }).then((response): void => {
                console.log(response?.value?.split('|')[response.value.split('|').length-1]);
            });
    }


}