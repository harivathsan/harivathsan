import { ICommonMethods } from './ICommonMethods';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/fields";
import "@pnp/sp/content-types";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";
import "@pnp/sp/site-groups/web";
import { SPHttpClient } from '@microsoft/sp-http';
import { IFieldSchema } from './CommonProperties';
export declare class CommonMethods implements ICommonMethods {
    private context;
    private spHttpClient;
    constructor(context: WebPartContext, spHttpClient: SPHttpClient);
    GetSPLargeListData(listName: string, selectQuery: string, expandQuery?: string): Promise<any[]>;
    GetSPLargeListDataFilter(listName: string, selectQuery: string, expandQuery?: string, filterQuery?: string): Promise<any[]>;
    getFieldSchemas(listName: string): Promise<IFieldSchema[]>;
    GetSPListItemData(listName: string, selectQuery: string, expandQuery: string, itemID: number): Promise<any>;
    SaveItem(listName: string, itemBody: any, itemId?: number): Promise<number>;
    getManager(): Promise<void>;
}
//# sourceMappingURL=CommonMethods.d.ts.map