import { IFieldSchema } from "./CommonProperties";
export interface ICommonMethods {
    GetSPLargeListData(listName: string, selectQuery: string, expandQuery?: string): Promise<any[]>;
    GetSPLargeListDataFilter(listName: string, selectQuery: string, expandQuery?: string, filterQuery?: string): Promise<any[]>;
    getFieldSchemas(listName: string): Promise<IFieldSchema[]>;
    GetSPListItemData(listName: string, selectQuery: string, expandQuery: string, itemID: number): Promise<any>;
    SaveItem(listName: string, itemBody: any, itemId?: number): Promise<number>;
    getManager(): Promise<void>;
}
//# sourceMappingURL=ICommonMethods.d.ts.map