import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface IIpmsWebPartProps {
    description: string;
    css: string;
    listName: string;
    context: any;
    webURL: string;
    homelistName: string;
    pmflistName: string;
    projectStandardsList: string;
    expectedPracticeMapsList: string;
}
export default class IpmsWebPart extends BaseClientSideWebPart<IIpmsWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=IpmsWebPart.d.ts.map