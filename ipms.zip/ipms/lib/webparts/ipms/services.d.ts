export declare const getListAllItem: (props: any, listName: string) => Promise<any>;
export declare const getMenuList: (props: any, listName: string) => Promise<any[]>;
//# sourceMappingURL=services.d.ts.map