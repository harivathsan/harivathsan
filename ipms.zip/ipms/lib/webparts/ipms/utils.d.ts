export declare const StringFormat: (...params: any[]) => string;
//# sourceMappingURL=utils.d.ts.map