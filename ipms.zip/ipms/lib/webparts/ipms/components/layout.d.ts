import * as React from 'react';
export default class Layout extends React.Component<any, any> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=layout.d.ts.map