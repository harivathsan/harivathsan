import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './shellBrand.css';
import type { IIpmsProps } from './IIpmsProps';
export default class Ipms extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement<IIpmsProps>;
}
//# sourceMappingURL=Ipms.d.ts.map