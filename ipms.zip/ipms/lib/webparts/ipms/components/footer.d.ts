import * as React from 'react';
export default class FooterSection extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement;
}
//# sourceMappingURL=footer.d.ts.map