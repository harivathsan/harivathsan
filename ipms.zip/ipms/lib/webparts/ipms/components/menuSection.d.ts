import * as React from 'react';
export default class MenuSection extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement;
}
//# sourceMappingURL=menuSection.d.ts.map