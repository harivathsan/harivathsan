declare const styles: {
    pmf: string;
    heading: string;
};
export default styles;
//# sourceMappingURL=pmfstructure.module.scss.d.ts.map