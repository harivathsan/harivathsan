declare const styles: {
    ipms: string;
    logo: string;
    topNav: string;
    h_line: string;
    mainNav: string;
    active: string;
    carouselSection: string;
    carouselleftarrow: string;
    carouselrightarrow: string;
    clickHere: string;
    tilesSection: string;
    tiles: string;
    tilesContent: string;
    tablesection: string;
    footerSection: string;
    footerlist: string;
};
export default styles;
//# sourceMappingURL=Ipms.module.scss.d.ts.map