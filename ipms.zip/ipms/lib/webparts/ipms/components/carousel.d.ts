import * as React from 'react';
export default class CarouselSection extends React.Component<any, any> {
    constructor(props: any);
    handleSelect: (selectedIndex: any) => void;
    render(): React.ReactElement;
}
//# sourceMappingURL=carousel.d.ts.map