declare const styles: {};
export default styles;
//# sourceMappingURL=pmf.scss.d.ts.map