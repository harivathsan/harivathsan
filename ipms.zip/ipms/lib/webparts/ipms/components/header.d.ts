import * as React from 'react';
export default class Header extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement;
}
//# sourceMappingURL=header.d.ts.map