import * as React from 'react';
export default class PMFStructure extends React.Component<any, any> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement;
}
//# sourceMappingURL=pmfStructure.d.ts.map