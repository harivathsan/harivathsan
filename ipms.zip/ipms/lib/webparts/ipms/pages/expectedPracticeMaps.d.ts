import * as React from 'react';
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient } from "@microsoft/sp-http";
interface IExpectedPracticeMaps {
    context: WebPartContext;
    spHttpClient: SPHttpClient;
}
interface IExpectedPracticeMapsState {
    Phases: any[];
    EPMappings: any[];
}
export default class ExpectedPracticeMaps extends React.Component<IExpectedPracticeMaps, IExpectedPracticeMapsState> {
    private commonMethods;
    constructor(props: IExpectedPracticeMaps);
    render(): React.ReactElement;
    componentDidMount(): Promise<void>;
}
export {};
//# sourceMappingURL=expectedPracticeMaps.d.ts.map