import * as React from 'react';
export default class HowToApplyThePMF extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement;
}
//# sourceMappingURL=howToApplyThePmf.d.ts.map