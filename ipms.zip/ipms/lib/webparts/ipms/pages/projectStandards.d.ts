import * as React from 'react';
export default class ProjectStandards extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement;
}
//# sourceMappingURL=projectStandards.d.ts.map