import * as React from 'react';
export default class Home extends React.Component<any, any> {
    constructor(props: any);
    componentDidMount(): Promise<void>;
    render(): React.ReactElement;
}
//# sourceMappingURL=home.d.ts.map