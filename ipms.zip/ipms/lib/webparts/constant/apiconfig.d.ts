export declare const masterapi: {
    list: string;
    allItem: string;
};
export declare const homepapi: {
    listParam: string;
};
//# sourceMappingURL=apiconfig.d.ts.map