import { WebPartContext } from "@microsoft/sp-webpart-base";
//import { sp, Web, PermissionKind, RegionalSettings} from '@pnp/sp';
import { sp,Web,PermissionKind, RegionalSettings, ClientSideWebpart, ClientSideWebpartPropertyTypes, ClientSidePage } from '@pnp/sp';
//import {Web} from '@pnp/sp';
import { graph} from "@pnp/graph";
import * as $ from 'jquery';
import { SiteUser } from "@pnp/sp/src/siteusers";
//import { IUserPermissions } from './IUserPermissions';
//import { IClientsidePage } from "@pnp/sp";
//import "@pnp/sp/clientside-pages/web";

// Class Services
class spservices {

    constructor(private context: WebPartContext) {
        // Setuo Context to PnPjs and MSGraph
        sp.setup({
            spfxContext: this.context
        });

        graph.setup({
            spfxContext: this.context
        });
        // Init
        this.onInit();
    }
    // OnInit Function
    private async onInit() {
        debugger;
        //var page2 = sp.web.addClientSidePage("PageWithSections.aspx");
        /*
        try {            
        
        const page = await ClientSidePage.fromFile(sp.web.getFileByServerRelativeUrl("/sites/SPOAA0342/PTM/SitePages/TestCal.aspx"));

        const partDefs = await sp.web.getClientSideWebParts();
        // find the definition we want, here by id
               
        const partDef = partDefs.filter(c => c.Id === "f92bf067-bc19-489e-a556-7fe95f508720");
        // optionally ensure you found the def
        if (partDef.length < 1) {
            // we didn't find it so we throw an error
            throw new Error("Could not find the web part");
        }
        const part =await ClientSideWebpart.fromComponentDef(partDef[0]);
         part.setProperties({
            isDocumentLibrary:true,
            selectedListId:'7cbc6698-8077-4142-98d6-e226d454fe01'
        });
        
        // we add that part to a new section
        page.addSection().addControl(part);
        // save our content changes back to the server
        await page.save();
    } catch (error) {
        console.log(error.message);
    }
    */
    }//End Init

    /**
   *
   * @param {number} userId
   * @param {string} siteUrl
   * @returns {Promise<SiteUser>}
   * @memberof spservices
   */
    public async getUserById(userId: number, siteUrl: string): Promise<SiteUser> {
        let results: SiteUser = null;

        if (!userId && !siteUrl) {
            return null;
        }

        try {
            const web = new Web(siteUrl);
            results = await web.siteUsers.getById(userId).get();
            //results = await web.siteUsers.getByLoginName(userId).get();
        } catch (error) {
            return Promise.reject(error);
        }
        return results;
    }

}//End Class

export default spservices;
