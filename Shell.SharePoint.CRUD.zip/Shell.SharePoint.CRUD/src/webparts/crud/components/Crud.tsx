/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Project Structure
Project Handled By                 : IMS US Capacity Projects
Module Name						             : CRUD
Module Description                 : CRUD Operation
Author                             : Firdous Ali K.A
Created Date                       : 3rd November 2023
Modified Date                      : 3rd November 2023
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/
import * as React from 'react';
import styles from './Crud.module.scss';
import { ICrudProps } from './ICrudProps';
import { escape } from '@microsoft/sp-lodash-subset';
import Form from './Form';

export default class Crud extends React.Component<ICrudProps, {}> {
  public render(): React.ReactElement<ICrudProps> {
    
    return (
      <div className={ styles.crud }>
        <Form context={this.props.context} displayMode={this.props.displayMode} updateProperty={this.props.updateProperty}></Form>
      </div>
    );
  }
}
