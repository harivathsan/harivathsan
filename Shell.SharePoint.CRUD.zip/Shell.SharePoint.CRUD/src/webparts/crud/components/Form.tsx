import * as React from 'react';
//import spservices from '../../../services/spservices';
import spservices from '../../../services/spservices';

import { WebPartTitle } from "@pnp/spfx-controls-react/lib/WebPartTitle";
import { Placeholder } from "@pnp/spfx-controls-react/lib/Placeholder";
import { WebPartContext } from "@microsoft/sp-webpart-base";
//import { ClientSideWebPartManager, IWebPartManagerContext, IWebPartData } from '@microsoft/sp-webpart-base';
import { DisplayMode } from '@microsoft/sp-core-library';

import { sp, Web, PermissionKind, RegionalSettings, ClientSideWebpart, ClientSideWebpartPropertyTypes, ClientSidePage } from '@pnp/sp';
import { ListView } from '@pnp/spfx-controls-react';
import { SPComponentLoader } from '@microsoft/sp-loader';

export interface IFormProps {
  context: any;
  displayMode: any;
  updateProperty: any;
}

export interface IFormState {
  userInfo: any;
  customWebPart: any;
}

class Form extends React.Component<IFormProps, IFormState> {
  //Global Variable  
  public readonly state: IFormState;
  private spService: spservices = null;

  //Begin Constructor
  constructor(props: IFormProps) {
    super(props);

    this.state = {
      userInfo: '',
      customWebPart: ''
    };
    this.spService = new spservices(this.props.context);

    //Begin
    sp.setup({
      spfxContext: this.props.context
    });
    //End
  }
  //End Constructor

  //Begin Methods

  private async getUserInfo() {
    debugger;
    let user: any = await this.spService.getUserById(29, 'https://eu023-sp.shell.com/sites/SPOAA0342/PTM/');
    console.log("Title" + user.Title);
    console.log("Email" + user.Email);
    this.setState({
      userInfo: user
    });
  }

  private async getWebPart() {
    try {

      const page = await ClientSidePage.fromFile(sp.web.getFileByServerRelativeUrl("/sites/SPOAA0342/PTM/SitePages/TestCal.aspx"));

      const partDefs = await sp.web.getClientSideWebParts();
      // find the definition we want, here by id

      const partDef = partDefs.filter(c => c.Id === "f92bf067-bc19-489e-a556-7fe95f508720");
      // optionally ensure you found the def
      if (partDef.length < 1) {
        // we didn't find it so we throw an error
        throw new Error("Could not find the web part");
      }
      const part = await ClientSideWebpart.fromComponentDef(partDef[0]);
      part.setProperties({
        isDocumentLibrary: true,
        selectedListId: '7cbc6698-8077-4142-98d6-e226d454fe01'
      });

      // we add that part to a new section
      //page.addSection().addControl(part);
      // save our content changes back to the server
      //await page.save();
//page.sections[0].addControl(part);
//const Component =await SPComponentLoader.loadComponent(JSON.parse(partDef[0].Manifest));
page.sections[0].columns[0].addControl(part);

//await page.save();


      this.setState({
        //customWebPart:part.data.webPartData.toString()
        //customWebPart: Component
      });

    } catch (error) {
      console.log(error.message);
    }
  }
  //End Methods

  //Begin Handlers

  public componentDidMount() {
    this.getUserInfo();
    this.getWebPart();
  }

  public render() {


    const { userInfo, customWebPart } = this.state;
    return (
      <div>
        <h3>Loading Form</h3>
        <div>
          {
            userInfo == "" ? 'null' : <div>
              <p><b>Title1:</b> {userInfo.Title}</p>
              <p><b>Email:</b> {userInfo.Email}</p>
              {/* <WebPartTitle displayMode={this.props.displayMode} title='Test Webpart' updateProperty={this.props.updateProperty}   > */}
                {/* <Placeholder iconName='Edit'  
                  iconText='Configure your web part'  
                  description='Please configure the web part.'  
                  buttonLabel='Configure'  
                  hideButton={this.props.displayMode === DisplayMode.Edit}  
                  />    */}
              {/* </WebPartTitle> */}              
              {/* <div>
                <section>
                
                {
                  customWebPart
                }        
                </section>        
              </div> */}
              <div id='docID'>
                {
                  // customWebPart
                }
              </div>             
            </div>
          }
        </div>
      </div>
    );
  }
  //End Handlers

}//End Class
export default Form;
