import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'CrudWebPartStrings';
import Crud from './components/Crud';
import { ICrudProps } from './components/ICrudProps';
import spservices from '../../services/spservices';


export interface ICrudWebPartProps {
  description: string;
  title: string;
}

export default class CrudWebPart extends BaseClientSideWebPart<ICrudWebPartProps> {

  private spService: spservices = null;

  // onInit
  public async onInit(): Promise<void> {
    this.spService = new spservices(this.context);

  }

  public render(): void {
    const element: React.ReactElement<ICrudProps> = React.createElement(
      Crud,
      {
        description: this.properties.description,
        title: this.properties.title,
        context: this.context,
        displayMode: this.displayMode,
        updateProperty: (value: string) => {
          this.properties.title = value;
        },
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
