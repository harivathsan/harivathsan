export interface IListItem{
    Title?:string;
    PopupContent:string;
}