/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Work Repoistory Tool
Project Handled By                 : AI&DS
Module Name						             : Banner Info
Module Description                 : Display Banner Info
Author                             : Firdous Ali K.A
Created Date                       : 9th September 2022
Modified Date                      : 9th September 2022
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/
import * as React from "react";
import * as ReactDom from 'react-dom';
import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer, PlaceholderContent, PlaceholderName
} from '@microsoft/sp-application-base';
//import { Dialog } from '@microsoft/sp-dialog';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import * as strings from 'BannerinfoApplicationCustomizerStrings';
import BannerInfoPopup from './components/BannerInfoPopup';
import { IBannerInfoProps } from './components/BannerInfoPopup';

const LOG_SOURCE: string = 'BannerinfoApplicationCustomizer';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IBannerinfoApplicationCustomizerProperties {
  // This is an example; replace with your own property
  testMessage: string;
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class BannerinfoApplicationCustomizer
  extends BaseApplicationCustomizer<IBannerinfoApplicationCustomizerProperties> {

  //Global Variable  
  private _headerPlaceholder: PlaceholderContent;
  private listName: string = "Banner%20Info";
  //  private currentEmailId: string;
  //  private listName: string = "Log%20List";
  //  private listItemCount: number;

  @override
  public onInit(): Promise<void> {
    console.log("Begin Banner Info Message");
    this
      .context
      .placeholderProvider
      .changedEvent
      .add(this, this.renderPlaceHolders);

    // Call render method for generating the needed html elements
    this.renderPlaceHolders();

    console.log("End Banner Info Message");

    return Promise.resolve();
  }//End Init

  //Begin renderPlaceHolders
  private renderPlaceHolders(): void {
    // Check if the header placeholder is already set and if the header placeholder
    // is available
    if (!this._headerPlaceholder && this.context.placeholderProvider.placeholderNames.indexOf(PlaceholderName.Top) !== -1) {
      this._headerPlaceholder = this
        .context
        .placeholderProvider
        .tryCreateContent(PlaceholderName.Top, { onDispose: this._onDispose });

      // The extension should not assume that the expected placeholder is available.
      if (!this._headerPlaceholder) {
        console.error('The expected placeholder (PageHeader) was not found.');
        return;
      }

      if (this._headerPlaceholder.domElement) {
        const context: any = this.context;
        let listTitle = this.context.pageContext.list.title;
        if (listTitle.toLowerCase() === "work repository tool") {
          //var propObj = { userEmailID: this.currentEmailId, listName: this.listName, count: 1, listItemCount: this.listItemCount, context};
          var propObj = { listName: this.listName, context };
          const element: React.ReactElement<IBannerInfoProps> = React.createElement(BannerInfoPopup, propObj);
          ReactDom.render(element, this._headerPlaceholder.domElement);
        }
      }
    }
  }//End renderPlaceHolders

  //Begin _onDispose
  private _onDispose(): void {
    console.log(' Disposed Banner Info Message');
  }
  //End _onDispose
}
