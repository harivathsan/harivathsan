import * as React from 'react';
import ApplicationCustomizerContext from "@microsoft/sp-application-base/lib/extensibility/ApplicationCustomizerContext";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IListItem } from '../IListItem';
import styles from './BannerInfo.module.scss';
import Modal from 'react-modal';

export interface IBannerInfoProps {
    context: ApplicationCustomizerContext;
    listName: string;
}

export interface IBannerInfoPopupProps {

}

export interface IBannerInfoPopupState {
    popupHeading: string;
    popupContent: string;
}

class BannerInfoPopup extends React.Component<any, IBannerInfoPopupState> {
    //Global Variables
    public readonly state: IBannerInfoPopupState;

    //constructor
    constructor(props: any) {

        super(props);
        //debugger;      
        this.state = {
            popupHeading: '',
            popupContent: ''
        };
    }

    //******** Begin Methods********//

    //Begin GetListData
    private async GetListData() {
        try {
            let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.props.listName + "')/Items";
            let response = await this.props.context.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1,
                {
                    headers: {
                        'Accept': 'application/json;odata=nometadata',
                        'Content-type': 'application/json;odata=nometadata',
                        'odata-version': ''
                    }
                    //body: body
                })
                .then((responseValues: SPHttpClientResponse): Promise<IListItem> => {
                    return responseValues.json();
                })
                .then((item: IListItem): void => {
                    console.log("Get Items successfully !!!");

                    this.setState({
                        popupHeading: item['value'][0].Title,
                        popupContent: item['value'][0].PopupContent

                    });

                }, (error: any): void => {
                    alert("Error in Get Items !!!");
                });
        }
        catch (error) {
            console.log("Error in Get Items Data : " + error);
        }
    }
    //End GetListData

    //******** End Methods********//

    //******** Begin Hanlder********//


    //Begin componentDidMount
    public componentDidMount() {
        //Method to load pop up content dynamically from Banner Info        
        this.GetListData();
    }
    //End componentDidMount

    //Begin Render
    public render() {
        const { popupHeading, popupContent } = this.state;
        return (
            <div className={styles.BannerInfocss}>
                <Modal isOpen={true} className="modalPopup" >
                    {/* commenting the hardcoded content and rendering the content from State variable */}
                    {/* <p><b>Migration In-Progess...</b></p>
                    <p>
                        Due to some update on WR the site is down for <b>3 hours</b>. Thanks for your patience and come back after 3 hours
                    </p> */}

                    <p><b>{popupHeading}</b></p>
                    <p>
                        <div dangerouslySetInnerHTML={{ __html: popupContent }}></div>
                    </p>
                </Modal>
            </div>
        );
    }
    //End Render

    //******** End Hanlder********//

}

export default BannerInfoPopup;     