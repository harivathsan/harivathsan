define([], function() {
  return {
    "Title": "BannerinfoApplicationCustomizer"
  }
});