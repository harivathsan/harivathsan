declare interface IBannerinfoApplicationCustomizerStrings {
  Title: string;
}

declare module 'BannerinfoApplicationCustomizerStrings' {
  const strings: IBannerinfoApplicationCustomizerStrings;
  export = strings;
}
