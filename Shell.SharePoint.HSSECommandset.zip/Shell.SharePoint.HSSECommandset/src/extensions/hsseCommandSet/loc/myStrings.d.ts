declare interface IHsseCommandSetCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'HsseCommandSetCommandSetStrings' {
  const strings: IHsseCommandSetCommandSetStrings;
  export = strings;
}
