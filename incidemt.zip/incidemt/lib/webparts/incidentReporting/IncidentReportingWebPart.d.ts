import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import './Common/common.css';
export interface IIncidentReportingWebPartProps {
    description: string;
    allItemsPageURL: string;
    bseeDistrictAreasURL: string;
    bseeNtlNo: string;
}
export default class IncidentReportingWebPart extends BaseClientSideWebPart<IIncidentReportingWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    private incidentQuestions;
    private bseeContacts;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=IncidentReportingWebPart.d.ts.map