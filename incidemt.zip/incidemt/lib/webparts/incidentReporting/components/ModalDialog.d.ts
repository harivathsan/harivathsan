import * as React from 'react';
import '../Common/dailog.css';
export default class ModalDialog extends React.Component<any, any> {
    constructor(props: any);
    private hideModal;
    componentDidMount(): void;
    private saveData;
    render(): JSX.Element;
}
//# sourceMappingURL=ModalDialog.d.ts.map