import * as React from 'react';
export default class NotificationDialog extends React.Component<any, any> {
    constructor(props: any);
    private toggleHideDialog;
    render(): JSX.Element;
}
//# sourceMappingURL=NotificationDialog.d.ts.map