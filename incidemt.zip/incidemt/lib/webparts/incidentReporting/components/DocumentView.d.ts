import * as React from 'react';
export default class DocumentView extends React.Component<any, any> {
    constructor(props: any);
    private _onClosePanel;
    render(): JSX.Element;
}
//# sourceMappingURL=DocumentView.d.ts.map