declare const styles: {
    incidentReporting: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=IncidentReporting.module.scss.d.ts.map