/* tslint:disable */
require("./IncidentReporting.module.css");
const styles = {
  incidentReporting: 'incidentReporting_0fbcb57d',
  teams: 'teams_0fbcb57d',
  welcome: 'welcome_0fbcb57d',
  welcomeImage: 'welcomeImage_0fbcb57d',
  links: 'links_0fbcb57d'
};

export default styles;
/* tslint:enable */