import { Panel, PanelType } from 'office-ui-fabric-react';
import * as React from 'react';

export default class DocumentView extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            title: "",
            showPanel: this.props.showPanel,
        }
    }

    private _onClosePanel = (key: boolean) => {
        this.setState({ showPanel: false });
        this.props._onClosePanel(key);
    }
    render() {
        return (
            <React.Fragment>
                <div>
                    <Panel
                        isOpen={this.state.showPanel}
                        type={PanelType.custom}
                        onDismiss={() => this._onClosePanel(false)}
                        isFooterAtBottom={false}
                        headerText="Incident Info"
                        closeButtonAriaLabel='Close'
                        isBlocking={false}
                        //onRenderFooterContent={this._onRenderFooterContent}
                        customWidth={'40%'}
                    >
                        <iframe
                            width="100%"
                            height="700px"
                            src={this.props.docURL}
                        ></iframe>


                    </Panel>
                </div>
            </React.Fragment>
        )
    }
}