import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient } from "../../../../node_modules/@microsoft/sp-http";
export interface IIncidentReportingProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userEmail: string;
  context: WebPartContext;
  webURL: string;
  spHttpClient: SPHttpClient;
  allItemsPageURL: string;
  bseeDistrictAreasURL: string;
  bseeNtlNo: string;
  incidentQuestions: any;
  bseeContacts: any;
}
