import { Dialog, DialogFooter, DialogType, PrimaryButton } from '@fluentui/react';
import * as React from 'react';


export default class NotificationDialog extends React.Component<any, any> {
    constructor(props: any) {
        super(props)

        this.state = {
            isDialogOpen: false,
            dialogContentProps: {
                type: DialogType.largeHeader,
                title: this.props.title,
            }
        }
    }
    private toggleHideDialog = () => {
        this.setState({
            isDialogOpen: true
        });
        window.location.replace(this.props.redirectUrl);
    }
    render() {
        return (
            <Dialog
                hidden={this.state.isDialogOpen}
                onDismiss={this.toggleHideDialog}
                dialogContentProps={this.state.dialogContentProps}
                modalProps={{
                    isBlocking: true,
                    styles: {
                        main: [{
                            selectors: {
                                [""]: { // Apply at root 
                                    minWidth: this.props.dialogWidth
                                }
                            }
                        }]
                    },
                }}
            >
                <p dangerouslySetInnerHTML={{ __html: this.props.message }}></p>
                <DialogFooter>
                    <PrimaryButton onClick={this.toggleHideDialog} text="Close" />
                </DialogFooter>
            </Dialog>
        )
    }
}