import * as React from 'react';
// import styles from './IncidentReporting.module.scss';
import 'bootstrap/dist/css/bootstrap.min.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { IIncidentReportingProps } from './IIncidentReportingProps';
import { IIncidentReportingState } from './IIncidentReportingState';
import "@pnp/sp/webs";
import "@pnp/sp/site-groups"
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/folders";
import "@pnp/sp/fields";
import "@pnp/sp/files";
import "@pnp/sp/site-users/web";
import "office-ui-fabric-react/dist/css/fabric.css";
import * as moment from 'moment';

import { TimePicker, DatePicker, Label } from '@fluentui/react';
import swal from "sweetalert2";
import { withSwalInstance } from 'sweetalert2-react';
import * as _ from 'lodash';
//import Moment from 'react-moment';
//import moment from 'moment';
import { SPFI, SPFx, spfi } from "@pnp/sp";
import "@pnp/sp/regional-settings/web";
//import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import {
  //ChoiceGroup,
  ComboBox,
  Dropdown,
  IComboBox,
  IComboBoxOption,
  Icon,
  PrimaryButton,
  TextField,
  MaskedTextField
} from 'office-ui-fabric-react';
import * as ReactDOM from 'react-dom';
import DocumentView from './DocumentView';
import ModalDialog from './ModalDialog';
//import NotificationDialog from './NotificationDialog';
//import { Folder } from '@pnp/sp/folders';
//import * as _ from 'lodash';
// import styles from './IncidentReporting.module.scss';

export default class IncidentReporting extends React.Component<IIncidentReportingProps, IIncidentReportingState, {}> {
  public incidentdata: any = []
  private incidentTypes: any = [{ name: "Fatality", type: "Verbal Notification followed by Written Notification" }, { name: "Injury - Medical Treatment", type: "Verbal Notification followed by Written Notification" }, { name: "Fire", type: "Verbal Notification followed by Written Notification" },
  { name: "Explosion", type: "Verbal Notification followed by Written Notification" }, { name: "Loss of Well control", type: "Verbal Notification followed by Written Notification" }, { name: "Collision", type: "Verbal Notification followed by Written Notification" }, { name: "Structural Damage", type: "Verbal Notification followed by Written Notification" }, { name: "Spill", type: "Verbal Notification followed by Written Notification" }, { name: "H2S Gas Release", type: "Verbal Notification followed by Written Notification" }, { name: "Crane/Lifting - Material Handling", type: "Verbal Notification followed by Written Notification" }, { name: "Crane/Lifting - Load Strike", type: "Verbal Notification followed by Written Notification" },
  { name: "Safety Systems", type: "Verbal Notification followed by Written Notification" }, { name: "Injury - Days Away, Restricted Duty, Transfer", type: "Written Notification Only" }, { name: "Muster", type: "Written Notification Only" }, { name: "Items Lost Overboard", type: "Written Notification Only" }, { name: "Gas Release- Automatic Shutdown", type: "Written Notification Only" }, { name: "Other Property Damage >$25K", type: "Written Notification Only" }, { name: "Required Evacuation", type: "Verbal Notification followed by Written Notification" }, { name: "Injury – Lost Time", type: "Written Notification Only" }
  ];
  //private format:any ="{ month: 'numeric', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false, timeZoneName: 'short', time  Zone: 'UTC'}"
  private formID: any;
  private spcontext: SPFI;
  constructor(props: any) {
    super(props);
    this.state = {
      Name: "", //this.props.userDisplayName,
      Title: "",
      Date: "",
      PhoneNo: '',
      Well: "",
      Rig: "N/A",
      Vessel: "N/A",
      Pipeline: "N/A",
      ContractorCo: "",
      ContractorRep: "",
      ContactInfo: "",
      Propert: "",
      Descriptionoftheincident: "",
      CorrectiveActionTaken: "",
      attachments: [],
      fileURL: "",
      fileName: [],
      folderName: "",
      Comment: "",
      status: "",
      ShellRegAffairs: "",
      NextReviewDate: null,
      isPanelOpen: false,
      panelHandle: false,
      incidentReportedDate: "",
      incidentIsReportable: true,
      BSEEINC:false,
      Investigation:false,
      PreservationNotice:false,
      incidentDate: "",
      options: [],
      GeneralActivityoptions:[],
      operationorActvity: '',
      GeneralActivity:'',
      Block_OCS: this.props.bseeContacts.map((item: any) => ({ text: item.Title, key: item.Title })),
      TypeofIncident: [],
      followUpAction: "",
      followUpActionRevDetails: [],
      reportStatus: "",
      reportDueDate: "",
      Block: '',
      district: "",
      initialDistricts: [],
      TypeofIncident_Value: [],
      additionalInfo: "",
      WrittenNotificationOnly: [],
      WrittenNotificationOnly_value: [],
      incident: '',
      Other: '',
      formMode: '',
      TypeofIncidentIdentification: '',
      showErrorAlert: false,
      rerender: "",
      linktoFolder: '',
      BSEEPhoneNo: '',
      NameofthePerson: '',
      USCG: '',
      USCGPhoneNo: '',
      Platform: 'N/A',
      Blocknumber: '',
      OCSnumber: '',
      IncidentSequentialNo: '',
      isdisableSubmit: false,
      ReportStatusOptions: [],

      spheraNumber: '',
      PlatformOptions: [],
      RigOptions: [],
      VesselOptions: [],
      rigOther: '',
      platformOther: '',
      vesselOther: '',
      reportedToBSEEDate: '',
      incidentReportedDateTime: '',
      incidentDateTime: '',
      reportedToBSEEDateTime: '',
      reportDate: '',
      hasFullControlAccess: false,
      hasContributeAccess: false,
      ItemCreatedBy: '',
      EmailTo: [],
      EmailCc: [],
      EmailSubject: '',
      EmailBody: ''

    }
    this.spcontext = spfi().using(SPFx(this.props.context));
  }
  public async componentDidMount() {
    debugger;
    await this.getTotalNumberOfIncidentReport();
    debugger;
    await this.checkUser();
    let spCommandBar = document.getElementById('spCommandBar')
    spCommandBar ? spCommandBar.style.display = 'none' : "";

    let spLeftNav = document.getElementById('spLeftNav');
    spLeftNav ? spLeftNav.style.display = 'none' : '';

    let spSiteHeader = document.getElementById('spSiteHeader');
    spSiteHeader ? spSiteHeader.style.display = "none" : "";
    await this.GetChoiceColumnsData();

    let url = new URL(window.location.href);
    let params = new URLSearchParams(url.search);
    let formMode;
    let formID;
    if (params.has('incidentID')) {
      formID = params.get('incidentID');
      this.formID = formID;
    }
    formMode = params.get('formMode');
    this.setState({ formMode: formMode })
    //Modified By Suresh
    // formMode === "New" ? "" : await this.getIncidentDetails(formID)
    // formMode === "New" ? "" : await this.getfiles(formID);
    formMode === "New" ? "" : await this.getIncidentDetails(formID)
    formMode === "New" ? "" : await this.getfiles(this.state.IncidentSequentialNo);
    //Modified End
    formMode === "EditForm" ? await this.getSendEmailData() : "";

    console.log(formID);
    /*
    if (this.state.status == "Submitted") {
      this.openModalDialog(NotificationDialog, {
        title: "Warning",
        message: `This incident has been already submitted.`,
        dialogWidth: '500px',
        redirectUrl: this.props.allItemsPageURL
      });
    } */
  }
  public async checkUser() {
    let fullControlAccess = false;
    let contributeAccess = false;
    let currentUser = await this.spcontext.web.currentUser();
    try {
      let owners = await this.spcontext.web.siteGroups.getByName("SER COMMUNITY_FULL ACCESS").users();
      let members = await this.spcontext.web.siteGroups.getByName("SER COMMUNITY_CONTRIBUTE ACCESS").users();
      owners.map((user, key) => {
        if (currentUser.Id === user.Id) {
          fullControlAccess = true;
        }
      });
      members.map((user, key) => {
        if (currentUser.Id === user.Id) {
          contributeAccess = true;
        }
      });
      this.setState({ hasFullControlAccess: fullControlAccess, hasContributeAccess: contributeAccess });
    }
    catch (error) {
      console.log("checkUser-" + error)
    }
  }
  public async GetChoiceColumnsData() {
    debugger;
    await this.spcontext.web.lists.getByTitle('IncidentReport').fields.filter("ReadOnlyField eq false and Hidden eq false and TypeAsString eq 'Choice' or TypeAsString eq 'MultiChoice'")().then((ChoicesValues) => {
      console.log(ChoicesValues);
      debugger;
      ChoicesValues.map((item) => {
        // if (item.InternalName === "BlockOCS") {
        //   let optionsLoc: any
        //   let OptionsValues: any = item.Choices
        //   optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
        //   this.setState({ Block_OCS: optionsLoc })
        // }
        if (item.InternalName === "GeneralActivity") {
          let optionsLoc: any
          let OptionsValues: any = item.Choices
          optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
          this.setState({ GeneralActivityoptions: optionsLoc })
        }
        if (item.InternalName === "OperationorActvityattimeofIncide") {
          let optionsLoc: any
          let OptionsValues: any = item.Choices
          optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
          this.setState({ options: optionsLoc })
        }
        if (item.InternalName === "TypeofIncident") {
          let optionsLoc: any
          let OptionsValues: any = item.Choices
          optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
          this.setState({ TypeofIncident: optionsLoc })
        }
        if (item.InternalName === "WrittenNotificationOnly") {
          let optionsLoc: any
          let OptionsValues: any = item.Choices
          optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
          this.setState({ WrittenNotificationOnly: optionsLoc })
        }
        if (item.InternalName === "ReportStatus") {
          let optionsLoc:any
          let contributeopt: any
          let OptionsValues: any = item.Choices
          contributeopt = OptionsValues.map((item_s: any) =>(item_s =="Pending"?{text: item_s, key: item_s}:{text: item_s, key: item_s,disabled: true }))
          optionsLoc = OptionsValues.map((item: any) =>({ text: item, key: item}))
          if(this.state.hasContributeAccess==true){
            this.setState({ ReportStatusOptions:contributeopt })
          }else{
            this.setState({ ReportStatusOptions: optionsLoc})}
        }

        if (item.InternalName === "Platform") {
          let optionsLoc: any
          let OptionsValues: any = item.Choices
          optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
          this.setState({ PlatformOptions: optionsLoc })
        }
        if (item.InternalName === "Rig") {
          let optionsLoc: any
          let OptionsValues: any = item.Choices
          optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
          this.setState({ RigOptions: optionsLoc })
        }
        if (item.InternalName === "Vessel") {
          let optionsLoc: any
          let OptionsValues: any = item.Choices
          optionsLoc = OptionsValues.map((item: any) => ({ text: item, key: item }))
          this.setState({ VesselOptions: optionsLoc })
        }
      })

    });

  }

  public async getTotalNumberOfIncidentReport() {
    debugger;
    await this.spcontext.web.lists.getByTitle('IncidentReport').items.top(5000)().then((IncidentValues: any[]) => {
      debugger;
      this.setState({ IncidentSequentialNo: IncidentValues.length + 1 })
    })
  }

  // Get data from configuration list for send email functionality
  public async getSendEmailData() {
    try{
      let ToEmails: any[] = [];
      let CcEmails: any[] = [];
      await this.spcontext.web.lists.getByTitle('Notify Users').items.select("To/EMail","Cc/EMail","Title","Body").expand("To","Cc").top(1)().then((response) => {
        if(response.length > 0 ){
          response.map((item) => {
            if (item.To.length > 0) {
              item.To.map((emails: { EMail: any; }) => {
                ToEmails.push(emails.EMail);
              });
            }
            if (item.Cc && item.Cc.length > 0) {
              item.Cc.map((ccEmails: { EMail: any; }) => {
                CcEmails.push(ccEmails.EMail);
              });
            }
            this.setState({
              EmailBody: item.Body,
              EmailSubject: item.Title,
              EmailCc: CcEmails,
              EmailTo: ToEmails
            });
          });
        }
      })    
    }
    catch (error) {
      console.log("getSendEmailData-" + error)
    }
  }

  public _selectDate(item: any) {
    this.setState({ Date: item })
  }

  public OpenPanel(item: any) {
    this.setState({ isPanelOpen: true, panelHandle: true, docURL: item })
  }

  private refreshDBs = async (key: boolean) => {
    try {
      this.setState({
        isPanelOpen: false,
        panelHandle: false
      });
    } catch (error) {
      throw new Error(error);
    }
  }

  private renderFormContent = () => {
    const panel = document.createElement("div");
    const panelElement: React.ReactElement<{}> = React.createElement(
      DocumentView,
      {
        showPanel: true,
        _onClosePanel: this.refreshDBs,
        context: this.props.context,
        docURL: this.state.docURL,

      }
    );
    ReactDOM.render(panelElement, panel);
  }
  private _numberChange(e: any) {

    this.setState({ PhoneNo: e.target.value })

  }
  public onSelectDate = (selectedDate: Date) => {
    let dateTimeValue: Date = selectedDate;
    if (this.state.incidentReportedDateTime) {
      dateTimeValue = new Date(selectedDate.getFullYear(),
        selectedDate.getMonth(),
        selectedDate.getDate(),
        this.state.incidentReportedDateTime.getHours(),
        this.state.incidentReportedDateTime.getMinutes()
      );
    }
    this.setState({
      incidentReportedDate: selectedDate,
      incidentReportedDateTime: dateTimeValue
    });
  }
  public onSelectDateBSEE = (selectedDate: Date) => {
    let dateTimeValue: Date = selectedDate;
    if (this.state.reportedToBSEEDateTime) {
      dateTimeValue = new Date(selectedDate.getFullYear(),
        selectedDate.getMonth(),
        selectedDate.getDate(),
        this.state.reportedToBSEEDateTime.getHours(),
        this.state.reportedToBSEEDateTime.getMinutes()
      );
    }
    this.setState({
      reportedToBSEEDate: selectedDate,
      reportedToBSEEDateTime: dateTimeValue
    });
  }
  public onSelectDueDate = (selectedDate: Date) => {
    this.setState({ reportDueDate: selectedDate });

  }
  public onSelectReportDate = (selectedDate: Date) => {
    this.setState({ reportDate: selectedDate });

  }
  public onFormatDate = (date: Date) => {
    return moment(date).format("MM-DD-YY");
  };
  public onTimePickerChange = async (_ev: React.FormEvent<IComboBox>, date: Date) => {
    //let spTimeZone = await this.spcontext.web.regionalSettings.timeZone.utcToLocalTime(date);
    //this.setState({ incidentReportedDate: new Date(spTimeZone) });
    this.setState({
      incidentReportedDateTime: new Date(date)
    });
  }
  public onTimePickerChangeBSEE = async (_ev: React.FormEvent<IComboBox>, date: Date) => {
    this.setState({ reportedToBSEEDateTime: date });
  }
  public onSelectDateincidentDate = (selectedDate: Date) => {
    let dateTimeValue: Date = selectedDate;
    if (this.state.incidentDateTime) {
      dateTimeValue = new Date(selectedDate.getFullYear(),
        selectedDate.getMonth(),
        selectedDate.getDate(),
        this.state.incidentDateTime.getHours(),
        this.state.incidentDateTime.getMinutes()
      );
    }
    this.setState({
      incidentDate: selectedDate,
      incidentDateTime: dateTimeValue,
      reportDueDate: this.addDays(selectedDate, 15)
    });
  }

  public addDays(date: Date, days: number): any {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  public onTimePickerChangeincidentDate = async (_ev: React.FormEvent<IComboBox>, date: Date) => {
    this.setState({ incidentDateTime: date });
  }

  public _onWhaleAttachmentsChange = (file: any) => {
    try { this.setState({ attachments: [...this.state.attachments, ...file.target.files] }); }
    catch (error) {
      console.log("render-" + error)
    }
  }

  // Remove attachment from the form on click of X
  private removeAttachment(file: any) {
    let oldattachments = this.state.attachments
    try {
      let finalattachments = _.filter(oldattachments, function (oldFile) {
        return oldFile.name != file.name
      })
      this.setState({
        attachments: finalattachments
      })

    }
    catch (error) {
      console.log("removeAttachment-" + error)
    }

  }
  public openEmail() {
    debugger;
    let subjectName = (moment(this.state.incidentDate).format('YYYYMMDD') + ' ' +
        (this.state.Block.indexOf('(') != -1 ? this.state.Block.substring(
          this.state.Block.indexOf("(") + 1,
          this.state.Block.lastIndexOf(")")) : this.state.Block.replace(/[^A-Z]+/g, ""))
        + '-' + this.state.Blocknumber + ' '
        + (this.state.operationorActvity == 'Other' ? this.state.Other : this.state.operationorActvity) + '').replace(/[^a-zA-Z0-9 -]/g, "");
    let toAddress = this.state.EmailTo.join(";");
    let ccAddress = this.state.EmailCc.length > 0 ? ("cc=" +  this.state.EmailCc.join(";") + "&") : "";
    let emailSubject = this.state.EmailSubject.replace("<<Inc Folder>>", subjectName);
    let viewItemLink = this.props.context.pageContext.web.absoluteUrl + `/SitePages/IncidentReporting.aspx?formMode=View&incidentID=${this.formID}`;
    let emailBody = encodeURIComponent(`${this.state.EmailBody.replace("<<URL>>", viewItemLink)}`);
    try {
      window.location.href = "mailto:" + toAddress + "?" + ccAddress + "subject=" + emailSubject + "&body=" + emailBody;
    }
    catch (error) {
      console.log("openEmail-" + error)
    }
  }
  //Validate columns for required fiedls
  public async valdateColumns(status: string) {
    debugger;
    try {
      if (this.state.Title.trim() !== "" && this.state.incidentReportedDate !== "" && this.state.incidentReportedDateTime !== ""
        && this.state.incidentDate !== "" && this.state.incidentDateTime !== ""
        && ((this.state.reportedToBSEEDate !== "" && this.state.reportedToBSEEDateTime !== "")
          || (this.state.reportedToBSEEDate == "" && this.state.reportedToBSEEDateTime == ""))
        && (this.state.spheraNumber == "" || this.state.spheraNumber.startsWith("https://") || this.state.spheraNumber.startsWith("http://"))
        && this.state.Name.trim() !== "" && this.state.Block.trim() !== "" && this.state.Blocknumber.trim() !== "" && this.state.TypeofIncident_Value.length > 0
        && this.state.Descriptionoftheincident.trim() !== "" && this.state.district.trim() !== "" && this.state.NameofthePerson.trim() !== "" && this.state.ShellRegAffairs.trim() !== ""
       
        // && ([/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) => pattern.test(this.state.PhoneNo)) || this.state.PhoneNo == "" || this.state.PhoneNo == null)
        // && ([/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) => pattern.test(this.state.BSEEPhoneNo)) || this.state.BSEEPhoneNo == "" || this.state.BSEEPhoneNo == null)
        // && ([/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) => pattern.test(this.state.USCGPhoneNo)) || this.state.USCGPhoneNo == "" || this.state.USCGPhoneNo == null)
        // && ([/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) => pattern.test(this.state.ContactInfo)) || this.state.ContactInfo == "" || this.state.ContactInfo == null)
        
        /* && ((this.state.Rig == "N/A" && ((this.state.Platform !== "" && this.state.Platform !== "N/A" && this.state.Platform !== "Other") || (this.state.Platform == "Other" && this.state.platformOther !== "")))
          || (this.state.Platform == "N/A" && ((this.state.Rig !== "" && this.state.Rig !== "N/A" && this.state.Rig !== "Other") || (this.state.Rig == "Other" && this.state.rigOther !== "")))) */
        && (((this.state.Platform == "N/A" && this.state.Vessel == "N/A" && this.state.Pipeline == "N/A") && ((this.state.Rig !== "N/A" && this.state.Rig !== "Other") || (this.state.Rig == "Other" && this.state.rigOther.trim() !== "" && this.state.rigOther !== null)))
          || ((this.state.Rig == "N/A" && this.state.Vessel == "N/A" && this.state.Pipeline == "N/A") && ((this.state.Platform !== "N/A" && this.state.Platform !== "Other") || (this.state.Platform == "Other" && this.state.platformOther.trim() !== "" && this.state.platformOther !== null)))
          || ((this.state.Rig == "N/A" && this.state.Platform == "N/A" && this.state.Pipeline == "N/A") && ((this.state.Vessel !== "N/A" && this.state.Vessel !== "Other") || (this.state.Vessel == "Other" && this.state.vesselOther.trim() !== "" && this.state.vesselOther !== null)))
          || (this.state.Rig == "N/A" && this.state.Platform == "N/A" && this.state.Vessel == "N/A" && this.state.Pipeline !== "N/A" && this.state.Pipeline.trim() !== ""))
        && ((this.state.operationorActvity != "" && this.state.operationorActvity !== "Other") || (this.state.operationorActvity == "Other" && this.state.Other.trim() !== ""))&& (this.state.GeneralActivity !=='')
      ) {
        this.setState({ isdisableSubmit: true }, async () => {
          if (this.state.formMode == "New") {
            await this.createIncident(status);
          } else {
            await this.updateIncident(status);
          }
        });

        debugger;
        //window.location.href = "" + this.props.context.pageContext.web.absoluteUrl + "/SitePages/Incident-Reporting-Tool.aspx";
      }
      else {
        this.setState({ showErrorAlert: true }); //SHow error Alert box
      }
    }
    catch (error) {
      console.log("valdateColumns-" + error)
    }


  }


  // public multiSelectOptions(event: any, item: any) {
  //   // {(event, item: any) => { this.state.incident === 'Written Notification Only' ? this.setState({ WrittenNotificationOnly_value: item.text, TypeofIncident_Value: [] }) : this.setState({ WrittenNotificationOnly_value: [], TypeofIncident_Value: item.text }) }}
  //   if (event.target.checked) {
  //     //this.state.WrittenNotificationOnly_value.push(item.text);
  //     if (this.state.incident === 'Written Notification Only') {
  //       this.state.WrittenNotificationOnly_value.push(item.text)
  //       this.setState({ TypeofIncident_Value: [] })
  //     }
  //     else {
  //       this.state.TypeofIncident_Value.push(item.text)
  //       this.setState({ WrittenNotificationOnly_value: [] })
  //     }
  //     //this.state.incident === 'Written Notification Only' ? this.state.WrittenNotificationOnly_value.push(item.text) : this.state.TypeofIncident_Value.push(item.text)
  //     //_.pull(this.state.WrittenNotificationOnly_value, item.text)
  //   }
  //   else {
  //     this.state.incident === 'Written Notification Only' ? _.remove(this.state.WrittenNotificationOnly_value, item.text) : _.remove(this.state.TypeofIncident_Value, item.text)

  //     //  _.remove(this.state.WrittenNotificationOnly_value, item.text)
  //   }
  // }

  public multiSelectOptions(event: any, item: any) {
    let currentValue: any
    this.incidentdata = []
    if (event.target.checked) {
      this.setState({ TypeofIncident_Value: [...this.state.TypeofIncident_Value, item.text] })
      let arr: any = this.state.TypeofIncident_Value ? [...this.state.TypeofIncident_Value, item.text] : [...item.text]
      arr.map((e: any) => {
        currentValue = this.incidentTypes.filter((i: { name: any; }) => i.name === e)
        this.incidentdata = [...this.incidentdata, ...currentValue]
      })
    }
    else {
      let arr: any = this.state.TypeofIncident_Value
      _.pull(arr, item.text)
      arr.map((e: any) => {
        currentValue = this.incidentTypes.filter((i: { name: any; }) => i.name === e)
        this.incidentdata = [...this.incidentdata, ...currentValue]
      })
      this.setState({ TypeofIncident_Value: [...arr] })
    }
  }

  public async createIncident(sts: string) {
    debugger;
    await this.spcontext.web.lists.getByTitle('IncidentReport').items.add({
      Title: this.state.Title,
      //Number
      IncidentNumber: this.state.IncidentSequentialNo,
      Phone: this.state.PhoneNo,  //.toString(),

      //Single Line of Text
      Blocknumber: this.state.Blocknumber,
      Well: this.state.Well,
      // Rig: this.state.Rig,
      // Vessel: this.state.Vessel,
      Pipeline: this.state.Pipeline,
      ContractorCo: this.state.ContractorCo,
      ContractorRep: this.state.ContractorRep,
      ContactInfo: this.state.ContactInfo,
      PropertEquimentDamage: this.state.Propert,
      //Platform: this.state.Platform,
      Other: this.state.Other,
      OCSnumber: this.state.OCSnumber,
      ShellRegAffairs: this.state.ShellRegAffairs,
      District: this.state.district,
      BSEEPhoneNo: this.state.BSEEPhoneNo,
      NameofthePerson: this.state.NameofthePerson,
      USCG: this.state.USCG,
      USCGPhoneNo: this.state.USCGPhoneNo,
      IncidentReportedByName: this.state.Name,
      RigOther: this.state.Rig == "Other" ? this.state.rigOther : this.state.Rig,
      PlatformOther: this.state.Platform == "Other" ? this.state.platformOther : this.state.Platform,
      VesselOther: this.state.Vessel == "Other" ? this.state.vesselOther : this.state.Vessel,

      //Multiline of text
      Description_x0020_of_x0020_the_x: this.state.Descriptionoftheincident,
      CorrectiveActionTaken: this.state.CorrectiveActionTaken,
      Comment: this.state.Comment,
      IncidentAdditionalInfo: this.state.additionalInfo,
      FollowUpAction: this.state.followUpAction,


      //Date and Time 
      incidentReportedDate: this.state.incidentReportedDateTime, //this.state.incidentReportedDate,
      incidentDate: this.state.incidentDateTime, //this.state.incidentDate,
      DueDate: this.state.reportDueDate !== '' ? this.state.reportDueDate : null,
      ReportedToBSEEDate: this.state.reportedToBSEEDateTime ? this.state.reportedToBSEEDateTime : null, //this.state.reportedToBSEEDate ? this.state.reportedToBSEEDate : null,
      ReportDate: (this.state.incidentIsReportable && this.state.reportDate !== '') ? this.state.reportDate : null,

      //Choice
      TypeofIncident: this.state.TypeofIncident_Value,
      BlockOCS: this.state.Block,
      ReportStatus: this.state.reportStatus,
      OperationorActvityattimeofIncide: this.state.operationorActvity,
      GeneralActivity:this.state.GeneralActivity,
      Platform: this.state.Platform,
      Rig: this.state.Rig,
      Vessel: this.state.Vessel,
      Status: sts,

      //YesOrNo
      IncidentIsReportable: this.state.incidentIsReportable,
      BSEEINC:this.state.BSEEINC,
      Investigation:this.state.Investigation,
      PreservationNotice:this.state.PreservationNotice,

      //Hyperlink
      SpheraNumber: {
        Description: "Sphera",
        Url: this.state.spheraNumber
      }

    }).then(async (item: any) => {
      console.log(item);
      alert("Item created Successfully!")
      //Modified By Suresh
      //await this.CheckFolderBeforeCreate(item.data.Id);
      //await this.updateIncidentlink(item.data.Id);
      await this.CheckFolderBeforeCreate(item.data.Id, this.state.IncidentSequentialNo);
      await this.updateIncidentlink(item.data.Id, this.state.IncidentSequentialNo);
      this.navigateToAllItems();

      //Modified End

    })

  }

  public async updateIncident(status: string) {
    debugger;
    console.log(this.formID);
    debugger;
    //if((this.state.spheraNumber == "" || this.state.spheraNumber.startsWith("https://") || this.state.spheraNumber.startsWith("http://")) ) {
    this.setState({ isdisableSubmit: true }, async () => {
      await this.spcontext.web.lists.getByTitle('IncidentReport').items.getById(this.formID).update({
        Title: this.state.Title,
        incidentReportedDate: this.state.incidentReportedDateTime, //this.state.incidentReportedDate,
        Phone: this.state.PhoneNo, //.toString(),
        incidentDate: this.state.incidentDateTime,  //this.state.incidentDate,
        Well: this.state.Well,
        Rig: this.state.Rig,
        Vessel: this.state.Vessel,
        Platform: this.state.Platform,

        Pipeline: this.state.Pipeline,
        ContractorCo: this.state.ContractorCo,
        ContractorRep: this.state.ContractorRep,
        ContactInfo: this.state.ContactInfo,
        PropertEquimentDamage: this.state.Propert,
        Description_x0020_of_x0020_the_x: this.state.Descriptionoftheincident,
        CorrectiveActionTaken: this.state.CorrectiveActionTaken,
        BlockOCS: this.state.Block,
        Blocknumber: this.state.Blocknumber,
        OCSnumber: this.state.OCSnumber,
        District: this.state.district,
        BSEEPhoneNo: this.state.BSEEPhoneNo,
        NameofthePerson: this.state.NameofthePerson,
        USCG: this.state.USCG,
        USCGPhoneNo: this.state.USCGPhoneNo,
        IncidentIsReportable: this.state.incidentIsReportable,
        BSEEINC:this.state.BSEEINC,
        Investigation:this.state.Investigation,
        PreservationNotice:this.state.PreservationNotice,
        DueDate: this.state.reportDueDate !== '' ? this.state.reportDueDate : null,
        ReportStatus: this.state.reportStatus,
        FollowUpAction: this.state.followUpAction,
        OperationorActvityattimeofIncide: this.state.operationorActvity,
        GeneralActivity:this.state.GeneralActivity,
        Other: this.state.Other,
        TypeofIncident: this.state.TypeofIncident_Value,
        IncidentAdditionalInfo: JSON.stringify(this.state.additionalInfo),
        Status: status,
        //WrittenNotificationOnly: this.state.WrittenNotificationOnly_value,
        Comment: this.state.Comment,
        ShellRegAffairs: this.state.ShellRegAffairs,
        //TypeofIncidentIdentification: this.state.incident,
        SpheraNumber: {
          Description: "Sphera",
          Url: this.state.spheraNumber
        },
        IncidentReportedByName: this.state.Name,
        RigOther: this.state.Rig == "Other" ? this.state.rigOther : this.state.Rig,
        PlatformOther: this.state.Platform == "Other" ? this.state.platformOther : this.state.Platform,
        VesselOther: this.state.Vessel == "Other" ? this.state.vesselOther : this.state.Vessel,
        ReportedToBSEEDate: this.state.reportedToBSEEDateTime ? this.state.reportedToBSEEDateTime : null, //this.state.reportedToBSEEDate ? this.state.reportedToBSEEDate : null
        ReportDate: (this.state.incidentIsReportable && this.state.reportDate !== '') ? this.state.reportDate : null
      }).then(async (item: any) => {
        console.log(item);
        alert("Item updated Successfully!")

        //modified by Suresh
        //await this.CheckFolderBeforeCreate(this.formID);
        await this.CheckFolderBeforeCreate(this.formID, this.state.IncidentSequentialNo);

        this.navigateToAllItems();
        //modified End

      })
    })
    /* }
    else {
      this.setState({ showErrorAlert: true }); //SHow error Alert box
    } */


  }

  public async updateIncidentlink(itemID: any, Incident_No: any) {
    debugger;
    console.log(this.formID);
    debugger;
    await this.spcontext.web.lists.getByTitle('IncidentReport').items.getById(itemID).update({
      //Linktofolder: this.state.linktoFolder,
      Linktofolder: {
        // "__metadata": { type: "SP.FieldUrlValue" },
        //Description: "Open Folder",
        Description: this.state.folderName,
        Url: this.state.linktoFolder
      }
      //TypeofIncidentIdentification: this.state.incident,
    }).then(async (item: any) => {
      debugger;
      console.log(item);
      // alert("Item updated Successfully!")
      this.navigateToAllItems();
      //await this.CheckFolderBeforeCreate(this.formID);
    })

  }
  public async getIncidentDetails(itemID: any) {
    debugger;
    await this.spcontext.web.lists.getByTitle('IncidentReport').items.getById(itemID).select("Title", "IncidentNumber", "incidentReportedDate", "Phone", "incidentDate", "Well", "Rig", "Vessel", "Pipeline", "Platform", "ContractorCo", "ContractorRep", "ContactInfo", "PropertEquimentDamage", "Description_x0020_of_x0020_the_x", "CorrectiveActionTaken", "BlockOCS", "Blocknumber", "OCSnumber","GeneralActivity", "OperationorActvityattimeofIncide", "Other", "TypeofIncident", "WrittenNotificationOnly", "Comment", "ShellRegAffairs", "TypeofIncidentIdentification", "IncidentAdditionalInfo", "Status", "District", "BSEEPhoneNo", "NameofthePerson", "USCG", "USCGPhoneNo", "FollowUpAction", "IncidentIsReportable","BSEEINC","Investigation","PreservationNotice", "DueDate", "ReportStatus", "SpheraNumber", "IncidentReportedByName", "RigOther", "PlatformOther", "VesselOther", "ReportedToBSEEDate", "Linktofolder", "ReportDate", "Author/EMail").expand("Author")().then((item: any) => {
      console.log(item);
      let incReportedDate: Date = new Date(item.incidentReportedDate);
      let incDate: Date = new Date(item.incidentDate);
      let BSEEDate: any = item.ReportedToBSEEDate ? new Date(item.ReportedToBSEEDate) : '';
      this.setState({
        Title: item.Title ? item.Title : '',
        IncidentSequentialNo: item.IncidentNumber,
        incidentReportedDate: new Date(incReportedDate.getFullYear(), incReportedDate.getMonth(), incReportedDate.getDate()),
        incidentReportedDateTime: incReportedDate,
        PhoneNo: item.Phone ? item.Phone : '', //parseInt(item.Phone),
        incidentDate: new Date(incDate.getFullYear(), incDate.getMonth(), incDate.getDate()),
        incidentDateTime: incDate,
        Well: item.Well ? item.Well : '',
        Rig: item.Rig ? item.Rig : 'N/A',
        Name: item.IncidentReportedByName ? item.IncidentReportedByName : '',
        ItemCreatedBy: item.Author.EMail,
        Platform: item.Platform ? item.Platform : 'N/A',
        Vessel: item.Vessel ? item.Vessel : 'N/A',
        Pipeline: item.Pipeline ? item.Pipeline : 'N/A',
        ContractorCo: item.ContractorCo ? item.ContractorCo : '',
        ContractorRep: item.ContractorRep ? item.ContractorRep : '',
        ContactInfo: item.ContactInfo ? item.ContactInfo : '',
        Propert: item.PropertEquimentDamage ? item.PropertEquimentDamage : '',
        Descriptionoftheincident: item.Description_x0020_of_x0020_the_x ? item.Description_x0020_of_x0020_the_x : '',
        CorrectiveActionTaken: item.CorrectiveActionTaken ? item.CorrectiveActionTaken : '',
        Block: item.BlockOCS,
        Blocknumber: item.Blocknumber ? item.Blocknumber : '',
        OCSnumber: item.OCSnumber ? item.OCSnumber : '',
        district: item.District ? item.District : '',
        BSEEPhoneNo: item.BSEEPhoneNo ? item.BSEEPhoneNo : '',
        NameofthePerson: item.NameofthePerson ? item.NameofthePerson : '',
        USCG: item.USCG ? item.USCG : '',
        USCGPhoneNo: item.USCGPhoneNo ? item.USCGPhoneNo : '',
        operationorActvity: item.OperationorActvityattimeofIncide ? item.OperationorActvityattimeofIncide : '',
        GeneralActivity: item.GeneralActivity ? item.GeneralActivity : '',
        Other: item.Other ? item.Other : '',
        incidentIsReportable: item.IncidentIsReportable,
        BSEEINC:item.BSEEINC,
        Investigation:item.Investigation,
        PreservationNotice:item.PreservationNotice,
        reportDueDate: item.DueDate ? new Date(item.DueDate) : '',
        reportStatus: item.ReportStatus,
        TypeofIncident_Value: item.TypeofIncident == null ? [] : item.TypeofIncident,
        additionalInfo: JSON.parse(item.IncidentAdditionalInfo),
        //WrittenNotificationOnly_value: item.WrittenNotificationOnly,
        Comment: item.Comment ? item.Comment : '',
        status: item.Status,
        ShellRegAffairs: item.ShellRegAffairs ? item.ShellRegAffairs : '',
        //incident: item.TypeofIncidentIdentification,
        spheraNumber: item.SpheraNumber == null ? '' : item.SpheraNumber.Url,
        rigOther: item.Rig == "Other" ? item.RigOther : '',
        platformOther: item.Platform == "Other" ? item.PlatformOther : '',
        vesselOther: item.Vessel == "Other" ? item.VesselOther : '',
        reportedToBSEEDate: item.ReportedToBSEEDate ? new Date(BSEEDate.getFullYear(), BSEEDate.getMonth(), BSEEDate.getDate()) : '',
        reportedToBSEEDateTime: BSEEDate,
        linktoFolder: item.Linktofolder == null ? '' : item.Linktofolder.Url,
        reportDate: item.ReportDate ? new Date(item.ReportDate) : ''
      })
    })
    this.incidentTypevalues(this.state.TypeofIncident_Value);
    let itemPrevVersionDetails: any = await this.getItemData(itemID);
    this.setState({
      followUpActionRevDetails: itemPrevVersionDetails
    });
  }
  private getItemData = async (itemID: any) => {
    return fetch(`${this.props.context.pageContext.web.absoluteUrl}/_api/Web/Lists/GetByTitle('IncidentReport')/Items(${itemID})/versions?$select=Id,FollowUpAction,Modified,Editor/Title&$expand=Editor&$filter=FollowUpAction ne null&$oderby=Modified desc`, {
      headers: { 'accept': 'application/json; odata=verbose' },
    }).then((res) => {
      return res.json();
    }).then((json) => {
      return json.d.results;
    });
  }
  public getfiles = async (itemId: any) => {
    await this.spcontext.web.lists.getByTitle("IncidentDocs").items.select('FileLeafRef', 'FileRef', 'formNo', 'ID').filter(`formNo eq ${itemId}`)().then(async (folders: any) => {
      console.log(folders);
      let files = await this.spcontext.web.getFolderByServerRelativePath(folders[0].FileRef).files();
      console.log(files);
      let finalFiles = [];
      for (const file of files) {
        finalFiles.push({
          name: file.Name,
          path: file.ServerRelativeUrl
        })

      }
      this.setState({ attachments: finalFiles });
    })


  }

  public CheckFolderBeforeCreate = async (itemId: number, incident_No: any) => {
    debugger;
    let results = [];
    console.log(itemId);
    debugger;
    if (this.state.formMode == "New") {
      //let iFolder = await this.spcontext.web.folders.addUsingPath('IncidentDocs/Incident_No_' + incident_No + '');
      let folderName = (moment(this.state.incidentDate).format('YYYYMMDD') + ' ' +
        (this.state.Block.indexOf('(') != -1 ? this.state.Block.substring(
          this.state.Block.indexOf("(") + 1,
          this.state.Block.lastIndexOf(")")) : this.state.Block.replace(/[^A-Z]+/g, ""))
        + '-' + this.state.Blocknumber + ' '
        + (this.state.operationorActvity == 'Other' ? this.state.Other : this.state.operationorActvity) + '').replace(/[^a-zA-Z0-9 -]/g, "");
      let iFolder = await this.spcontext.web.folders.addUsingPath('IncidentDocs/' + folderName);
      let folderInfo = await iFolder.folder.getItem();
      await folderInfo.update({ formNo: `${incident_No}` });
      console.log(iFolder);
      //let link = 'https://eu023-sp.shell.com' + iFolder.data.ServerRelativeUrl
      let link = 'https://eu001-sp.shell.com' + iFolder.data.ServerRelativeUrl
      this.setState({
        linktoFolder: link,
        folderName: folderName
      });
      console.log()
    }
    for (const attachment of this.state.attachments) {
      let ifolderrelativePath: string = this.state.linktoFolder.substring(this.props.context.pageContext.web.absoluteUrl.length - this.state.linktoFolder.lastIndexOf(this.props.context.pageContext.web.absoluteUrl) + 1)
      if (attachment.path === undefined) {
        const fileNamePath = decodeURI(attachment.name);
        debugger;
        if (attachment.size <= 10485760) {
          // small upload
          //let iFile = await this.spcontext.web.getFolderByServerRelativePath('IncidentDocs/Incident_No_' + incident_No + '').files.addUsingPath(fileNamePath, attachment, { Overwrite: true });
          let iFile = await this.spcontext.web.getFolderByServerRelativePath(ifolderrelativePath).files.addUsingPath(fileNamePath, attachment, { Overwrite: true });

          results.push(iFile);
        } else {
          // large upload
          //let iFile = await this.spcontext.web.getFolderByServerRelativePath('IncidentDocs/Incident_No_' + incident_No + '').files.addChunked(fileNamePath, attachment, data => {
          let iFile = await this.spcontext.web.getFolderByServerRelativePath(ifolderrelativePath).files.addChunked(fileNamePath, attachment, data => {
            console.log(`progress`);
          }, true);
          results.push(iFile);
        }
      }
    }
    if (results === this.state.attachments) {
      debugger;
      alert("item created successfully and uploaded files");
    }
  }
  private navigateToAllItems() {
    try {
      //this.setState({ modalIsOpen: false });
      //modified By Suresh
      //window.location.href = this.props.allItemsPageURL;
      window.location.href = "" + this.props.context.pageContext.web.absoluteUrl + "/SitePages/Incident-Reporting-Tool.aspx";
      //modified End
    }
    catch (error) {
      console.log("navigateToAllItems-" + error)
    }

  }

  public incidentTypevalues(values: any) {
    debugger;
    let currentValue: any
    this.incidentdata = []
    values.length > 0 && values.map((e: any) => {
      currentValue = this.incidentTypes.filter((i: { name: any; }) => i.name === e)
      this.incidentdata = [...this.incidentdata, ...currentValue]
    })
    this.setState({ TypeofIncident_Value: values })
  }
  private openDialog = (formMode: string) => {
    let alltypes = _.intersectionWith(this.state.TypeofIncident_Value, ["Injury - First Aid Only","Injury - Lost Time","Injury - Days Away, Restricted Duty, Transfer","Injury - Medical Treatment","Crane/Lifting - Material Handling","Crane/Lifting - Load Strike", "Fire", "Spill", "Loss of Well Control", "Fatality"], _.isEqual);
    // let alltypes = _.intersectionWith(this.state.TypeofIncident_Value, [{IncidentType : "Injury Medical Treatment"}, {IncidentType : "Crane Material Handling"}, {IncidentType : "Crane Personnel Handling"}, {IncidentType : "Fire"}, {IncidentType : "Spill"}, {IncidentType : "Loss of Well Control"}, {IncidentType : "Fatality"}], _.isEqual);
    this.openModalDialog(ModalDialog, {
      selectedTab: "Additional Information",
      closeModalLayout: this.getData,
      context: this.props.context,
      types: alltypes,
      formMode: formMode,
      incidentQuestions: this.props.incidentQuestions,
      additionalInfo: this.state.additionalInfo
    });
  }

  private openModalDialog = (componant: any, parms: {}) => {
    const modalDialogDiv = document.createElement('div');
    const modalDialogEelement: React.ReactElement<{}> = React.createElement(componant, parms);
    ReactDOM.render(modalDialogEelement, modalDialogDiv);
  }

  private getData = (data: any) => {
    this.setState({ additionalInfo: JSON.stringify(data) });
  }
  private blockOCSHandle = (item: any) => {
    this.setState({
      Block: item.text,
      panelHandle: false,
      district: Array(_.find(this.props.bseeContacts, ['Title', item.text]).District).toString(),
      initialDistricts: _.find(this.props.bseeContacts, ['Title', item.text]).District
    })
  }
  public render(): React.ReactElement<IIncidentReportingProps> {
    //let {formMode} = this.state
    //const SweetAlert = withSwalInstance(swal);
    return (
      <>
        <swal
          type="warning"
          show={this.state.showErrorAlert}
          title="Please fill valid data and all the required fields marked with an asterisk(*)"
          // text="Please fill all the required fields marked with an asterisk(*)"
          onConfirm={() => this.setState({ showErrorAlert: false })}
        /> 
        <Row>
          <Col sm={this.state.isPanelOpen ? 7 : 12}><Row className='headerStyles'>
            <Col sm={12} className='shell-font-bold'>Incident Reported by</Col>
          </Row>
            <Row>
              <Col sm={this.state.isPanelOpen ? 6 : 4}>
                <Label required={false}>{'Incident Number'}</Label>
                <Label required={false}>{this.state.IncidentSequentialNo}</Label>

              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                {/* <DatePicker
              label='Date'
              placeholder='date'
              disableAutoFocus={true}
              onChange={(e) => this._selectDate(e)}
              value={this.state.Date.toString()}
             /> */}
                <Label required={true}>{'Date and Time'}</Label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gridColumnGap: '3px' }}>
                  <DatePicker placeholder="Select a date..."
                    value={this.state.incidentReportedDate}
                    onSelectDate={this.onSelectDate}
                    formatDate={this.onFormatDate}
                    disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false} />
                  <TimePicker
                    placeholder="Select a time"
                    dateAnchor={this.state.incidentReportedDate}
                    value={this.state.incidentReportedDateTime}
                    onChange={this.onTimePickerChange}
                    increments={1}
                    useHour12
                    allowFreeform={false}
                    required={true}
                    disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  />
                </div>
              </Col>
              {/* <Col sm={4} >
            <TextField
              label='Time'
              type='Time'
              scrolling='No'
              placeholder='Time'
            //onChange={(e) => this.setState({ number: e.target["value"] })}
            //value={this.state.number.toString()}
            //required
            />
          </Col> */}
            <Col sm={this.state.isPanelOpen ? 6 : 4}>
                <TextField
                  label='Sphera Number'
                  type='url'
                  scrolling='No'
                  placeholder='Sphera Number'
                  onChange={(e, _item: any) => this.setState({ spheraNumber: _item, panelHandle: false })}
                  value={this.state.spheraNumber}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  onGetErrorMessage={(value: string): string => {
                    return (value == "" || value.startsWith("https://") || value.startsWith("http://") ? '' : `Invalid URL`);
                  }}
                  validateOnFocusOut
                  validateOnLoad
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <TextField
                  label='Field Contact’s Name'
                  type='text'
                  scrolling='No'
                  placeholder='Field Contact’s Name'
                  onChange={(e, _item: any) => this.setState({ Name: _item, panelHandle: false })}
                  value={this.state.Name}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  //readOnly
                  required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4}>
                <TextField
                  label='Field Contact’s Position'
                  type='text'
                  scrolling='No'
                  placeholder='Field Contact’s Position'
                  onChange={(e, _item: any) => this.setState({ Title: _item, panelHandle: false })}
                  value={this.state.Title}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4}>
                {/* <Row><Col sm={8} style={{ padding: 0 }}><Label>Phone</Label></Col><Col sm={4} className='root-ReferenceLink'><div className='referencelink' onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%204-USCG%20Contact%20List.pdf')}>Assets Contact List</div></Col></Row> */}
                <Row><Col sm={7} style={{ padding: 0 }}><Label>Phone</Label></Col><Col sm={5} className='root-ReferenceLink'> <PrimaryButton className='submitbtnclick' text="Assets Contact List" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%201%20-%20Assets%20Contact%20List.xlsx?web=1')} /></Col></Row>
                <MaskedTextField mask="(999) 999-9999" onChange={(e) => this._numberChange(e)}
                  value={this.state.PhoneNo}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  />
                {/* <TextField
                  // label='Phone'
                  placeholder='Phone'
                  type='tel'
                  onChange={(e) => this._numberChange(e)}
                  value={this.state.PhoneNo}
                  //defaultValue={this.state.PhoneNo}
                  //pattern="\d{10}"
                  //pattern='\d{10}'
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  // onInput={(e: any) => {
                  //   e.target.value = Math.max(0, parseInt(e.target.value)).toString().slice(0, 10)
                  // }} 
                  maxLength={12}
                  onGetErrorMessage={(value: string): string => {
                    return (
                      //[/^[1-9]\d{2}[-][1-9]\d{2}[-]\d{4}$/].every((pattern) =>
                      [/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) =>
                        pattern.test(value)
                      ) || value == "" ? "" : "Please enter numbers in the format: xxx-xxx-xxxx"
                    );
                  }}
                  validateOnFocusOut
                  validateOnLoad
                //required
                /> */}

              </Col>
              {/* <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <PrimaryButton className="submitbtn" text="Assets Contact List" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%204-USCG%20Contact%20List.pdf')} />
              </Col> */}
            
            </Row>
            <Row className='headerStyles'>
              <Col sm={12} className='shell-font-bold'>Incident</Col>
            </Row>
            <Row>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <Label required>{'Date and Time'}</Label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gridColumnGap: '3px' }}>
                  <DatePicker placeholder="Select a date..."
                    value={this.state.incidentDate}
                    onSelectDate={this.onSelectDateincidentDate}
                    formatDate={this.onFormatDate}
                    disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false} />
                  <TimePicker
                    placeholder="Select a time"
                    dateAnchor={this.state.incidentDate}
                    value={this.state.incidentDateTime}
                    onChange={this.onTimePickerChangeincidentDate}
                    increments={1}
                    useHour12
                    allowFreeform={false}
                    disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  />
                </div>
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <Dropdown
                  label='Block name'
                  placeholder='Block name'
                  options={this.state.Block_OCS}
                  onChange={(event, Item: any) => this.blockOCSHandle(Item)}
                  //defaultSelectedKey={this.state.Block}
                  selectedKey={this.state.Block}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  required
                //item: IDropdownOption

                //defaultSelectedKey={this.state.cityId}

                />

              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <TextField
                  label='Block number '
                  type='text'
                  scrolling='No'
                  placeholder='Block number'
                  onChange={(e, _item: any) => this.setState({ Blocknumber: _item, panelHandle: false })}
                  value={this.state.Blocknumber}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  //onChange={(e) => this.setState({ number: e.target["value"] })}
                  //value={this.state.number.toString()}
                  required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <TextField
                  label='OCS number'
                  type='text'
                  scrolling='No'
                  placeholder='OCS number'
                  onChange={(e, _item: any) => this.setState({ OCSnumber: _item, panelHandle: false })}
                  value={this.state.OCSnumber}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                {/* <TextField
                  label='Rig'
                  type='text'
                  scrolling='No'
                  placeholder='Rig'
                  onChange={(e, _item: any) => this.setState({ Rig: _item, panelHandle: false })}
                  value={this.state.Rig}
                  disabled={this.state.formMode == 'View'|| this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                /> */}
                <Dropdown
                  label='Rig'
                  placeholder='Rig'
                  options={this.state.RigOptions}
                  onChange={(event, Item: any) => { this.setState({ Rig: Item.text }); Item.text !== 'N/A' ? this.setState({ Platform: 'N/A', Vessel: 'N/A', Pipeline: 'N/A' }) : '' }}
                  //onChange={(event, Item: any) => this.setState({ Rig: Item.text, Platform: "N/A" })}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  selectedKey={this.state.Rig}
                  //defaultSelectedKey={this.state.Rig}
                  //required={((this.state.Platform == '' || this.state.Platform == "N/A") || (this.state.Platform == "Other" && this.state.platformOther == "")) ? true : false}
                  required={this.state.Platform == 'N/A' && this.state.Vessel == 'N/A' && this.state.Pipeline == 'N/A'}
                />

                {
                  this.state.Rig == "Other" ? <Col sm={12} >
                    <TextField
                      label='Rig Other'
                      type='text'
                      scrolling='No'
                      placeholder='Rig Other'
                      onChange={(event, item: any) => this.setState({ rigOther: item, panelHandle: false })}
                      disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                      value={this.state.rigOther}
                      //onChange={(e) => this.setState({ number: e.target["value"] })}
                      //value={this.state.number.toString()}
                      required={this.state.Rig == "Other" ? true : false}
                    />
                  </Col> : <Col sm={12} ></Col>
                }
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <Dropdown
                  label='Platform'
                  placeholder='Platform'
                  options={this.state.PlatformOptions}
                  onChange={(event, Item: any) => { this.setState({ Platform: Item.text }); Item.text !== 'N/A' ? this.setState({ Rig: 'N/A', Vessel: 'N/A', Pipeline: 'N/A' }) : '' }}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  selectedKey={this.state.Platform}
                  //defaultSelectedKey={this.state.Platform}
                  //required={((this.state.Rig == '' || this.state.Rig == "N/A") || (this.state.Rig == "Other" && this.state.rigOther == "")) ? true : false}
                  required={this.state.Rig == 'N/A' && this.state.Vessel == 'N/A' && this.state.Pipeline == 'N/A'}
                />
                {/*<TextField
                  label='Platform'
                  type='text'
                  scrolling='No'
                  placeholder='Platform'
                  onChange={(e, _item: any) => this.setState({ Platform: _item, panelHandle: false })}
                  value={this.state.Platform}
                  disabled={this.state.formMode == 'View'|| this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                // required
                />*/}

                {
                  this.state.Platform == "Other" ? <Col sm={12} >
                    <TextField
                      label='Platform Other'
                      type='text'
                      scrolling='No'
                      placeholder='Platform Other'
                      onChange={(event, item: any) => this.setState({ platformOther: item, panelHandle: false })}
                      disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                      value={this.state.platformOther}
                      //onChange={(e) => this.setState({ number: e.target["value"] })}
                      //value={this.state.number.toString()}
                      required={this.state.Platform == "Other" ? true : false}
                    />
                  </Col> : <Col sm={12} ></Col>
                }
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                {/* <TextField
                  label='Vessel'
                  type='text'
                  scrolling='No'
                  placeholder='Vessel'
                  onChange={(e, _item: any) => this.setState({ Vessel: _item, panelHandle: false })}
                  value={this.state.Vessel}
                  disabled={this.state.formMode == 'View'|| this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                // required
                /> */}
                <Dropdown
                  label='Vessel'
                  placeholder='Vessel'
                  options={this.state.VesselOptions}
                  onChange={(event, Item: any) => { this.setState({ Vessel: Item.text }); Item.text !== 'N/A' ? this.setState({ Rig: 'N/A', Platform: 'N/A', Pipeline: 'N/A' }) : '' }}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  selectedKey={this.state.Vessel}
                  required={this.state.Rig == 'N/A' && this.state.Platform == 'N/A' && this.state.Pipeline == 'N/A'}
                //defaultSelectedKey={this.state.Vessel}
                />

                {
                  this.state.Vessel == "Other" ? <Col sm={12} >
                    <TextField
                      label='Vessel Other'
                      type='text'
                      scrolling='No'
                      placeholder='Vessel Other'
                      onChange={(event, item: any) => this.setState({ vesselOther: item, panelHandle: false })}
                      disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                      value={this.state.vesselOther}
                      //onChange={(e) => this.setState({ number: e.target["value"] })}
                      //value={this.state.number.toString()}
                      required={this.state.Vessel == "Other" ? true : false}
                    />
                  </Col> : <Col sm={12} ></Col>
                }
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <TextField
                  label='Pipeline Segment Number'
                  type='text'
                  scrolling='No'
                  placeholder='Pipeline'
                  onChange={(e, _item: any) => { this.setState({ Pipeline: _item, panelHandle: false }); _item !== 'N/A' ? this.setState({ Rig: 'N/A', Platform: 'N/A', Vessel: 'N/A' }) : '' }}
                  value={this.state.Pipeline}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  //onChange={(e) => this.setState({ number: e.target["value"] })}
                  //value={this.state.number.toString()}
                  required={this.state.Rig == 'N/A' && this.state.Platform == 'N/A' && this.state.Vessel == 'N/A'}
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <TextField
                  label='Well (API#)'
                  type='text'
                  scrolling='No'
                  placeholder='Well (API#)'
                  onChange={(e, _item: any) => this.setState({ Well: _item, panelHandle: false })}
                  value={this.state.Well}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <Dropdown

                  label='General Activity at the time of incident '
                  placeholder='General Activity at the time of incident '
                  options={this.state.GeneralActivityoptions}
                  onChange={(event, item: any) => { this.setState({ GeneralActivity: item.text }); item.text !== "Other" ? this.setState({ Other: '' }) : '' }}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  selectedKey={this.state.GeneralActivity}
                  //defaultSelectedKey={this.state.operationorActvity}
                  required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <Dropdown

                  label='Operation at the time of incident'
                  placeholder='Operation at the time of incident'
                  options={this.state.options}
                  onChange={(event, item: any) => { this.setState({ operationorActvity: item.text }); item.text !== "Other" ? this.setState({ Other: '' }) : '' }}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  selectedKey={this.state.operationorActvity}
                  //defaultSelectedKey={this.state.operationorActvity}
                  required
                />
              </Col>
              {
                this.state.operationorActvity == "Other" ? <Col sm={this.state.isPanelOpen ? 6 : 4} >
                  <TextField
                    label='Other'
                    type='text'
                    scrolling='No'
                    placeholder='Other'
                    onChange={(event, item: any) => this.setState({ Other: item, panelHandle: false })}
                    disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                    value={this.state.Other}
                    //onChange={(e) => this.setState({ number: e.target["value"] })}
                    //value={this.state.number.toString()}
                    required={this.state.operationorActvity == "Other" ? true : false}
                  />
                </Col> : <Col sm={this.state.isPanelOpen ? 6 : 4} ></Col>
              }
            </Row>
            <Row className='headerStyles'>
              <Col sm={12} className='shell-font-bold'>Contractor Information</Col>
            </Row>
            <Row>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <TextField
                  label='Contractor Co.'
                  type='text'
                  scrolling='No'
                  placeholder='Contractor Co.'
                  onChange={(e, _item: any) => this.setState({ ContractorCo: _item, panelHandle: false })}
                  value={this.state.ContractorCo}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <TextField
                  label='Contractor Supervisor name'
                  type='text'
                  scrolling='No'
                  placeholder='Contractor Supervisor name'
                  onChange={(e, _item: any) => this.setState({ ContractorRep: _item, panelHandle: false })}
                  value={this.state.ContractorRep}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
              <MaskedTextField label='Supervisor phone no'  mask="(999) 999-9999"
               onChange={(e, _item: any) => this.setState({ ContactInfo: _item, panelHandle: false })}
               value={this.state.ContactInfo}
               disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
               />
                {/* <TextField
                  label='Supervisor phone no'
                  type='tel'
                  scrolling='No'
                  placeholder='Supervisor phone no'
                  onChange={(e, _item: any) => this.setState({ ContactInfo: _item, panelHandle: false })}
                  value={this.state.ContactInfo}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  maxLength={12}
                  onGetErrorMessage={(value: string): string => {
                    return (
                      //[/^[1-9]\d{2}[-][1-9]\d{2}[-]\d{4}$/].every((pattern) =>
                      [/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) =>
                        pattern.test(value)
                      ) || value == "" ? "" : "Please enter numbers in the format: xxx-xxx-xxxx"
                    );
                  }}
                  //onChange={(e) => this.setState({ number: e.target["value"] })}
                  //value={this.state.number.toString()}
                  //required
                  validateOnFocusOut
                  validateOnLoad
                /> */}
              </Col>

              {/* {
                this.state.operationorActvity == "Other" ? <Col sm={this.state.isPanelOpen ? 6 : 4} >
                  <TextField
                    label='Other'
                    type='text'
                    scrolling='No'
                    placeholder='Other'
                    onChange={(event, item: any) => this.setState({ Other: item, panelHandle: false })}
                    disabled={this.state.formMode == 'View'|| this.state.status == "Submitted" ? true : false}
                    value={this.state.Other}
                  //onChange={(e) => this.setState({ number: e.target["value"] })}
                  //value={this.state.number.toString()}
                  //required
                  />
                </Col> : <Col sm={this.state.isPanelOpen ? 6 : 4} ></Col>
              } */}

            </Row>
            <Row className='headerStyles'>
              <Col sm={12} className='shell-font-bold'>Type of Incident</Col>
            </Row>
            <Row>

              {/* <Col sm={this.state.isPanelOpen ? 8 : 8} className='radioButton'>
                <ChoiceGroup
                  label='Type of Incident'
                  options={[
                    {
                      key: 'Verbal Notification followed by Written Notification',
                      text: 'Verbal Notification followed by Written Notification'
                    },
                    {
                      key: 'Written Notification Only',
                      text: 'Written Notification Only'
                    }]}
                  onChange={(event, item: any) => this.setState({ incident: item.text, WrittenNotificationOnly_value: [], TypeofIncident_Value: [] })}
                  value={this.state.incident}
                  defaultSelectedKey={this.state.incident}
                  selectedKey={this.state.incident}
                  disabled={this.state.formMode !== 'View' ? false : true}
                />
              </Col> 
              {this.state.incident ? <Col sm={this.state.isPanelOpen ? 4 : 4} >
                <ComboBox style={{ paddingTop: '10px' }}
                  // label='Options'
                  placeholder='select options'

                  defaultValue={this.state.incident === 'Written Notification Only' ? this.state.WrittenNotificationOnly_value : this.state.TypeofIncident_Value}
                  options={this.state.incident === 'Written Notification Only' ? this.state.WrittenNotificationOnly : this.state.TypeofIncident}
                  onChange={(event: React.FormEvent<IComboBox>, item: IComboBoxOption) => this.multiSelectOptions(event, item)}
                  // selectedKey={this.state.incident === 'Written Notification Only' ? this.state.WrittenNotificationOnly_value : this.state.TypeofIncident_Value}
                  defaultSelectedKey={this.state.incident === 'Written Notification Only' ? this.state.WrittenNotificationOnly_value : this.state.TypeofIncident_Value}
                  multiSelect
                  disabled={this.state.formMode !== 'View' ? false : true}

                />
              </Col> : <Col sm={4}></Col>} */}
              <Col sm={this.state.isPanelOpen ? 4 : 4}>
                <ComboBox style={{ paddingTop: '10px' }}
                  label='Options'
                  placeholder='Select incident options'
                  defaultValue={this.state.TypeofIncident_Value}
                  options={this.state.TypeofIncident}
                  selectedKey={this.state.TypeofIncident_Value}
                  //defaultSelectedKey={this.state.TypeofIncident_Value}
                  onChange={(event: React.FormEvent<IComboBox>, item: IComboBoxOption) => this.multiSelectOptions(event, item)}
                  multiSelect
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 8 : 8}>
                <Row>{this.state.TypeofIncident_Value.length > 0 ? <><Col sm={6}><u><b>Written Notification Only</b></u></Col>
                  <Col sm={6}><u><b>Verbal Notification followed by Written Notification</b></u></Col></> : ""}
                </Row>
                <Row>
                  {this.incidentdata ?
                    <Col sm={6}>
                      {this.incidentdata.filter((item: { type: any; }) => item.type == "Written Notification Only").map((evnt: any) => {
                        if (evnt.type.includes('Written Notification Only')) {
                          return <Col sm={12}>{evnt.name}</Col>
                        }
                      })
                      }
                    </Col> : ""}
                  {this.incidentdata ?
                    <Col sm={6}>
                      {this.incidentdata.filter((item: { type: any; }) => item.type == "Verbal Notification followed by Written Notification").map((evnt: any) => {
                        if (evnt.type.includes('Verbal Notification followed by Written Notification')) {
                          return <Col sm={12}>{evnt.name}</Col>
                        }
                      })
                      }
                    </Col> : ""}
                </Row>

              </Col>
            </Row>
            <Row>
              {/* <Col sm={4} >Description of the incident, damage, or injury</Col> */}
              <Col sm={6} >
                <TextField
                  multiline
                  label='Description of the incident, damage, or injury'
                  type='text'
                  scrolling='No'
                  placeholder='Other'
                  onChange={(e, _item: any) => this.setState({ Descriptionoftheincident: _item, panelHandle: false })}
                  value={this.state.Descriptionoftheincident ? this.state.Descriptionoftheincident : ''}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  //onChange={(e) => this.setState({ number: e.target["value"] })}
                  //value={this.state.number.toString()}
                  required
                />
              </Col>
              <Col sm={6} >
                <TextField
                  multiline
                  label='Corrective Action Taken'
                  type='text'
                  scrolling='No'
                  placeholder='Other'
                  onChange={(e, _item: any) => this.setState({ CorrectiveActionTaken: _item, panelHandle: false })}
                  value={this.state.CorrectiveActionTaken}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>
            </Row>
            <Row>
              {/* <Col sm={4} >Description of the incident, damage, or injury</Col> */}
              <Col sm={6} >
                <TextField
                  multiline
                  label='Follow up actions'
                  type='text'
                  placeholder=''
                  onChange={(e, _item: any) => this.setState({ followUpAction: _item, panelHandle: false })}
                  value={this.state.followUpAction ? this.state.followUpAction : ''}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <TextField
                  label='Propert/Equiment Damage Est. (US$)'
                  type='text'
                  scrolling='No'
                  placeholder='Propert/Equiment Damage Est. (US$)'
                  onChange={(e, _item: any) => this.setState({ Propert: _item, panelHandle: false })}
                  value={this.state.Propert}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>
            </Row>
            <Row>
              <Col sm={6}>
                {this.state.followUpActionRevDetails.map((item: any) => (
                  <Row>
                    <Label style={{ fontWeight: 'normal', padding: 0 }}>{`${item.Editor.LookupValue} (${new Date(item.Modified).getDate()}/${new Date(item.Modified).getMonth() + 1}/${new Date(item.Modified).getFullYear()}): ${item.FollowUpAction}`}</Label>
                  </Row>
                ))}
              </Col>
            </Row>
            <Row>
              <Col sm={6}>
                <PrimaryButton className='submitbtnclick' text="Incident Reporting Procedure" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%202-%20HSE0137-PR01.pdf')} />
              </Col>
              {/* <Col sm={6}>
                <PrimaryButton className='submitbtnclick' text="Incident Info" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%202-%20HSE0137-PR01.pdf')} />
              </Col> */}
            </Row>
            {
              _.intersectionWith(this.state.TypeofIncident_Value, ["Injury - First Aid Only","Injury - Lost Time","Injury - Days Away, Restricted Duty, Transfer","Injury - Medical Treatment","Crane/Lifting - Material Handling","Crane/Lifting - Load Strike","Fire", "Spill", "Loss of Well Control", "Fatality"], _.isEqual).length > 0 ?
                <Row>
                  <Col sm={this.state.isPanelOpen ? 6 : 4} >
                    <PrimaryButton className="additionalbtn" text="Additional Info" onClick={() => this.openDialog((this.state.hasFullControlAccess || (this.state.hasContributeAccess && this.state.formMode == "EditForm" && this.state.ItemCreatedBy == this.props.userEmail)
                      || (this.state.formMode == "New" && this.state.hasContributeAccess)) ? this.state.formMode : "View")}>
                    </PrimaryButton>
                    {this.state.formMode == 'View' || this.state.status == "Submitted" || !(this.state.hasFullControlAccess || (this.state.hasContributeAccess && this.state.formMode == "EditForm" && this.state.ItemCreatedBy == this.props.userEmail)
                      || (this.state.formMode == "New" && this.state.hasContributeAccess)) ? <></> :
                      <Label style={{ color: 'rgb(164, 38, 44)' }}>Please fill additional info.</Label>
                    }
                  </Col>
                </Row> : <></>
            }
            <Row className='headerStyles'>
              <Col sm={12} className='shell-font-bold'>Responsible Agencies</Col>
            </Row>
            <Row>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                {/* <Row><Col sm={8} style={{ padding: 0 }}><Label>BSEE (District)</Label></Col><Col sm={4} className='root-ReferenceLink'><div className='referencelink' onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%205-BSEE%20District%20Areas%20of%20Responsibility.docx?web=1')}>BSEE District Areas</div></Col></Row> */}
                <Row><Col sm={7} style={{ padding: 0 }}><Label required>BSEE (District)</Label></Col><Col sm={5} className='root-ReferenceLink'> <PrimaryButton className='submitbtnclick' text="BSEE District Areas" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.bseeDistrictAreasURL)} /></Col></Row>
                {/* this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%205-BSEE%20District%20Areas%20of%20Responsibility.docx?web=1')} /></Col></Row> */}
                <TextField
                  //label='BSEE (District)'
                  scrolling='No'
                  placeholder='District'
                  disabled={(this.state.initialDistricts && this.state.initialDistricts.length > 1) ? false : true}
                  //onChange={(e) => this.setState({ number: e.target["value"] })}
                  onChange={(e, _item: any) => this.setState({ district: _item, panelHandle: false })}
                  value={this.state.district ? this.state.district : ""}
                //defaultValue={this.state.district ? this.state.district : ""}
                //required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                {/* <Row><Col sm={8} style={{ padding: 0 }}><Label>BSEE (phone #)</Label></Col><Col sm={4} className='root-ReferenceLink'><div className='referencelink' onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%203-%20BSEE%20Contact%20List.xlsx?web=1')}>BSEE contact List</div></Col></Row> */}
                <Row><Col sm={7} style={{ padding: 0 }}><Label>BSEE (phone #)</Label></Col><Col sm={5} className='root-ReferenceLink'> <PrimaryButton className='submitbtnclick' text="BSEE Contact List" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%203-%20BSEE%20Contact%20List.xlsx?web=1')} /></Col></Row>
                <MaskedTextField  mask="(999) 999-9999"
                 disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                 onChange={(e, _item: any) => this.setState({ BSEEPhoneNo: _item, panelHandle: false })}
                 value={this.state.BSEEPhoneNo}
                 />
                {/* <TextField
                  
                  scrolling='No'
                  placeholder='Phone'
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}

                  onChange={(e, _item: any) => this.setState({ BSEEPhoneNo: _item, panelHandle: false })}
                  value={this.state.BSEEPhoneNo}
                  // maxLength={12}
                  // onGetErrorMessage={(value: string): string => {
                  //   return (
                  //         //[/^[1-9]\d{2}[-][1-9]\d{2}[-]\d{4}$/].every((pattern) =>
                  //     [/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) =>
                  //       pattern.test(value)
                  //     ) || value == "" ? "" : "Please enter numbers in the format: xxx-xxx-xxxx"
                  //   );
                  // }}
                  // validateOnFocusOut
                  // validateOnLoad
                //value={this.state.number.toString()}
                //required
                /> */}
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <TextField
                  label='Name of Person (BSEE)'
                  type='text'
                  scrolling='No'
                  placeholder='Name of Person (BSEE)'
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  onChange={(e, _item: any) => this.setState({ NameofthePerson: _item, panelHandle: false })}
                  value={this.state.NameofthePerson}
                  required
                />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                {/* <Row><Col sm={8} style={{ padding: 0 }}><Label>USCG</Label></Col><Col sm={4} className='root-ReferenceLink'><div className='referencelink' onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%206-%20USCG%20District%20Areas%20of%20Responsibility.docx?web=1')}>USCG District Areas</div></Col></Row> */}
                <Row><Col sm={7} style={{ padding: 0 }}><Label >USCG <span style={{color:"#dc3545",fontSize:'15px'}}>**</span></Label></Col><Col sm={5} className='root-ReferenceLink'> <PrimaryButton className='submitbtnclick' text="USCG District Areas" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%206-%20USCG%20District%20Areas%20of%20Responsibility.docx?web=1')} /></Col></Row>
                <TextField
                  // label='USCG'
                  scrolling='No'
                  placeholder='District'
                  onChange={(e, _item: any) => this.setState({ USCG: _item, panelHandle: false })}
                  value={this.state.USCG}
                  //required
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                />
                <span style={{fontWeight:600,fontSize:'11px'}}><span style={{color:"#dc3545"}}>**</span> Note: Phone holder should go through USCG RA focal point if incident is to be reported to the USCG</span>
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                {/* <Row><Col sm={8} style={{ padding: 0 }}><Label>USCG (phone #)</Label></Col><Col sm={4} className='root-ReferenceLink'><div className='referencelink' aria-disabled={false} aria-checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%204-USCG%20Contact%20List.pdf')}>USCG Contact List</div></Col></Row> */}
                <Row><Col sm={7} style={{ padding: 0 }}><Label >USCG (phone #)</Label></Col><Col sm={5} className='root-ReferenceLink'> <PrimaryButton className='submitbtnclick' text="USCG Contact List" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%204-USCG%20Contact%20List.pdf')} /></Col></Row>
                <MaskedTextField  mask="(999) 999-9999"
                 disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                 onChange={(e, _item: any) => this.setState({ USCGPhoneNo: _item, panelHandle: false })}
                 value={this.state.USCGPhoneNo}/>
                {/* <TextField                 
                  type='text'
                  scrolling='No'
                  placeholder='Phone'
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  onChange={(e, _item: any) => this.setState({ USCGPhoneNo: _item, panelHandle: false })}
                  value={this.state.USCGPhoneNo}
                  // maxLength={12}
                  // onGetErrorMessage={(value: string): string => {
                  //   return (
                  //     //[/^[1-9]\d{2}[-][1-9]\d{2}[-]\d{4}$/].every((pattern) =>
                  //     [/^\d{3}[-]\d{3}[-]\d{4}$/].every((pattern) =>
                  //       pattern.test(value)
                  //     ) || value == "" ? "" : "Please enter numbers in the format: xxx-xxx-xxxx"
                  //   );
                  // }}
                  // validateOnFocusOut
                  // validateOnLoad
                //required
                /> */}
              </Col>
              {/* <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <PrimaryButton className="submitbtnclickRA" style={{ paddingTop: "43%" }} text="BSEE NTL No. 2018-G02" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%207-%20BSEE%20Reporting%20Guidance%20-%20NTL2018-G02%20-%209-27-2018.pdf')} />
              </Col> */}
              <Col sm={this.state.isPanelOpen ? 6 : 4} >
                <Row><Col sm={7} style={{ padding: 0 }}><Label>Date and Time (BSEE)</Label></Col><Col sm={5} className='root-ReferenceLink'> <PrimaryButton className="submitbtnclick" text={"BSEE " + this.props.bseeNtlNo} allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%207-%20BSEE%20Reporting%20Guidance%20-%20NTL.pdf')} /></Col></Row>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gridColumnGap: '3px' }}>
                  <DatePicker placeholder="Select a date..."
                    value={this.state.reportedToBSEEDate}
                    onSelectDate={this.onSelectDateBSEE}
                    formatDate={this.onFormatDate}
                    disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false} />
                  <TimePicker
                    placeholder="Select a time"
                    dateAnchor={this.state.reportedToBSEEDate}
                    value={this.state.reportedToBSEEDateTime}
                    onChange={this.onTimePickerChangeBSEE}
                    increments={1}
                    useHour12
                    allowFreeform={false}
                    required={true}
                    disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                  />
                  {(((this.state.reportedToBSEEDate !== "" && this.state.reportedToBSEEDateTime !== "")
                    || (this.state.reportedToBSEEDate == "" && this.state.reportedToBSEEDateTime == "")) ? <span></span>
                    : <span style={{ fontSize: '12px', color: 'rgb(164, 38, 44)', margin: '0px', paddingTop: '5px' }}>Invalid date</span>)}
                </div>
              </Col>
              {/* <Row>
                <Col sm={this.state.isPanelOpen ? 6 : 3} >
                  <PrimaryButton className="submitbtn" text="BSEE contact List" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%203-%20BSEE%20Contact%20List.xlsx?web=1')} />
                </Col>
                <Col sm={this.state.isPanelOpen ? 6 : 3} >
                  <PrimaryButton className="submitbtn" text="BSEE District Areas of Responsabilities" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%205-BSEE%20District%20Areas%20of%20Responsibility.docx?web=1')} />
                </Col>
                <Col sm={this.state.isPanelOpen ? 6 : 3} >
                  <PrimaryButton className="submitbtn" text="USCG Contact List" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%204-USCG%20Contact%20List.pdf')} />
                </Col>
                <Col sm={this.state.isPanelOpen ? 6 : 3} >
                  <PrimaryButton className="submitbtn" text="USCG District Areas of Responsabilities" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%206-%20USCG%20District%20Areas%20of%20Responsibility.docx?web=1')} />
                </Col>
              </Row> */}
            </Row>
            <Row style={{ padding: '2% 0%' }}>
              <Col sm={3} >Comment (communication with the Agency)</Col>
              <Col sm={9} >
                <TextField
                  multiline
                  // label='Description of the incident, damage, or injury'
                  type='text'
                  scrolling='No'
                  placeholder='Other'
                  onChange={(e, _item: any) => this.setState({ Comment: _item, panelHandle: false })}
                  value={this.state.Comment}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //onChange={(e) => this.setState({ number: e.target["value"] })}
                //value={this.state.number.toString()}
                //required
                />
              </Col>

            </Row>
            <Row>
              <Col sm={3} ><Label required>Shell Reg. Affairs (RA)</Label></Col>
              <Col sm={5} >
                <TextField
                  type='text'
                  scrolling='No'
                  placeholder='Shell Reg. Affairs (RA)'
                  onChange={(e, _item: any) => this.setState({ ShellRegAffairs: _item, panelHandle: false })}
                  value={this.state.ShellRegAffairs ? this.state.ShellRegAffairs.toString() : ""}
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                //required
                />
              </Col>
              {/* <Row><Col sm={7} style={{ padding: 0 }}><Label>BSEE (District)</Label></Col><Col sm={5} className='root-ReferenceLink'> <PrimaryButton className='submitbtnclick' text="BSEE District Areas" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%205-BSEE%20District%20Areas%20of%20Responsibility.docx?web=1')} /></Col></Row> */}
              <Col sm={3} >
                <PrimaryButton className="submitbtnclick" text="Shell RA contact List " allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%205-BSEE%20District%20Areas%20of%20Responsibility.pdf')} />
              </Col>
            </Row>
            <Row className='headerStylesBlank'>
              <Col sm={12}></Col>
            </Row>
            <Row>
              <Col sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>The Incident is reportable</Col>
              <Col className={'col-4 toogleButton'} sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>
                <input tabIndex={0} id="chck" type="checkbox" checked={this.state.incidentIsReportable} disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false} onChange={(e: any) => this.setState({ incidentIsReportable: e.target.checked })} />
                <label tabIndex={0} htmlFor="chck" className="check-trail">
                  <span className="check-handler"></span>
                </label>
              </Col>
              {this.state.incidentIsReportable ?
                <>
                  <Col sm={4} >
                    <Label>{'BSEE Report Date'}</Label>
                    <DatePicker placeholder="Select a date..."
                      title='Report Date'
                      value={this.state.reportDate}
                      onSelectDate={this.onSelectReportDate}
                      formatDate={this.onFormatDate}
                      disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false}
                    />
                  </Col>
                  <Col sm={4}>
                    <Label>{'BSEE Report Due Date'}</Label>
                    <DatePicker placeholder="Select a date..."
                      title='Due Date'
                      value={this.state.reportDueDate}
                      onSelectDate={this.onSelectDueDate}
                      formatDate={this.onFormatDate}
                      disabled={true} //{this.state.formMode == 'View'|| this.state.status == "Submitted" ? true : false} 
                    />
                  </Col>
                </>
                : <></>}
              <Col sm={4} >
                
                <Dropdown
                  label='BSEE Report Status'
                  placeholder=''
                  //options={[{ text: "Open", key: "Open" }, { text: "InProgress", key: "InProgress" }, { text: "Closed", key: "Closed" }]}
                  options={this.state.ReportStatusOptions}
                  
                  onChange={(event, Item: any) => this.setState({ reportStatus: Item.text })}
                  //defaultSelectedKey={this.state.reportStatus}
              
                  selectedKey={this.state.reportStatus}
                 
                  disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false }

                //item: IDropdownOption

                //defaultSelectedKey={this.state.cityId}

                />
              </Col>
            </Row>
            <Row>
              <Col sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>BSEE INC</Col>
              <Col className={'col-4 toogleButton'} sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>
                <input tabIndex={0} id="chck1" type="checkbox" checked={this.state.BSEEINC} disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false} onChange={(e: any) => this.setState({ BSEEINC: e.target.checked })} />
                <label tabIndex={0} htmlFor="chck1" className="check-trail">
                  <span className="check-handler"></span>
                </label>
              </Col>
              <Col sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>Investigation(BSEE/Shell)</Col>
              <Col className={'col-4 toogleButton'} sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>
                <input tabIndex={0} id="chck2" type="checkbox" checked={this.state.Investigation} disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false} onChange={(e: any) => this.setState({ Investigation: e.target.checked })} />
                <label tabIndex={0} htmlFor="chck2" className="check-trail">
                  <span className="check-handler"></span>
                </label>
              </Col>
              <Col sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>Preservation Notice</Col>
              <Col className={'col-4 toogleButton'} sm={2} md={2} lg={2} xl={2} style={{ paddingTop: "22px" }}>
                <input tabIndex={0} id="chck3" type="checkbox" checked={this.state.PreservationNotice} disabled={this.state.formMode == 'View' || this.state.status == "Submitted" ? true : false} onChange={(e: any) => this.setState({ PreservationNotice: e.target.checked })} />
                <label tabIndex={0} htmlFor="chck3" className="check-trail">
                  <span className="check-handler"></span>
                </label>
              </Col>
            </Row>
            <Row className='headerStyles'>
              <Col sm={12} className='shell-font-bold'>References</Col>
            </Row>
            <Row>
              <Row><p className='shell-font-book' style={{ textAlign: 'center' }}>You can download the below reference files in the visualization window</p></Row>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <PrimaryButton className="submitbtnclick" text={"BSEE " + this.props.bseeNtlNo} allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%207-%20BSEE%20Reporting%20Guidance%20-%20NTL.pdf')} />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <PrimaryButton className="submitbtnclick" text="Incident Reporting Procedure" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%202-%20HSE0137-PR01.pdf')} />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <PrimaryButton className="submitbtnclick" text="Regulatory Alert No. 2019-03" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%208-%20Regulatory%20Alert%20No.%202019-03%20--%20Incident%20Reporting%20for%20Potential%20Medical%20Treatment.pdf')} />
              </Col>
              <Col sm={this.state.isPanelOpen ? 6 : 3} >
                <PrimaryButton className="submitbtnclick" text="Regulatory Alert No. 2020-01" allowDisabledFocus disabled={false} checked={false} onClick={() => this.OpenPanel(this.props.context.pageContext.web.absoluteUrl + '/Shared%20Documents/File%209-%20Regulatory%20Alert%20No.%202020-01%20--%20BSEE%20Incident%20Reporting%20Changes%20Effective%2012-3-2019.pdf')} />
              </Col>
            </Row>
            <Row className='headerStyles'>
              <Col sm={12} className='shell-font-bold' >Upload Documents</Col>
            </Row>
            <Row>
              <Col sm={12} >
                <input className='uploadControl' type="file" multiple id='uploadfile' onChange={(e) => this._onWhaleAttachmentsChange(e)} disabled={this.state.formMode !== 'View' ? false : true} />
              </Col>
              <Col sm={12} >
                {this.state.attachments.map((file: { name: any; }, index: string) => (
                  <p className='attachmentFiles' id={"File" + index} >{file.name} <Icon iconName="Cancel" title="Remove" style={{ color: "red", fontWeight: 500, fontSize: 10, cursor: 'pointer' }} onClick={() => this.removeAttachment(file)} /></p>
                ))}
              </Col>
            </Row>

            <Row>
              <Col sm={this.state.isPanelOpen ? 12 : 8} >
                <PrimaryButton style={{ display: (this.state.formMode == "View" ? "none" : "inline-block") }} className="submitbtn" text={this.state.formMode == "New" ? "Save" : "Update"} allowDisabledFocus
                  disabled={this.state.isdisableSubmit || (this.state.reportStatus == "Final Accepted - Closed if not Reportable") ||
                    !(this.state.hasFullControlAccess || (this.state.hasContributeAccess && this.state.formMode == "EditForm" && this.state.ItemCreatedBy == this.props.userEmail)
                      || (this.state.formMode == "New" && this.state.hasContributeAccess))}
                  onClick={() => this.valdateColumns("Draft")} checked={false}><i className='ms-Icon ms-Icon--Save' /></PrimaryButton>
                <PrimaryButton style={{
                  marginLeft: 15,
                  display: (this.state.status == "Draft" || this.state.status == "" && this.state.formMode == "New" || this.state.formMode == "EditForm" ? "inline-block" : "none")
                  //display: (this.state.formMode == "EditForm" && (this.state.reportStatus == "Final Accepted") ? "inline-block" : "none")
                }} className="submitbtn" text="Final Accepted" allowDisabledFocus
                  disabled={this.state.isdisableSubmit || (this.state.reportStatus != "Final Accepted - Closed if not Reportable") ||
                    !(this.state.hasFullControlAccess || (this.state.hasContributeAccess && this.state.formMode == "EditForm" && this.state.ItemCreatedBy == this.props.userEmail)
                      || (this.state.formMode == "New" && this.state.hasContributeAccess))}
                  onClick={() => this.valdateColumns("Submitted")} checked={false}><i className='ms-Icon ms-Icon--Save' /></PrimaryButton>
              <PrimaryButton style={{ marginLeft: 15, display: (this.state.formMode == "EditForm" && (this.state.reportStatus != "Final Accepted - Closed if not Reportable") ? "inline-block" : "none") }} className="submitbtn" text="Send Email" allowDisabledFocus
                  disabled={!(this.state.hasFullControlAccess || (this.state.hasContributeAccess && this.state.formMode == "EditForm" && this.state.ItemCreatedBy == this.props.userEmail)
                    || (this.state.formMode == "New" && this.state.hasContributeAccess))}
                  onClick={() => this.openEmail()} checked={false}></PrimaryButton>
               <PrimaryButton className="cancelbtn" text="Cancel" onClick={() => this.navigateToAllItems()}>
                  <i className='ms-Icon ms-Icon--Cancel' ></i>
                </PrimaryButton>
              </Col>


            </Row>
            {this.state.isPanelOpen && this.state.panelHandle ? this.renderFormContent() : ""}</Col>


        </Row>

      </>
    );
  }
}