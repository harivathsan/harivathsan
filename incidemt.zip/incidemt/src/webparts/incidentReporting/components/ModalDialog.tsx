import * as React from 'react';
import { FontWeights, getTheme, IButtonStyles, IconButton, IIconProps, mergeStyleSets, Modal, PrimaryButton, TextField } from '@fluentui/react';
import { Row, Col } from 'react-bootstrap';
import * as _ from 'lodash';
import { Label } from 'office-ui-fabric-react';
import '../Common/dailog.css';

const theme = getTheme();
const cancelIcon: IIconProps = { iconName: 'Cancel' };
const iconButtonStyles: Partial<IButtonStyles> = {
    root: {
        color: theme.palette.neutralPrimary,
        marginLeft: 'auto',
        marginTop: '4px',
        marginRight: '2px'
    },
    rootHovered: {
        color: theme.palette.neutralDark,
    },
};
const contentStyles = mergeStyleSets({
    container: {
        display: 'flex',
        flexFlow: 'column nowrap',
        alignItems: 'stretch',
        width: "60%"
    },
    header: [
        theme.fonts.xLargePlus,
        {
            flex: '1 1 auto',
            borderTop: `0px solid ${theme.palette.themePrimary}`,
            color: theme.palette.neutralPrimary,
            display: 'flex',
            alignItems: 'center',
            fontWeight: FontWeights.semibold,
            padding: '12px 12px 14px 24px',
            background: 'lightgray',
            fontSize: '16px'
        },
    ],
    body: {
        flex: '4 4 auto',
        padding: '0 24px 24px 24px',
        overflowY: 'hidden',
        selectors: {
            p: { margin: '14px 0' },
            'p:first-child': { marginTop: 0 },
            'p:last-child': { marginBottom: 0 },
        },
    },
});
export default class ModalDialog extends React.Component<any, any> {
    constructor(props: any) {
        super(props)

        this.state = {
            isModalOpen: true,
            data: []
        }
    }
    private hideModal = () => {
        this.setState({ isModalOpen: false });
    }
    componentDidMount(): void {
        let finalData: any = [];
        let existingData: any = this.props.additionalInfo != "" && typeof this.props.additionalInfo == "string" ? JSON.parse(this.props.additionalInfo) : this.props.additionalInfo;
        this.props.types.forEach((type: string) => {
            finalData.push({
                "type": type,
                "questions": _.filter(this.props.incidentQuestions, function (oldFile) {
                    delete oldFile['odata.editLink'];
                    delete oldFile['odata.etag'];
                    delete oldFile['odata.id'];
                    delete oldFile['odata.type'];
                    if (oldFile.IncidentType.toLocaleLowerCase() == type.toLocaleLowerCase()) {
                        let item: any = _.find(existingData, { 'type': type });
                        if (item) {
                            let itemAnswer: any = _.find(item ? item.questions : [], { 'Id': oldFile.Id });
                            oldFile["answer"] = itemAnswer.answer;
                        } else {
                            oldFile["answer"] = "";
                        }
                    }
                    return oldFile.IncidentType.toLocaleLowerCase() == type.toLocaleLowerCase();
                })
            });
        });
        this.setState({ data: finalData })
    }
    private saveData = () => {
        this.props.closeModalLayout(this.state.data);
        this.hideModal();
    }
    render() {
        return (
            <Modal
                titleAriaId="Title"
                isOpen={this.state.isModalOpen}
                onDismiss={this.hideModal}
                isBlocking={true}
                isModeless={false}
                containerClassName={contentStyles.container}
            >
                <div className={contentStyles.header}>
                    <span id={"title"} dangerouslySetInnerHTML={{ __html: this.props.selectedTab }}></span>
                    <PrimaryButton onClick={() => this.saveData()}>
                        Save
                    </PrimaryButton>
                    <IconButton
                        styles={iconButtonStyles}
                        iconProps={cancelIcon}
                        ariaLabel="Close popup modal"
                        onClick={this.hideModal}
                    />
                </div>
                <div className={contentStyles.body}>
                    {
                        this.state.data.map((item: any) => ((
                            <React.Fragment><Row><Label>{item.type}</Label></Row>
                                <Row>
                                    {
                                        item.questions.map((item: any) => ((
                                            <React.Fragment>
                                                <Col md={6}>
                                                    {item.Question}
                                                </Col>
                                                <Col md={6} style={{ marginTop: '5px' }}>
                                                    <TextField defaultValue={item.answer} onChange={(e: any) => { item["answer"] = e.target.value }}
                                                        disabled={this.props.formMode !== 'View' ? false : true} />
                                                </Col>
                                            </React.Fragment>
                                        )))
                                    }
                                </Row>
                            </React.Fragment>
                        )))
                    }
                </div>
            </Modal>
        )
    }
}