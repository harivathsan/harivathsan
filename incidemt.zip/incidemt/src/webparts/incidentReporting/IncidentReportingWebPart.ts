import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'IncidentReportingWebPartStrings';
import IncidentReporting from './components/IncidentReporting';
import { IIncidentReportingProps } from './components/IIncidentReportingProps';
import './Common/common.css';
import { SPFx, spfi } from '@pnp/sp';
export interface IIncidentReportingWebPartProps {
  description: string;
  allItemsPageURL: string;
  bseeDistrictAreasURL: string;
  bseeNtlNo: string;

}
export default class IncidentReportingWebPart extends BaseClientSideWebPart<IIncidentReportingWebPartProps> {
  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private incidentQuestions: any;
  private bseeContacts: any;
  public render(): void {
    const element: React.ReactElement<IIncidentReportingProps> = React.createElement(
      IncidentReporting,
      {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userEmail: this.context.pageContext.user.email,
        context: this.context,
        webURL: this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        allItemsPageURL: this.properties.allItemsPageURL,
        incidentQuestions: this.incidentQuestions,
        bseeContacts: this.bseeContacts,
        bseeDistrictAreasURL: this.properties.bseeDistrictAreasURL,
        bseeNtlNo:this.properties.bseeNtlNo
      }
    );
    ReactDom.render(element, this.domElement);
  }

  protected async onInit(): Promise<void> {
    let _sp = spfi().using(SPFx(this.context))
    this.incidentQuestions = await _sp.web.lists.getByTitle("IncidentAdditionalInformation").items.select("ID,Question,IncidentType").top(5000)();
    this.bseeContacts = await _sp.web.lists.getByTitle("BSEEContacts").items.select("ID,Title,District").top(5000).orderBy("Title", true)();
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              throw new Error('Unknown host');
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('allItemsPageURL', {
                  label: strings.AllItemsURLFieldLable
                }),
                PropertyPaneTextField('bseeDistrictAreasURL', {
                  label: strings.BSEEDistrictAreasURLFieldLabel
                }),
                PropertyPaneTextField('bseeNtlNo', {
                  label: strings.BSEENTLNoFieldLabel
                }),
              ]
            }
          ]
        }
      ]
    };
  }
}
