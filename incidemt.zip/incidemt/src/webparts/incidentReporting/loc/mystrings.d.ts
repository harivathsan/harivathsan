declare interface IIncidentReportingWebPartStrings {
  AllItemsURLFieldLable: string | undefined;
  BSEEDistrictAreasURLFieldLabel: string | undefined;
  BSEENTLNoFieldLabel: string | undefined;
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
}

declare module 'IncidentReportingWebPartStrings' {
  const strings: IIncidentReportingWebPartStrings;
  export = strings;
}

declare module 'moment';
declare module 'sweetalert2-react';