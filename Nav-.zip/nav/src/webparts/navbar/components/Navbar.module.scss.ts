/* tslint:disable */
require("./Navbar.module.css");
const styles = {
  navbar: 'navbar_1436dc85',
  teams: 'teams_1436dc85',
  inlineoptions: 'inlineoptions_1436dc85',
  options: 'options_1436dc85',
  welcome: 'welcome_1436dc85',
  welcomeImage: 'welcomeImage_1436dc85',
  links: 'links_1436dc85'
};

export default styles;
/* tslint:enable */