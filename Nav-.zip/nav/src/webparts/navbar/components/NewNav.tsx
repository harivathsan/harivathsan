import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'
import { escape } from '@microsoft/sp-lodash-subset';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';
import NavbarCollapse from 'react-bootstrap/NavbarCollapse'
import { SPComponentLoader } from '@microsoft/sp-loader';
import { Dropdown } from 'react-bootstrap';
import styles from './Navbar.module.scss';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import * as _ from 'lodash';



export default class NewNavbars extends React.Component<any, any> {
  constructor(props: any) {
  super(props);
  let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }

  this.state = {
    NavItems:[],
    NavItemss:[]
  };
}
public async getNewsList() {
  debugger;
  try {
      let endpointUrl = this.props.webURL.concat(`/_api/web/Lists/GetByTitle('Navigation List')/items?$orderby=MenuOrder,SubMenuOrder,SubSubMenuOrder`);
      const listItems = await this.props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1)
          .then(async (response: SPHttpClientResponse) => {
              if (await response.ok) {
                  response.json().then(async (res) => {
                    listItems
                      let arr: any = [];
                      let SubMenu:any = [];
                      let submenuss:any=[];
                      let SubSubMenu1:any =[];
                      let a = this.groupByVal(res.value, 'Menu');
                      let b = this.groupByVal(res.value, 'SubMenu');
                      a.map((item: any, index: number) => {
                          arr.push({
                            Menu: item[0].Menu,
                            
                              SubMenu:item[0].SubMenu,
                              SubSubMenu:item[0].SubSubMenu
                              
                          });
                          b.map((item: any, index: number) => {
                            
                            SubMenu.push({
                              Menu: item[0].Menu,
                              
                                SubMenu:item[0].SubMenu,
                                SubSubMenu:item[0].SubSubMenu
                                
                            });
                            item.map((itemSub: any, subIndex: number) => {
                              return(
                                SubMenu[index].length>0 && SubMenu.map((itemSub_1: any, indexNew: number) => {
                                if (itemSub_1.SubMenu !== null) {
                                  if (itemSub_1.SubMenu == itemSub.SubMenu) {
                                    
                                    submenuss.push({
                                      Menu:itemSub_1.Menu,
                                      SubMenu: itemSub_1.SubMenu,
                                      SubSubMenu: itemSub_1.SubSubMenu,
                                      SubSubMenu1:itemSub.SubSubMenu
                                    })

                                  }
                                }
                                
                              }));

                            });
                            
                          });

                        this.setState({
                          NavItems: arr,
                          NavItem: SubMenu,
                          NavItemss: SubSubMenu1


                        });

                      });
                  });
            }
          });
    }
    catch (e) {
      console.log("Error in getCarouselData", e);
    }
  }
componentDidMount(): void {
//var SITE_TITLE: string = this.props.description;
debugger;
this.getNewsList();

}
private groupByVal(list:any, property:any) {
    var i = 0, val, index,
        values = [], result = [];
    for (; i < list.length; i++) {
        val = list[i][property];
        index = values.indexOf(val);
        if (index > -1)
            result[index].push(list[i]);
        else {
            values.push(val);
            result.push([list[i]]);
        }
    }
    return result;
}

  public render(): React.ReactElement<any> {
    return (
      <>

       <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
       <Container>
        <Navbar.Brand href="https://eu023-sp.shell.com/sites/SPOAA1198/GOM/SitePages/NavBar.aspx">HOME</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <NavbarCollapse id="responsive-navbar-nav" role={undefined}>
                        <Nav className="me-auto">
                            {this.state.NavItems.map((item: any, key: any) => {
                                return (
                                    <>
                                        {(item.Menu.length>0 && item.SubMenu != null)?
                                        <NavDropdown title={item.Menu} id="collapsible-nav-dropdown">
                                        {(item.SubMenu != null && item.SubSubMenu != null) ?
                                        <>
                                         <NavDropdown
                                                key={'end'}
                                                id={`dropdown-button-drop-${'end'}`}
                                                drop={'end'}
                                                title={item.SubMenu}
                                                className={styles.inlineoptions}
                                            >
                                                {(item.SubSubMenu != null?
                                                <><Dropdown.Item eventKey="1">{item.SubSubMenu}</Dropdown.Item>
                                                </>
                                                :"")}
                                                
                                            </NavDropdown>
                                         </>
                                            :<NavDropdown.Item target={"_blank"} >{item.SubMenu}</NavDropdown.Item>}
                                           
                                           

                                          

                                        </NavDropdown>
                            :<Nav.Link target={"_blank"}>{item.Menu}</Nav.Link>}
                                    </>
                                );
                            })}

           
            {/* <Nav.Link target={"_blank"} href="https://copilot.microsoft.com/">Copilot</Nav.Link> */}


          </Nav>
          
        </NavbarCollapse>
      </Container>
    </Navbar>                                                                                                          

</>
    );
  }
}
