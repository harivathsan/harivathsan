import * as React from 'react';
import type { INavbarProps } from './INavbarProps';
import 'bootstrap/dist/css/bootstrap.min.css'
import { escape } from '@microsoft/sp-lodash-subset';
import { SPComponentLoader } from '@microsoft/sp-loader';
import NewNavbars from './NewNav';



export default class Navbars extends React.Component<any, any> {
  constructor(props: any) {
  super(props);
  let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }

  this.state = {
  };
}


  public render(): React.ReactElement<INavbarProps> {
    return (
      <>

{/* <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
       <Container>
        <Navbar.Brand href="https://eu023-sp.shell.com/sites/SPOAA1198/GOM/SitePages/NavBar.aspx">HOME</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <NavbarCollapse id="responsive-navbar-nav" role={undefined}>
          <Nav className="me-auto">
            <NavDropdown title="Nav 1" id="collapsible-nav-dropdown">
            <NavDropdown              
              key={'end'}
              id={`dropdown-button-drop-${'end'}`}
              drop={'end'}
              title={`Drop`}
              className={styles.inlineoptions}
            >
              <Dropdown.Item eventKey="1">Action</Dropdown.Item>
              <Dropdown.Item eventKey="2">Another action</Dropdown.Item>
              <Dropdown.Item eventKey="3">Something else here</Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item eventKey="4">Separated link</Dropdown.Item>
            </NavDropdown>
            <Dropdown.Divider />
            <NavDropdown
              
              key={'end'}
              id={`dropdown-button-drop-${'end'}`}
              drop={'end'}
              title={`Drop`}
              className={styles.inlineoptions}
            >
              <Dropdown.Item eventKey="1">Action</Dropdown.Item>
              <Dropdown.Item eventKey="2">Another action</Dropdown.Item>
              <Dropdown.Item eventKey="3">Something else here</Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item eventKey="4">Separated link</Dropdown.Item>
            </NavDropdown>
            <Dropdown.Divider />

              <NavDropdown.Item target={"_blank"} href="https://www.google.com/" className={styles.options}>Google</NavDropdown.Item>
                
              <NavDropdown.Divider />
              <NavDropdown.Item target={"_blank"} href="https://www.yahoo.com/" className={styles.options}> Yahoo</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item target={"_blank"} href="https://www.bing.com/" className={styles.options}>Bing</NavDropdown.Item>
              
            </NavDropdown>
            <NavDropdown title="Nav 2" id="collapsible-nav-dropdown">
              <NavDropdown.Item target={"_blank"}href="www.outlook.com login">Outlook</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item target={"_blank"} href="www.teams.microsoft.com login">Teams</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item target={"_blank"} href="www.ondrive.com login">Onedrive</NavDropdown.Item>
              
            </NavDropdown>
            <NavDropdown title="Nav 3" id="collapsible-nav-dropdown">
              <NavDropdown.Item target={"_blank"}  href="https://www.youtube.com/">Youtube</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item target={"_blank"} href="https://www.yammer.com/">Yammer</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item target={"_blank"} href="https://www.linkedin.com/">Linkedin</NavDropdown.Item>
              
            </NavDropdown>
            <Nav.Link target={"_blank"} href="https://copilot.microsoft.com/">Copilot</Nav.Link>


          </Nav> */}
          {/* <Nav>
            <Nav.Link href="#deets">More deets</Nav.Link>
            <Nav.Link eventKey={2} href="#memes">
              Dank memes
            </Nav.Link>
          </Nav> */}
        {/* </NavbarCollapse>
      </Container>
    </Navbar>                                                                                                           */}
       <NewNavbars {...this.state} {...this.props}></NewNavbars>
</>
    );
  }
}
