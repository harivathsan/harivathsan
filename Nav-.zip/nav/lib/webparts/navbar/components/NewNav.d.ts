import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
export default class NewNavbars extends React.Component<any, any> {
    constructor(props: any);
    getNewsList(): Promise<void>;
    componentDidMount(): void;
    private groupByVal;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=NewNav.d.ts.map