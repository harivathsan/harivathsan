declare const styles: {
    navbar: string;
    teams: string;
    inlineoptions: string;
    options: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Navbar.module.scss.d.ts.map