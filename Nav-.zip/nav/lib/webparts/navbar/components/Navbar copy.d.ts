import * as React from 'react';
import type { INavbarProps } from './INavbarProps';
import 'bootstrap/dist/css/bootstrap.min.css';
export default class Navbars extends React.Component<any, any> {
    constructor(props: any);
    render(): React.ReactElement<INavbarProps>;
}
//# sourceMappingURL=Navbar%20copy.d.ts.map