declare interface ISpfxbootstrapWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpfxbootstrapWebPartStrings' {
  const strings: ISpfxbootstrapWebPartStrings;
  export = strings;
}
