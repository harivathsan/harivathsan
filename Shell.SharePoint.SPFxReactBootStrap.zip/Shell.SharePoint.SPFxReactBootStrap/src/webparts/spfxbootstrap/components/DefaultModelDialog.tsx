import * as React from 'react';
import styles from './Spfxbootstrap.module.scss';
import * as $ from 'jquery';
import 'bootstrap/dist/css/bootstrap.css';
import * as bootstrap from 'bootstrap';
import Modal from './Modal';



const DefaultModelDialog=()=>{ 
        return (
            <div className={styles.spfxbootstrap}>
                <div className="modal fade in" id="myModal" role="dialog"  >
                    <div className="modal-dialog modal-sm">
                        <div className="modal-content">
                            <div className="modal-header">
                                <button type="button" className="close" data-dismiss="modal">&times;</button>
                                <h4 className="modal-title">Modal Header</h4>
                            </div>
                            <div className="modal-body">
                                <p>This is a small modal.</p>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        );//End return
    
};

export default DefaultModelDialog;