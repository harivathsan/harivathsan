import * as React from 'react';
import styles from './Spfxbootstrap.module.scss';
import { ISpfxbootstrapProps } from './ISpfxbootstrapProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as $ from 'jquery';
import 'bootstrap/dist/css/bootstrap.css';
import * as bootstrap from 'bootstrap';
import Modal, { ModalHeader, ModalBody, ModalFooter } from './Modal';
import { IState } from './IState';
import DefaultDialog from './DefaultModelDialog';

export default class Spfxbootstrap extends React.Component<ISpfxbootstrapProps, {}> {

  public state = {
    modal: false
  };

  constructor(props) {
    super(props);
    this.state = {
      modal: false
    };
    this.toggle = this.toggle.bind(this);
  }

  private toggle(): void {
    this.setState({ modal: !this.state.modal });
  }

  public render(): React.ReactElement<ISpfxbootstrapProps> {
    console.log("render");
    
    return (
      <div className={styles.spfxbootstrap}>
        <div className="container">
          <h3>Grid</h3>
          <p>This example demonstrates a 50%/50% split on small, medium and large devices. On extra small devices, it will stack (100% width).</p>
          <p>Resize the browser window to see the effect.</p>
          <div className="row" >
            <div className="col-sm-6" >
              <div className="columnOne">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
              </div>
            </div>
            <div className="col-sm-6">
              <div className="columnTwo">
                Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto.
              </div>
            </div>
          </div>
          <h3>Alert</h3>
          <div className="alert alert-success">
            <strong>Success!</strong> This alert box could indicate a successful or positive action.
         </div>
          <h3>Button States</h3>
          <button type="button" className="btn btn-primary">Primary Button</button>
          <button type="button" className="btn btn-primary active">Active Primary</button>
          <button type="button" className="btn btn-primary disabled">Disabled Primary</button>
        </div>
        {/*   End container */}

        {/* Begin Modal Container */}
        {/* <div className="container">
          <h2>Small Modal</h2>
          <button type="button" className="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"  id="btnModel" onClick={this._displayModelDialog.bind(this)} >Open Small Modal</button>
          <div className="modal fade" id="myModal" role="dialog"  >
            <div className="modal-dialog modal-sm">
              <div className="modal-content">
                <div className="modal-header">
                  <button type="button" className="close" data-dismiss="modal">&times;</button>
                  <h4 className="modal-title">Modal Header</h4>
                </div>
                <div className="modal-body">
                  <p>This is a small modal.</p>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </div> */}

        <div className="container">
          <h3>Bootstrap Components Modal Dialog</h3>

          <button
            type="button"
            className="btn btn-secondary"
            onClick={this.toggle}
          >
            Open Small Modal
        </button>
          <Modal isOpen={this.state.modal}>
            <ModalHeader>
              <h3>This is modal header</h3>
              <button
                type="button"
                className="close"
                aria-label="Close"
                onClick={this.toggle}
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </ModalHeader>
            <ModalBody>
              <p>This is modal body</p>
            </ModalBody>
            <ModalFooter>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={this.toggle}
              >
                Close
            </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={this.toggle}
              >
                Save changes
            </button>
            </ModalFooter>
          </Modal>
        </div>
        {/* End Modal Container */}       
        <div className="container">
          <div className="row" >
            <div className="col-xs-12 col-sm-10 col-md-10 col-lg-10">
              <div>
                 <iframe src="https://eu023-sp.shell.com/sites/SPOAA0342/nert/Shared%20Documents/Yammer.aspx" width="100%" height="453" scrolling="no" className="frame"></iframe>
              </div>
            </div>
            <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2">
              <div>
                <b>Quick Link container</b>
              </div>
            </div>
          </div>
        </div>
      </div>
    );//End return 
    
    
  }//End render
 
  private _displayModelDialog(): void {
    console.log("Method");
    //debugger;
    //$(DefaultDialog).modal('show');
    ///$("#myModal").modal('show');

    //$("#myModal").modal('show');
  
  }


}//End class
