import * as React from 'react';
import { IProp } from './IProp';
import { IState } from './IState';

export const ModalHeader = props => {
    return <div className="modal-header">{props.children}</div>;
  };
  
  export const ModalBody = props => {
    return <div className="modal-body">{props.children}</div>;
  };
  
  export const ModalFooter = props => {
    return <div className="modal-footer">{props.children}</div>;
  };
  
  export default class Modal extends React.Component<IProp, IState>{
    constructor(props) {
      super(props);
      this.state = {
        modalShow: '',
        display: 'none'
      };
      this.openModal = this.openModal.bind(this);
      this.closeModal = this.closeModal.bind(this);
    }
  
   private openModal():void {
      this.setState({
        modalShow: 'show',
        display: 'block'
      });
    }
  
    private closeModal():void {
      this.setState({
        modalShow: '',
        display: 'none'
      });
    }
  
   public componentDidMount() {
      this.props.isOpen ? this.openModal() : this.closeModal();
    }
  
    public componentDidUpdate(prevProps) {
      if (prevProps.isOpen !== this.props.isOpen) {
        this.props.isOpen ? this.openModal() : this.closeModal();
      }
    }
  
    public render(): React.ReactElement<IState> {
      return (
        <div
          className={'modal fade ' + this.state.modalShow}
          role="dialog"
          aria-hidden="true"
          style={{ display: this.state.display }}
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">{this.props.children}</div>
          </div>
        </div>
      );
    }
  }
  
 