export interface IState{
    modalShow: string;
    display: string;
}