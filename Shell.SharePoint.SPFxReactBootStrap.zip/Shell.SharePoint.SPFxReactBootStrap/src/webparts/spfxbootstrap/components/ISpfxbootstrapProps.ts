export interface ISpfxbootstrapProps {
  description: string;
  
}
