export interface IProp{
    isOpen: boolean;
    
}