import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from '@microsoft/sp-http';
import { masterDataActionTypes, formAction } from '../constants/actionType';
import { StringFormat, removeSpecialChars, connectArray, isEmptyOrUndefine } from '../utils/commonUtils';
import { ToastContainer, toast } from 'react-toastify';
import { masterData, WHC_API_Path } from '../constants/apiConfig';
//import * as pnp from "@pnp/sp";
//import * as pnp from "sp-pnp-js"
// import "@pnp/sp/webs";
// import "@pnp/sp/folders";


const actions = {
    AddNewDetails: (payload) => ({
        type: formAction.ADD_NEW_WHC_DETAILS,
        data: payload
    }),
    FetchSelectedRowDataResults: (payload) => ({
        type: formAction.FETCH_SELECTED_ITEM_ROWDATA,
        data: payload
    }),
    UpdateSelectedRowData: (payload) => ({
        type: formAction.UPDATE_SELECTED_ROWDATA,
        data: payload
    }),
    FetchUserGroupInfo: (payload) => ({
        type: formAction.FETCH_GROUP_NAME,
        data: payload
    }),
    PoListAddNewDetails: (payload) => ({
        type: formAction.POLIST_ADD_NEW,
        data: payload
    }),
    PoListUpdateSelectedRowData: (payload) => ({
        type: formAction.POLIST_UPDATE_DATA,
        data: payload
    }),
    PoListFetchSelectedRowDataResults: (payload) => ({
        type: formAction.POLIST_FETCH_LIST,
        data: payload
    }),
    FileUpload: (payload) => ({
        type: formAction.FILE_UPLOAD,
        data: payload
    }),
    CreateFolder: (payload) => ({
        type: formAction.CREATE_FOLDER,
        data: payload
    }),
    GetListItemAll: (payload) => ({
        type: formAction.GET_LIST_ALL_ITEM,
        data: payload
    }),
    GetuploadedList: (payload) => ({
        type: formAction.GET_UPLOADED_FILE_LIST,
        data: payload
    }),
    ClearuploadedMOAList: () => ({
        type: formAction.CLEAR_MOA_UPLOADED_FILE_LIST,
        data: []
    }),
    ClearuploadedSupplierList: () => ({
        type: formAction.CLEAR_SUPPLIER_UPLOADED_FILE_LIST,
        data: []
    }),
    ClearuploadedOtherList: () => ({
        type: formAction.CLEAR_OTHER_UPLOADED_FILE_LIST,
        data: []
    }),
    GetuploadedMOAList: (payload) => ({
        type: formAction.GET_MOA_UPLOADED_FILE_LIST,
        data: payload
    }),
    GetuploadedSupplierList: (payload) => ({
        type: formAction.GET_SUPPLIER_UPLOADED_FILE_LIST,
        data: payload
    }),
    GetuploadedOtherList: (payload) => ({
        type: formAction.GET_OTHER_UPLOADED_FILE_LIST,
        data: payload
    }),
    FileAttachmentsClear: () => ({
        type: formAction.FILE_CLEAR,
        data: []
    }),
    FetchSelectedAlterationRowListItems: (payload) => ({
        type: formAction.AlTERATIONITEM,
        data: payload
    }),
    FetchSelectedAlterationRowListItems_Id: (payload) => ({
        type: formAction.AlTERATIONITEM_ID,
        data: payload
    })

}




export const getFileBuffer = (uploadedFiles) => {

    let promised = new Promise((resolve, reject) => {
        let reader = new FileReader();
        reader.onload = (e) => {
            resolve(e.target.result);
        };
        reader.onerror = (e) => {
            reject(e.target.error);
        };
        //reader.readAsArrayBuffer(uploadedFiles[0]);
        reader.readAsArrayBuffer(uploadedFiles);
    });

    return promised;
}
export const FileAttachments = (uploadedFile: any, id: any,) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;
    let ItemId = StringFormat(WHC_API_Path.getEditDeatails, id);
    const url = baseURL + WHC_API_Path.apiListName + "('" + postURL + "')" + ItemId + "/AttachmentFiles/add(FileName='" + uploadedFile.name + "')";
    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=verbose',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': ''
        },
        body: uploadedFile
    }).then((result) => {
        console.log(result);

    });
    return Promise.resolve<any>(itemResults);
};


export const AddNewDetails = (data: any, Status: any, Attachment: any) => async (dispatch, getstate) => {

    //dispatch(actions.AddDNRFDetails(data));

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;
    const url = baseURL + WHC_API_Path.apiListName + "('" + postURL + "')" + WHC_API_Path.items;

    //const url = baseURL;
    //let web = new Web(baseURL);

    const postJosnData: string = JSON.stringify({
        __metadata: { type: 'SP.Data.PurchaseOrderListItem' },
        SerialNumber: data.SerialNumber,
        Date: new Date(data.Date),
        submittedDate: Status == 'Open' ? new Date() : null,
        RequestorId: data.RequestorId != "" ? data.RequestorId : null,
        RequestorName: data.RequestorName != "" ? data.RequestorName : '',
        VendorName: data.VendorName,
        PODescription: data.PODescription,
        MOAApproverId: data.MOAApproverId != "" ? data.MOAApproverId : null,
        InvoiceApproverId: data.InvoiceApproverId != "" ? data.InvoiceApproverId : null,
        ProjectType: data.ProjectType,
        CPBuyerId: data.CPBuyerId != "" ? data.CPBuyerId : null,
        EstimatedCommitment: data.EstimatedCommitment,
        VendorOutlineAgreementNumber: data.VendorOutlineAgreementNumber,
        ProjectServicesName: data.ProjectServicesName,
        ProjectName: data.ProjectName,
        VendorContractNumber: data.VendorContractNumber,

        VendorContactName: data.VendorContactName,
        VendorContactPhoneNumber: data.VendorContactPhoneNumber,
        VendorContactEmailAddress: data.VendorContactEmailAddress,
        VendorSAP: data.VendorSAP,
        OffshoreServices: data.OffshoreServices,
        CommentaryInstructions: data.CommentaryInstructions,
        Status: Status,
        ApplicationUserEmailID: data.ApplicationUserEmailID,
        AlterationNo: 0,
        MOAAttachment: data.MOAAttachment,
        SupplierAttachment: data.SupplierAttachment,
        OtherAttachment: data.OtherAttachment



    });
    let final: any;

    await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=verbose',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': ''
        },
        body: postJosnData
    }).then(async (response: SPHttpClientResponse) => {
        if (response.ok) {
            final = await response.json().then(async (res): Promise<void> => {
                if (res != null) {

                    return res
                } else {
                    toast.error('Records failed');
                    console.log('Records failed');
                    return res

                }
            })
        }
    });
    return Promise.resolve<any>(final);


};

export const UpdateSelectedRowData = (data: any, id: any, Status: any, stateData) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;
    let ItemId = StringFormat(WHC_API_Path.getEditDeatails, id);
    const url = baseURL + WHC_API_Path.apiListName + "('" + postURL + "')" + ItemId;
    let body: any = {};

    if (Status === 'Draft') {
        body = JSON.stringify({
            __metadata: { type: 'SP.Data.PurchaseOrderListItem' },
            SerialNumber: data.SerialNumber,
            RequestorId: data.RequestorId != "" ? data.RequestorId : null,
            RequestorName: data.RequestorName != "" ? data.RequestorName : null,
            VendorName: data.VendorName,
            PODescription: data.PODescription,
            MOAApproverId: data.MOAApproverId != "" ? data.MOAApproverId : null,
            InvoiceApproverId: data.InvoiceApproverId != "" ? data.InvoiceApproverId : null,
            ProjectType: data.ProjectType,
            CPBuyerId: data.CPBuyerId != "" ? data.CPBuyerId : null,
            EstimatedCommitment: data.EstimatedCommitment,
            VendorOutlineAgreementNumber: data.VendorOutlineAgreementNumber,
            ProjectServicesName: data.ProjectServicesName,
            ProjectName: data.ProjectName,
            VendorContractNumber: data.VendorContractNumber,

            VendorContactName: data.VendorContactName,
            VendorContactPhoneNumber: data.VendorContactPhoneNumber,
            VendorContactEmailAddress: data.VendorContactEmailAddress,
            VendorSAP: data.VendorSAP,
            OffshoreServices: data.OffshoreServices,
            CommentaryInstructions: data.CommentaryInstructions,
            Status: Status,
            ApplicationUserEmailID: data.ApplicationUserEmailID,
            MOAAttachment: data.MOAAttachment,
            SupplierAttachment: data.SupplierAttachment,
            OtherAttachment: data.OtherAttachment


        });
    } else if (Status === 'Open') {
        body = JSON.stringify({
            __metadata: { type: 'SP.Data.PurchaseOrderListItem' },
            SerialNumber: data.SerialNumber,
            RequestorId: data.RequestorId != "" ? data.RequestorId : null,
            RequestorName: data.RequestorName != "" ? data.RequestorName : null,
            VendorName: data.VendorName,
            PODescription: data.PODescription,
            MOAApproverId: data.MOAApproverId != "" ? data.MOAApproverId : null,
            InvoiceApproverId: data.InvoiceApproverId != "" ? data.InvoiceApproverId : null,
            ProjectType: data.ProjectType,
            CPBuyerId: data.CPBuyerId != "" ? data.CPBuyerId : null,
            EstimatedCommitment: data.EstimatedCommitment,
            VendorOutlineAgreementNumber: data.VendorOutlineAgreementNumber,
            ProjectServicesName: data.ProjectServicesName,
            ProjectName: data.ProjectName,
            VendorContractNumber: data.VendorContractNumber,
            VendorContactName: data.VendorContactName,
            VendorContactPhoneNumber: data.VendorContactPhoneNumber,
            VendorContactEmailAddress: data.VendorContactEmailAddress,
            VendorSAP: data.VendorSAP,
            OffshoreServices: data.OffshoreServices,
            CommentaryInstructions: data.CommentaryInstructions,
            Status: Status,
            ApplicationUserEmailID: data.ApplicationUserEmailID,
            submittedDate: new Date(),
            AlterationNo: parseInt(data.AlterationNo),
            MOAAttachment: data.MOAAttachment,
            SupplierAttachment: data.SupplierAttachment,
            OtherAttachment: data.OtherAttachment


        });
    } else if (Status === 'Close') {
        body = JSON.stringify({
            __metadata: { type: 'SP.Data.PurchaseOrderListItem' },
            SerialNumber: data.SerialNumber,
            RequestorId: data.RequestorId != "" ? data.RequestorId : null,
            RequestorName: data.RequestorName != "" ? data.RequestorName : null,
            VendorName: data.VendorName,
            PODescription: data.PODescription,
            MOAApproverId: data.MOAApproverId != "" ? data.MOAApproverId : null,
            InvoiceApproverId: data.InvoiceApproverId != "" ? data.InvoiceApproverId : null,
            ProjectType: data.ProjectType,
            CPBuyerId: data.CPBuyerId != "" ? data.CPBuyerId : null,
            EstimatedCommitment: data.EstimatedCommitment,
            VendorOutlineAgreementNumber: data.VendorOutlineAgreementNumber,
            ProjectServicesName: data.ProjectServicesName,
            ProjectName: data.ProjectName,
            VendorContractNumber: data.VendorContractNumber,
            VendorContactName: data.VendorContactName,
            VendorContactPhoneNumber: data.VendorContactPhoneNumber,
            VendorContactEmailAddress: data.VendorContactEmailAddress,
            VendorSAP: data.VendorSAP,
            OffshoreServices: data.OffshoreServices,
            CommentaryInstructions: data.CommentaryInstructions,
            Status: Status,
            ApplicationUserEmailID: data.ApplicationUserEmailID,
            DateClosed: new Date(),
            RequisitionNo: stateData.RequisitionNo,
            PurchaseOrderNo: data.PurchaseOrderNo,

        })
    } else if (Status === 'Rejected') {

        body = JSON.stringify({
            __metadata: { type: 'SP.Data.PurchaseOrderListItem' },
            SerialNumber: data.SerialNumber,
            RequestorId: data.RequestorId != "" ? data.RequestorId : null,
            RequestorName: data.RequestorName != "" ? data.RequestorName : null,
            VendorName: data.VendorName,
            PODescription: data.PODescription,
            MOAApproverId: data.MOAApproverId != "" ? data.MOAApproverId : null,
            InvoiceApproverId: data.InvoiceApproverId != "" ? data.InvoiceApproverId : null,
            ProjectType: data.ProjectType,
            CPBuyerId: data.CPBuyerId != "" ? data.CPBuyerId : null,
            EstimatedCommitment: data.EstimatedCommitment,
            VendorOutlineAgreementNumber: data.VendorOutlineAgreementNumber,
            ProjectServicesName: data.ProjectServicesName,
            ProjectName: data.ProjectName,
            VendorContractNumber: data.VendorContractNumber,
            VendorContactName: data.VendorContactName,
            VendorContactPhoneNumber: data.VendorContactPhoneNumber,
            VendorContactEmailAddress: data.VendorContactEmailAddress,
            VendorSAP: data.VendorSAP,
            OffshoreServices: data.OffshoreServices,
            CommentaryInstructions: data.CommentaryInstructions,
            Status: Status,
            ApplicationUserEmailID: data.ApplicationUserEmailID,
            AlterationNo: parseInt(data.AlterationNo),
            isReject: data.isReject,
            RejectReasons: data.RejectReasons,
            RejectComments: data.RejectComments,
            RequisitionNo: stateData.RequisitionNo,
            PurchaseOrderNo: data.PurchaseOrderNo,
        })

    }

    console.log("submitItem: " + url);

    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': '',
            'IF-MATCH': '*',
            'X-Http-Method': 'PATCH'
        },
        body: body
    }).then(async (response: SPHttpClientResponse) => {
        if (response.ok) {

            stateData.NewItemsInChildList.length > 0 && stateData.NewItemsInChildList.map(async (Newitem, rowIndex) => {
                await dispatch(PoListAddNewDetails(Newitem));

            })
            stateData.EditItemsInChildList.length > 0 && stateData.EditItemsInChildList.map(async (Edititem, rowIndex) => {
                if (Edititem.Id != undefined) {
                    await dispatch(PoListUpdateSelectedRowData(Edititem));
                }
            })

            stateData.ChildListRemovedItem.length > 0 && stateData.ChildListRemovedItem.map(async (Deleteitem, rowIndex) => {
                if (Deleteitem.Id != undefined) {
                    await dispatch(PoListDeleteSelectedRowData(Deleteitem));
                }
            })

            //toast.success('successfully Updated');
            return response
        } else {
            toast.error('Updated Records failed');
        }
    });
    return Promise.resolve<any>(itemResults);

}

export const AlterationRowListItems = (data: any, id: any, Status: any, stateData) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;
    let ItemId = StringFormat(WHC_API_Path.getEditDeatails, id);
    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Alterations List')" + WHC_API_Path.items;
    let body: any = {};
    let obj: any = "";
    let AlterlistJSON: any = {};


    AlterlistJSON = JSON.stringify({
        SerialNumber: data.SerialNumber,
        Date: new Date(data.Date),
        RequestorEmail: data.RequestorEmail != "" ? data.RequestorEmail : null,
        VendorName: data.VendorName,
        PODescription: data.PODescription,
        MOAApproverEmail: data.MOAApproverEmail != "" ? data.MOAApproverEmail : null,
        InvoiceApproverEmail: data.MOAApproverEmail != "" ? data.MOAApproverEmail : null,
        ProjectType: data.ProjectType,
        CPBuyerEmail: data.CPBuyerEmail != "" ? data.CPBuyerEmail : null,
        EstimatedCommitment: data.EstimatedCommitment,
        VendorOutlineAgreementNumber: data.VendorOutlineAgreementNumber,
        ProjectServicesName: data.ProjectServicesName,
        ProjectName: data.ProjectName,
        VendorContractNumber: data.VendorContractNumber,
        VendorContactName: data.VendorContactName,
        VendorContactPhoneNumber: data.VendorContactPhoneNumber,
        VendorContactEmailAddress: data.VendorContactEmailAddress,
        VendorSAP: data.VendorSAP,
        OffshoreServices: data.OffshoreServices,
        CommentaryInstructions: data.CommentaryInstructions,
        Status: Status,
        ApplicationUserEmailID: data.ApplicationUserEmailID,
        AlterationNo: data.AlterationNo,
        isReject: data.isReject,
        RejectReasons: data.RejectReasons,
        RejectComments: data.RejectComments,
        RequisitionNo: stateData.RequisitionNo,
        PurchaseOrderNo: stateData.PurchaseOrderNo,
        ChildList: stateData.ChildList,
        MOAAttachment: data.MOAAttachment,
        SupplierAttachment: data.SupplierAttachment,
        OtherAttachment: data.OtherAttachment


    })
    if (data.AlterationNo == 0) {
        obj = JSON.stringify({
            __metadata: { type: 'SP.Data.Purchase_x0020_Order_x0020_Alterations_x0020_ListItem' },
            ParentListId: id,
            AlterationNo: data.AlterationNo,
            Title: "Version_V0",
            AlterationsListVersion_0: AlterlistJSON
        })
    }




    console.log("submitItem: " + url);

    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=verbose',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': ''
        },

        body: obj
    }).then(async (response: SPHttpClientResponse) => {
        if (response.ok) {

            //toast.success('Alertation successfully Updated');
            return response
        } else {
            //toast.error('Updated Records failed');
            console.log('Alertation Records failed')
        }
    });
    return Promise.resolve<any>(itemResults);

}

export const AlterationRowUpdateListItems = (data: any, id: any, Status: any, stateData) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;
    let ItemId = StringFormat(WHC_API_Path.editItemParam, id);
    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Alterations List')" + ItemId;
    let body: any = {};
    let obj: any = "";
    let AlterlistJSON: any = {};


    AlterlistJSON = JSON.stringify({
        SerialNumber: data.SerialNumber,
        Date: new Date(data.Date),
        RequestorEmail: data.RequestorEmail != "" ? data.RequestorEmail : null,
        RequestorName: data.RequestorName != "" ? data.RequestorName : null,
        VendorName: data.VendorName,
        PODescription: data.PODescription,
        MOAApproverEmail: data.MOAApproverEmail != "" ? data.MOAApproverEmail : null,
        InvoiceApproverEmail: data.MOAApproverEmail != "" ? data.MOAApproverEmail : null,
        ProjectType: data.ProjectType,
        CPBuyerEmail: data.CPBuyerEmail != "" ? data.CPBuyerEmail : null,
        EstimatedCommitment: data.EstimatedCommitment,
        VendorOutlineAgreementNumber: data.VendorOutlineAgreementNumber,
        ProjectServicesName: data.ProjectServicesName,
        ProjectName: data.ProjectName,
        VendorContractNumber: data.VendorContractNumber,
        VendorContactName: data.VendorContactName,
        VendorContactPhoneNumber: data.VendorContactPhoneNumber,
        VendorContactEmailAddress: data.VendorContactEmailAddress,
        VendorSAP: data.VendorSAP,
        OffshoreServices: data.OffshoreServices,
        CommentaryInstructions: data.CommentaryInstructions,
        Status: Status,
        ApplicationUserEmailID: data.ApplicationUserEmailID,
        AlterationNo: data.AlterationNo,
        isReject: data.isReject,
        RejectReasons: data.RejectReasons,
        RejectComments: data.RejectComments,
        RequisitionNo: data.RequisitionNo,
        PurchaseOrderNo: data.PurchaseOrderNo,
        ChildList: stateData.ChildList,
        MOAAttachment: data.MOAAttachment,
        SupplierAttachment: data.SupplierAttachment,
        OtherAttachment: data.OtherAttachment


    })
    if (data.AlterationNo == 0) {
        obj = JSON.stringify({
            __metadata: { type: 'SP.Data.Purchase_x0020_Order_x0020_Alterations_x0020_ListItem' },
            ParentListId: stateData.currentId,
            AlterationNo: data.AlterationNo,
            Title: "Version_V0",
            AlterationsListVersion_0: AlterlistJSON
        })
    } else if (data.AlterationNo == 1) {
        obj = JSON.stringify({
            __metadata: { type: 'SP.Data.Purchase_x0020_Order_x0020_Alterations_x0020_ListItem' },
            ParentListId: stateData.currentId,
            AlterationNo: data.AlterationNo,
            Title: "Version_V1",
            AlterationsListVersion_1: AlterlistJSON
        })
    } else if (data.AlterationNo == 2) {
        obj = JSON.stringify({
            __metadata: { type: 'SP.Data.Purchase_x0020_Order_x0020_Alterations_x0020_ListItem' },
            ParentListId: stateData.currentId,
            AlterationNo: data.AlterationNo,
            Title: "Version_V2",
            AlterationsListVersion_2: AlterlistJSON
        })
    } else if (data.AlterationNo == 3) {
        obj = JSON.stringify({
            __metadata: { type: 'SP.Data.Purchase_x0020_Order_x0020_Alterations_x0020_ListItem' },
            ParentListId: stateData.currentId,
            AlterationNo: data.AlterationNo,
            Title: "Version_V3",
            AlterationsListVersion_3: AlterlistJSON
        })
    } else if (data.AlterationNo == 4) {
        obj = JSON.stringify({
            __metadata: { type: 'SP.Data.Purchase_x0020_Order_x0020_Alterations_x0020_ListItem' },
            ParentListId: stateData.currentId,
            AlterationNo: data.AlterationNo,
            Title: "Version_V4",
            AlterationsListVersion_4: AlterlistJSON
        })
    }




    console.log("submitItem: " + url);

    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': '',
            'IF-MATCH': '*',
            'X-Http-Method': 'PATCH'
        },

        body: obj
    }).then(async (response: SPHttpClientResponse) => {
        if (response.ok) {


            //toast.success('Alertation Update successfully');
            return response
        } else {
            //toast.error('Updated Records failed');
            console.log('Alertation update fail')
        }
    });
    return Promise.resolve<any>(itemResults);

}


export const FetchSelectedAlterationRowListItems = (ParentID: any, selectedNo: any) => async (dispatch, getstate) => {

    //dispatch(actions.AddDNRFDetails(data));
    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;


    let ItemId = StringFormat(WHC_API_Path.getAlertaionDeatails, ParentID);

    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Alterations List')" + ItemId;
    let getDetailsInfo: any;

    const itemResults = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
            if (response.ok) {

                getDetailsInfo = await response.json().then((response) => {
                    if (response != null) {

                        let obj = {
                            Mainlist: JSON.parse(response.value[0]['AlterationsListVersion_' + selectedNo]),
                            ChildList: JSON.parse(response.value[0]['AlterationsListVersion_' + selectedNo]).ChildList,
                            AlterationRowId: response.value[0].Id
                        }




                        dispatch(actions.FetchSelectedAlterationRowListItems(obj));
                        return response;
                    } else {
                        toast.warning('Respective File Not get');
                    }
                })
            }
        });
    return Promise.resolve<any>(getDetailsInfo);
}

export const FetchSelectedAlterationRowListItems_Id = (ParentID: any, selectedNo: any) => async (dispatch, getstate) => {

    //dispatch(actions.AddDNRFDetails(data));
    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;


    let ItemId = StringFormat(WHC_API_Path.getAlertaionDeatails, ParentID);

    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Alterations List')" + ItemId;
    let getDetailsInfo: any;

    const itemResults = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
            if (response.ok) {

                getDetailsInfo = await response.json().then((response) => {
                    if (response.value.length > 0) {

                        let obj = {
                            AlterationRowId: response.value[0].Id
                        }
                        dispatch(actions.FetchSelectedAlterationRowListItems_Id(obj));
                        return response;
                    } else {
                        toast.warning('Respective File Not get');
                    }
                })
            }
        });
    return Promise.resolve<any>(getDetailsInfo);
}

export const FetchSelectedRowDataResults = (id: any, pageMode: any) => async (dispatch, getstate) => {

    //dispatch(actions.AddDNRFDetails(data));
    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;


    let ItemId = StringFormat(WHC_API_Path.getEditDeatails, id);

    const url = baseURL + WHC_API_Path.apiListName + "('" + postURL + "')" + ItemId;
    let getDetailsInfo: any;
    let detailsArray: any[] = [];

    const itemResults = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
            if (response.ok) {
                getDetailsInfo = await response.json().then((response) => {
                    if (response != null) {

                        const obj = {
                            SerialNumber: response.SerialNumber,
                            Date: new Date(response.Date),


                            // MOAApproverEmail: (response.MOAApprover != undefined) ? response.MOAApprover.EMail : null,
                            // AlterationNumber: response.AlterationNumber,
                            // InvoiceApproverEmail: (response.InvoiceApprover != undefined) ? response.InvoiceApprover.EMail : null,
                            // CPBuyerEmail: (response.CPBuyer != undefined) ? response.CPBuyer.EMail : null,
                            // ProjectServicesFocalPointEmail: (response.ProjectServicesFocalPoint != undefined) ? response.ProjectServicesFocalPoint.EMail : null,
                            // ProjectType: response.ProjectType,
                            // ProjectName: response.ProjectName,
                            // VendorName: response.VendorName,
                            // VendorNumber: response.VendorNumber,
                            // VendorAddress: response.VendorAddress,
                            // OutlineAgreementAndLineNumber: response.OutlineAgreementAndLineNumber,
                            // OffshoreServices: response.OffshoreServices,
                            // VendorContactName: response.VendorContactName,
                            // PhoneNumber: response.PhoneNumber,
                            // FaxNumber: response.FaxNumber,
                            // EmailAddress: response.EmailAddress,
                            // ApplicationUserEmailID: response.ApplicationUserEmailID,
                            // AttachmentFiles: response.AttachmentFiles,
                            // Attachments: response.Attachments
                            RequestorEmail: (response.Requestor != undefined) ? response.Requestor.EMail : null,
                            RequestorName: response.RequestorName != "" ? response.RequestorName : '',
                            VendorName: response.VendorName,
                            PODescription: response.PODescription,
                            MOAApproverEmail: (response.MOAApprover != undefined) ? response.MOAApprover.EMail : null,
                            InvoiceApproverEmail: (response.InvoiceApprover != undefined) ? response.InvoiceApprover.EMail : null,
                            ProjectType: response.ProjectType,
                            CPBuyerEmail: (response.CPBuyer != undefined) ? response.CPBuyer.EMail : null,
                            EstimatedCommitment: response.EstimatedCommitment,
                            VendorOutlineAgreementNumber: response.VendorOutlineAgreementNumber,
                            ProjectServicesName: response.ProjectServicesName,
                            ProjectName: response.ProjectName,
                            VendorContractNumber: response.VendorContractNumber,

                            VendorContactName: response.VendorContactName,
                            VendorContactPhoneNumber: response.VendorContactPhoneNumber,
                            VendorContactEmailAddress: response.VendorContactEmailAddress,
                            VendorSAP: response.VendorSAP,
                            OffshoreServices: response.OffshoreServices,
                            CommentaryInstructions: response.CommentaryInstructions,
                            Status: response.Status,
                            ApplicationUserEmailID: response.ApplicationUserEmailID,
                            // AttachmentFiles: response.AttachmentFiles,
                            // Attachments: response.Attachments,
                            submittedDate: new Date(response.submittedDate),
                            DateClosed: new Date(response.DateClosed),
                            AlterationNo: response.AlterationNo,
                            isReject: response.isReject,
                            RejectReasons: response.RejectReasons,
                            RejectComments: response.RejectComments,
                            RequisitionNo: response.RequisitionNo,
                            PurchaseOrderNo: response.PurchaseOrderNo,
                            MOAAttachment: response.MOAAttachment,
                            SupplierAttachment: response.SupplierAttachment,
                            OtherAttachment: response.OtherAttachment





                        }
                        detailsArray.push(obj)
                        dispatch(actions.FetchSelectedRowDataResults(obj));
                        return response;
                    } else {
                        toast.warning('Respective File Not get');
                    }
                })
            }
        });
    return Promise.resolve<any>(getDetailsInfo);
}


export const PoListAddNewDetails = (data: any) => async (dispatch, getstate) => {

    //dispatch(actions.AddDNRFDetails(data));

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;
    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Line Numbers List')" + WHC_API_Path.items;

    const postJosnData: string = JSON.stringify({
        __metadata: { type: 'SP.Data.PurchaseOrderLineNumbersListItem' },
        DeliveryDate: new Date(data.DeliveryDate),
        Description: data.Description,
        NetworkActivityCode: data.NetworkActivityCode,
        OriginalCost: data.OriginalCost,
        POLineNumber: data.POLineNumber,
        ProgressPayment: data.ProgressPayment,
        Quantity: data.Quantity,
        ReqAndLineNumber: data.ReqAndLineNumber,
        SerialNumber: data.SerialNumber,
        ServiceOrMaterial: data.ServiceOrMaterial,
        Taxable: data.Taxable,
        //Title: data.Title,
        TotalCost: data.TotalCost,
        Units: data.Units
    });
    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=verbose',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': ''
        },
        body: postJosnData
    }).then(async (response: SPHttpClientResponse) => {
        if (response.ok) {
            final = await response.json().then((response) => {
                if (response != null) {
                    //toast.success('Records Sucessfully Added');
                    return response

                } else {
                    toast.error('Records failed');
                    console.log('Records failed');
                    return response

                }
            })
        }
    });
    return Promise.resolve<any>(final);


};



export const PoListUpdateSelectedRowData = (data: any) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;

    let ItemId = StringFormat(WHC_API_Path.getPoListEditDeatails, data.Id);
    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Line Numbers List')" + ItemId;

    console.log("submitItem: " + url);
    const body: string = JSON.stringify({
        __metadata: { type: 'SP.Data.PurchaseOrderLineNumbersListItem' },
        DeliveryDate: new Date(data.DeliveryDate),
        Description: data.Description,
        NetworkActivityCode: data.NetworkActivityCode,
        OriginalCost: data.OriginalCost,
        POLineNumber: data.POLineNumber,
        ProgressPayment: data.ProgressPayment,
        Quantity: data.Quantity,
        ReqAndLineNumber: data.ReqAndLineNumber,
        SerialNumber: data.SerialNumber,
        ServiceOrMaterial: data.ServiceOrMaterial,
        Taxable: data.Taxable,
        //Title: data.Title,
        TotalCost: data.TotalCost,
        Units: data.Units

    });
    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': '',
            'IF-MATCH': '*',
            'X-Http-Method': 'PATCH'
        },
        body: body
    }).then((response: SPHttpClientResponse) => {
        if (response.ok) {
            //toast.success('successfully Updated');
            PoListDeleteSelectedRowData(data)
            return response
        } else {
            toast.error('Updated Records failed');
        }
    });
    return Promise.resolve<any>(itemResults);

}
export const PoListDeleteSelectedRowData = (data: any) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;

    let ItemId = StringFormat(WHC_API_Path.getPoListDeleteDeatails, data.Id);
    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Line Numbers List')" + ItemId;

    console.log("submitItem: " + url);

    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        async: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            'OData-Version': '3.0',
            "If-Match": "*",
            "X-Http-Method": "DELETE",
        },

    }).then((response: SPHttpClientResponse) => {
        if (response.ok) {
            //toast.success('Deleted successfully');
            return response
        }
    });
    return Promise.resolve<any>(itemResults);

}

export const DeleteDraftSelectedRowData = (Id: any) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;

    let ItemId = StringFormat(WHC_API_Path.DeleteSelectedRowDeatails, Id);
    const url = baseURL + WHC_API_Path.apiListName + "('" + postURL + "')" + ItemId;

    console.log("submitItem: " + url);

    let final: any;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        async: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            'OData-Version': '3.0',
            "If-Match": "*",
            "X-Http-Method": "DELETE",
        },

    }).then((response: SPHttpClientResponse) => {
        if (response.ok) {
            toast.success('Deleted successfully');
            return response
        }
    });
    return Promise.resolve<any>(itemResults);

}

export const PoListFetchSelectedRowDataResults = (SerialNumber: any, pageMode: any) => async (dispatch, getstate) => {

    //dispatch(actions.AddDNRFDetails(data));
    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;


    let items = StringFormat(WHC_API_Path.getPoListDeatails, SerialNumber);
    //let S_Number = ItemId.toString();
    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Line Numbers List')" + items;
    let getDetailsInfo: any;
    let detailsArray: any[] = [];
    let tempArray: [];



    const itemResults = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
            if (response.ok) {
                getDetailsInfo = await response.json().then((response) => {
                    if (response != null) {
                        // response.value.map((item: any, index) => {
                        //     if (item) {
                        //         let collection = {
                        //             DeliveryDate: new Date(item.DeliveryDate),
                        //             Description: item.Description,
                        //             NetworkActivityCode: item.NetworkActivityCode,
                        //             OriginalCost: item.OriginalCost,
                        //             POLineNumber: item.POLineNumber,
                        //             ProgressPayment: item.ProgressPayment,
                        //             Quantity: item.Quantity,
                        //             ReqAndLineNumber: item.ReqAndLineNumber,
                        //             SerialNumber: item.SerialNumber,
                        //             Service: item.ServiceOrMaterial,
                        //             Taxable: item.Taxable,
                        //             TotalCost: item.TotalCost,
                        //             Units: item.Units
                        //         }
                        //         tempArray.push(collection);
                        //     }



                        // });



                        dispatch(actions.PoListFetchSelectedRowDataResults(response.value));
                        return response;
                    } else {
                        toast.warning('Respective File Not get');
                    }
                })
            }
        });
    return Promise.resolve<any>(getDetailsInfo);
}

export const FetchUserGroupInfo = (data: any) => async (dispatch, getstate) => {


    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    const url = baseURL + WHC_API_Path.apiCurrentUserGroup;

    // const siteURL = this.context.pageContext.web.absoluteUrl;
    //const currentUserEmail = this.context.pageContext.user.email;
    const currentUserEmail = data.userEmail;
    let permissionLevel: string = "No";
    let permissionLevelMem: string = "No";

    await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
            return response.json().then((response): void => {
                if (response.value != undefined && response.value.length > 0) {

                    console.log(response.value);
                    let obj = {}
                    dispatch(actions.FetchUserGroupInfo(obj));

                }

            });
        })


}
export const SendMail = (emailBody, data, Subject) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;




    let from = getstate().DetailReducer.parentProps.userEmail
    let url = baseURL + WHC_API_Path.sendMailParam;
    const reqOptions: any = {
        headers: {
            "Accept": "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "odata-version": "3.0",
        },
        body: JSON.stringify({
            'properties': {
                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                'From': from,
                'To': { 'results': data },
                'CC': { 'results': data },
                'Body': emailBody,
                'Subject': Subject
            }
        })
    };
    let mailRes: any;
    const mail = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, reqOptions)
        .then(async (response: SPHttpClientResponse) => {
            //console.log(`Status code: ${response.status}`);
            //console.log(`Status text: ${response.statusText}`);
            mailRes = await response.json().then((responseJSON: JSON) => {
                console.log("ResponseJSON:" + responseJSON);
                //toast.success('Mail sent successfully');
                //alert("Email Send Successfully!!!");
                //this.setState({ modalIsOpen: false });
                return response;
            });
        })
    return Promise.resolve<any>(mailRes);
}


export const CreateFolder = (data, Section) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let FolderName = 'Other';
    //let postURL = getstate().DetailReducer.parentProps.DNRFDocumentsLibrary;

    //let FolderNane = "PO - Attachment" + "-" + removeSpecialChars(data.DocumentTitle);
    if (Section == 'MOAApproval') {
        FolderName = "MOA-Approval-" + data.SerialNumber + '-' + data.AlterationNo;
    } else if (Section == 'SupplierCTR') {
        FolderName = "SupplierCTR-" + data.SerialNumber + '-' + data.AlterationNo;
    } else {
        FolderName = "Other-" + data.SerialNumber + '-' + data.AlterationNo;
    }

    const createFloader = StringFormat(WHC_API_Path.folderUrlParam, encodeURIComponent(FolderName))
    const url = baseURL + WHC_API_Path.apiListName + "('Purchase Order Documents Library')" + createFloader;
    let createForlder: any;

    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': ''
        }
    }).then(async (response: SPHttpClientResponse) => {
        if (response.ok) {
            createForlder = await response.json().then((response) => {
                if (response != null) {
                    dispatch(actions.CreateFolder(response));
                    return response
                }
            })
        }
    });
    return Promise.resolve<any>(createForlder);
}

export const getFolderAvailability = (data, Section) => async (dispatch, getstate) => {

    const weburl = getstate().DetailReducer.parentProps.webURL;
    const baseProps = getstate().DetailReducer.parentProps;
    const documentName = 'Purchase Order Documents Library';
    //const FolderName = "PO - Attachment" + "-" + removeSpecialChars(data.DocumentTitle);
    let FolderName = "MOA-Approval-" + data.SerialNumber + '-' + data.AlterationNo;
    if (Section == 'MOAApproval') {
        FolderName = "MOA-Approval-" + data.SerialNumber + '-' + data.AlterationNo;
    } else if (Section == 'SupplierCTR') {
        FolderName = "SupplierCTR-" + data.SerialNumber + '-' + data.AlterationNo;
    } else {
        FolderName = "Other-" + data.SerialNumber + '-' + data.AlterationNo;
    }


    const FolderPath = StringFormat(WHC_API_Path.getFolderParam, documentName);
    const FolderNameparam = StringFormat(WHC_API_Path.getFileListItemAllFieldsParams, FolderName);
    const url = weburl + FolderPath + FolderNameparam;
    let getFolderInfo: any;
    const itemResults = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
            if (response.ok) {
                getFolderInfo = await response.json().then((response) => {
                    dispatch(actions.GetListItemAll(response))
                    return response;
                })

            }
            else if (response.ok == false) {
                console.log('folder not get')
                //this.createFolder();
                return response;
            }
        });
    return Promise.resolve<any>(getFolderInfo);

}


export const FileUpload = (data, isExistingFolder) => async (dispatch, getstate) => {

    const baseURL = getstate().DetailReducer.parentProps.webURL;
    const baseProps = getstate().DetailReducer.parentProps;
    const documentName = 'Purchase Order Documents Library';
    const folderID = getstate().DetailReducer.listItemAllFiled.ListItemAllFields.ID;
    const metaDataType = getstate().DetailReducer.listItemAllFiled.ListItemAllFields["@odata.type"];
    //const formNo = getstate().DetailReducer.formNo;
    const url = baseURL + WHC_API_Path.apiListName + "('" + documentName + "')" + '/items(' + folderID + ')';
    //const displayFormNo = String(formNo) + "_" + removeSpecialChars(data.DocumentTitle);
    //const displayFormNo = String(formNo);
    const type = metaDataType.slice(1);
    //Uploaded Docuemnt have Empty 
    // let newPayload: string = JSON.stringify({
    //     '__metadata': { "type": type },
    //     'FormNo': String(displayFormNo)
    // });
    let newPayload: string = JSON.stringify({
        '__metadata': { "type": type }

    });
    newPayload = newPayload.substring(1, newPayload.length - 1);
    newPayload = '{' + newPayload + '}';
    //Upload Document have existing Docuemnt
    let oldPayload: string = JSON.stringify({
        '__metadata': { "type": type }
    });
    oldPayload = oldPayload.substring(1, oldPayload.length - 1);
    oldPayload = '{' + oldPayload + '}';

    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1,
        {
            headers: {
                'Accept': 'application/json;odata=nometadata',
                'Content-type': 'application/json;odata=verbose',
                'odata-version': '',
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE'
            },
            body: isExistingFolder ? oldPayload : newPayload
        }).then(async (response: SPHttpClientResponse) => {
            if (response.ok) {
                debugger;
                // if (response != null) {
                //     for (let i = 0; i < data.file.length; i++) {
                //         await dispatch(fileUploadLocation(data.file[i], 'MOAApproval'));
                //     }
                //     return response;
                // }
                return response;
            }
        });
    return Promise.resolve<any>(itemResults);
}

export const fileUploadLocation = (uploadedfile, Section) => async (dispatch, getstate) => {

    const baseURL = getstate().DetailReducer.parentProps.webURL;
    const baseProps = getstate().DetailReducer.parentProps;
    const documentName = 'Purchase Order Documents Library';
    //const FolderName = getstate().DNRFDetailReducer.folderDetails.Name;
    const FolderName = getstate().DetailReducer.listItemAllFiled.Name;
    const RootFolderParam = StringFormat(WHC_API_Path.rootFolderparam, FolderName);
    const fileName = StringFormat(WHC_API_Path.filenameParam, encodeURIComponent(uploadedfile.name));
    let fileUpload: any;
    const filesArray: any[] = [];
    let reader = new FileReader();
    reader.readAsArrayBuffer(uploadedfile);
    reader.onload = (evt) => {
        //let buffer = evt.target.result;
        let buffer = reader.result;

        const url = baseURL + WHC_API_Path.apiListName + "('" + documentName + "')" + RootFolderParam + fileName;
        const itemResults = baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
            headers: {
                'Accept': 'application/json;odata=nometadata',
                'Content-type': 'application/json;odata=verbose',
                'odata-version': ''
            },
            body: buffer
        }).then(async (response: SPHttpClientResponse) => {
            if (response.ok) {
                debugger;
                fileUpload = await response.json().then((resp) => {
                    if (resp != null) {

                        //console.log('file added');
                        const files = (<any>Object).assign({}, null, resp);
                        filesArray.push(files);

                        if (Section == 'MOAApproval') {
                            const exgistingFile = getstate().DetailReducer.MOAApprovalUploadFileList;
                            const final = connectArray(exgistingFile, filesArray);
                            dispatch(actions.GetuploadedMOAList(final));
                        } else if (Section == 'SupplierCTR') {
                            const exgistingFile = getstate().DetailReducer.SupplierUploadFileList;
                            const final = connectArray(exgistingFile, filesArray);
                            dispatch(actions.GetuploadedSupplierList(final));

                        } else {
                            const exgistingFile = getstate().DetailReducer.OtherUploadFileList;
                            const final = connectArray(exgistingFile, filesArray);
                            dispatch(actions.GetuploadedOtherList(final));
                        }

                        return resp;
                    }

                })
            }
        });
        // this.setState({ modalIsOpen: false });
        return Promise.resolve<any>(itemResults);
    }
}


export const DeleteSingleFile = (selectedFileName, folderpath, Section) => async (dispatch, getstate) => {

    const baseURL = getstate().DetailReducer.parentProps.webURL;
    const baseProps = getstate().DetailReducer.parentProps;
    const deleteParam = StringFormat(WHC_API_Path.deleteUploadFileParam, selectedFileName);
    const url = baseURL + deleteParam;

    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': '',
            'X-Http-Method': 'DELETE'
        },
    }).then(async (response: SPHttpClientResponse) => {
        if (response.ok) {


            toast.success("Attached File Deleted Sucessfully");
            return response
        }
    });
    return Promise.resolve<any>(itemResults);
}




export const DeleteAllFile = (selectedFileName) => async (dispatch, getstate) => {

    const baseURL = getstate().DetailReducer.parentProps.webURL;
    const baseProps = getstate().DetailReducer.parentProps;
    const deleteParam = StringFormat(WHC_API_Path.deleteUploadFileParam, selectedFileName);
    const url = baseURL + deleteParam;
    const itemResults = await baseProps.spHttpClient.post(url, SPHttpClient.configurations.v1, {
        headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': '',
            'X-Http-Method': 'DELETE'
        },
    }).then((response: SPHttpClientResponse) => {
        if (response.ok) {
            return response;
        }
    });
    return Promise.resolve<any>(itemResults);

}

export const GetAssociatedFolder = (data: any, Section) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    const documentName = 'Purchase Order Documents Library';
    let getFolderParam = StringFormat(WHC_API_Path.getDetailsFolder, data);
    const url = baseURL + "/_api/web/GetFolderByServerRelativeUrl('Purchase%20Order%20Documents%20Library/" + data + "')"
    const filesArray: any[] = [];
    let getFile: any;
    let getFolder: any;
    const itemResults = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
            if (response.ok) {
                getFolder = await response.json().then(async (response) => {

                    if (response != undefined) {

                        let folderName = response.Name; // Just for this function as setstate values won't reflect immediately
                        await dispatch(GetAssociatedFiles(folderName, Section));
                        return response
                    }

                })
            }
        });
    return Promise.resolve<any>(getFolder);
}

export const GetAssociatedFiles = (folderName, Section) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    const documentName = 'Purchase Order Documents Library';
    let getFileParam = StringFormat(WHC_API_Path.getDetailsFilePath, folderName);
    const url = baseURL + WHC_API_Path.getFileListParamURL + "('" + documentName + getFileParam;
    const filesArray: any[] = [];
    let getFile: any;

    const itemFile = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {
            if (response.ok) {
                getFile = await response.json().then(async (response) => {
                    if (response.value.length > 0) {
                        response.value.map((file, index) => {
                            const files = (<any>Object).assign({}, null, file);
                            filesArray.push(files);
                        })
                    }
                    if (Section == 'MOAApproval') {
                        debugger;
                        dispatch(actions.ClearuploadedMOAList());
                        dispatch(actions.GetuploadedMOAList(filesArray));
                    } else if (Section == 'SupplierCTR') {
                        dispatch(actions.ClearuploadedSupplierList());
                        dispatch(actions.GetuploadedSupplierList(filesArray));

                    } else {
                        dispatch(actions.ClearuploadedOtherList());
                        dispatch(actions.GetuploadedOtherList(filesArray));
                    }
                    //await dispatch(actions.GetuploadedList(filesArray));
                    return response
                })
            } else {
                if (Section == 'MOAApproval') {
                    dispatch(actions.ClearuploadedMOAList());
                    dispatch(actions.GetuploadedMOAList(filesArray));
                } else if (Section == 'SupplierCTR') {
                    dispatch(actions.ClearuploadedSupplierList());
                    dispatch(actions.GetuploadedSupplierList(filesArray));

                } else {
                    dispatch(actions.ClearuploadedOtherList());
                    dispatch(actions.GetuploadedOtherList(filesArray));
                }

                return response
            }

        });
    return Promise.resolve<any>(getFile);
}
export const fileUplaodtoLocalStore = (data) => (dispatch, getstate) => {

    let fileUpload: any;
    const filesArray: any[] = [];
    const files = (<any>Object).assign({}, null, data);
    filesArray.push(files);
    const exgistingFile = getstate().DetailReducer.uploadFileList;
    const final = connectArray(exgistingFile, filesArray)
    dispatch(actions.GetuploadedList(final));
}
export const FileAttachmentsClear = () => (dispatch, getstate) => {
    dispatch(actions.FileAttachmentsClear());
}