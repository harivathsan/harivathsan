import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from '@microsoft/sp-http';
import { masterDataActionTypes } from '../constants/actionType';
import { masterData, WHC_API_Path } from '../constants/apiConfig';
import * as pnp from "sp-pnp-js";
const actions = {
    FetchParentProps: (payload) => ({
        type: masterDataActionTypes.FETCH_PARENT_PROPS,
        data: payload
    }),

    FetchDefaultResults: (payload) => ({
        type: masterDataActionTypes.FETCH_LIST_DATA,
        data: payload
    }),
    FetchUserGroupInfo: (payload) => ({
        type: masterDataActionTypes.FETCH_USER_GROUP,
        data: payload
    }),
    FetchCurrentUserInfo: (payload) => ({
        type: masterDataActionTypes.FETCH_CRRENT_USER,
        data: payload
    }),
}

export const FetchParentProps = (parentProps: any) => async (dispatch, getstate) => {
    dispatch(actions.FetchParentProps(parentProps));

};

export const FetchDefaultResults = (lsitName: any) => async (dispatch, getstate) => {

    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    let postURL = getstate().DetailReducer.parentProps.listName;
    let currentUserEmail = getstate().DetailReducer.parentProps.userEmail;
    let isSupportTeam = getstate().DetailReducer.isSupportTeam;
    let isRequestors = getstate().DetailReducer.isRequestorsTeam;
    const url = baseURL + masterData.apiListName + "('" + postURL + "')" + masterData.item;
    let getDetailsInfo: any;
    let CurrentUserPurchaseOrderItems = [];
    let CurrentUserSupportTeamItems = [];
    const defaultDataResults = await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then(async (response: SPHttpClientResponse) => {

            if (response.ok) {
                getDetailsInfo = await response.json().then((response) => {
                    if (isSupportTeam) {
                        let teams = [];
                        let obj = {
                            AlertationTableView: false
                        }
                        teams = response.value.filter((hero) => {
                            return hero.Status != 'Draft' && hero.Status != 'Rejected';
                        });

                        teams.map((item, index) => {
                            let Supportobj = { ...item, ...obj }
                            CurrentUserSupportTeamItems.push(Supportobj);
                        })

                    } else if (isRequestors) {
                        if (response != null && response.value != null && response.value.length > 0) {

                            CurrentUserPurchaseOrderItems = response.value.filter((hero) => {
                                return hero.ApplicationUserEmailID == currentUserEmail;
                            });
                        }
                    }

                    let obj = {
                        CurrentUserSupportTeamItems: CurrentUserSupportTeamItems,
                        CurrentUserPurchaseOrderItems: CurrentUserPurchaseOrderItems,
                        PurchaseOrderData: response.value
                    }
                    dispatch(actions.FetchDefaultResults(obj));

                })
            }
        });
    return Promise.resolve<any>(getDetailsInfo);


};
export const FetchUserGroupInfo = (data: any) => async (dispatch, getstate) => {


    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    const url = baseURL + WHC_API_Path.apiCurrentUserGroup;
    let currentUserEmail = getstate().DetailReducer.parentProps.userEmail;

    await baseProps.spHttpClient.get(url, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
            return response.json().then((response): void => {
                if (response.value != undefined && response.value.length > 0) {

                    console.log(response.value);

                    const PortfolioSupportTeamMember = response.value.filter(group => group.Title == 'Portfolio Support Team Member');


                    let isPortfolioSupportTeamMember = [];
                    isPortfolioSupportTeamMember = PortfolioSupportTeamMember.length > 0 && PortfolioSupportTeamMember[0].Users.filter(user => user.Email == currentUserEmail);


                    let obj = {}
                    if (isPortfolioSupportTeamMember.length > 0) {
                        obj = {
                            isPortfolioSupportTeam: true,
                            isRequestors: false

                        }
                    } else {
                        obj = {
                            isPortfolioSupportTeam: false,
                            isRequestors: true
                        }
                    }
                    dispatch(actions.FetchUserGroupInfo(obj));

                }

            });
        })


}
export const FetchCurrentUserInfo = (data: any) => async (dispatch, getstate) => {


    let baseURL = getstate().DetailReducer.parentProps.webURL;
    let baseProps = getstate().DetailReducer.parentProps;
    const url = baseURL + WHC_API_Path.apiCurrentUserGroup;
    let currentUserEmail = getstate().DetailReducer.parentProps.userEmail;

    const web = new pnp.Web(baseProps.context.pageContext.site.absoluteUrl);

    web.ensureUser(currentUserEmail).then(result => {

        dispatch(actions.FetchCurrentUserInfo(result.data));

    });

}
