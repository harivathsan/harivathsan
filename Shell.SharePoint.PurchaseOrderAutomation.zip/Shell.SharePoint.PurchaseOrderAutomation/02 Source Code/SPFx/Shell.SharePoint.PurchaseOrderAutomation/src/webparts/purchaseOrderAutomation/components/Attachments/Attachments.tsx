import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import {
    Container,
    Row,
    Col,
    Button,
    Form,
    FormGroup,
    Label,
    Input,
} from "reactstrap";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
// Import React FilePond
import { FilePond, registerPlugin } from "react-filepond";
// Import FilePond styles
import "filepond/dist/filepond.min.css";
import FilePondPluginImageExifOrientation from "filepond-plugin-image-exif-orientation";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";

// Register the plugins
registerPlugin(FilePondPluginImageExifOrientation, FilePondPluginImagePreview);

export interface IUploadProps {
    spHttpClient: any;
    siteUrl: any;
    listName: string;
}

export interface IUploadState {
    files1: any;
    uploading: boolean;
}

export interface IListItem {
    Title?: string;
    Id: number;
}

class Upload extends React.Component<IUploadProps, IUploadState> {
    public readonly state: IUploadState;
    private pond: any;
    private files1: any;

    constructor(props: IUploadProps) {
        super(props);
        this.state = {
            files1: [],
            uploading: false
        };
    }

    private handleInit = () => {
        console.log("FilePond instance has initialised", this.pond);
    }

    private onupdatefilesHandler = (fileItems: any) => {

        // Set currently active file objects to this.state
        this.setState({
            files1: fileItems.map(fileItem => fileItem.file)
        }, () => {
            console.log('Filename:' + this.state.files1);
        });

    }
    private getFileBuffer = (uploadedFiles) => {
        let promised = new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.onload = (e) => {
                resolve(e.target.result);
            };
            reader.onerror = (e) => {
                reject(e.target.error);
            };
            //reader.readAsArrayBuffer(uploadedFiles[0]);
            reader.readAsArrayBuffer(uploadedFiles);
        });

        return promised;
    }

    private submitHandler = () => {
        //alert("item submitted");
        this.insertItem();
    }

    private insertItem = () => {
        this.setState(
            {
                uploading: true
            }
        );
        const body: string = JSON.stringify({
            'Title': `Item ${new Date()}`
        });

        this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items`,
            SPHttpClient.configurations.v1,
            {
                headers: {
                    'Accept': 'application/json;odata=nometadata',
                    'Content-type': 'application/json;odata=nometadata',
                    'odata-version': ''
                },
                body: body
            })
            .then((response: SPHttpClientResponse): void => {
                response.json().then(async (item: IListItem): Promise<void> => {
                    //alert(`ID: ${item.Id} successfully created`);
                    const uploadedFiles = this.state.files1;
                    for (let index = 0; index < (uploadedFiles.length); index++) {
                        const uploadedFile = uploadedFiles[index];
                        await this.getFileBuffer(uploadedFile).then(async () => {
                            //upload the file                
                            await this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items(${item.Id})/AttachmentFiles/add(FileName='${uploadedFiles[index].name}')`,
                                SPHttpClient.configurations.v1,
                                {
                                    headers: {
                                        'Accept': 'application/json;odata=nometadata',
                                        'Content-type': 'application/json;odata=nometadata',
                                        'odata-version': ''
                                    },
                                    body: uploadedFiles[index]
                                }).then((result) => {
                                    //console.log(uploadedFiles[index]);
                                    //console.log("Uploaded file");
                                    console.log(result);
                                    //
                                });
                        });
                    }//End For
                    alert(` ${uploadedFiles.length}  Attachment successfully Attached`);
                    this.setState(
                        {
                            uploading: false,
                            files1: []
                        }
                    );
                }, (error: any): void => {
                    console.log('Error Message:' + error);
                });
            });

    }
    public render() {
        return (
            <div>
                <h2>File Attachment Demo</h2>
                <Container>
                    <Row>
                        <Col xs="12" sm="12" md="12" lg="12">
                            <FilePond
                                ref={ref => (this.pond = ref)}
                                files={this.state.files1}
                                allowMultiple={true}
                                allowReorder={true}
                                maxFiles={5}
                                //name="files" {/* sets the file input name, it's filepond by default */}
                                oninit={() => this.handleInit()}
                                onupdatefiles={fileItems => this.onupdatefilesHandler(fileItems)}
                                labelIdle='<span class="filepond--label-action">Browse to Upload the File</span>'
                            />
                        </Col>
                    </Row>
                    <Row>
                        <Col xs="12" sm="12" md="12" lg="12">
                            <button onClick={this.submitHandler} disabled={this.state.uploading} >Submit Attachments</button>
                            {
                                this.state.uploading ? <img src="https://eu023-sp.shell.com/sites/SPOAA0342/ls/SiteAssets/Loading/Loading.gif" height={50} /> : ""
                            }

                        </Col>
                    </Row>
                </Container>
            </div>
        );
    }
}

export default Upload;
