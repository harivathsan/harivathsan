import * as React from 'react';
import styles from '../PurchaseOrderAutomation.module.scss';
import { Col, Row, Table, Container, Button, Form, FormGroup, Label, Input, FormText, Toast, ToastBody, ToastHeader } from 'reactstrap';
import InputControl from '../InputComponent/inputControl';
import { ToastContainer, toast } from 'react-toastify';
import PaginationUI from '../Pagination';
import DataTable from 'react-data-table-component';
import DataTableExtensions from 'react-data-table-component-extensions';
import 'react-data-table-component-extensions/dist/index.css';


class ServicesRequestTable extends React.Component<any, any>{
    constructor(props) {
        super(props)
        this.state = {
            pageOfItems: this.props.CurrentUserPurchaseOrderItems,
            searchTable: '',
            tableData: {
                columns: [
                    {
                        name: 'Request Number',
                        selector: 'SerialNumber',
                        sortable: true,
                    },
                    {
                        name: 'Created On Date',
                        selector: 'Date',
                        sortable: true,
                        right: true,
                        cell: row => (
                            row.Date != null && <InputControl
                                type={'date'}
                                labelClassName={styles.label}
                                name={'Date'}
                                defaultValue={new Date(row.Date)}
                                formatDate={this.props.onFormatDate}
                                onDateHandleChange={this.props.onCreateDate}
                                isdisabled={true}
                            />
                        )

                    },
                    {
                        name: 'Project Name',
                        selector: 'ProjectName',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'Supplier Name',
                        selector: 'VendorName',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'PO No',
                        selector: 'PurchaseOrderNo',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'PO Description',
                        selector: 'PODescription',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'Estimated Commitment value',
                        selector: 'EstimatedCommitment',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'Status',
                        selector: 'Status',
                        sortable: true,
                        right: true


                    },
                    {
                        name: '',
                        selector: 'Status',
                        sortable: true,
                        right: true,
                        cell: row => (row.Status == 'Draft' ? <>
                            <Button outline id={row.Id} data-name={row.Status} onClick={this.props.onEdit}>Edit</Button>
                            <Button outline id={row.Id} data-serialnumber={row.SerialNumber} data-name={row.Status} onClick={this.props.onDelete}>Delete</Button></> :
                            (row.Status == 'Rejected' ?
                                <Button outline id={row.Id} data-name={row.Status} onClick={this.props.onEdit}>Edit</Button> :
                                (row.Status == 'Open') ? <Button outline id={row.Id} data-name={row.Status} onClick={this.props.onView}>View</Button> : ""))
                        // (row.Status == 'Draft' || row.Status == 'Rejected') ?
                        //     ((row.Status == 'Rejected' && <Button outline id={row.Id} data-name={row.Status} onClick={this.props.onEdit}>Edit</Button>)
                        //         && (row.Status == 'Draft' && <><Button outline id={row.Id} data-name={row.Status} onClick={this.props.onEdit}>Edit</Button>{' '}<Button outline id={row.Id} data-name={row.Status} onClick={this.props.OnDelete}>Delete</Button></>)) :
                        //     ((row.Status == 'Open') ? <Button outline id={row.Id} data-name={row.Status} onClick={this.props.onView}>View</Button> : "")


                    }

                ],
                data: this.props.CurrentUserPurchaseOrderItems
            }
        }
    }

    public render(): JSX.Element {

        return (<>
            <DataTableExtensions {...this.state.tableData} export={false} print={false}>
                <DataTable
                    columns={this.state.tableData.column}
                    data={this.state.tableData.data}
                    noHeader
                    defaultSortField="Id"
                    defaultSortAsc={false}
                    pagination
                    highlightOnHover
                />
            </DataTableExtensions>
        </>
        )
    }
} export default ServicesRequestTable