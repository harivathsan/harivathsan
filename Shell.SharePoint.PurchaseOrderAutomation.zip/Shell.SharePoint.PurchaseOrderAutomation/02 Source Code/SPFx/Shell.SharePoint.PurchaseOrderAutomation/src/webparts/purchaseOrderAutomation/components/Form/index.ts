import PurchaseOrder from './purchaseOrder';
import {
    AddNewDetails, FetchSelectedRowDataResults, UpdateSelectedRowData, PoListAddNewDetails, PoListUpdateSelectedRowData, PoListFetchSelectedRowDataResults, PoListDeleteSelectedRowData, SendMail,
    CreateFolder, FileUpload, getFolderAvailability, fileUploadLocation, DeleteSingleFile, DeleteAllFile, fileUplaodtoLocalStore, GetAssociatedFolder, GetAssociatedFiles, FileAttachmentsClear,
    AlterationRowListItems, FetchSelectedAlterationRowListItems, AlterationRowUpdateListItems, FetchSelectedAlterationRowListItems_Id, DeleteDraftSelectedRowData
} from "../../../actions/purchaseOrderActions";
import { FetchParentProps, FetchDefaultResults, FetchUserGroupInfo, FetchCurrentUserInfo } from "../../../actions/masterData";
import { bindActionCreators, Dispatch, AnyAction } from 'redux';
import { connect } from "react-redux";
const mapStateToProps = (state: any) => {

    return {
        WHC_listData: state.DetailReducer.WHC_listData,
        CurrentUserInfo: state.DetailReducer.CurrentUserInfo,
        listItems: state.DetailReducer.listItems,
        PurchaseOrderData: state.DetailReducer.PurchaseOrderData,
        MasterDataProjectType: state.DetailReducer.MasterDataProjectType,
        MasterDataOffshoreServices: state.DetailReducer.MasterDataOffshoreServices,
        MasterDataService: state.DetailReducer.MasterDataService,
        MasterDataTaxable: state.DetailReducer.MasterDataTaxable,
        MasterDataProgressPayment: state.DetailReducer.MasterDataProgressPayment,
        MasterDataRejectedReasons: state.DetailReducer.MasterDataRejectedReasons,
        CurrentUserPurchaseOrderItems: state.DetailReducer.CurrentUserPurchaseOrderItems,
        CurrentUserSupportTeamItems: state.DetailReducer.CurrentUserSupportTeamItems,
        ChildList: state.DetailReducer.ChildList,
        isSupportTeam: state.DetailReducer.isSupportTeam,
        isRequestorsTeam: state.DetailReducer.isRequestorsTeam,
        MOAApprovalUploadFileList: state.DetailReducer.MOAApprovalUploadFileList,
        SupplierUploadFileList: state.DetailReducer.SupplierUploadFileList,
        OtherUploadFileList: state.DetailReducer.OtherUploadFileList,
        OtherAttachment: state.DetailReducer.OtherAttachment,
        SupplierAttachment: state.DetailReducer.SupplierAttachment,
        MOAAttachment: state.DetailReducer.MOAAttachment,
        AlterationRowListItems: state.DetailReducer.AlterationRowListItems,
        AlterationArray: state.DetailReducer.AlterationArray,
        AlterationRowId: state.DetailReducer.AlterationRowId


    };
};
const mapDispatchToProps = (dispatch: Dispatch<AnyAction>) => {

    return {
        actions: bindActionCreators(
            {
                AddNewDetails,
                FetchUserGroupInfo,
                FetchParentProps,
                FetchDefaultResults,
                UpdateSelectedRowData,
                FetchSelectedRowDataResults,
                PoListAddNewDetails,
                PoListUpdateSelectedRowData,
                PoListFetchSelectedRowDataResults,
                PoListDeleteSelectedRowData,
                SendMail,
                FetchCurrentUserInfo,
                CreateFolder,
                FileUpload,
                getFolderAvailability,
                fileUploadLocation,
                DeleteSingleFile,
                DeleteAllFile,
                fileUplaodtoLocalStore,
                GetAssociatedFolder,
                GetAssociatedFiles,
                FileAttachmentsClear,
                AlterationRowListItems,
                AlterationRowUpdateListItems,
                FetchSelectedAlterationRowListItems,
                FetchSelectedAlterationRowListItems_Id,
                DeleteDraftSelectedRowData,


            },
            dispatch
        ),
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(PurchaseOrder)
