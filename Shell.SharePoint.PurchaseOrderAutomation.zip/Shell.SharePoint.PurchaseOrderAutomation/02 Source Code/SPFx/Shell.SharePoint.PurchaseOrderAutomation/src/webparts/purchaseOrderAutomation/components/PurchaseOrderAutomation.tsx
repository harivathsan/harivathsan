import * as React from 'react';

import { IPurchaseOrderAutomationProps } from './IPurchaseOrderAutomationProps';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { escape } from '@microsoft/sp-lodash-subset';
import { Provider } from "react-redux";
import PurchaseOrder from '../components/Form/index';
import 'bootstrap/dist/css/bootstrap.min.css';
import store from '../../store/reduxStore';
import 'react-toastify/dist/ReactToastify.css';

export default class PurchaseOrderAutomation extends React.Component<any, any> {
  constructor(props) {

    super(props);
    //importing Global CSS
    let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
  }
  public render(): React.ReactElement<IPurchaseOrderAutomationProps> {
    return (
      <React.Fragment>
        <Provider store={store}>
          <PurchaseOrder {...this.props} />
        </Provider>
      </React.Fragment>
    );
  }
}
