import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'PurchaseOrderAutomationWebPartStrings';
import PurchaseOrderAutomation from './components/PurchaseOrderAutomation';
import { IPurchaseOrderAutomationProps } from './components/IPurchaseOrderAutomationProps';
import { sp } from "@pnp/sp"

export interface IPurchaseOrderAutomationWebPartProps {
  description: string;
  css: string;
  listName: string;
  listPageURL: string;
}

export default class PurchaseOrderAutomationWebPart extends BaseClientSideWebPart<IPurchaseOrderAutomationWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IPurchaseOrderAutomationProps> = React.createElement(
      PurchaseOrderAutomation,
      {
        description: this.properties.description,
        webURL: this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        context: this.context,
        userDisplayName: this.context.pageContext.user.displayName,
        userLoginName: this.context.pageContext.user.loginName,
        userEmail: this.context.pageContext.user.email,
        css: this.properties.css,
        listName: this.properties.listName,
        listPageURL: this.properties.listPageURL
      }
    );

    ReactDom.render(element, this.domElement);
  }


  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  protected onInit(): Promise<void> {
    return new Promise<void>((resolve, _reject) => {
      sp.setup({
        spfxContext: this.context, defaultCachingTimeoutSeconds: 300,
      });

      if (this.properties.css === undefined) {
        this.properties.css = this.context.pageContext.web.absoluteUrl + "/SiteAssets/assets/globalCss/globalcss.css";

      }
      if (this.properties.listPageURL === undefined) {
        this.properties.listPageURL = this.context.pageContext.web.absoluteUrl + "/PurchaseOrderLineNumbersList/AllItems.aspx";
      }

      resolve(undefined);

    });

  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('css', {
                  label: '~CSS'
                }),
                PropertyPaneTextField('listName', {
                  label: 'listName'
                }),
                PropertyPaneTextField('listPageURL', {
                  label: 'listPageURL'
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
