declare interface IPurchaseOrderAutomationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PurchaseOrderAutomationWebPartStrings' {
  const strings: IPurchaseOrderAutomationWebPartStrings;
  export = strings;
}
