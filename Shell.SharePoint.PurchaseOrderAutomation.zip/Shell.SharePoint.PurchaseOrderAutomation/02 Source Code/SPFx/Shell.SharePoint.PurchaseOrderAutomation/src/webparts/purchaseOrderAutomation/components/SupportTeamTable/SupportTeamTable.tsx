import * as React from 'react';
import styles from '../PurchaseOrderAutomation.module.scss';
import { Col, Row, Table, Container, Button, Form, FormGroup, Label, Input, FormText, Toast, ToastBody, ToastHeader } from 'reactstrap';
import InputControl from '../InputComponent/inputControl';
import { ToastContainer, toast } from 'react-toastify';
import PaginationUI from '../Pagination';
import DataTable from 'react-data-table-component';
import DataTableExtensions from "react-data-table-component-extensions";
import "react-data-table-component-extensions/dist/index.css";
class SupportTeamTable extends React.Component<any, any>{
    constructor(props) {
        super(props)
        this.state = {
            pageOfItems: this.props.CurrentUserSupportTeamItems,
            searchTable: '',
            tableData: {
                columns: [
                    {
                        name: 'Request No',
                        selector: 'SerialNumber',
                        sortable: true,
                    },
                    {
                        name: 'Date Submitted',
                        selector: 'submittedDate',
                        sortable: true,
                        right: true,
                        cell: d => (
                            d.submittedDate != null && <InputControl
                                type={'date'}
                                labelClassName={styles.label}
                                name={'submittedDate'}
                                defaultValue={new Date(d.submittedDate)}
                                formatDate={this.props.onFormatDate}
                                onDateHandleChange={this.props.onCreateDate}
                                isdisabled={true}
                            />
                        )

                    },
                    {
                        name: 'Project Type',
                        selector: 'ProjectType',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'Req Analyst',
                        selector: 'RequestorName',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'Status',
                        selector: 'Status',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'PO Number',
                        selector: 'PurchaseOrderNo',
                        sortable: true,
                        right: true,
                    },
                    {
                        name: 'Alteration No',
                        selector: 'AlterationNo',
                        sortable: true,
                        right: true,
                        cell: d => {

                            return ((d.Status != 'Close') ?
                                <>

                                    <InputControl
                                        type={'DataTableSelectonly'}
                                        labelClassName={styles.label}
                                        label={'Alteration No'}
                                        id={d.Id}
                                        name={'AlterationNo'}
                                        isRequire={true}
                                        defaultValue={d.AlertationTableView == true ? (d.AlterationNo != d.SelectedAlterationNo ? this.props.SelectedAlterationNo : d.AlterationNo) : d.AlterationNo}
                                        selectOnchange={this.props.onSelectAlertation}
                                        options={(d.AlterationNo == 0 ? [{
                                            label: "0",
                                            value: "0"
                                        },] : d.AlterationNo == 1 ? [{
                                            label: "0",
                                            value: "0"
                                        },
                                        {
                                            label: "1",
                                            value: "1"
                                        },] : d.AlterationNo == 2 ? [{
                                            label: "0",
                                            value: "0"
                                        },
                                        {
                                            label: "1",
                                            value: "1"
                                        },
                                        {
                                            label: "2",
                                            value: "2"
                                        }] : d.AlterationNo == 3 ? [{
                                            label: "0",
                                            value: "0"
                                        },
                                        {
                                            label: "1",
                                            value: "1"
                                        },
                                        {
                                            label: "2",
                                            value: "2"
                                        },
                                        {
                                            label: "3",
                                            value: "3"
                                        }] : d.AlterationNo >= 4 && [{
                                            label: "0",
                                            value: "0"
                                        },
                                        {
                                            label: "1",
                                            value: "1"
                                        },
                                        {
                                            label: "2",
                                            value: "2"
                                        },
                                        {
                                            label: "3",
                                            value: "3"
                                        },
                                        {
                                            label: "4",
                                            value: "4"
                                        }])}
                                    /> {d.AlterationNo >= 5 && <span> <span className={styles.divied}> | </span>  {d.AlterationNo}</span>} </> : d.AlterationNo)
                        }


                    },
                    {
                        name: 'Date Closed',
                        selector: 'DateClosed',
                        sortable: true,
                        right: true,
                        cell: d => (
                            d.DateClosed != null && <InputControl
                                type={'date'}
                                labelClassName={styles.label}
                                name={'DateClosed'}
                                defaultValue={new Date(d.DateClosed)}
                                formatDate={this.props.onFormatDate}
                                onDateHandleChange={this.props.onCreateDate}
                                isdisabled={true}
                            />
                        )


                    },
                    {
                        name: 'No of Days',
                        selector: '',
                        sortable: true,
                        right: true,
                        cell: d => (
                            d.DateClosed != null && <InputControl
                                type={'dayCount'}
                                dateFrom={d.submittedDate}
                                dateEnd={d.DateClosed}
                            />
                        )
                    },
                    {
                        name: '',
                        selector: 'Status',
                        sortable: true,
                        right: true,
                        cell: d =>
                            ((d.Status == 'Open' && d.AlterationNo >= 5 ? <> <Button outline id={d.Id} data-name={this.props.SelectedAlterationNo} onClick={this.props.onAlertationView}>View</Button> <Button outline id={d.Id} data-name={d.Status} onClick={this.props.onEdit}>Edit</Button></> : (d.AlertationTableView == true && d.AlterationNo != parseInt(this.props.SelectedAlterationNo)) ? <Button outline id={d.Id} data-name={this.props.SelectedAlterationNo} onClick={this.props.onAlertationView}>View</Button> : (d.Status == 'Close' ? <Button outline id={d.Id} data-name={d.Status} onClick={this.props.onView}>View</Button> : (d.Status == 'Open' ? <Button outline id={d.Id} data-name={d.Status} onClick={this.props.onEdit}>Edit</Button> : ""))))


                    }
                ],
                //data: this.props.CurrentUserSupportTeamItems
                data: this.props.supportTeamTable
            }

        }

    }




    public render(): JSX.Element {

        return (
            <DataTableExtensions {...this.state.tableData} export={false} print={false}>
                <DataTable
                    columns={this.state.tableData.column}
                    data={this.state.tableData.data}
                    noHeader
                    defaultSortField="Id"
                    defaultSortAsc={false}
                    pagination
                    highlightOnHover
                />
            </DataTableExtensions>
        )
    }
} export default SupportTeamTable