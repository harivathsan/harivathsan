import * as React from 'react';
import styles from '../PurchaseOrderAutomation.module.scss';
import { Col, Row, Table, Container, Button, Form, FormGroup, Label, Input, FormText, Toast, ToastBody, ToastHeader } from 'reactstrap';
import InputControl from '../InputComponent/inputControl';
import { ToastContainer, toast } from 'react-toastify';
import CurrencyFormat from 'react-currency-format';
class PONumberTable extends React.Component<any, any>{
    removedItems = [];
    constructor(props) {
        super(props);
        this.state = {
            rows: [{}],
            removedItems: []
        };
        this.removedItems = [];
    }
    _handleQuantityCostOnBlur = (idx) => (e) => {

        let baseCost: any = 0;
        let totalCost = 0;
        const { name, value } = e.target;
        const rows = [...this.state.rows];
        let obj = {
            [name]: value
        }
        rows[idx] = { ...rows[idx], ...obj };

        rows.map((item, index) => {

            if (item[name] != '' && item[name] != null) {

                item['TotalCost'] = Number(item[name]) * Number(item['OriginalCost']);
                baseCost = baseCost + Number(item['OriginalCost']);
                totalCost = totalCost + (item['TotalCost']);
            }
        })

        this.setState({
            rows,
            SumBaseCost: baseCost,
            SumTotalCost: totalCost
        }, () => {

            this.props.parentCallback(this.state.rows, null, 'eventCallback');
        })
        console.log('blur Function')
    }
    // _handleBaseCostOnBlur = (idx) => (e) => {

    //     let baseCost: any = 0;
    //     let totalCost = 0;
    //     const { name, value } = e.target;
    //     const rows = [...this.state.rows];
    //     let obj = {
    //         [name]: value
    //     }
    //     rows[idx] = { ...rows[idx], ...obj };

    //     rows.map((item, index) => {

    //         if (item[name] != '' && item[name] != null) {
    //             
    //             item['TotalCost'] = Number(item['Quantity']) * Number(item[name]);
    //             baseCost = baseCost + Number(item[name]);
    //             totalCost = totalCost + (item['TotalCost']);
    //         }
    //     })

    //     this.setState({
    //         rows,
    //         SumBaseCost: baseCost,
    //         SumTotalCost: totalCost
    //     }, () => {

    //         this.props.parentCallback(this.state.rows, null, 'eventCallback');
    //     })
    //     console.log('blur Function')
    // }

    _handleBaseCostOnBlur = (idx) => (e) => {

        let baseCost: any = 0;
        let totalCost = 0;
        //const { name, value } = e.target;
        const rows = [...this.state.rows];
        let obj = {
            ['OriginalCost']: e.value
        }
        rows[idx] = { ...rows[idx], ...obj };

        rows.map((item, index) => {

            if (item['OriginalCost'] != '' && item['OriginalCost'] != null) {

                item['TotalCost'] = Number(item['Quantity']) * Number(item['OriginalCost']);
                baseCost = baseCost + Number(item['OriginalCost']);
                totalCost = totalCost + (item['TotalCost']);
            }
        })

        this.setState({
            rows,
            SumBaseCost: baseCost,
            SumTotalCost: totalCost,

        }, () => {

            this.props.parentCallback(this.state.rows, null, 'eventCallback');
        })
        console.log('blur Function')
    }

    _handleTotalCostOnBlur = (idx) => (e) => {

        let SumTotalCost: any = 0;
        let totalCost = 0;
        const { name, value } = e.target;
        const rows = [...this.state.rows];
        let obj = {
            [name]: value
        }
        rows[idx] = { ...rows[idx], ...obj };
        rows.map((item, index) => {

            if (item[name] != '' && item[name] != null) {
                totalCost = totalCost + parseInt(item[name])
            }
        })

        this.setState({
            rows,
            SumTotalCost: totalCost
        }, () => {

            this.props.parentCallback(this.state.rows, null, 'eventCallback');
        })
        console.log('blur Function')
    }

    _totalCalculation = (columnName) => {
        let Cost = 0;
        this.state.rows.map((item, index) => {

            if (item[columnName] != '') {
                Cost = Cost + parseInt(item[columnName])
            }

        })
        return Cost;
    }

    _handleChange = (idx) => (e) => {

        const { name, value } = e.target;
        const rows = [...this.state.rows];
        let obj = {
            [name]: value
        }
        rows[idx] = { ...rows[idx], ...obj };



        this.setState({
            rows
        }, () => {

            this.props.parentCallback(this.state.rows, null, 'eventCallback');
        });
    };
    _validation = () => {

        for (var i = 0; i < this.state.rows.length; i++) {
            if (this.state.rows[i].Description === undefined || this.state.rows[i].Description === "") {
                toast.error('Required Description');
                return false;

            } else

                if (this.state.rows[i].Quantity === undefined || this.state.rows[i].Quantity === "") {
                    toast.error('Required Quantity');
                    return false;
                } else
                    if (this.state.rows[i].OriginalCost === undefined || this.state.rows[i].OriginalCost === "") {
                        toast.error('Required Base Cost');
                        return false;
                    } else
                        if (this.state.rows[i].TotalCost === undefined || this.state.rows[i].TotalCost === "") {
                            toast.error('Required Total Cost');
                            return false;
                        } else
                            if (this.state.rows[i].DeliveryDate === undefined || this.state.rows[i].DeliveryDate === "") {
                                toast.error('Required Delivery Date');
                                return false;
                            } else
                                if (this.state.rows[i].NetworkActivityCode === undefined || this.state.rows[i].NetworkActivityCode === "") {
                                    toast.error('Required Network Activity Code');
                                    return false;
                                } else
                                    if (this.state.rows[i].ServiceOrMaterial === undefined || this.state.rows[i].ServiceOrMaterial === null || this.state.rows[i].ServiceOrMaterial === "") {
                                        toast.error('Required Service');
                                        return false;
                                    }
                                    else if (i == (this.state.rows.length - 1)) {
                                        return true;
                                    }

        }


    }


    _handleAddRow = () => {

        if (this._validation()) {

            const orderNumber = this._generatePONumber();

            const item = {
                Description: '',
                Quantity: '',
                Units: '',
                OriginalCost: '',
                TotalCost: '',
                DeliveryDate: new Date(),
                NetworkActivityCode: '',
                ServiceOrMaterial: '',
                Taxable: '',
                ProgressPayment: '',
                BaseCost: 0
            };
            const newItems = [{ ...item, ...orderNumber }];
            this.setState({
                rows: [...this.state.rows, ...newItems]
            }, () => {

                this.props.parentCallback(this.state.rows, null, 'eventCallback');
            });
        }

    };

    _handleRemoveRow = () => {

        let baseCost: any = 0;
        //baseCost = this._totalCalculation('OriginalCost');
        this.setState({
            rows: this.state.rows.slice(0, -1),
            BaseCost: baseCost
        }, () => {

            this.props.parentCallback(this.state.rows, null, 'eventCallback');
        });
    };
    _handleRemoveSpecificRow = (idx) => () => {

        let SumBaseCost: any = 0;
        let SumTotalCost: any = 0;
        const rowData = [...this.state.rows];
        this.removedItems.push(rowData[idx])

        rowData.splice(idx, 1);
        //baseCost = this._totalCalculation('OriginalCost');
        //baseCost = this.state.BaseCost - parseInt(rowData[idx]['OriginalCost']);

        rowData.map((item, index) => {

            if (item['OriginalCost'] != '') {
                SumBaseCost = SumBaseCost + parseInt(item['OriginalCost'])
            }
            if (item['TotalCost'] != '') {
                SumTotalCost = SumTotalCost + parseInt(item['TotalCost'])
            }
        })

        this.setState({ rows: [], removedItems: this.removedItems, BaseCost: 0, TotalCost: 0 }, () => {

            this.setState({ rows: rowData, removedItems: this.removedItems, SumBaseCost: SumBaseCost, SumTotalCost: SumTotalCost })
            this.props.parentCallback(this.state.rows, this.removedItems, 'removedItemEventCallback');
        })
    }
    componentDidMount(): void {
        if (this.props.isCurrentMode == 'New') {

            const obj = this._generatePONumber();
            let rowIndex = this.state.rows.length - 1;
            const rows = [...this.state.rows];
            rows[rowIndex] = obj;
            this.setState({ rows });
            this.props.parentCallback(rows, null, 'didMountCallback');

        } else {

            let listItemsArray = [];
            let BaseCost = 0;
            let TotalCost = 0;
            this.props.ChildList.length > 0 && this.props.ChildList.map((item, index) => {
                let obj = {
                    Id: item.Id,
                    DeliveryDate: new Date(item.DeliveryDate),
                    Description: item.Description,
                    NetworkActivityCode: item.NetworkActivityCode,
                    OriginalCost: item.OriginalCost,
                    POLineNumber: item.POLineNumber,
                    ProgressPayment: item.ProgressPayment,
                    Quantity: item.Quantity,
                    ReqAndLineNumber: item.ReqAndLineNumber,
                    SerialNumber: item.SerialNumber,
                    ServiceOrMaterial: item.ServiceOrMaterial,
                    Taxable: item.Taxable,
                    TotalCost: item.TotalCost,
                    Units: item.Units
                }
                listItemsArray.push(obj);
                if (item.OriginalCost != '' && item.OriginalCost != null) {
                    BaseCost = BaseCost + parseInt(item.OriginalCost)
                }
                if (item.TotalCost != '' && item.TotalCost != null) {
                    TotalCost = TotalCost + parseInt(item.TotalCost)
                }
            })

            this.setState({
                rows: listItemsArray,
                SumTotalCost: TotalCost,
                SumBaseCost: BaseCost
            })
        }


    }
    _generatePONumber = () => {

        const PONumber = this.props.SerialNumber.slice(this.props.SerialNumber.indexOf('-') + 1);
        const ReqAndLineNumber = this.props.SerialNumber.slice(0, -4);
        let obj = {}
        return obj = {
            ['SerialNumber']: this.props.SerialNumber,
            ['POLineNumber']: PONumber,
            ['ReqAndLineNumber']: ReqAndLineNumber + ' Line ' + PONumber,
            ['DeliveryDate']: new Date(),
            ['OriginalCost']: 0
        };
    }
    _onFormatDate = (date: Date): string => {
        return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
    };

    _onDeliveryDate = (idx) => (date, e) => {

        //const { name, value } = e.target;
        const rows = [...this.state.rows];
        let obj = {
            ['DeliveryDate']: date
        }
        rows[idx] = { ...rows[idx], ...obj };
        this.setState({ rows }, () => {

            this.props.parentCallback(this.state.rows, null, 'eventCallback');
        });

    }
    render() {

        return (
            <div>
                <div className="container-fluid p-0">
                    <div className="row clearfix">
                        <div className="col-md-12 column p-0">
                            <table className="table table-bordered table-hover" id="tab_logic">
                                <thead>
                                    <tr>

                                        <th className="text-center"> PO Line Number </th>
                                        {/* <th className="text-center"> Req & Line Number </th> */}
                                        <th className="text-center"> Description <span className='require'>*</span> </th>
                                        <th className="text-center"> Quantity <span className='require'>*</span></th>
                                        <th className="text-center"> Units </th>
                                        <th className="text-center"> Base Cost <span className='require'>*</span></th>
                                        <th className="text-center"> Total Cost <span className='require'>*</span></th>
                                        <th className="text-center"> Delivery Date <span className='require'>*</span></th>
                                        <th className="text-center"> Network Activity Code <span className='require'>*</span> </th>
                                        <th className="text-center"> ServiceOrMaterial <span className='require'>*</span> </th>
                                        <th className="text-center"> Taxable</th>
                                        <th className="text-center"> Progress Payment </th>
                                        <th />
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.rows.map((item, idx) => {

                                        return (
                                            <tr id="addr0" key={idx}>

                                                <td>
                                                    <InputControl

                                                        isRequire={true}
                                                        type="textonly"
                                                        name="POLineNumber"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['POLineNumber']}
                                                        onTextblur={this._handleChange(idx)}
                                                        isdisabled={this.props.isViewMode} />
                                                    {/* <input
                                                        type="text"
                                                        name="name"
                                                        value={this.state.rows[idx]['name']}
                                                        onChange={this._handleChange(idx)}
                                                        className="form-control"
                                                    /> */}
                                                </td>
                                                {/* <td>
                                                    <InputControl

                                                        isRequire={true}
                                                        type="textonly"
                                                        name="ReqAndLineNumber"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['ReqAndLineNumber']}
                                                        onTextblur={this._handleChange(idx)}
                                                        isdisabled={true} />

                                                </td> */}
                                                <td>
                                                    <InputControl
                                                        isRequire={true}
                                                        type="textonly"
                                                        name="Description"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['Description']}
                                                        onTextblur={this._handleChange(idx)}
                                                        isdisabled={this.props.isViewMode} />

                                                </td>
                                                <td>
                                                    <InputControl
                                                        isRequire={true}
                                                        isblur={true}
                                                        type="textonly"
                                                        name="Quantity"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['Quantity']}
                                                        onTextblur={this._handleChange(idx)}
                                                        isdisabled={this.props.isViewMode}
                                                        blurfunction={this._handleQuantityCostOnBlur(idx)} />

                                                </td>
                                                <td>
                                                    <InputControl
                                                        isRequire={true}
                                                        type="textonly"
                                                        name="Units"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['Units']}
                                                        onTextblur={this._handleChange(idx)}
                                                        isdisabled={this.props.isViewMode} />

                                                </td>
                                                <td>
                                                    <CurrencyFormat disabled={this.props.isViewMode}
                                                        onValueChange={this._handleBaseCostOnBlur(idx)}
                                                        name="OriginalCost"
                                                        value={this.state.rows[idx]['OriginalCost']}
                                                        thousandSeparator={true}
                                                        className="form-control"
                                                        inputmode="numeric" />
                                                    {/* <InputControl
                                                        isRequire={true}
                                                        inptType="number"
                                                        type="textOnlyBlur"
                                                        name="OriginalCost"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['OriginalCost']}
                                                        onblur={this._handleBaseCostOnBlur(idx)}
                                                        isdisabled={this.props.isViewMode} /> */}

                                                </td>
                                                <td>
                                                    <CurrencyFormat disabled={true}
                                                        onValueChange={this._handleBaseCostOnBlur(idx)}
                                                        name="TotalCost"
                                                        value={this.state.rows[idx]['TotalCost']}
                                                        thousandSeparator={true}
                                                        className="form-control"
                                                        inputmode="numeric" />
                                                    {/* <InputControl
                                                        isRequire={true}
                                                        inptType="number"
                                                        type="textOnlyBlur"
                                                        name="TotalCost"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['TotalCost']}
                                                        onblur={this._handleTotalCostOnBlur(idx)}
                                                        isdisabled={true} /> */}

                                                </td>
                                                <td>
                                                    <InputControl

                                                        isRequire={true}
                                                        type="dateonly"
                                                        name="DeliveryDate"
                                                        placeholder=""
                                                        //onTextblur={this._handleChange(idx)}                                                                                                                             
                                                        id={'DeliveryDate'}
                                                        defaultValue={this.state.rows[idx]['DeliveryDate']}
                                                        formatDate={this._onFormatDate}
                                                        onDateHandleChange={this._onDeliveryDate(idx)}
                                                        isdisabled={this.props.isViewMode}
                                                    />

                                                </td>
                                                <td>
                                                    <InputControl
                                                        isRequire={true}
                                                        type="textonly"
                                                        name="NetworkActivityCode"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['NetworkActivityCode']}
                                                        onTextblur={this._handleChange(idx)}
                                                        isdisabled={this.props.isViewMode} />

                                                </td>
                                                <td>
                                                    <InputControl
                                                        isRequire={true}
                                                        inputClassName={styles.selectWidth}
                                                        type="selectonly"
                                                        name="ServiceOrMaterial"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['ServiceOrMaterial']}
                                                        selectOnchange={this._handleChange(idx)}
                                                        options={this.props.MasterDataService}
                                                        isdisabled={this.props.isViewMode} />

                                                </td>
                                                <td>
                                                    <InputControl
                                                        isRequire={true}
                                                        inputClassName={styles.selectWidth}
                                                        type="selectonly"
                                                        name="Taxable"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['Taxable']}
                                                        selectOnchange={this._handleChange(idx)}
                                                        options={this.props.MasterDataTaxable}
                                                        isdisabled={this.props.isViewMode} />

                                                </td>
                                                <td>
                                                    <InputControl
                                                        isRequire={true}
                                                        inputClassName={styles.selectWidth}
                                                        type="selectonly"
                                                        name="ProgressPayment"
                                                        placeholder=""
                                                        defaultValue={this.state.rows[idx]['ProgressPayment']}
                                                        selectOnchange={this._handleChange(idx)}
                                                        options={this.props.MasterDataProgressPayment}
                                                        isdisabled={this.props.isViewMode} />

                                                </td>
                                                {this.props.isViewMode != true &&
                                                    <td>
                                                        {idx !== 0 && <span onClick={this._handleRemoveSpecificRow(idx)}>X</span>}

                                                    </td>
                                                }
                                            </tr>
                                        )

                                    })}
                                </tbody>
                            </table>
                            <Row>
                                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                                    <InputControl
                                        label={'Total Original Cost'}
                                        labelClassName={styles.label}
                                        type="labelwithCurrencyFormat"
                                        labelValue={this.state.SumBaseCost}
                                    />
                                </Col>
                                <Col xs={5} sm={5} md={5} lg={5} xl={5}>

                                    <InputControl
                                        label={'Total Cost'}
                                        labelClassName={styles.label}
                                        type="labelwithCurrencyFormat"
                                        labelValue={this.state.SumTotalCost}
                                    />

                                </Col>
                                {this.props.isViewMode != true && <Col xs={1} sm={1} md={1} lg={1} xl={1} className="pr-0">
                                    <button onClick={this._handleAddRow} className="btn btn-primary float-right">
                                        Add Row
                                    </button>
                                </Col>}
                            </Row>
                            {/* <button
                                onClick={this._handleRemoveRow}
                                className="btn btn-danger float-right"
                            >
                                Delete Last Row
                            </button> */}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default PONumberTable;