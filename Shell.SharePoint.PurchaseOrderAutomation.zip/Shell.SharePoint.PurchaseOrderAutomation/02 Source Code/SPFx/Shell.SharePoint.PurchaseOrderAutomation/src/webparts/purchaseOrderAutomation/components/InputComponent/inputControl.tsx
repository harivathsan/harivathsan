import * as React from 'react';
import { Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import classNames from 'classnames';
import CurrencyFormat from 'react-currency-format';
const infoImg = 'https://eu023-sp.shell.com/sites/SPOAA0342/PurchaseOrder/SiteAssets/assets/images/informationIcon.png';


const InputControl = (props) => {
    if (props.type == "dayCount") {
        const { dateFrom, dateEnd } = props;
        let date1: any = dateFrom != null ? new Date(dateFrom) : new Date();
        let date2: any = props.Status == 'Close' ? new Date(dateEnd) : new Date();
        let start = Math.floor(date1.getTime() / (3600 * 24 * 1000)); //days as integer from..
        let end = Math.floor(date2.getTime() / (3600 * 24 * 1000)); //days as integer from..
        let days = (end - start);

        return (
            <React.Fragment>

                <span> {days} </span>


            </React.Fragment>
        );
    }
    if (props.type == "labelwithtext") {
        const { id, name, placeholder, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, labelValue } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Label for={name} className={labelClassName}>{label} </Label>
                    <span className={labelClassName}> {labelValue} </span>

                </FormGroup>
            </React.Fragment>
        );
    }
    if (props.type == "labelwithCurrencyFormat") {
        const { id, name, placeholder, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, labelValue } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Label for={name} className={labelClassName}>{label} </Label>
                    <span className={labelClassName}>  <CurrencyFormat value={labelValue} displayType={'text'} thousandSeparator={true} /> </span>

                </FormGroup>
            </React.Fragment>
        );
    }



    if (props.type == "textonly") {
        const { id, name, placeholder, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, labelValue, isblur, blurfunction } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    {isblur == true ?
                        <Input type="text" name={name} id={id} placeholder={placeholder} defaultValue={defaultValue} onChange={onTextblur} onBlur={blurfunction} disabled={isdisabled} /> :
                        <Input type="text" name={name} id={id} placeholder={placeholder} defaultValue={defaultValue} onChange={onTextblur} disabled={isdisabled} />}
                    {/* <Input type="text" name={name} id={id} placeholder={placeholder} defaultValue={defaultValue} onChange={onTextblur} disabled={isdisabled} /> */}
                </FormGroup>
            </React.Fragment>
        );
    }
    if (props.type == "textOnlyBlur") {
        const { id, name, inptType, placeholder, label, isRequire, defaultValue, onblur, labelClassName, isdisabled, labelValue } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Input type={inptType} name={name} id={id} placeholder={placeholder} defaultValue={defaultValue} onBlur={onblur} disabled={isdisabled} />
                </FormGroup>
            </React.Fragment>
        );
    }
    if (props.type == "selectonly") {
        const { id, name, placeholder, options, selectOnchange, label, isRequire, defaultValue, onTextblur, inputClassName, labelClassName, isdisabled, labelValue } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Input type="select" name={name} id={id} onChange={selectOnchange} disabled={isdisabled} className={inputClassName}>
                        {!defaultValue || defaultValue === undefined ? <option value="" selected >Select</option> : null}
                        {options.length > 0 && options.map((item: any, index: number) => {
                            return (
                                <option value={item.value}
                                    selected={item.value == defaultValue ? true : false}
                                >{item.label}</option>
                            );
                        })
                        }
                    </Input>
                </FormGroup>
            </React.Fragment>
        );
    }

    if (props.type == "DataTableSelectonly") {
        const { id, name, placeholder, options, selectOnchange, label, isRequire, defaultValue, onTextblur, inputClassName, labelClassName, isdisabled, labelValue } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Input type="select" name={name} id={id} onChange={selectOnchange} disabled={isdisabled} className={inputClassName}>
                        {/* {!defaultValue || defaultValue === undefined ? <option value="" selected >Select</option> : null} */}
                        {options.length > 0 && options.map((item: any, index: number) => {
                            return (
                                <option value={item.value}
                                    selected={item.value == defaultValue ? true : false}
                                >{item.label}</option>
                            );
                        })
                        }
                    </Input>
                </FormGroup>
            </React.Fragment>
        );
    }
    if (props.type == "dateonly") {
        const { id, name, placeholder, options, onDateHandleChange, selectOnchange, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, labelValue } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <DatePicker
                        id={id}
                        placeholder={placeholder}
                        name={name}
                        selected={defaultValue}
                        onChange={onDateHandleChange}
                        dateFormat="MM/dd/yyyy"
                        disabled={isdisabled}
                    />
                </FormGroup>
            </React.Fragment>
        );
    }


    if (props.type == "number") {
        const { id, name, placeholder, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, isInfo, tooltipMsg } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Label for={name} className={labelClassName}>{label} {isRequire && <span className='require'>*</span>}
                        {isInfo && <div className="tooltipinfo"><img className='infoIcon' src={infoImg} />
                            <span className="tooltiptext">{tooltipMsg}</span>
                        </div>
                        }
                    </Label>
                    <Input type="number" step="any" name={name} id={id} placeholder={placeholder} defaultValue={defaultValue} onChange={onTextblur} disabled={isdisabled} />
                </FormGroup>
            </React.Fragment>
        );
    }
    if (props.type == "text") {
        const { id, name, placeholder, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, isInfo, tooltipMsg } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Label for={name} className={labelClassName}>{label} {isRequire && <span className='require'>*</span>}
                        {isInfo && <div className="tooltipinfo"><img className='infoIcon' src={infoImg} />
                            <span className="tooltiptext">{tooltipMsg}</span>
                        </div>
                        }</Label>
                    <Input type="text" name={name} id={id} placeholder={placeholder} defaultValue={defaultValue} onChange={onTextblur} disabled={isdisabled} />
                </FormGroup>
            </React.Fragment>
        );
    }

    if (props.type == "CurrencyFormat") {
        const { id, name, placeholder, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, isInfo, tooltipMsg } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    <Label for={name} className={labelClassName}>{label} {isRequire && <span className='require'>*</span>}
                        {isInfo && <div className="tooltipinfo"><img className='infoIcon' src={infoImg} />
                            <span className="tooltiptext">{tooltipMsg}</span>
                        </div>
                        }</Label>
                    <CurrencyFormat
                        onValueChange={onTextblur}
                        name={name}
                        value={defaultValue}
                        thousandSeparator={true}
                        className="form-control"
                        inputmode="numeric"
                        disabled={isdisabled} />

                </FormGroup>
            </React.Fragment>
        );
    }

    if (props.type == "date") {
        const { id, name, placeholder, label, isRequire, defaultValue, onDateHandleChange, labelClassName, isdisabled, formatDate, isInfo, tooltipMsg } = props;
        return (
            <React.Fragment>
                <FormGroup>
                    {label != undefined && <>  <Label for={name} className={labelClassName}>{label} {isRequire && <span className='require'>*</span>}
                        {isInfo && <div className="tooltipinfo"><img className='infoIcon' src={infoImg} />
                            <span className="tooltiptext">{tooltipMsg}</span>
                        </div>
                        }</Label>
                    </>
                    }
                    <DatePicker
                        id={id}
                        placeholder={placeholder}
                        name={name}
                        selected={defaultValue}
                        onChange={onDateHandleChange}
                        dateFormat="MM/dd/yyyy"
                        disabled={isdisabled}
                    />
                    {/* <Input
                        type="date"
                        name={name}
                        id={id}
                        placeholder="date placeholder"
                        onChange={onDateHandleChange}
                        value={defaultValue}
                        formatDate={formatDate}
                        //data-date-format="dd/mm/yyyy"
                        disabled={isdisabled}
                    /> */}
                    {/* <DatePicker selected={defaultValue} onChange={onDateHandleChange}
                 scrollableYearDropdown
                 showMonthDropdown
                 yearDropdownItemNumber={15}
                 autoComplete="off"
                 showYearDropdown 
                 dateFormat={configuration.dateFormat}
                 placeholderText={configuration.dateFormat}               
                  /> */}
                </FormGroup>
            </React.Fragment>
        );
    }

    if (props.type == "select") {
        const { id, name, options, selectOnchange, label, isRequire, defaultValue, labelClassName, isdisabled, isInfo, tooltipMsg } = props;
        return (
            <FormGroup>
                <Label for={name} className={labelClassName}>{label} {isRequire && <span className='require'>*</span>}
                    {isInfo && <div className="tooltipinfo"><img className='infoIcon' src={infoImg} />
                        <span className="tooltiptext">{tooltipMsg}</span>
                    </div>
                    }</Label>
                <Input type="select" name={name} id={id} onChange={selectOnchange} disabled={isdisabled}>
                    {!defaultValue || defaultValue === undefined ? <option value="" selected >Select</option> : null}
                    {options.length > 0 && options.map((item: any, index: number) => {
                        return (
                            <option value={item.value}
                                selected={item.value == defaultValue ? true : false}
                            >{item.label}</option>
                        );
                    })
                    }
                </Input>
            </FormGroup>
        )
    }
    if (props.type == "textarea") {
        const { id, name, placeholder, label, isRequire, defaultValue, onTextblur, labelClassName, isdisabled, isInfo, tooltipMsg } = props;
        return (
            <FormGroup>
                <Label for={name} className={labelClassName}>{label}{isRequire && <span className='require'>*</span>}
                    {isInfo && <div className="tooltipinfo"><img className='infoIcon' src={infoImg} />
                        <span className="tooltiptext">{tooltipMsg}</span>
                    </div>
                    }</Label>
                <Input type="textarea" name={name} id={id} defaultValue={defaultValue} onChange={onTextblur} disabled={isdisabled} />
            </FormGroup>
        )
    }
    if (props.type == "checkbox") {
        const { id, name, placeholder, label, isRequire, defaultValue, value, checked, onTextblur, labelClassName, isdisabled } = props;

        return (
            <React.Fragment>
                <FormGroup check inline>

                    <Input type="checkbox" name={name} id={id} value={value} defaultchecked={checked} onChange={onTextblur} disabled={isdisabled} />
                    <Label for={name} className={labelClassName}>{label} {isRequire && <span>*</span>}</Label>
                </FormGroup>
            </React.Fragment>
        );
    }

}

export default InputControl;