import * as React from 'react';
import styles from '../PurchaseOrderAutomation.module.scss';
import 'react-accessible-accordion/dist/fancy-example.css';
//import PropTypes from "prop-types";
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { ToastContainer, toast } from 'react-toastify';
import { isEmptyOrUndefine, isEmpty } from '../../../utils/commonUtils';
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
import classNames from 'classnames';
import InputControl from '../InputComponent/inputControl';
import { Col, Row, Table, Container, Button, Form, FormGroup, Label, Input, FormText, Toast, ToastBody, ToastHeader, Modal, ModalBody, ModalHeader, ModalFooter, } from 'reactstrap';
import PONumberTable from '../PO-Numbertable/poNumberTable';
import ReactTable from "react-table";
import { FilePond, registerPlugin } from "react-filepond";
// Import FilePond styles
import "filepond/dist/filepond.min.css";
import FilePondPluginImageExifOrientation from "filepond-plugin-image-exif-orientation";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";
import ServicesRequestTable from '../ServicesRequesterTable/ServicesReqesterTable';
import SupportTeamTable from '../SupportTeamTable/SupportTeamTable';
import { Item } from 'sp-pnp-js';
import CurrencyFormat from 'react-currency-format';
// Register the plugins
registerPlugin(FilePondPluginImageExifOrientation, FilePondPluginImagePreview);

import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/folders";

const ServicesRequestList = (props) => {
    return (
        <>
            {props.CurrentUserPurchaseOrderItems.length > 0 && <Table bordered striped>
                <thead>
                    <tr>
                        <th scope="row"> Request Number</th>
                        <th scope="row">Created On Date</th>
                        <th scope='row'>Project Name</th>
                        <th scope='row'>Supplier Name</th>
                        <th scope='row'>PO Description</th>
                        <th scope='row'>Estimated Commitment value</th>
                        <th scope="row"> Status </th>
                        <th scope="row"> </th>

                    </tr>
                </thead>
                <tbody>
                    {props.CurrentUserPurchaseOrderItems.map((item, index) => {

                        return (
                            <tr className={styles.tr_Border}>
                                <td>{item.SerialNumber}</td>
                                <td>{item.Date != null && <InputControl
                                    type={'date'}
                                    labelClassName={styles.label}
                                    id={'date' + index}
                                    name={'date'}
                                    defaultValue={new Date(item.Date)}
                                    formatDate={props.onFormatDate}
                                    onDateHandleChange={props.onCreateDate}
                                    isdisabled={true}
                                />
                                }</td>
                                <td>{item.ProjectName}</td>
                                <td>{item.VendorName}</td>
                                <td>{item.PODescription}</td>
                                <td>{item.EstimatedCommitment}</td>
                                <td>{item.Status}</td>
                                <td className='float-right' id={item.Id}>
                                    {(item.Status == 'Draft' || item.Status == 'Rejected') && <Button outline id={item.Id} data-name={item.Status} onClick={props.onEdit}>Edit</Button>}
                                    {item.Status == 'Open' && <Button outline id={item.Id} onClick={props.onView}>View</Button>}
                                </td>

                            </tr>
                        )
                    })}
                </tbody>
            </Table>
            }
        </>
    )
}

const SupportTeamList = (props) => {

    return (
        <>
            {props.CurrentUserSupportTeamItems.length > 0 && <Table bordered striped>
                <thead>
                    <tr>
                        <th scope="row"> Request No</th>
                        <th scope="row"> Date Submitted </th>
                        <th scope="row"> Project Type</th>
                        <th scope="row"> Req Analyst</th>
                        <th scope="row"> Status</th>
                        <th scope="row"> Purchase Order Number</th>
                        <th scope="row"> Alteration No</th>
                        <th scope="row"> Date Closed</th>
                        <th scope="row"> No of Days</th>

                    </tr>
                </thead>
                <tbody>
                    {props.CurrentUserSupportTeamItems.map((item, index) => {
                        let date1: any = item.submittedDate != null ? new Date(item.submittedDate) : new Date();
                        let date2: any = item.Status == 'Close' ? new Date(item.DateClosed) : new Date();
                        //let days = (end - start) / 1000 / 60 / 60 / 24;
                        let start = Math.floor(date1.getTime() / (3600 * 24 * 1000)); //days as integer from..
                        let end = Math.floor(date2.getTime() / (3600 * 24 * 1000)); //days as integer from..
                        let days = (end - start)
                        console.log(days);
                        //days = days - (end.getTimezoneOffset() - start.getTimezoneOffset()) / (60 * 24);
                        return (
                            <tr className={styles.tr_Border}>
                                <td>{item.SerialNumber}</td>
                                <td>
                                    {item.submittedDate != null && <InputControl
                                        type={'date'}
                                        labelClassName={styles.label}
                                        id={'submittedDate_' + index}
                                        name={'submittedDate'}
                                        defaultValue={new Date(item.submittedDate)}
                                        formatDate={props.onFormatDate}
                                        onDateHandleChange={props.onCreateDate}
                                        isdisabled={true}
                                    />
                                    }</td>
                                <td>{item.ProjectType}</td>
                                <td>{item.RequestorName}</td>
                                <td>{item.Status}</td>
                                <td>{item.SerialNumber.slice(item.SerialNumber.indexOf('-') + 1)}</td>
                                <td>{item.AlterationNo}</td>
                                <td>{item.DateClosed}</td>
                                <td>{days}</td>

                                <td className='float-right' id={item.Id}>
                                    {item.Status == 'Close' && <Button outline id={item.Id} onClick={props.onView}>View</Button>}
                                    {item.Status == 'Open' && <Button outline id={item.Id} onClick={props.onEdit}>Edit</Button>}
                                </td>

                            </tr>
                        )
                    })}
                </tbody>
            </Table>
            }
        </>
    )
}

const FormFiled = (props: any) => {
    debugger;
    return (
        <>   <h3>Purchase Request Summary</h3>
            <Col xs={12} sm={12} md={12} lg={12} xl={12} >
                <Row>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            label={'Request No'}
                            labelClassName={styles.label}
                            type="labelwithtext"
                            labelValue={props.isCurrentMode == 'New' ? props.SerialNumber : props.listItems.SerialNumber}
                        />
                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6} className="float-right text-right">
                        <InputControl
                            type={'date'}
                            labelClassName={styles.label}
                            label={'Date of Request:'}
                            id={'Date'}
                            name={'Date'}
                            defaultValue={props.isCurrentMode == 'New' ? props.Date : new Date(props.listItems.Date)}
                            formatDate={props.onFormatDate}
                            onDateHandleChange={props.onCreateDate}
                            isdisabled={true}
                        />
                        {/* <InputControl
                            label={'Created on'}
                            labelClassName={styles.label}
                            type="labelwithtext"
                            labelValue={props.listItems.Date}
                        /> */}
                    </Col>
                </Row>

            </Col>

            <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.panel_border}>
                <Row >
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        {/* {(props.isCurrentMode == 'New') && <PeoplePicker
                            context={props.context}
                            titleText="Requestor's Name"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users                    
                            ensureUser={true}
                            required={true}
                            onChange={props.GetPepoleRequestorName}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}

                        />} */}
                        {
                            (props.isCurrentMode == 'New') && <PeoplePicker
                                context={props.context}
                                titleText="Requestor's Name"
                                personSelectionLimit={1}
                                groupName={""} // Leave this blank in case you want to filter from all users 
                                defaultSelectedUsers={[props.CurrentUserInfo.Email]}
                                ensureUser={true}
                                required={true}
                                onChange={props.GetPepoleRequestorName}
                                showHiddenInUI={false}
                                principalTypes={[PrincipalType.User]}
                                resolveDelay={1000}
                                disabled={true}

                            />
                        }
                        {(props.isCurrentMode != 'New') && <PeoplePicker
                            context={props.context}
                            titleText="Requestor's Name"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users 
                            defaultSelectedUsers={[props.listItems.RequestorEmail]}
                            ensureUser={true}
                            required={true}
                            onChange={props.GetPepoleRequestorName}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}
                            disabled={true}

                        />}

                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        {!props.isViewMode && <label className={styles.label}> Attachment - MOA Approval <span className='require'>*</span> </label>}
                        {props.isViewMode && <label className={styles.label}>Upload documents - MOA Approval <span className='require'>*</span> </label>}
                        {!props.isViewMode && <input className={styles.uploadControl} type="file" name="MOAApproval" multiple onChange={props.onFileUpload} id='MOAApproval' />}
                        {props.MOAfileloader && <img className={styles.imgloader} src={props.webURL + "/SiteAssets/assets/images/loder.gif"}></img>}

                        {

                            props.MOAApprovalUploadFileList.length > 0 ? props.MOAApprovalUploadFileList.map((file, index) => {
                                debugger;
                                return (
                                    <span className={styles.attachmentFiles} id={"File" + index} >
                                        <a href={'https://eu023-sp.shell.com' + file.ServerRelativeUrl} download={'https://eu023-sp.shell.com' + file.ServerRelativeUrl}>{file.Name}</a>
                                        {!props.isViewMode && <i className={styles.close_button} title="Remove" data-foldername={'MOA-Approval-'} data-section={'MOAApproval'} data-url={file.ServerRelativeUrl} onClick={props.DeleteUploadedDoc} />}
                                    </span>
                                );

                            }) : <span>No Records</span>}

                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            label={'Vendor Name'}
                            labelClassName={styles.label}
                            isRequire={true}
                            type="text"
                            name="VendorName"
                            placeholder=""
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.VendorName : ''}
                            onTextblur={props.onHandlechange}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'The 3rd Party Company name we are buying from'} />
                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        {!props.isViewMode && <label className={styles.label}> Attachment - Supplier CTR/Quote <span className='require'>*</span></label>}
                        {props.isViewMode && <label className={styles.label}>Upload documents - Supplier CTR/Quote <span className='require'>*</span></label>}
                        {!props.isViewMode && <input className={styles.uploadControl} type="file" name="SupplierCTR" multiple onChange={props.onFileUpload} id='SupplierCTR' />}
                        {props.Supplierfileloader && <img className={styles.imgloader} src={props.webURL + "/SiteAssets/assets/images/loder.gif"}></img>}

                        {
                            props.SupplierUploadFileList.length > 0 ? props.SupplierUploadFileList.map((file, index) => {
                                return (
                                    <span className={styles.attachmentFiles} id={"File" + index} >
                                        <a href={'https://eu023-sp.shell.com' + file.ServerRelativeUrl} download={'https://eu023-sp.shell.com' + file.ServerRelativeUrl}>{file.Name}</a>
                                        {!props.isViewMode && <i className={styles.close_button} title="Remove" data-foldername={'SupplierCTR-'} data-section={'SupplierCTR'} data-url={file.ServerRelativeUrl} onClick={props.DeleteUploadedDoc} />}
                                    </span>
                                );

                            }) : <span>No Records</span>}

                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            label={'PO Description'}
                            labelClassName={styles.label}
                            isRequire={true}
                            type="textarea"
                            name="PODescription"
                            placeholder=""
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.PODescription : ""}
                            onTextblur={props.onHandlechange}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'Short description of this purchase'} />
                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        {!props.isViewMode && <label className={styles.label}>Attachment - Other </label>}
                        {props.isViewMode && <label className={styles.label}>Upload documents - Other </label>}
                        {!props.isViewMode && <input className={styles.uploadControl} type="file" name="Other" multiple onChange={props.onFileUpload} id='Other' />}
                        {props.Otherfileloader && <img className={styles.imgloader} src={props.webURL + "/SiteAssets/assets/images/loder.gif"}></img>}

                        {
                            props.OtherUploadFileList.length > 0 ? props.OtherUploadFileList.map((file, index) => {
                                return (
                                    <span className={styles.attachmentFiles} id={"File" + index} >
                                        <a href={'https://eu023-sp.shell.com' + file.ServerRelativeUrl} download={'https://eu023-sp.shell.com' + file.ServerRelativeUrl}>{file.Name}</a>
                                        {!props.isViewMode && <i className={styles.close_button} title="Remove" data-foldername={'Other-'} data-section={'Other'} data-url={file.ServerRelativeUrl} onClick={props.DeleteUploadedDoc} />}
                                    </span>
                                );

                            }) : <span>No Records</span>}

                    </Col>



                    <Col xs={6} sm={6} md={6} lg={6} xl={6} className='mb-3'>
                        {(props.isCurrentMode == 'New') && <PeoplePicker
                            context={props.context}
                            titleText="MoA Approver Name"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users                    
                            ensureUser={true}
                            required={true}
                            onChange={props.GetPepoleMOAApprover}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}

                        />}
                        {(props.isCurrentMode != 'New') && <PeoplePicker
                            context={props.context}
                            titleText="MoA Approver Name"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users 
                            defaultSelectedUsers={[props.listItems.MOAApproverEmail]}
                            ensureUser={true}
                            required={true}
                            onChange={props.GetPepoleMOAApprover}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}
                            disabled={props.isViewMode}

                        />}

                    </Col>



                    <Col xs={6} sm={6} md={6} lg={6} xl={6} className="mb-3">
                        {(props.isCurrentMode == 'New') && <PeoplePicker
                            context={props.context}
                            titleText="Invoice Approver Name"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users                    
                            ensureUser={true}
                            required={true}
                            onChange={props.GetPepoleInvoiceApprover}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}

                        />}
                        {(props.isCurrentMode != 'New') && <PeoplePicker
                            context={props.context}
                            titleText="Invoice Approver Name"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users  
                            defaultSelectedUsers={[props.listItems.InvoiceApproverEmail]}
                            ensureUser={true}
                            required={true}
                            onChange={props.GetPepoleInvoiceApprover}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}
                            disabled={props.isViewMode}

                        />}

                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            type={'select'}
                            labelClassName={styles.label}
                            label={'Project Type'}
                            id={'ProjectType'}
                            name={'ProjectType'}
                            isRequire={true}
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.ProjectType : ''}
                            selectOnchange={props.onHandlechange}
                            options={props.MasterDataProjectType}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'Greenfield = Material and Flagship Projects only'}
                        />

                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            label={'Vendor Contract Number'}
                            labelClassName={styles.label}
                            isRequire={false}
                            type="text"
                            name="VendorContractNumber"
                            placeholder=""
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.VendorContractNumber : ""}
                            onTextblur={props.onHandlechange}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'Your C&P Contact has this number. i.e. CWxxxx9'} />
                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            label={'Project Name'}
                            labelClassName={styles.label}
                            isRequire={true}
                            type="text"
                            name="ProjectName"
                            placeholder=""
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.ProjectName : ''}
                            onTextblur={props.onHandlechange}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'Add Specific project that this prchase is charging.'} />
                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            label={'Vendor Outline Agreement Number'}
                            labelClassName={styles.label}
                            isRequire={false}
                            type="text"
                            name="VendorOutlineAgreementNumber"
                            placeholder=""
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.VendorOutlineAgreementNumber : ""}
                            onTextblur={props.onHandlechange}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'Not Mandatory; C&P has this information if required.(10 digits) and Item # (4 digits)'} />
                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        {/* <CurrencyFormat onValueChange={(ev) => props.handleCurrencyChange(ev)} name="EstimatedCommitment" value={props.isCurrentMode != 'New' ? props.listItems.EstimatedCommitment : props.EstimatedCommitment} thousandSeparator={true} className="some" inputmode="numeric" /> */}
                        {<InputControl
                            label={'Estimated Commitment'}
                            labelClassName={styles.label}
                            isRequire={true}
                            type="CurrencyFormat"
                            name="EstimatedCommitment"
                            placeholder=""
                            defaultValue={props.isCurrentMode == 'View' ? props.listItems.EstimatedCommitment : props.EstimatedCommitment}
                            //defaultValue={props.listItems.EstimatedCommitment}
                            onTextblur={(ev) => props.handleCurrencyChange(ev)}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'Total Value of this purchase request.'} />}
                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6} id={'CPBuyer'}>
                        {(props.isCurrentMode == 'New') && <PeoplePicker
                            context={props.context}
                            titleText="C&P Buyer"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users                                             
                            ensureUser={true}

                            onChange={props.GetPepoleCPBuyer}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}
                            required={false}

                        />}
                        {(props.isCurrentMode != 'New') && <PeoplePicker
                            context={props.context}
                            titleText="C&P Buyer"
                            personSelectionLimit={1}
                            groupName={""} // Leave this blank in case you want to filter from all users  
                            defaultSelectedUsers={[props.listItems.CPBuyerEmail]}
                            ensureUser={true}
                            onChange={props.GetPepoleCPBuyer}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}
                            disabled={props.isViewMode}
                            required={false}


                        />}

                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}></Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            label={'Project Service Name'}
                            labelClassName={styles.label}
                            isRequire={false}
                            type="text"
                            name="ProjectServicesName"
                            placeholder=""
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.ProjectServicesName : ''}
                            onTextblur={props.onHandlechange}
                            isdisabled={props.isViewMode}
                            isInfo={true}
                            tooltipMsg={'Project Services Cost Analyst assigned to the project.'} />
                    </Col>
                </Row>
            </Col>




        </>
    )
}


const PoListForm = (props) => {
    return (
        <>
            <Row>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Vendor Contact Name'}
                        labelClassName={styles.label}
                        isRequire={true}
                        type="text"
                        name="VendorContactName"
                        placeholder=""
                        defaultValue={props.isCurrentMode != 'New' ? props.listItems.VendorContactName : ""}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isViewMode}
                        isInfo={true}
                        tooltipMsg={'The name of the person at the vendor you spoke to for this purchase agreement'} />
                </Col>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        type={'select'}
                        labelClassName={styles.label}
                        label={'Offshore Services'}
                        id={'OffshoreServices'}
                        name={'OffshoreServices'}
                        isRequire={false}
                        defaultValue={props.isCurrentMode != 'New' ? props.listItems.OffshoreServices : ""}
                        selectOnchange={props.onHandlechange}
                        options={props.MasterDataOffshoreServices}
                        isdisabled={props.isViewMode}
                    />

                </Col>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Vendor Contact Phone'}
                        labelClassName={styles.label}
                        isRequire={false}
                        type="text"
                        name="VendorContactPhoneNumber"
                        placeholder=""
                        defaultValue={props.isCurrentMode != 'New' ? props.listItems.VendorContactPhoneNumber : ""}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isViewMode} />
                </Col>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Commentary/Instructions'}
                        labelClassName={styles.label}
                        isRequire={false}
                        type="textarea"
                        name="CommentaryInstructions"
                        placeholder=""
                        defaultValue={props.isCurrentMode != 'New' ? props.listItems.CommentaryInstructions : ""}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isViewMode}
                        isInfo={true}
                        tooltipMsg={'Note or guidance to the requisitioners about this purchase.'} />
                </Col>


                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Vendor Contact E-mail Address'}
                        labelClassName={styles.label}
                        isRequire={true}
                        type="text"
                        name="VendorContactEmailAddress"
                        placeholder=""
                        defaultValue={props.isCurrentMode != 'New' ? props.listItems.VendorContactEmailAddress : ""}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isViewMode} />
                </Col>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}></Col>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Vendor SAP # '}
                        labelClassName={styles.label}
                        isRequire={false}
                        type="text"
                        name="VendorSAP"
                        placeholder=""
                        defaultValue={props.isCurrentMode != 'New' ? props.listItems.VendorSAP : ""}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isViewMode}
                        isInfo={true}
                        tooltipMsg={'Not Mandatory; 6 digits,C&P can provide this information'} />
                </Col>





            </Row>
        </>
    )
}

const SupportTeamForm = (props) => {
    debugger;
    return (
        <>
            <Row>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Alteration No'}
                        labelClassName={styles.label}
                        isRequire={true}
                        type="number"
                        name="AlterationNo"
                        placeholder=""
                        defaultValue={props.listItems.AlterationNo}
                        onTextblur={props.onHandlechange}
                        isdisabled={true} />
                </Col>

                {/* <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Requisition No'}
                        labelClassName={styles.label}
                        isRequire={false}
                        type="text"
                        name="RequisitionNo"
                        placeholder=""
                        defaultValue={(props.isCurrentMode == 'Edit' && props.listItems.AlterationNo == 0) ? props.RequisitionNo : props.listItems.RequisitionNo}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isCurrentMode == 'Edit' ? (props.listItems.AlterationNo == 0 ? false : true) : true} />
                </Col> */}
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Purchase Order No'}
                        labelClassName={styles.label}
                        isRequire={false}
                        type="text"
                        name="PurchaseOrderNo"
                        placeholder=""
                        defaultValue={(props.isCurrentMode == 'Edit' && props.listItems.AlterationNo == 0) ? props.PurchaseOrderNo : props.listItems.PurchaseOrderNo}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isCurrentMode == 'Edit' ? (props.listItems.AlterationNo == 0 ? false : true) : true} />
                </Col>
                <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                    <InputControl
                        label={'Estimated Commitment'}
                        labelClassName={styles.label}
                        isRequire={false}
                        type="CurrencyFormat"
                        name="EstimatedCommitment"
                        placeholder=""
                        defaultValue={(props.isCurrentMode == 'View') ? props.listItems.EstimatedCommitment : props.EstimatedCommitment}
                        onTextblur={(ev) => props.handleCurrencyChange(ev)}
                        isdisabled={props.isViewMode}
                    />
                    {/* <InputControl
                        label={'Estimated Commitment'}
                        labelClassName={styles.label}
                        isRequire={false}
                        type="number"
                        name="EstimatedCommitment"
                        placeholder=""
                        defaultValue={props.isCurrentMode != 'New' ? props.listItems.EstimatedCommitment : props.EstimatedCommitment}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isViewMode} /> */}
                </Col>
                {(props.listItems.Status !== 'Close') && <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                    <InputControl
                        label={'Do you want to reject?'}
                        labelClassName={styles.label}
                        isRequire={false}
                        type={"checkbox"}
                        id={"isReject"}
                        name={"isReject"}
                        placeholder=""
                        value={props.isReject == 'Yes' ? 'No' : 'Yes'}
                        checked={props.isCurrentMode != 'View' ? props.isReject == 'Yes' : props.listItems.isReject == 'No'}
                        onTextblur={props.onHandlechange}
                        isdisabled={props.isViewMode}
                    />
                </Col>}
                {(props.isCurrentMode != 'View' ? props.isReject == 'Yes' : props.listItems.isReject == 'Yes') && (props.listItems.Status !== 'Close') && <>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                        <InputControl
                            type={'select'}
                            labelClassName={styles.label}
                            label={'Reject Reasons'}
                            id={'RejectReasons'}
                            name={'RejectReasons'}
                            isRequire={true}
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.RejectReasons : ''}
                            selectOnchange={props.onHandlechange}
                            options={props.MasterDataRejectedReasons}
                            isdisabled={props.isViewMode}
                        />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                        <InputControl
                            label={'Reject Comments'}
                            labelClassName={styles.label}
                            isRequire={false}
                            type="textarea"
                            name="RejectComments"
                            placeholder=""
                            defaultValue={props.isCurrentMode != 'New' ? props.listItems.RejectComments : ""}
                            onTextblur={props.onHandlechange}
                            isdisabled={props.isViewMode} />
                    </Col>
                </>
                }

            </Row>
        </>
    )
}

const loading = () => <div className="animated fadeIn pt-3 text-center">Loading...</div>;


// export interface IUploadState {
//     attachments: any;
//     uploading: boolean;
// }
class PurchaseOrder extends React.Component<any, any> {
    private pond: any;
    updatedData = {}
    columns = []
    MOAApprovaluploadedDocList = []

    constructor(props) {
        super(props);
        this.state = {
            isloading: false,
            supportTeamTable: [],
            PurchaseOrderTable: [],
            AlterationTableMode: false,
            SelectedAlterationNo: 0,
            isCreateBtnShow: true,
            isShowPurchaseOrderTable: false,
            isShowSupportTeamTable: false,
            isReject: 'No',
            isCurrentMode: 'New',
            Date: new Date(),
            isSaveBtnEnableFlag: 0,
            ChildList: [],
            ChildListRemovedItem: [],
            NewItemsInChildList: [],
            EditItemsInChildList: [],
            AlterationNumber: '',
            ProjectType: '',
            ProjectName: '',
            VendorName: '',
            VendorNumber: '',
            VendorAddress: '',
            OutlineAgreementAndLineNumber: '',
            OffshoreServices: '',
            VendorContactName: '',
            PhoneNumber: '',
            FaxNumber: '',
            EmailAddress: '',
            attachments: [],
            uploading: false,
            isSubmit: false,
            isDocDeleteFlag: false,
            DocumentTitle: '',
            MOAshowLoader: false,
            MOAshowLoaderlevel: false,
            SuppliershowLoader: false,
            SuppliershowLoaderlevel: false,
            OthershowLoader: false,
            OthershowLoaderlevel: false,
            AttachmnetType: ["MOAApproval", "SupplierCTR", "Other"],
            EstimatedCommitment: '',
            MOAApprovalUploadFileList: [],
            SupplierUploadFileList: [],
            OtherUploadFileList: []
        };

        this.updatedData = {
            Date: new Date(),
            ApplicationUserEmailID: this.props.userEmail,
            attachments: [],
            AlterationNo: 0

        }
        this.MOAApprovaluploadedDocList = []

    }
    _CopyPath = async (folderName, destinationFolder) => {

        let libraryName = "Purchase Order Documents Library";
        let destinationUrl = "https://eu023-sp.shell.com/sites/SPOAA0342/PurchaseOrder/Purchase Order Documents Library/" + destinationFolder
        const folder = await sp.web.rootFolder.folders.getByName(libraryName).folders.getByName(folderName).copyTo(destinationUrl);


    }
    public _DeleteUploadedDoc = async (ev: React.ChangeEvent<HTMLInputElement>,) => {
        debugger;
        //this.updatedData['deletedFileName']=ev.target.parentElement.innerText;
        const fileUrl = ev.target.dataset.url;
        const filename = ev.target.parentElement.innerText;
        let section = ev.target.dataset.section;
        let foldername = ev.target.dataset.foldername;
        let folderpath = foldername + this.updatedData['SerialNumber'] + '-' + this.updatedData['AlterationNo'];

        await this.props.actions.DeleteSingleFile(fileUrl, folderpath, section).then(async (responce) => {
            if (responce.ok) {
                this.setState({ isDocDeleteFlag: true, isDeletedFileName: filename, showLoader: false }, async () => {
                    debugger;
                    await this.props.actions.GetAssociatedFiles(foldername + this.updatedData['SerialNumber'] + '-' + this.updatedData['AlterationNo'], section);

                });
            }
        })

    }

    public _DeleteUploadedAllFolder = async (Section) => {

        //this.updatedData['deletedFileName']=ev.target.parentElement.innerText;

        const f_name = this.updatedData['SerialNumber'] + '-' + this.updatedData['AlterationNo'];
        const folderUrl = "/sites/SPOAA0342/PurchaseOrder/Purchase Order Documents Library/" + Section + "-" + f_name;
        await this.props.actions.DeleteAllFile(folderUrl).then((responce) => {
            if (responce.ok) {
                //this.setState({ isDocDeleteFlag: true, isDeletedFileName: filename, showLoader: false });
                console.log('file deleted');
            }
        });

    }
    public _DeleteAllFolder = async (Section, SerialNumber) => {

        //this.updatedData['deletedFileName']=ev.target.parentElement.innerText;

        const f_name = SerialNumber + '-' + 0;
        const folderUrl = "/sites/SPOAA0342/PurchaseOrder/Purchase Order Documents Library/" + Section + "-" + f_name;
        await this.props.actions.DeleteAllFile(folderUrl).then((responce) => {
            if (responce.ok) {
                //this.setState({ isDocDeleteFlag: true, isDeletedFileName: filename, showLoader: false });
                console.log('file deleted');
            }
        });

    }


    public _onFileUpload = (
        ev: React.ChangeEvent<HTMLInputElement>,
    ): void => {

        this.updatedData['file'] = ev.target.files;

        let Section = ev.target.name;
        if (ev.target.files.length > 0) {
            if (Section == 'MOAApproval') {

                this.setState({ file: ev.target.files, MOAshowLoader: true, MOAshowLoaderlevel: true });
            } else if (Section == 'SupplierCTR') {
                this.setState({ file: ev.target.files, SuppliershowLoader: true, SuppliershowLoaderlevel: true });
            } else {
                this.setState({ file: ev.target.files, OthershowLoader: true, OthershowLoaderlevel: true });
            }
            if ((this.props.MOAAttachment == 'Yes' && Section == 'MOAApproval') ||
                (this.props.SupplierAttachment == 'Yes' && Section == 'SupplierCTR') ||
                (this.props.OtherAttachment == 'Yes' && Section == 'Other')) {
                this.props.actions.getFolderAvailability(this.updatedData, Section).then((responce) => {
                    if (responce) {
                        this.props.actions.FileUpload(this.updatedData, true).then((responce) => {
                            if (responce) {
                                //toast.success('Folder Availbility Sucess');
                                //console.log('send to mail');
                                let j = 0;
                                for (let i = 0; i < this.updatedData["file"].length; i++) {
                                    this.props.actions.fileUploadLocation(this.updatedData["file"][i], Section).then((res) => {

                                        j++;
                                        if (j == this.updatedData["file"].length) {
                                            debugger;
                                            if (Section == 'MOAApproval') {
                                                this.setState({ MOAshowLoader: false, MOAshowLoaderlevel: false, MOAApprovalUploadFileList: this.props.MOAApprovalUploadFileList }, () => toast.success('File uploaded Successfuly'));
                                            } else if (Section == 'SupplierCTR') {
                                                this.setState({ SuppliershowLoader: false, SuppliershowLoaderlevel: false, SupplierUploadFileList: this.props.SupplierUploadFileList }, () => toast.success('File uploaded Successfuly'));
                                            } else {
                                                this.setState({ OthershowLoader: false, OthershowLoaderlevel: false, OtherUploadFileList: this.props.OtherUploadFileList }, () => toast.success('File uploaded Successfuly'));
                                            }

                                        }
                                    })

                                }
                            }
                        })
                    } else {
                        this.props.actions.CreateFolder(this.updatedData, Section).then((responce) => {

                            if (responce) {
                                //toast.success('successfully created Folder added');                        
                                this.props.actions.getFolderAvailability(this.updatedData, Section).then((responce) => {

                                    if (responce) {
                                        this.props.actions.FileUpload(this.updatedData, false).then((responce) => {
                                            if (responce) {

                                                let j = 0;
                                                for (let i = 0; i < this.updatedData["file"].length; i++) {
                                                    this.props.actions.fileUploadLocation(this.updatedData["file"][i], Section).then((res) => {
                                                        j++;
                                                        if (j == this.updatedData["file"].length) {

                                                            if (j == this.updatedData["file"].length) {
                                                                if (Section == 'MOAApproval') {
                                                                    this.updatedData['MOAAttachment'] = 'Yes';
                                                                    this.setState({ MOAshowLoader: false, MOAshowLoaderlevel: false, MOAApprovalUploadFileList: this.props.MOAApprovalUploadFileList }, () => toast.success('File uploaded successfully'));
                                                                } else if (Section == 'SupplierCTR') {
                                                                    this.updatedData['SupplierAttachment'] = 'Yes';
                                                                    this.setState({ SuppliershowLoader: false, SuppliershowLoaderlevel: false, SupplierUploadFileList: this.props.SupplierUploadFileList }, () => toast.success('File uploaded successfully'));
                                                                } else {
                                                                    this.updatedData['OtherAttachment'] = 'Yes';
                                                                    this.setState({ OthershowLoader: false, OthershowLoaderlevel: false, OtherUploadFileList: this.props.OtherUploadFileList }, () => toast.success('File uploaded successfully'));
                                                                }

                                                            }
                                                        }

                                                    })
                                                }
                                            }
                                        })
                                    }
                                })
                            }
                        });
                    }
                })
            } else {
                this.props.actions.CreateFolder(this.updatedData, Section).then((responce) => {

                    if (responce) {
                        //toast.success('successfully created Folder added');                        
                        this.props.actions.getFolderAvailability(this.updatedData, Section).then(async (responce) => {

                            if (responce) {
                                await this.props.actions.FileUpload(this.updatedData, false).then(async (folderResponce) => {
                                    if (folderResponce) {
                                        await this.props.actions.fileUploadLocation(this.updatedData["file"][0], Section).then((res) => { })
                                        let j = 0;
                                        for (let i = 0; i < this.updatedData["file"].length; i++) {
                                            await this.props.actions.fileUploadLocation(this.updatedData["file"][i], Section).then((res) => {
                                                debugger;
                                                j++;
                                                if (j == this.updatedData["file"].length) {

                                                    if (j == this.updatedData["file"].length) {
                                                        if (Section == 'MOAApproval') {
                                                            this.updatedData['MOAAttachment'] = 'Yes';
                                                            this.setState({ MOAshowLoader: false, MOAshowLoaderlevel: false, }, () => toast.success('File uploaded successfully'));
                                                        } else if (Section == 'SupplierCTR') {
                                                            this.updatedData['SupplierAttachment'] = 'Yes';
                                                            this.setState({ SuppliershowLoader: false, SuppliershowLoaderlevel: false }, () => toast.success('File uploaded successfully'));
                                                        } else {
                                                            this.updatedData['OtherAttachment'] = 'Yes';
                                                            this.setState({ OthershowLoader: false, OthershowLoaderlevel: false }, () => toast.success('File uploaded successfully'));
                                                        }
                                                    }
                                                }

                                            })
                                        }
                                    }
                                })
                            }
                        })
                    }
                });
            }


        }

    }
    private _OnhandleInit = () => {

        console.log("FilePond instance has initialised", this.pond);
    }
    private _onupdatefilesHandler = (fileItems: any) => {

        //this.updatedData['attachments'].push(fileItems.map(fileItem => fileItem.file));
        // Set currently active file objects to this.state
        if (this.state.isCurrentMode == "Edit" && this.props.listItems.Attachments == true) {
            let obj = {};
            let attachmentTemp = [];
            this.props.listItems.AttachmentFiles.map((item, index) => {
                obj = {
                    source: "https://eu023-sp.shell.com" + item.ServerRelativeUrl,
                    options: {
                        type: "local"
                    }
                }
                attachmentTemp.push(obj);
            })
            this.setState({

                attachments: attachmentTemp
            })
        } else {
            this.setState({
                attachments: fileItems.map(fileItem => fileItem.file)
            }, () => {

                console.log('Filename:' + this.state.attachments);
            });
        }


    }

    public _generateSerialNumber = (tableName) => {

        let min = 0;
        let max = 9999;
        let currentDate = new Date();
        let SerialNumber: any;
        let month: any = '0';
        if (currentDate.getMonth() < 10) {
            month = '0' + (currentDate.getMonth() + 1);
        } else {
            month = currentDate.getMonth() + 1;
        }

        let Num = currentDate.getDate() + '' + (month) + '' + currentDate.getFullYear();
        //return SerialNumber = Num + '-' + (tableName.length < 10 ? ('00' + (tableName.length + 1)) : (tableName.length < 100 ? ('0' + (tableName.length + 1)) : ((tableName.length + 1))));
        return SerialNumber = Num + '-' + Math.round(Math.random() * (max - min) + min);

    }
    async componentDidMount() {

        const queryParms: any = new UrlQueryParameterCollection(window.location.href);

        await this.props.actions.FetchParentProps(this.props);
        await this.props.actions.FetchCurrentUserInfo();
        await this.props.actions.FetchUserGroupInfo(this.props);
        await this.props.actions.FetchDefaultResults(this.props);



        if (this.props.CurrentUserPurchaseOrderItems.length > 0) {
            this.setState({
                isShowPurchaseOrderTable: true,
                PurchaseOrderTable: this.props.CurrentUserPurchaseOrderItems

            })
        } else {
            this.setState({
                isShowSupportTeamTable: true,
                supportTeamTable: this.props.CurrentUserSupportTeamItems
            })
        }


    }
    public _GetPepoleRequestorName = (people: any[]) => {
        if (people.length > 0) {

            this.setState({
                RequestorId: people[0].id,
                RequestorEmail: people[0].secondaryText,
                RequestorName: people[0].text
                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });

            this.updatedData['RequestorId'] = people[0].id;
            this.updatedData['RequestorEmail'] = people[0].secondaryText;
            this.updatedData['RequestorName'] = people[0].text;

        } else {
            this.setState({
                RequestorId: '',
                RequestorEmail: '',
                RequestorName: '',

                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['RequestorId'] = '';
            this.updatedData['RequestorEmail'] = '';
            this.updatedData['RequestorName'] = '';

        }
    }

    public _GetPepoleMOAApprover = (people: any[]) => {
        if (people.length > 0) {

            this.setState({
                MOAApproverId: people[0].id,
                MOAApproverEmail: people[0].secondaryText,
                MOAApproverName: people[0].text
                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });

            this.updatedData['MOAApproverId'] = people[0].id;
            this.updatedData['MOAApproverEmail'] = people[0].secondaryText;
            this.updatedData['MOAApproverName'] = people[0].text;

        } else {
            this.setState({
                MOAApproverId: '',
                MOAApproverEmail: '',
                MOAApproverName: '',

                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['MOAApproverId'] = '';
            this.updatedData['MOAApproverEmail'] = '';
            this.updatedData['MOAApproverName'] = '';

        }
    }

    public _GetPepoleCPBuyer = (people: any[]) => {
        if (people.length > 0) {

            this.setState({
                CPBuyerId: people[0].id,
                CPBuyerEmail: people[0].secondaryText,
                CPBuyerName: people[0].text
                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['CPBuyerId'] = people[0].id;
            this.updatedData['CPBuyerEmail'] = people[0].secondaryText;
            this.updatedData['CPBuyerName'] = people[0].text;

        } else {
            this.setState({
                CPBuyerId: '',
                CPBuyerEmail: '',
                CPBuyerName: '',
                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['CPBuyerId'] = '';
            this.updatedData['CPBuyerEmail'] = '';
            this.updatedData['CPBuyerName'] = '';

        }
    }
    public _GetPepoleInvoiceApprover = (people: any[]) => {
        if (people.length > 0) {

            this.setState({
                InvoiceApproverId: people[0].id,
                InvoiceApproverEmail: people[0].secondaryText,
                InvoiceApproverName: people[0].text,

                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['InvoiceApproverId'] = people[0].id;
            this.updatedData['InvoiceApproverEmail'] = people[0].secondaryText;
            this.updatedData['InvoiceApproverName'] = people[0].text;

        } else {
            this.setState({
                InvoiceApproverId: '',
                InvoiceApproverEmail: '',
                InvoiceApproverName: '',

                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['InvoiceApproverId'] = '';
            this.updatedData['InvoiceApproverEmail'] = '';
            this.updatedData['InvoiceApproverName'] = '';

        }
    }

    public _GetPepoleProjectServicesFocalPoint = (people: any[]) => {
        if (people.length > 0) {

            this.setState({
                ProjectServicesFocalPointId: people[0].id,
                ProjectServicesFocalPointEmail: people[0].secondaryText,
                ProjectServicesFocalPointName: people[0].text
                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['ProjectServicesFocalPointId'] = people[0].id;
            this.updatedData['ProjectServicesFocalPointEmail'] = people[0].secondaryText;
            this.updatedData['ProjectServicesFocalPointName'] = people[0].text;

        } else {
            this.setState({
                ProjectServicesFocalPointId: '',
                ProjectServicesFocalPointEmail: '',
                ProjectServicesFocalPointName: ''
                //ApplicationLead_MC_MailSendTo: people[0].secondaryText,
            }, () => {
                if (this.state.isSaveBtnEnableFlag == 0) {
                    this.setState({ isSaveBtnEnableFlag: 1 })
                }
            });
            this.updatedData['ProjectServicesFocalPointId'] = '';
            this.updatedData['ProjectServicesFocalPointEmail'] = '';
            this.updatedData['ProjectServicesFocalPointName'] = '';

        }
    }

    public _onHandlechange = (
        ev: React.ChangeEvent<HTMLInputElement>,
    ): void => {

        if (this.state.isSaveBtnEnableFlag == 0) {
            this.setState({ isSaveBtnEnableFlag: 1 })
        }
        if (ev.target.type == 'checkbox') {

            if (ev.target.value == 'Yes') {
                this.updatedData[ev.target.name] = 'Yes';
                this.setState({
                    [ev.target.name]: 'Yes'
                });
            } else {
                this.updatedData[ev.target.name] = 'No';
                this.setState({
                    [ev.target.name]: 'No'
                });
            }
        }


        else {
            this.updatedData[ev.target.name] = ev.target.value;
        }

        //this.setState({ [ev.target.name]: ev.target.value })

    }
    public _onHandleCurrencyChange = (
        ev,
    ): void => {
        debugger;
        if (this.state.isSaveBtnEnableFlag == 0) {
            this.setState({ isSaveBtnEnableFlag: 1 })
        }
        this.updatedData['EstimatedCommitment'] = ev.formattedValue;

        this.setState({
            ['EstimatedCommitment']: ev.formattedValue,

        });


        //this.setState({ [ev.target.name]: ev.target.value })

    }
    public _onselectAlteration = (ev: React.ChangeEvent<HTMLInputElement>,
    ): void => {

        this.updatedData[ev.target.name] = 'AlterationTableCall';
        this.updatedData['SelectedAlterationNo'] = parseInt(ev.target.value);
        let supportTeam = this.props.CurrentUserSupportTeamItems;
        let obj = {
            AlertationTableView: true,
            SelectedAlterationNo: parseInt(ev.target.value)
        }
        // let selectedTeam = this.props.CurrentUserSupportTeamItems.filter(item => item.Id == parseInt(ev.target.id));
        //let selectTeamUpdate = { ...selectedTeam, ...obj }
        let final = [];
        supportTeam.map((item, i) => {
            if (item.Id == ev.target.id) {
                let updateobj = { ...item, ...obj };
                final.push(updateobj);
            } else {
                let obj2 = {
                    SelectedAlterationNo: parseInt(ev.target.value)
                }
                let alterItem = { ...item, ...obj2 };
                final.push(alterItem);
            }
        })

        // let final = [{...supportTeam, ...selectTeamUpdate}]


        this.setState({ supportTeamTable: [], SelectedAlterationNo: ev.target.value }, () => {
            this.setState({ supportTeamTable: final })
        })


    }
    private _onFormatDate = (date: Date): string => {
        return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
    };

    private _onCreateDate = (date: Date | null | undefined): void => {
        this.setState({ ['Date']: date });
        this.updatedData['Date'] = date;
    }

    _HandleCallback = (childData, childRemovedItems, flag) => {

        const NewItemsInChildList = childData.filter((items) => {
            return items.Id == undefined;
        });
        const EditItemsInChildList = childData.filter((items) => {
            return items.Id != undefined;
        });

        if (flag == 'removedItemEventCallback') {
            this.setState({
                ChildList: childData,
                ChildListRemovedItem: childRemovedItems,
                isSaveBtnEnableFlag: 1
            });
        } else {

            this.setState({
                ChildList: childData,
                NewItemsInChildList: NewItemsInChildList,
                EditItemsInChildList: EditItemsInChildList,
                isSaveBtnEnableFlag: flag != 'didMountCallback' ? (flag == 'eventCallback' ? 1 : this.state.isSaveBtnEnableFlag == 0 ? 1 : 0) : 0
            });
        }


    }

    _CreateList = async () => {

        await this.props.actions.FileAttachmentsClear();
        if (this.props.CurrentUserPurchaseOrderItems.length > 0) {
            let SerialNumber = this._generateSerialNumber(this.props.PurchaseOrderData);
            this.updatedData['SerialNumber'] = SerialNumber;
            this.updatedData['RequestorId'] = this.props.CurrentUserInfo.Id,
                this.updatedData['RequestorEmail'] = this.props.CurrentUserInfo.Email,
                this.updatedData['RequestorName'] = this.props.CurrentUserInfo.Title,
                this.updatedData['Status'] = '',
                this.updatedData['SupplierAttachment'] = 'No',
                this.updatedData['MOAAttachment'] = 'No',
                this.updatedData['OtherAttachment'] = 'No',
                this.updatedData['AlterationNo'] = 0
            this.MOAApprovaluploadedDocList = [],
                this.setState({
                    isShowPurchaseOrderTable: false,
                    isShowPrchaseOrderForm: true,
                    isCurrentMode: 'New',
                    SerialNumber: SerialNumber,
                    RequestorId: this.props.CurrentUserInfo.Id,
                    RequestorEmail: this.props.CurrentUserInfo.Email,
                    RequestorName: this.props.CurrentUserInfo.Title,
                    AlterationNo: 0,
                    MOAApprovalUploadFileList: [],
                    SupplierUploadFileList: [],
                    OtherUploadFileList: []
                })
        } else {
            let SerialNumber = this._generateSerialNumber(this.props.PurchaseOrderData);
            this.updatedData['SerialNumber'] = SerialNumber;
            this.updatedData['RequestorId'] = this.props.CurrentUserInfo.Id,
                this.updatedData['RequestorEmail'] = this.props.CurrentUserInfo.Email,
                this.updatedData['RequestorName'] = this.props.CurrentUserInfo.Title
            this.updatedData['Status'] = '',
                this.updatedData['SupplierAttachment'] = 'No',
                this.updatedData['MOAAttachment'] = 'No',
                this.updatedData['OtherAttachment'] = 'No',
                this.updatedData['AlterationNo'] = 0
            this.setState({
                isShowPrchaseOrderForm: true,
                isCurrentMode: 'New',
                SerialNumber: SerialNumber,
                RequestorId: this.props.CurrentUserInfo.Id,
                RequestorEmail: this.props.CurrentUserInfo.Email,
                RequestorName: this.props.CurrentUserInfo.Title,
                AlterationNo: 0,
                MOAApprovalUploadFileList: [],
                SupplierUploadFileList: [],
                OtherUploadFileList: []
            })
        }

    }
    _Edit = async (e) => {
        debugger;
        this.setState({ isloading: true });
        let Status = e.target.dataset.name;
        let PartntId = parseInt(e.target.id);

        await this.props.actions.FetchSelectedRowDataResults(PartntId);
        await this.props.actions.PoListFetchSelectedRowDataResults(this.props.listItems.SerialNumber);
        this.updatedData = {
            Date: new Date(),
            ApplicationUserEmailID: this.props.userEmail,
            attachments: [],
            AlterationNo: 0,
            Status: '',
            // SupplierAttachment: 'No',
            // MOAAttachment: 'No',
            // OtherAttachment: 'No'

        }
        debugger;
        this.updatedData = { ...this.props.listItems };

        //Get value from Rejected Mode  

        if (this.props.isRequestorsTeam && Status == "Rejected") {

            if (this.updatedData['AlterationNo'] < 5) {
                //await this.props.actions.FetchSelectedAlterationRowListItems(PartntId, (this.props.listItems.AlterationNo));
                await this.props.actions.FetchSelectedAlterationRowListItems_Id(PartntId, (this.props.listItems.AlterationNo));
            }

            //MoA Folder aviablity Check

            await this.props.actions.getFolderAvailability(this.updatedData, 'MOAApproval').then(async (responce) => {
                let count = parseInt(this.updatedData['AlterationNo']);
                debugger;
                if ((responce != undefined) && responce.Name == ('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + (count))) {


                    let obj = { SerialNumber: this.updatedData['SerialNumber'], AlterationNo: count + 1 };
                    await this.props.actions.getFolderAvailability(obj, 'MOAApproval').then(async (res) => {

                        if (res == undefined) {
                            await this._CopyPath('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + (count), 'MOA-Approval-' + this.props.listItems.SerialNumber + '-' + (count + 1));
                        }
                        //Get Copyed file from folder
                        debugger;
                        await this.props.actions.GetAssociatedFiles('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + (count + 1), 'MOAApproval');

                    })

                } else {
                    await this._CopyPath('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + (count - 1), 'MOA-Approval-' + this.props.listItems.SerialNumber + '-' + (count));
                    await this.props.actions.GetAssociatedFiles('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + (count), 'MOAApproval');
                }
            })


            //SupplierCTR Folder aviablity Check

            await this.props.actions.getFolderAvailability(this.updatedData, 'SupplierCTR').then(async (responce) => {
                let count = parseInt(this.updatedData['AlterationNo']);
                if ((responce != undefined) && responce.Name == ('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + (count))) {

                    let obj = { SerialNumber: this.updatedData['SerialNumber'], AlterationNo: count + 1 };
                    await this.props.actions.getFolderAvailability(obj, 'SupplierCTR').then(async (res) => {
                        if (res == undefined) {
                            await this._CopyPath('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + (count), 'SupplierCTR-' + this.props.listItems.SerialNumber + '-' + (count + 1));

                        }
                        await this.props.actions.GetAssociatedFiles('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + (count + 1), 'SupplierCTR');

                    })

                } else {
                    await this._CopyPath('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + (count - 1), 'SupplierCTR-' + this.props.listItems.SerialNumber + '-' + (count));
                    await this.props.actions.GetAssociatedFiles('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + (count), 'SupplierCTR-');
                }
            })

            //Other Folder aviablity Check

            if (this.updatedData['OtherAttachment'] == 'Yes') {
                await this.props.actions.getFolderAvailability(this.updatedData, 'Other').then(async (responce) => {
                    let count = parseInt(this.updatedData['AlterationNo']);

                    if (responce != undefined) {
                        if (responce.Name == ('Other-' + this.props.listItems.SerialNumber + '-' + (count))) {

                            let obj = { SerialNumber: this.updatedData['SerialNumber'], AlterationNo: count + 1 };
                            await this.props.actions.getFolderAvailability(obj, 'Other').then(async (res) => {
                                if (res == undefined) {
                                    await this._CopyPath('Other-' + this.props.listItems.SerialNumber + '-' + (count), 'Other-' + this.props.listItems.SerialNumber + '-' + (count + 1));

                                }
                                await this.props.actions.GetAssociatedFiles('Other-' + this.props.listItems.SerialNumber + '-' + (count + 1), 'Other');

                            })
                        }
                    } else {
                        let obj = { SerialNumber: this.updatedData['SerialNumber'], AlterationNo: count - 1 };
                        await this.props.actions.getFolderAvailability(obj, 'Other').then(async (responce) => {
                            if ((responce != undefined) && responce.Name == ('Other-' + this.props.listItems.SerialNumber + '-' + (count - 1))) {
                                await this._CopyPath('Other-' + this.props.listItems.SerialNumber + '-' + (count - 1), 'Other-' + this.props.listItems.SerialNumber + '-' + (count + 1));
                                await this.props.actions.GetAssociatedFiles('Other-' + this.props.listItems.SerialNumber + '-' + (count), 'Other');


                            }
                        })
                    }

                })
            }
        }

        if (this.props.isRequestorsTeam && Status == "Rejected") {
            this.updatedData['AlterationNo'] = (this.props.listItems.AlterationNo == null ? 0 : this.props.listItems.AlterationNo) + 1;
        }
        else if (this.props.isSupportTeam && Status == "Open") { //Get value from Support Team Mode 
            await this.props.actions.GetAssociatedFiles('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'MOAApproval').then((items) => {
                if (items) {
                    if (this.state.isSaveBtnEnableFlag == 0) {
                        this.setState({ isSaveBtnEnableFlag: 1, MOAshowLoader: false, MOAshowLoaderlevel: false })
                    } else {
                        this.setState({ MOAshowLoader: false, MOAshowLoaderlevel: false });
                    }

                } else {
                    toast.error('Folder Notfuond');
                }
            });
            await this.props.actions.GetAssociatedFiles('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'SupplierCTR').then((items) => {
                if (items) {
                    if (this.state.isSaveBtnEnableFlag == 0) {
                        this.setState({ isSaveBtnEnableFlag: 1, SuppliershowLoader: false, SuppliershowLoaderlevel: false })
                    } else {
                        this.setState({ SuppliershowLoader: false, SuppliershowLoaderlevel: false });
                    }

                } else {
                    toast.error('Folder Notfuond');
                }
            });
            if (this.updatedData['OtherAttachment'] == 'Yes') {
                await this.props.actions.GetAssociatedFiles('Other-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'Other').then((items) => {
                    if (items) {
                        if (this.state.isSaveBtnEnableFlag == 0) {
                            this.setState({ isSaveBtnEnableFlag: 1, OthershowLoader: false, OthershowLoaderlevel: false })
                        } else {
                            this.setState({ OthershowLoader: false, OthershowLoaderlevel: false });
                        }

                    }

                });
            }
        }
        else { //Get value from Draft Call and Rejected Call above 5th call 
            debugger;
            await this.props.actions.GetAssociatedFiles('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'MOAApproval').then((items) => {
                if (items) {
                    if (this.state.isSaveBtnEnableFlag == 0) {
                        this.setState({ isSaveBtnEnableFlag: 1, MOAshowLoader: false, MOAshowLoaderlevel: false })
                    } else {
                        this.setState({ MOAshowLoader: false, MOAshowLoaderlevel: false });
                    }

                    //toast.success('Get details');                                       
                } else {
                    toast.error('Folder Notfuond');
                }
            });
            await this.props.actions.GetAssociatedFiles('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'SupplierCTR').then((items) => {
                if (items) {
                    if (this.state.isSaveBtnEnableFlag == 0) {
                        this.setState({ isSaveBtnEnableFlag: 1, SuppliershowLoader: false, SuppliershowLoaderlevel: false })
                    } else {
                        this.setState({ SuppliershowLoader: false, SuppliershowLoaderlevel: false });
                    }
                    //toast.success('Get details');                                       
                } else {
                    toast.error('Folder Notfuond');
                }
            });

            if (this.updatedData['OtherAttachment'] == 'Yes') {
                await this.props.actions.GetAssociatedFiles('Other-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'Other').then((items) => {
                    if (items) {
                        if (this.state.isSaveBtnEnableFlag == 0) {
                            this.setState({ isSaveBtnEnableFlag: 1, OthershowLoader: false, OthershowLoaderlevel: false })
                        } else {
                            this.setState({ OthershowLoader: false, OthershowLoaderlevel: false });
                        }


                    }

                });
            }
        }




        if (this.props.isSupportTeam) {
            this.updatedData['RequisitionNo'] = (this.props.listItems.RequisitionNo == null || this.props.listItems.RequisitionNo == undefined) ? this.props.listItems.SerialNumber : this.props.listItems.RequisitionNo,
                this.updatedData['PurchaseOrderNo'] = (this.props.listItems.PurchaseOrderNo === null || this.props.listItems.PurchaseOrderNo === undefined) ? this.props.listItems.SerialNumber.slice(this.props.listItems.SerialNumber.indexOf('-') + 1) : this.props.listItems.PurchaseOrderNo

            this.setState({
                isloading: false,
                isShowSupportTeamTable: false,
                isShowPrchaseOrderForm: true,
                currentId: PartntId,
                isCurrentMode: 'Edit',
                SerialNumber: this.props.listItems.SerialNumber,
                ChildList: this.props.ChildList,
                RequisitionNo: (this.props.listItems.RequisitionNo == null || this.props.listItems.RequisitionNo == undefined) ? this.props.listItems.SerialNumber : this.props.listItems.RequisitionNo,
                PurchaseOrderNo: (this.props.listItems.PurchaseOrderNo === null || this.props.listItems.PurchaseOrderNo === undefined) ? this.props.listItems.SerialNumber.slice(this.props.listItems.SerialNumber.indexOf('-') + 1) : this.props.listItems.PurchaseOrderNo,
                EstimatedCommitment: this.props.listItems.EstimatedCommitment


            })
        } else if (this.props.isRequestorsTeam && Status == 'Rejected') {
            this.setState({
                isloading: false,
                isShowPurchaseOrderTable: false,
                isShowPrchaseOrderForm: true,
                currentId: PartntId,
                isCurrentMode: 'Edit',
                SerialNumber: this.props.listItems.SerialNumber,
                //AlterationNo: AlterationNo,
                ChildList: this.props.ChildList,
                EstimatedCommitment: this.props.listItems.EstimatedCommitment

            })

        } else {
            this.setState({
                isloading: false,
                isShowPurchaseOrderTable: false,
                isShowPrchaseOrderForm: true,
                currentId: PartntId,
                isCurrentMode: 'Edit',
                SerialNumber: this.props.listItems.SerialNumber,
                ChildList: this.props.ChildList,
                EstimatedCommitment: this.props.listItems.EstimatedCommitment
            })
        }

    }
    _View = async (e) => {
        this.setState({ isloading: true });
        let id = parseInt(e.target.id);
        await this.props.actions.FetchSelectedRowDataResults(id);
        await this.props.actions.PoListFetchSelectedRowDataResults(this.props.listItems.SerialNumber);
        this.updatedData = { ...this.props.listItems };

        await this.props.actions.GetAssociatedFiles('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'MOAApproval');
        await this.props.actions.GetAssociatedFiles('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'SupplierCTR');
        if (this.updatedData['OtherAttachment'] == 'Yes') {
            await this.props.actions.GetAssociatedFiles('Other-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'Other');

        }
        if (this.props.isSupportTeam) {
            this.setState({
                isloading: false,
                isShowSupportTeamTable: false,
                isShowPrchaseOrderForm: true,
                currentId: id,
                isCurrentMode: 'View',
                SerialNumber: this.props.listItems.SerialNumber,
                ChildList: this.props.ChildList,
                EstimatedCommitment: this.props.listItems.EstimatedCommitment
            })
        }
        this.setState({
            isloading: false,
            isShowPurchaseOrderTable: false,
            isShowPrchaseOrderForm: true,
            currentId: id,
            isCurrentMode: 'View',
            SerialNumber: this.props.listItems.SerialNumber,
            ChildList: this.props.ChildList,
            EstimatedCommitment: this.props.listItems.EstimatedCommitment

        })

    }
    _Delete = async (e) => {

        let selectedRowItem = [];
        this.setState({ isloading: true });
        let id = parseInt(e.target.id);
        let serialnumber = e.target.dataset.serialnumber;
        selectedRowItem = this.props.CurrentUserPurchaseOrderItems.filter(a => a.Id == id);
        if (selectedRowItem.length > 0) {
            if (selectedRowItem[0].MOAAttachment == 'Yes') {
                await this._DeleteAllFolder('MOA-Approval', serialnumber)
            }
            if (selectedRowItem[0].SupplierAttachment == 'Yes') {
                await this._DeleteAllFolder('SupplierCTR', serialnumber)
            }
            if (selectedRowItem[0].OtherAttachment == 'Yes') {
                await this._DeleteAllFolder('Other', serialnumber)
            }
        }

        await this.props.actions.DeleteDraftSelectedRowData(id);
        await this.props.actions.FetchDefaultResults();
        this.setState({
            isloading: false,
            PurchaseOrderTable: [],
            EstimatedCommitment: ''
        }, () => {
            this.setState({
                PurchaseOrderTable: this.props.CurrentUserPurchaseOrderItems
            })
        });
    }
    _AlertationView = async (e) => {
        this.setState({ isloading: true })
        let id = parseInt(e.target.id);
        let SelectedAlterationNo = e.target.dataset.name
        await this.props.actions.FetchSelectedAlterationRowListItems(id, SelectedAlterationNo);
        await this.props.actions.GetAssociatedFiles('MOA-Approval-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'MOAApproval').then((items) => {
            if (items) {
                this.setState({ MOAshowLoader: false, MOAshowLoaderlevel: false });
                //toast.success('Get details');                                       
            } else {
                toast.error('Folder Notfuond');
            }
        });
        await this.props.actions.GetAssociatedFiles('SupplierCTR-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'SupplierCTR').then((items) => {
            if (items) {
                this.setState({ SuppliershowLoader: false, SuppliershowLoaderlevel: false });
                //toast.success('Get details');                                       
            } else {
                toast.error('Folder Notfuond');
            }
        });
        await this.props.actions.GetAssociatedFiles('Other-' + this.props.listItems.SerialNumber + '-' + this.props.listItems.AlterationNo, 'Other').then((items) => {
            if (items) {
                this.setState({ OthershowLoader: false, OthershowLoaderlevel: false });

            }

        });

        if (this.props.isSupportTeam) {
            this.setState({
                isloading: false,
                isShowSupportTeamTable: false,
                isShowPrchaseOrderForm: true,
                currentId: id,
                isCurrentMode: 'View',
                SerialNumber: this.props.listItems.SerialNumber,
                ChildList: this.props.ChildList
            })
        }
        this.setState({
            isloading: false,
            isShowPurchaseOrderTable: false,
            isShowPrchaseOrderForm: true,
            currentId: id,
            isCurrentMode: 'View',
            SerialNumber: this.props.listItems.SerialNumber,
            ChildList: this.props.ChildList

        })
    }
    _SaveAsDraft = () => {
        if (this._validation(this.updatedData, this.props)) {
            this._SaveItemsToList('Draft');
        }
    }
    _Cancel = () => {
        debugger;
        if (this.updatedData['Status'] == '') {
            if (this.props.MOAAttachment == 'Yes') {
                this._DeleteUploadedAllFolder('MOA-Approval')
            }
            if (this.props.SupplierAttachment == 'Yes') {
                this._DeleteUploadedAllFolder('SupplierCTR')
            }
            if (this.props.OtherAttachment == 'Yes') {
                this._DeleteUploadedAllFolder('Other')
            }

        }
        if (this.props.isRequestorsTeam && this.updatedData['Status'] == 'Rejected') {
            if (this.props.MOAAttachment == 'Yes') {
                this._DeleteUploadedAllFolder('MOA-Approval')
            }
            if (this.props.SupplierAttachment == 'Yes') {
                this._DeleteUploadedAllFolder('SupplierCTR')
            }
            if (this.props.OtherAttachment == 'Yes') {
                this._DeleteUploadedAllFolder('Other')
            }

        }

        if (this.props.isSupportTeam) {
            this.setState({
                isShowPrchaseOrderForm: false,
                isShowSupportTeamTable: true,
                isCurrentMode: 'Edit',
                EstimatedCommitment: '',
                isReject: 'No'

            }, async () => {
                await this.props.actions.FileAttachmentsClear();
                await this.props.actions.FetchDefaultResults();
            })
        } else {
            this.setState({
                isShowPrchaseOrderForm: false,
                isShowPurchaseOrderTable: true,
                isCurrentMode: 'New',
                EstimatedCommitment: ''

            }, async () => {
                await this.props.actions.FileAttachmentsClear();
                await this.props.actions.FetchDefaultResults();
            })
        }


    }
    _Submit = () => {
        if (this._validation(this.updatedData, this.props)) {
            this.setState({ isSubmit: true });
        }

    }
    _SaveItemsToList = async (Status) => {

        let _this = this;



        if (this.state.isCurrentMode == 'New') {
            this.props.actions.AddNewDetails(this.updatedData, Status, this.state.attachments).then(async (responce) => {
                if (responce != undefined) {

                    this.state.ChildList.length > 0 && this.state.ChildList.map((item, index) => {
                        this.props.actions.PoListAddNewDetails(item).then(async (res) => {
                            if (res) {
                                if ((this.state.ChildList.length - 1) == index) {
                                    await this.props.actions.FetchDefaultResults();
                                    toast.success("Records successfully Saved!");
                                    this.setState({
                                        isShowPrchaseOrderForm: false,
                                        isShowPurchaseOrderTable: true,
                                        isCurrentMode: 'New',
                                        isSaveBtnEnableFlag: 0,
                                        ChildList: [],
                                        ChildListRemovedItem: [],
                                        NewItemsInChildList: [],
                                        EditItemsInChildList: [],
                                        // AlterationNumber: '',
                                        // ProjectType: '',
                                        // ProjectName: '',
                                        // VendorName: '',
                                        // VendorNumber: '',
                                        // VendorAddress: '',
                                        // OutlineAgreementAndLineNumber: '',
                                        // OffshoreServices: '',
                                        // VendorContactName: '',
                                        // PhoneNumber: '',
                                        // FaxNumber: '',
                                        // EmailAddress: ''
                                    })
                                }
                            }

                        })
                    });
                    // if (Status == 'Open' && this.updatedData['AlterationNo'] == 0) {
                    //     await this.props.actions.AlterationRowListItems(this.updatedData, responce.d.Id, Status, this.state);
                    // }
                    if (Status == 'Open') {

                        let EmailSubjectName = "New PO Request " + this.updatedData['SerialNumber'] + "," + " " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'];
                        let EmailBodyMessage = "New PO Request " + this.updatedData['SerialNumber'] + " for " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'] + " " + " was successfully submitted to the requisition team for review.</br> You will received a response in no more than 2 business days.";

                        this._sendMail([this.updatedData['RequestorEmail']], this.updatedData['RequestorName'], Status, this.updatedData['SerialNumber'], EmailSubjectName, EmailBodyMessage, 0, null, null)
                    }
                }
            });
        }
        if (this.state.isCurrentMode == 'Edit') {

            this.props.actions.UpdateSelectedRowData(this.updatedData, this.state.currentId, Status, this.state).then(async (responce) => {

                if (responce != undefined) {

                    // Support Team Rejected the request on first time
                    if (Status == 'Rejected' && this.updatedData['AlterationNo'] == 0) {
                        await this.props.actions.AlterationRowListItems(this.updatedData, this.state.currentId, Status, this.state);
                    }

                    // Requester Rejected Modified and Resubmit the request up to 4 times
                    if ((this.updatedData['AlterationNo'] >= 1 && this.updatedData['AlterationNo'] < 5) && this.props.isRequestorsTeam) {
                        await this.props.actions.AlterationRowUpdateListItems(this.updatedData, this.props.AlterationRowId, Status, this.state);
                    }
                    if (Status == 'Open' && this.updatedData['AlterationNo'] == 0) {

                        let EmailSubjectName = "New PO Request " + this.updatedData['SerialNumber'] + "," + " " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'];
                        let EmailBodyMessage = "New PO Request " + this.updatedData['SerialNumber'] + " for " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'] + " " + " was successfully submitted to the requisition team for review.</br> You will received a response in no more than 2 business days.";
                        this._sendMail([this.updatedData['RequestorEmail']], this.updatedData['RequestorName'], Status, this.updatedData['SerialNumber'], EmailSubjectName, EmailBodyMessage, this.updatedData['AlterationNo'], null, null);
                        toast.success("Records successfully Submitted!");
                    }
                    else if (Status == 'Open' && this.updatedData['AlterationNo'] != 0) {

                        let EmailSubjectName = "ALT " + this.updatedData['AlterationNo'] + " PO " + this.updatedData['SerialNumber'] + "," + " " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'];
                        let EmailBodyMessage = "ALT " + this.updatedData['AlterationNo'] + " PO " + this.updatedData['SerialNumber'] + " Request for " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'] + " " + " was successfully submitted to the requisition team for review.<br/> You will received a response in no more than 2 business days.";
                        this._sendMail([this.updatedData['RequestorEmail']], this.updatedData['RequestorName'], Status, this.updatedData['SerialNumber'], EmailSubjectName, EmailBodyMessage, this.updatedData['AlterationNo'], null, null);
                        toast.success("Records successfully Submitted!");
                    } else if (Status == 'Close') {
                        //this._sendMail([this.props.listItems.RequestorName], this.updatedData['RequestorName'], Status, this.updatedData['SerialNumber'], 'Project Request has been Approved', '', 0, null, null)
                        toast.success("Records successfully Approved");
                    } if (Status == 'Rejected' && this.updatedData['AlterationNo'] == 0) {

                        let EmailSubjectName = "Rejection New PO Request " + this.updatedData['SerialNumber'] + "," + " " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'];
                        let EmailBodyMessage = "New PO Request " + this.updatedData['SerialNumber'] + " for " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'] + " " + " was rejection for the reason(s) below.<br/> Please edit the request form with the updated information and resubmit.";

                        this._sendMail([this.props.listItems.RequestorName], this.updatedData['RequestorName'], Status, this.updatedData['SerialNumber'], EmailSubjectName, EmailBodyMessage, 0, this.updatedData['RejectReasons'], this.updatedData['RejectComments'])
                        toast.success("Application has Rejected");
                    }
                    else if (Status == 'Rejected' && this.updatedData['AlterationNo'] != 0) {

                        let EmailSubjectName = "Rejection ALT " + this.updatedData['AlterationNo'] + " PO " + this.updatedData['SerialNumber'] + "," + " " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'];
                        let EmailBodyMessage = "ALT " + this.updatedData['AlterationNo'] + " PO " + this.updatedData['SerialNumber'] + "Request for " + this.updatedData['ProjectName'] + "," + " " + this.updatedData['VendorName'] + "," + " " + this.updatedData['PODescription'] + "," + " " + this.updatedData['EstimatedCommitment'] + " " + " was rejection for the reason(s) below.<br/> Please edit the request form with the updated information and resubmit.";

                        this._sendMail([this.props.listItems.RequestorName], this.updatedData['RequestorName'], Status, this.updatedData['SerialNumber'], EmailSubjectName, EmailBodyMessage, 0, this.updatedData['RejectReasons'], this.updatedData['RejectComments'])
                        toast.success("Application has Rejected");
                    }

                    else if (Status == 'Draft') {
                        toast.success("Records successfully Saved as Draft");
                    }
                    if (this.props.isSupportTeam) {

                        await this.props.actions.FetchDefaultResults();
                        this.setState({
                            isloading: false,
                            isShowPrchaseOrderForm: false,
                            isShowSupportTeamTable: true,
                            isSaveBtnEnableFlag: 0,
                            isCurrentMode: 'Edit',
                            ChildList: [],
                            ChildListRemovedItem: [],
                            NewItemsInChildList: [],
                            EditItemsInChildList: [],
                            RequisitionNo: 0,
                            isReject: 'No',
                            supportTeamTable: this.props.CurrentUserSupportTeamItems
                        }, () => {
                            //this.props.actions.FetchDefaultResults();
                            //window.open(this.props.listPageURL, '_self');
                        })
                    } else {
                        await this.props.actions.FetchDefaultResults();
                        this.setState({
                            isloading: false,
                            isShowPrchaseOrderForm: false,
                            isShowPurchaseOrderTable: true,
                            isSaveBtnEnableFlag: 0,
                            isCurrentMode: 'New',
                            ChildList: [],
                            ChildListRemovedItem: [],
                            NewItemsInChildList: [],
                            EditItemsInChildList: [],
                            PurchaseOrderTable: this.props.CurrentUserPurchaseOrderItems,

                        }, () => {
                            this.updatedData = {
                                Date: new Date(),
                                ApplicationUserEmailID: this.props.userEmail,

                            }

                            //window.open(this.props.listPageURL, '_self');
                        })
                    }
                }
            });
        }
        if (Status == 'Open') {
            this.setState({ isSubmit: false });
        }

    }
    _SubmitAlertBox = () => {
        this.setState({ isSubmit: false })
    }
    _validation = (data, props) => {


        if (data.RequestorEmail === undefined || data.RequestorEmail === "") {
            toast.error('Required Requestor Name');
            return false;
        }
        if (props.MOAApprovalUploadFileList.length == 0) {
            toast.error('Required MOA Approval Documents');
            return false;
        }
        if (props.SupplierUploadFileList.length == 0) {
            toast.error('Required SupplierCTR Documents');
            return false;
        }
        if (data.VendorName === undefined || data.VendorName === "") {
            toast.error('Required Vendor Name');
            return false;
        }
        if (data.MOAApproverEmail === undefined || data.MOAApproverEmail === "") {
            toast.error('Required MOA Approver Name');
            return false;
        }
        if (data.PODescription === undefined || data.PODescription === "") {
            toast.error('Required PO Description');

            return false;
        }
        if (data.InvoiceApproverEmail === undefined || data.InvoiceApproverEmail === "") {
            toast.error('Required Invoice Approver Name');
            return false;
        }
        if (data.ProjectType === undefined || data.ProjectType === "") {
            toast.error('Required Project Type');
            return false;
        }
        if (data.ProjectName === undefined || data.ProjectName === "") {
            toast.error('Required Project Name');
            return false;
        }
        if (data.EstimatedCommitment === undefined || data.EstimatedCommitment === "") {
            toast.error('Required Estimated Commitment');
            return false;
        }
        if (data.VendorContactName === undefined || data.VendorContactName === "") {
            toast.error('Required Vendor Contact Name');
            return false;
        }
        if (data.VendorContactEmailAddress === undefined || data.VendorContactEmailAddress === "") {
            toast.error('Required Vendor Contact Email Address');
            return false;
        }
        if (this.state.ChildList.length > 0) {
            for (var i = 0; i < this.state.ChildList.length; i++) {
                if (this.state.ChildList[i].Description === undefined || this.state.ChildList[i].Description === "") {
                    toast.error('Required Description');
                    return false;

                } else if (this.state.ChildList[i].Quantity === undefined || this.state.ChildList[i].Quantity === "") {
                    toast.error('Required Quantity');
                    return false;
                } else if (this.state.ChildList[i].OriginalCost === undefined || this.state.ChildList[i].OriginalCost === "") {
                    toast.error('Required Base Cost');
                    return false;
                } else if (this.state.ChildList[i].TotalCost === undefined || this.state.ChildList[i].TotalCost === "") {
                    toast.error('Required Total Cost');
                    return false;
                } else if (this.state.ChildList[i].DeliveryDate === undefined || this.state.ChildList[i].DeliveryDate === "") {
                    toast.error('Required Delivery Date');
                    return false;
                } else if (this.state.ChildList[i].NetworkActivityCode === undefined || this.state.ChildList[i].NetworkActivityCode === "") {
                    toast.error('Required Network Activity Code');
                    return false;
                } else if (this.state.ChildList[i].ServiceOrMaterial === undefined || this.state.ChildList[i].ServiceOrMaterial === null || this.state.ChildList[i].ServiceOrMaterial === "") {
                    toast.error('Required Service');
                    return false;
                }
                else if (i == (this.state.ChildList.length - 1)) {
                    return true;
                }

            }
        } else {
            return true
        }




        //return true;
    }
    _RejectValidation = (data) => {
        if (data.RejectReasons === undefined || data.RejectReasons === null) {
            toast.error('Required Reject Reasons');
            return false;
        } else {
            return true
        }
    }
    _Reject = () => {
        if (this._RejectValidation(this.updatedData)) {
            this._SaveItemsToList('Rejected');
        }



    }
    _Approve = () => {
        this._SaveItemsToList('Close');


    }
    public _sendMail = (sendToEmailList, Name, status, ProjectNo, subject, bodyMsg, alteration, RejectReasons, RejectComment) => {

        //let RejectReasons = this.props.listItems.RejectReasons == null ? "" : this.props.listItems.RejectReasons;
        let RejectComments = RejectComment == null ? "" : RejectComment;
        let linkUrl: any = "";
        linkUrl += "<a href='" + this.props.webURL + "/SitePages/Purchase-order-Automation.aspx'> click here </a>";
        let body = "<span style='font-size:11pt; font-family:Calibri;'>Dear " + Name + ",</span><br/>";
        if (status == 'Open' && alteration == 0) {
            body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
            body += bodyMsg + "<span/><br/>"; // Current user's display name

        }
        if (status == 'Open' && alteration != 0) {
            body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
            body += bodyMsg + "<span/><br/>"; // Current user's display name

        }
        if (status == 'Rejected') {
            //xbody += "<span style='font-size:11pt; font-family:Calibri;'> A Project " + ProjectNo + " request has been Rejected by <b>" + this.props.userDisplayName + "</b></span></br>"; // Current user's display name
            body += "<span style='font-size:11pt; font-family:Calibri;margin-left: 15px;'>"
            body += bodyMsg + "<span/>" + linkUrl + "<br/>"; // Current user's display name
            body += "<b>Rejection Reason(s) and text explanation</b> <br/>";
            body += "<span>" + RejectReasons + "</span> <br/>";
            body += "<span>" + RejectComments + "</span> <br/><br/><br/>";
            body += "Regards," + "<br/>";
            body += "<span>" + this.props.userDisplayName + "</span>";

            // body += "<span><b>Reject Reasons:</b></span> <br/>";
            // body += "<span>" + RejectReasons + "</span> <br/>";
            // body += "<span><b>Rejected Comments:<b/></span> <br/>";
            // body += "<span>" + RejectComment + "</span> <br/>";
        }
        // if (status == 'Close') {
        //     body += "<span style='font-size:11pt; font-family:Calibri;'>"
        //     body += " A Project " + ProjectNo + " request has been Approved by <b>" + this.props.userDisplayName + "</b></span></br>"; // Current user's display name

        // }


        // if (status != 'Open' || status != 'Close') {
        //     body += "Regards," + "<br/>";
        //     body += "<span>" + this.props.userDisplayName + "</span>"; // Display Name of the current user
        // }

        this.props.actions.SendMail(body, sendToEmailList, subject).then((res) => {

            if (res) {
                toast.success("Email sent successfully!");
            }
        });
    }


    public render(): JSX.Element {
        return (
            <>
                <Container fluid>
                    {this.props.isRequestorsTeam && this.state.isCreateBtnShow && this.state.isCurrentMode == 'New' && <>
                        <h2>Create a new Purchase Request Summary</h2>
                        <Row>
                            <Col>
                                <Button color="primary" onClick={this._CreateList}>Create a new Service Request Form </Button>
                            </Col>
                        </Row>
                    </>
                    }


                    {this.props.isRequestorsTeam && this.state.isShowPurchaseOrderTable && <Row className='mt-5'>

                        {/* <ServicesRequestList
                            {...this.props}
                            {...this.state}
                            onEdit={(e) => this._Edit(e)}
                            onView={this._View}
                            onHandlechange={this._onHandlechange}
                            onFormatDate={this._onFormatDate}
                            isViewMode={true} /> */}
                        {this.state.PurchaseOrderTable.length > 0 && <ServicesRequestTable
                            {...this.props}
                            {...this.state}
                            onEdit={(e) => this._Edit(e)}
                            onView={this._View}
                            onDelete={(e) => this._Delete(e)}
                            onHandlechange={this._onHandlechange}

                            onFormatDate={this._onFormatDate}
                            isViewMode={true}
                        />
                        }

                    </Row>
                    }
                    {this.props.isSupportTeam && this.state.isShowSupportTeamTable && <Row className='mt-5'>

                        {/* <SupportTeamList
                            {...this.props}
                            {...this.state}
                            onEdit={(e) => this._Edit(e)}
                            onView={this._View}
                            onHandlechange={this._onHandlechange}
                            onFormatDate={this._onFormatDate}
                            isViewMode={true} /> */}

                        {this.state.supportTeamTable.length > 0 ? <SupportTeamTable
                            {...this.props}
                            {...this.state}
                            onEdit={(e) => this._Edit(e)}
                            onView={this._View}
                            onAlertationView={this._AlertationView}
                            onHandlechange={this._onHandlechange}
                            onFormatDate={this._onFormatDate}
                            isViewMode={true}
                            onSelectAlertation={this._onselectAlteration}
                            AlterationArray={this.props.AlterationArray}
                        />
                            : <span className={styles.noRecordsfound}>No Records found!..</span>
                        }
                    </Row>
                    }
                    {this.state.isShowPrchaseOrderForm &&
                        <>
                            <Row className='mt-5'>
                                <FormFiled  {...this.props} {...this.state}
                                    ref={ref => (this.pond = ref)}
                                    //attachments={this.state.attachments}
                                    OnupdatefilesHandler={fileItems => this._onupdatefilesHandler(fileItems)}
                                    OnhandleInit={() => this._OnhandleInit()}
                                    onCreateDate={this._onCreateDate}
                                    onHandlechange={this._onHandlechange}
                                    handleCurrencyChange={this._onHandleCurrencyChange}
                                    MasterDataProjectType={this.props.MasterDataProjectType}
                                    MasterDataOffshoreServices={this.props.MasterDataOffshoreServices}
                                    isViewMode={this.props.isSupportTeam ? true : (this.state.isCurrentMode != 'View' ? false : true)}
                                    GetPepoleMOAApprover={this._GetPepoleMOAApprover}
                                    GetPepoleRequestorName={this._GetPepoleRequestorName}
                                    GetPepoleCPBuyer={this._GetPepoleCPBuyer}
                                    GetPepoleInvoiceApprover={this._GetPepoleInvoiceApprover}
                                    GetPepoleProjectServicesFocalPoint={this._GetPepoleProjectServicesFocalPoint}
                                    MOAApprovalUploadFileList={this.props.MOAApprovalUploadFileList}
                                    SupplierUploadFileList={this.props.SupplierUploadFileList}
                                    OtherUploadFileList={this.props.OtherUploadFileList}
                                    attachments={[]}
                                    MOAfileloader={this.state.MOAshowLoader ? (!this.state.MOAshowLoaderlevel ? (this.props.MOAApprovalUploadFileList.length < 1 ? true : false) : true) : false}
                                    Supplierfileloader={this.state.SuppliershowLoader ? (!this.state.SuppliershowLoaderlevel ? (this.props.SupplierUploadFileList.length < 1 ? true : false) : true) : false}
                                    Otherfileloader={this.state.OthershowLoader ? (!this.state.OthershowLoaderlevel ? (this.props.OtherUploadFileList.length < 1 ? true : false) : true) : false}
                                    DeleteUploadedDoc={this._DeleteUploadedDoc}
                                    onFileUpload={this._onFileUpload} />


                            </Row>
                            <Row className='mt-5'>
                                <h3>Purchase Line Item Details</h3>
                                {/* <POLineList {...this.props} onHandlechange={this._onHandlechange} isViewMode={false} /> */}
                                <PONumberTable  {...this.props} isViewMode={this.props.isSupportTeam ? true : (this.state.isCurrentMode != 'View' ? false : true)} ChildList={this.props.ChildList} isCurrentMode={this.state.isCurrentMode} SerialNumber={this.state.SerialNumber} parentCallback={this._HandleCallback} />
                            </Row>
                            <Row className='mt-5'>
                                <h3>Additional Contact Information and Commentary</h3>
                                <PoListForm {...this.props} isCurrentMode={this.state.isCurrentMode} isViewMode={this.props.isSupportTeam ? true : (this.state.isCurrentMode != 'View' ? false : true)} onHandlechange={this._onHandlechange} />
                            </Row>

                            {this.props.isSupportTeam && <Row className='mt-5'>
                                <h3>To be completed by the Portfolio Support Team Member</h3>
                                <SupportTeamForm {...this.props}{...this.state}
                                    isCurrentMode={this.state.isCurrentMode}
                                    isViewMode={this.state.isCurrentMode != 'View' ? false : true}
                                    onHandlechange={this._onHandlechange}
                                    handleCurrencyChange={this._onHandleCurrencyChange} />
                            </Row>}

                            <Row>
                                <Col xs={6} sm={6} md={6} lg={6} xl={6} className="pl-0">
                                    <Button outline color="primary" onClick={this._Cancel}> Cancel</Button>
                                </Col>
                                {this.props.isRequestorsTeam && <Col xs={6} sm={6} md={6} lg={6} xl={6} className="text-right pr-0">
                                    {this.state.isCurrentMode != 'View' && this.updatedData['Status'] !== 'Rejected' && <Button outline color="primary" onClick={this._SaveAsDraft} disabled={this.state.isSaveBtnEnableFlag == 0 ? true : false}> Save as Draft </Button>} {' '}
                                    {this.state.isCurrentMode != 'View' && <Button color="primary" onClick={this._Submit} disabled={this.state.isSaveBtnEnableFlag == 0 ? (this.state.isCurrentMode == 'Edit' ? false : true) : (this.state.isCurrentMode != 'View' ? false : true)}> Submit </Button>}
                                </Col>
                                }
                                {this.props.isSupportTeam && <Col xs={6} sm={6} md={6} lg={6} xl={6} className="text-right pr-0">
                                    {this.state.isCurrentMode != 'View' && <Button outline color="primary" onClick={this._Reject} disabled={this.state.isReject == 'No' ? true : false} > Reject </Button>} {' '}
                                    {this.state.isCurrentMode != 'View' && <Button color="primary" onClick={this._Approve} disabled={this.state.isReject == 'Yes' ? true : false} > Approve </Button>}
                                </Col>
                                }
                            </Row>
                        </>
                    }


                    <Modal isOpen={this.state.isSubmit}>
                        <ModalHeader toggle={this._SubmitAlertBox}>Confirmation</ModalHeader>
                        <ModalBody>
                            <h1 className={styles.ModalHeading}>Are you want to submit your request?</h1>
                        </ModalBody>
                        <ModalFooter>
                            <Button outline color="primary" onClick={() => this._SaveItemsToList('Open')}> Yes </Button> {' '}
                            <Button outline color="primary" onClick={this._SubmitAlertBox}> Cancel </Button>
                        </ModalFooter>
                    </Modal>
                    {this.state.isloading && <div className={styles.spinnerContainer}>
                        <div className={styles.loader}> </div>
                    </div>
                    }

                </Container>



                {<ToastContainer
                    position="top-right"
                    autoClose={5000}
                    hideProgressBar={true}
                    newestOnTop={false}
                    closeOnClick={false}
                    rtl={false}
                    pauseOnFocusLoss={false}
                    draggable={false}
                    pauseOnHover={false}
                />
                }
            </>
        );
    }
}
export default PurchaseOrder;