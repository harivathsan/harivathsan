import { createStore, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import appReducers from '../reducer/rootReducer';
const middleware = [thunk];
const composeEnhancers = window['__REDUX_DEVTOOLS_EXTENSION_COMPOSE__'] as typeof compose || compose;
const store: any = createStore(
    appReducers,
    composeEnhancers(applyMiddleware(...middleware))
);
export default store;