
export const WHC_API_Path = {
    items: '/items',
    editItemParam: "/items('{0}')",
    apiListName: '/_api/web/Lists/GetByTitle',
    apiGroupName: '/_api/Web/CurrentUser/Groups',
    apiCurrentUserGroup: '/_api/web/RoleAssignments/Groups?$expand=Users',

    rootFolderparam: "/RootFolder/folders('{0}')",
    filenameParam: "/Files/Add(url='{0}',overwrite=true)",
    folderID: "/items('{0}')",
    getFolderParam: "/_api/web/GetFolderByServerRelativeUrl('{0}",
    getFileListItemAllFieldsParams: "/{0}')?$expand=ListItemAllFields",
    deleteUploadFileParam: "/_api/web/GetFolderByServerRelativeUrl('{0}')",
    //getEditDeatails: "/items('{0}')?$select=ID,Title,Project,Originator_x002f_RE/EMail,Originator_x002f_RE/Title,Originator_x002f_RE/ID,Notes,PCAP_x0020_ID,Document_x0020_Type,Distribution_x0020_List,Status,Area_x0020_Code,Discipline_x0020_Code,Classification,PlannedStartDate,Planned_x0020_Start_x0020_Date_x,FormNo&$expand=Originator_x002f_RE",

    getEditDeatails: "/items('{0}')?$select=*,MOAApprover/EMail,MOAApprover/Title,MOAApprover/ID,InvoiceApprover/EMail,InvoiceApprover/Title,InvoiceApprover/ID,CPBuyer/EMail,CPBuyer/Title,CPBuyer/ID,Requestor/EMail,Requestor/Title,Requestor/ID,Attachments,AttachmentFiles&$expand=MOAApprover,InvoiceApprover,CPBuyer,Requestor,AttachmentFiles",
    getAlertaionDeatails: "/items?$select=ID,ParentListId,Title,AlterationNo,AlterationsListVersion_0,AlterationsListVersion_1,AlterationsListVersion_2,AlterationsListVersion_3,AlterationsListVersion_4&$filter=ParentListId eq '{0}'",
    getPoListDeatails: "/items?$select=ID,POLineNumber,DeliveryDate,Description,NetworkActivityCode,OriginalCost,ProgressPayment,Quantity,ReqAndLineNumber,SerialNumber,ServiceOrMaterial,Taxable,TotalCost,Units&$filter=SerialNumber eq '{0}'",
    getPoListEditDeatails: "/items('{0}')",
    getPoListDeleteDeatails: "/items('{0}')",
    DeleteSelectedRowDeatails: "/items('{0}')",
    attachmentList: "/AttachmentFiles/add(FileName='${uploadedFiles[index].name}')",


    getDetailsFolder: "/items?$select=FormNo,FileRef,BaseName&$filter=substringof('DNRF',FileRef) and FormNo eq '{0}'&$orderby=Created asc &$top=1",
    getDetailsFilePath: "/{0}')/files?$expand=ListItemAllFields",
    getFileListParamURL: '/_api/web/GetFolderByServerRelativeUrl',
    sendMailParam: "/_api/SP.Utilities.Utility.SendEmail",
    folderUrlParam: "/rootfolder/folders/add(url='{0}')",

};
export const masterData = {
    assignmentReference: 'assignments/referencetypes',
    documentType: 'module/document/types',
    apiListName: '/_api/web/Lists/GetByTitle',
    items: '/items?$select=ID,Area_x0020_Combined_x0020_Result,CombinedArea&$orderby=CombinedArea',
    item: '/items',
    projectsListItemQueryParam: '/items?$select=ID,Title&$orderby=Title',
    disciplineItemQueryParam: '/items?$select=Title,Document_x0020_Type_x0020_Short_&$top=30000&$orderby=Title',
    docTypeListItemQueryParam: "/items?$select=Document_x0020_Type_x0020_Short_&$filter=Title eq'{0}'&$orderby=Document_x0020_Type_x0020_Short_",

    formNoQueryParam: '/items?$select=Id&$orderby=Id desc&$top=1',
    getEmailParam: "/items?$select=To/EMail,CC/EMail,Subject,EmailBox&$expand=To&$expand=CC&$top=1"

}