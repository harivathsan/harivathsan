import { masterDataActionTypes, formAction } from '../constants/actionType';
export const PurchaseOrderReducer = (state: any, action: any) => {
    const { type, data } = action;
    switch (type) {

        case formAction.FETCH_WHC_DATA:
            return {
                ...state
            };
        case formAction.FETCH_SELECTED_ITEM_ROWDATA: {
            return {
                ...state,
                listItems: data
            };
        }
        case formAction.FETCH_GROUP_NAME: {
            return {
                ...state,
                ...data
            };
        }
        case formAction.POLIST_ADD_NEW: {
            return {
                ...state,
                ...data
            };
        }
        case formAction.POLIST_UPDATE_DATA: {
            return {
                ...state,
                ...data
            };
        }
        case formAction.POLIST_FETCH_LIST: {
            return {
                ...state,
                ChildList: data
            };
        }
        case formAction.CREATE_FOLDER:
            state = {
                ...state,
                folderDetails: data
            };
            return state;
        case formAction.FILE_UPLOAD:
            state = {
                ...state,
                uploadFile: data
            };
            return state;
        case formAction.GET_LIST_ALL_ITEM:
            state = {
                ...state,
                listItemAllFiled: data
            };
            return state;
        case formAction.CLEAR_MOA_UPLOADED_FILE_LIST:
            state = {
                ...state,
                MOAApprovalUploadFileList: data
            };
            return state;
        case formAction.CLEAR_SUPPLIER_UPLOADED_FILE_LIST:
            state = {
                ...state,
                SupplierUploadFileList: data
            };
            return state;
        case formAction.CLEAR_OTHER_UPLOADED_FILE_LIST:
            state = {
                ...state,
                OtherUploadFileList: data
            };
            return state;
        case formAction.GET_MOA_UPLOADED_FILE_LIST:
            state = {
                ...state,
                MOAAttachment: data.length > 0 ? 'Yes' : 'No',
                MOAApprovalUploadFileList: data
            };
            return state;
        case formAction.GET_SUPPLIER_UPLOADED_FILE_LIST:
            state = {
                ...state,
                SupplierAttachment: data.length > 0 ? 'Yes' : 'No',
                SupplierUploadFileList: data
            };
            return state;
        case formAction.GET_OTHER_UPLOADED_FILE_LIST:
            state = {
                ...state,
                OtherAttachment: data.length > 0 ? 'Yes' : 'No',
                OtherUploadFileList: data
            };
            return state;
        case formAction.FILE_CLEAR:
            state = {
                ...state,
                MOAApprovalUploadFileList: [],
                SupplierUploadFileList: [],
                OtherUploadFileList: [],
                MOAAttachment: 'No',
                OtherAttachment: 'No',
                SupplierAttachment: 'No'
            };

            return state;
        case formAction.AlTERATIONITEM:
            state = {
                ...state,
                AlterationRowListItems: data,
                listItems: data.Mainlist,
                ChildList: data.ChildList,
                AlterationRowId: data.AlterationRowId
            };
            return state;
        case formAction.AlTERATIONITEM_ID:
            state = {
                ...state,
                AlterationRowId: data.AlterationRowId
            };
            return state;
        default:
            return state;
    }
};