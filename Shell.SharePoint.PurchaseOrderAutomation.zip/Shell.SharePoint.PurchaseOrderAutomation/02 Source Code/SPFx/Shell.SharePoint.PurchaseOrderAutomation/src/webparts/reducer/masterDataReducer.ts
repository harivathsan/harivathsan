import { masterDataActionTypes } from '../constants/actionType';

export const MasterDataReducer = (state, actions) => {

    const { type, data } = actions;
    switch (type) {
        case masterDataActionTypes.FETCH_PARENT_PROPS:
            state = {
                ...state,
                parentProps: data
            };
            return state;
        case masterDataActionTypes.FETCH_LIST_DATA:
            state = {
                ...state,
                CurrentUserSupportTeamItems: data.CurrentUserSupportTeamItems,
                CurrentUserPurchaseOrderItems: data.CurrentUserPurchaseOrderItems,
                PurchaseOrderData: data.PurchaseOrderData

            };
            return state;
        case masterDataActionTypes.FETCH_USER_GROUP:
            state = {
                ...state,
                isSupportTeam: data.isPortfolioSupportTeam,
                isRequestorsTeam: data.isRequestors


            };
            return state;
        case masterDataActionTypes.FETCH_CRRENT_USER:
            state = {
                ...state,
                CurrentUserInfo: data,
            };
            return state;

        default:
            return state;
    }
};