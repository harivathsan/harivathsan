import { combineReducers } from 'redux';
import { PurchaseOrderReducer } from '../reducer/purchaseOrderReducer';
import { MasterDataReducer } from '../reducer/masterDataReducer';
import reduceReducers from 'reduce-reducers';
const initialstate: any = {
    AlterationRowListItems: {},
    AlterationRowId: 0,
    isSupportTeam: false,
    isRequestorsTeam: false,
    CurrentUserInfo: {},
    CurrentUserPurchaseOrderItems: [],
    CurrentUserSupportTeamItems: [],
    PurchaseOrderData: [],
    ChildList: [],
    listItems: {},
    MOAApprovalUploadFileList: [],
    SupplierUploadFileList: [],
    OtherUploadFileList: [],
    OtherAttachment: 'No',
    SupplierAttachment: 'No',
    MOAAttachment: 'No',
    listItemAllFiled: {},
    MasterDataProjectType: [
        {
            label: "Brownfield",
            value: "Brownfield"
        },
        {
            label: "Greenfield",
            value: "Greenfield"
        },
        {
            label: "Topsides",
            value: "Topsides"
        }
    ],
    MasterDataOffshoreServices: [
        {
            label: "Yes",
            value: "Yes"
        },
        {
            label: "No",
            value: "No"
        }
    ],
    MasterDataService: [
        {
            label: "Service",
            value: "service"
        },
        {
            label: "Material",
            value: "Material"
        }
    ],
    MasterDataTaxable: [
        {
            label: "Yes",
            value: "Yes"
        },
        {
            label: "No",
            value: "No"
        }
    ],
    MasterDataProgressPayment: [
        {
            label: "Yes",
            value: "Yes"
        },
        {
            label: "No",
            value: "No"
        }
    ],
    MasterDataRejectedReasons: [
        {
            label: "Charge code(s) budget error",
            value: "Charge code(s) budget error"
        },
        {
            label: "Charge code(s) not released",
            value: "Charge code(s) not released"
        },
        {
            label: "Charge code(s) blocked",
            value: "Charge code(s) blocked"
        },
        {
            label: "Request value and supplier CTR mismatch",
            value: "Request value and supplier CTR mismatch"
        },
        {
            label: "Incorrect project MoA approver",
            value: "Incorrect project MoA approver"
        },
        {
            label: "Incorrect required information",
            value: "Incorrect required information"
        },
        {
            label: "Other",
            value: "Other"
        }


    ],
    AlterationArray: [
        {
            label: "0",
            value: "0"
        },
        {
            label: "1",
            value: "1"
        },
        {
            label: "2",
            value: "2"
        },
        {
            label: "3",
            value: "3"
        },
        {
            label: "4",
            value: "4"
        },
    ]
};
const DetailReducer = reduceReducers(

    initialstate,
    PurchaseOrderReducer,
    MasterDataReducer

);
const appReducers = combineReducers({
    DetailReducer


});
export default appReducers;