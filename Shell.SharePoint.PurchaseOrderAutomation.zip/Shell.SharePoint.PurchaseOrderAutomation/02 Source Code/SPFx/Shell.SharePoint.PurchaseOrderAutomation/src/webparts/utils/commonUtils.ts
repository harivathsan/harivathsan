import * as _ from "lodash";
export const StringFormat = (...params) => {
    let str = '';
    if (params.length) {
        str = params[0];
        let key;
        params.shift();
        for (key in params) {
            str = str.replace(new RegExp("\\{" +  key + "\\}", "gi"), params[key]);
        }
    }
    return str;
};

export const removeSpecialChars=(str)=> {
    try {
      return str.replace(/(?!\w|\s)./g, ' ') // 1st regex /(?!\w|\s)./g remove any character that is not a word or whitespace. \w is equivalent to [A-Za-z0-9_]
        .replace(/\s+/g, ' ') // find any appearance of 1 or more whitespaces and replace it with one single white space
        .replace(/^(\s*)([\W\w]*)(\b\s*$)/g, '$2'); //trim the string to remove any whitespace at the beginning or the end.
    }
    catch (error) {
      console.log("removeSpecialChars-" + error)
    }

  }

  
export const isEmpty = function (obj) {
  if (obj === null) return true;
  if (_.isArray(obj) || _.isString(obj)) return obj.length === 0;
  for (const key in obj)
      if (_.has(obj, key)) return false;
  return true;
};

export const isEmptyOrUndefine = function (obj) {
  if (obj === 'undefined' || obj === null || obj === "" || obj === " " || isEmpty(obj))
      return true;

  if (_.isArray(obj) || _.isString(obj))
      return obj.length === 0;

  for (const key in obj)
      if (_.has(obj, key)) return false;

  return true;
};

export const connectArray= (souce, des) => {
  const obj = _.concat(souce,des);
  return obj;
}