declare interface ICopytofolderWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CopytofolderWebPartStrings' {
  const strings: ICopytofolderWebPartStrings;
  export = strings;
}
