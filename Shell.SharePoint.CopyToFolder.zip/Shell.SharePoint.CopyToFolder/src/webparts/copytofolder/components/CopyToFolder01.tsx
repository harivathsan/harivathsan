import * as React from 'react';
//import { spfi, SPFx as spSPFx } from "@pnp/sp";
//import "@pnp/sp/webs";
//import "@pnp/sp/folders";

import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';

export interface ICopyToFolder01Props {
    spHttpClient: any;
    siteUrl: any;
    listName: string;
}

export interface ICopyToFolder01State {

}



class CopyToFolder01 extends React.Component<ICopyToFolder01Props, ICopyToFolder01State> {
    public readonly state: ICopyToFolder01State;

    //public sp = spfi().using(spSPFx(this.context));

    constructor(props: ICopyToFolder01Props) {
        super(props);

        this.state = {

        };

    }

    public componentDidMount() {

    }


    private copyBtnClickHandler = async () => {
        // destination is a server-relative url of a new folder changes 
        // const destinationUrl = `/sites/SPOAA0342/PurchaseOrder/Purchase%20Order%20Documents%20Library/new-folder`;
        //await this.sp.web.rootFolder.folders.getByUrl("Purchase%20Order%20Documents%20Library").folders.getByUrl("SupplierCTR-190102022-4593-0").copyByPath(destinationUrl,true);
        //Begin
        const body: string = JSON.stringify({
            //'Title': `Item ${new Date()}`
            "srcPath": {
                "__metadata": {
                    "type": "SP.ResourcePath"
                },
                "DecodedUrl": "https://eu023-sp.shell.com/sites/SPOAA0342/PurchaseOrder/Purchase%20Order%20Documents%20Library/SupplierCTR-190102022-4593-0"
            },
            "destPath": {
                "__metadata": {
                    "type": "SP.ResourcePath"
                },
                "DecodedUrl": "https://eu023-sp.shell.com/sites/SPOAA0342/PurchaseOrder/Purchase%20Order%20Documents%20Library/mynewfolder01"
            },
            "options": {
                "__metadata": {
                    "type": "SP.MoveCopyOptions"
                },
                "ResetAuthorAndCreatedOnCopy": true,
                "ShouldBypassSharedLocks": true
            }
        });
        //https://example.com/sites/<siteName>/_api/SP.MoveCopyUtil.CopyFolderByPath()
        //this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items`,
    
        this.props.spHttpClient.post(`${this.props.siteUrl}/_api/web/GetFolderByServerRelativeUrl('/sites/SPOAA0342/PurchaseOrder/Purchase%20Order%20Documents%20Library/SupplierCTR-190102022-4593-0')/copyTo('/sites/SPOAA0342/PurchaseOrder/Purchase%20Order%20Documents%20Library/mynewcopyfolder')`,
            SPHttpClient.configurations.v1,
            {
                headers: {
                    'Accept': 'application/json;odata=nometadata',
                    'Content-type': 'application/json;odata=nometadata',
                    'odata-version': ''
                },
                //body: body
            })
            .then((response: SPHttpClientResponse): void => {
                response.json().then(async (item: any): Promise<void> => {
                    console.log(response.text);
                }, (error: any): void => {
                    console.log('Error Message:' + error);
                });
            });

        //End

    }

    public render() {
        return (
            <div>
                <button onClick={this.copyBtnClickHandler}>Copy To Folder</button>
            </div>
        );
    }
}

export default CopyToFolder01;