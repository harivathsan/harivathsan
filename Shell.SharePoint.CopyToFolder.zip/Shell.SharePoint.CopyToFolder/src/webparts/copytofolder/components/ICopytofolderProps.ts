import { SPHttpClient } from '@microsoft/sp-http';
export interface ICopytofolderProps {
  description: string;
  listName: string;
  spHttpClient: SPHttpClient;  
  siteUrl: string;
}
