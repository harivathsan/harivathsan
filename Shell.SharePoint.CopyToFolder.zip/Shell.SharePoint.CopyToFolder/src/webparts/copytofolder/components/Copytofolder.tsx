import * as React from 'react';
import styles from './Copytofolder.module.scss';
import { ICopytofolderProps } from './ICopytofolderProps';
import { escape } from '@microsoft/sp-lodash-subset';
import CopyToFolder01 from './CopyToFolder01';

export default class Copytofolder extends React.Component<ICopytofolderProps, {}> {
  public render(): React.ReactElement<ICopytofolderProps> {
    return (
      <div className={styles.copytofolder}>
        <h2>test</h2>
        <CopyToFolder01 {...this.props}/>
      </div>
    );
  }
}
