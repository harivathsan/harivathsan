import * as React from 'react';
import ApplicationCustomizerContext from "@microsoft/sp-application-base/lib/extensibility/ApplicationCustomizerContext";
import styles from './Notification.module.scss';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IListItem } from '../IListItem';

export interface INotificationProps {
  context: ApplicationCustomizerContext;
}

export interface INotificationState {
  Title: string;
  URL: string;
}

export class Notification extends React.Component<any, INotificationState> {
  //Global Variables
  public readonly state: INotificationState;

  constructor(props: INotificationProps) {
    super(props);

    this.state = {
      Title: '',
      URL: ''
    };
  }//End Constructor

  //******** Begin Methods********//

  //Begin GetListData
  private async GetListData() {
    try {
      let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.props.listName + "')/Items";
      let response = await this.props.context.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1,
        {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=nometadata',
            'odata-version': ''
          }
          //body: body
        })
        .then((responseValues: SPHttpClientResponse): Promise<IListItem> => {
          return responseValues.json();
        })
        .then((item: IListItem): void => {
          console.log("Get Items successfully !!!");

          this.setState({
            Title: item['value'][0].Title,
            URL: item['value'][0].URL

          });

        }, (error: any): void => {
          alert("Error in Get Items !!!");
        });
    }
    catch (error) {
      console.log("Error in Get Items Data : " + error);
    }
  }
  //End GetListData

  //******** End Methods********//

  //******** Begin Hanlder********//

  //Begin componentDidMount
  public componentDidMount() {
    //Method to load pop up content dynamically from Banner Info        
    this.GetListData();
  }
  //End componentDidMount

  //Begin Render
  public render() {
    const { Title, URL } = this.state;
    return (
      <div className={styles.notification}>
        <div className={styles.btnAlignment}>
          <span>
            <a href={URL}>
              <button className={styles.btn}>{Title}</button>
            </a>
          </span>
        </div>
      </div>
    );
  }
  //End Render

  //******** End Hanlder********//
}

export default Notification;