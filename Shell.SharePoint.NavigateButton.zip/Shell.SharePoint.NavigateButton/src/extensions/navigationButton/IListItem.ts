export interface IListItem{
    Title?:string;
    URL:string;
}