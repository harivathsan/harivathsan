import * as React from "react";
import * as ReactDom from 'react-dom';
import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer, PlaceholderContent, PlaceholderName
} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'NavigationButtonApplicationCustomizerStrings';
import NotificationMsg from './components/Notification';
import { INotificationProps } from './components/Notification';

const LOG_SOURCE: string = 'NavigationButtonApplicationCustomizer';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface INavigationButtonApplicationCustomizerProperties {
  // This is an example; replace with your own property
  testMessage: string;
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class NavigationButtonApplicationCustomizer
  extends BaseApplicationCustomizer<INavigationButtonApplicationCustomizerProperties> {


  //Global Variable  
  private _headerPlaceholder: PlaceholderContent;
  private listName: string = "Config%20List";

  @override
  public onInit(): Promise<void> {
    console.log("Begin Navigation Button");
    // Added to handle possible changes on the existence of placeholders
    this
      .context
      .placeholderProvider
      .changedEvent
      .add(this, this._renderPlaceHolders);

    // Call render method for generating the needed html elements
    this._renderPlaceHolders();
    console.log("End Navigation Button");

    return Promise.resolve();
  }

  private _renderPlaceHolders(): void {
    // Check if the header placeholder is already set and if the header placeholder
    // is available
    if (!this._headerPlaceholder && this.context.placeholderProvider.placeholderNames.indexOf(PlaceholderName.Top) !== -1) {
      this._headerPlaceholder = this
        .context
        .placeholderProvider
        .tryCreateContent(PlaceholderName.Top, { onDispose: this._onDispose });

      // The extension should not assume that the expected placeholder is available.
      if (!this._headerPlaceholder) {
        console.error('The expected placeholder (PageHeader) was not found.');
        return;
      }

      if (this._headerPlaceholder.domElement) {
        const context: any = this.context;
        var propObj = { listName: this.listName, context };
        const element: React.ReactElement<INotificationProps> = React.createElement(NotificationMsg, propObj);
        ReactDom.render(element, this._headerPlaceholder.domElement);
      }
    }
  }

  private _onDispose(): void {
    console.log('[Navigation._onDispose] Disposed Navigation.');
  }

}
