declare interface INavigationButtonApplicationCustomizerStrings {
  Title: string;
}

declare module 'NavigationButtonApplicationCustomizerStrings' {
  const strings: INavigationButtonApplicationCustomizerStrings;
  export = strings;
}
