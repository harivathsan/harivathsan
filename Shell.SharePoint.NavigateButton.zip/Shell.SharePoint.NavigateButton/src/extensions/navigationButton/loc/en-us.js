define([], function() {
  return {
    "Title": "NavigationButtonApplicationCustomizer"
  }
});