declare interface ICommandsetdemoCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'CommandsetdemoCommandSetStrings' {
  const strings: ICommandsetdemoCommandSetStrings;
  export = strings;
}
