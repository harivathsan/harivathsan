import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import { BaseListViewCommandSet, Command, IListViewCommandSetListViewUpdatedParameters, IListViewCommandSetExecuteEventParameters } from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'CommandsetdemoCommandSetStrings';
import { SPHttpClientResponse, SPHttpClient } from '@microsoft/sp-http';
import { SPPermission } from '@microsoft/sp-page-context';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface ICommandsetdemoCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  sampleTextTwo: string;
  pemissions: string;
}

const LOG_SOURCE: string = 'CommandsetdemoCommandSet';

export default class CommandsetdemoCommandSet extends BaseListViewCommandSet<ICommandsetdemoCommandSetProperties> {
  private ViewID: string = "123";

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized CommandsetdemoCommandSet');

    //Begin
    return new Promise<void>((resolve, reject) => {
      this
        .getPermissions()
        .then((permissionLevel: string) => {
          this.properties.pemissions = permissionLevel;
          resolve();
        }, (error: any): void => {
          this.properties.pemissions = "No";
          resolve();
        });
    });
    //End

  }

  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {
    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');
    /*
  if (compareOneCommand) {
  // This command should be hidden unless exactly one row is selected.
  // compareOneCommand.visible = event.selectedRows.length === 1;
  compareOneCommand.visible = event.selectedRows.length === 0;
  }
  */
    //debugger;
    let listTitle = this.context.pageContext.list.title;
    if (listTitle.toLowerCase() === "asset compliance project process") {
      compareOneCommand.visible = event.selectedRows.length === 1;
      //if (this.properties.pemissions === "Testing") {
      if (this.properties.pemissions === "ACP_Members") {
        compareOneCommand.visible = event.selectedRows.length === 0;
        switch (event.selectedRows.length) {
          case 0:
            compareOneCommand.visible = true;
            const url = new URL(window.location.href);
            const params = new URLSearchParams(url.search);
            let searchParam: string;
            params.has('search') ? searchParam = params.get("search") : searchParam = "";
            if (searchParam === this.ViewID) {
              document.querySelectorAll("[data-automationid='TitleSpan']")[0]["innerText"] = "Query Command 1";
            }
            break;
          case 1:
            compareOneCommand.visible = true;
            break;
          default:
            compareOneCommand.visible = true;
            break;
        }
      } else {
        compareOneCommand.visible = false;
      }
    }

  } //End ListView Updated

  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void {
    switch (event.itemId) {
      case 'COMMAND_1':
        Dialog.alert(`${this.properties.sampleTextOne}`);
        document.querySelectorAll("[data-automationid='TitleSpan']")[0]["innerText"] = "Command 1";
        break;
      case 'COMMAND_2':
        Dialog.alert(`you have clicked command 2 ${this.properties.sampleTextTwo}`);
        document.querySelectorAll("[data-automationid='TitleSpan']")[0]["innerText"] = "Command 2";
        break;
      default:
        throw new Error('Unknown command');
    }
  }

  /**
 * Get Permission for the Users
 */
  protected getPermissions(): Promise<string> {
    //debugger;
    const siteURL = this.context.pageContext.web.absoluteUrl;
    const currentUserEmail = this.context.pageContext.user.email;
    let permissionLevel: string = "No";
    return new Promise<string>((resolve, reject) => {
      this
        .context
        .spHttpClient
        //.get(`${siteURL}/_api/web/RoleAssignments/Groups?$filter=(substringof('Owners',Title) or substringof('Testing',Title))&$expand=Users`, SPHttpClient.configurations.v1)
        .get(`${siteURL}/_api/web/RoleAssignments/Groups?$filter=(substringof('Owners1',Title) or substringof('ACP_Members',Title))&$expand=Users`, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        })
        .then((response): void => {
          if (response.value !== undefined && response.value.length > 0) {
            //const ownerUsers = this.filterArray("Owners", response.value);
            //const testingUsers = this.filterArray("Testing", response.value);
            const testingUsers = this.filterArray("ACP_Members", response.value);

            if (testingUsers.filter((userObj) => userObj.Email === currentUserEmail).length > 0) {
              //permissionLevel = "Testing";
              permissionLevel = "ACP_Members";
            } else {
              permissionLevel = "No";
            }
          }
          resolve(permissionLevel);
        }, (error: any): void => {
          reject(permissionLevel);
        });
    });
  }

  /**
 * Filter Array Value
 */
  private filterArray(groupName: string, responseArr: any) {
    let filter = responseArr.filter((group) => {
      return group.Title.indexOf(groupName) > -1;
    });
    return (filter.length > 0 ? filter[0].Users : "");
  }

} //End Class