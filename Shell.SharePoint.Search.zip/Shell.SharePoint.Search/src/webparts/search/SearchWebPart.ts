import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'SearchWebPartStrings';
import Search from './components/Search';
import { ISearchProps } from './components/ISearchProps';

export interface ISearchWebPartProps {
  description: string;
  css: string;
  documentsName:string;
  webURL:string;

}

export default class SearchWebPart extends BaseClientSideWebPart<ISearchWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ISearchProps> = React.createElement(
      Search,
      {
        description: this.properties.description,
        css: this.properties.css,
        webURL: this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        context: this.context,
        documentsName:this.properties.documentsName

      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('css', {
                  label: "~ Css"
                }),
                 PropertyPaneTextField('documentsName', {
                  label: 'Library name',
                  multiline: true,
                  rows: 5
                
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
