import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface ISearchProps {
  description: string;
  context: WebPartContext;
  css: string;  
  documentsName:string;
  webURL:string;
}
