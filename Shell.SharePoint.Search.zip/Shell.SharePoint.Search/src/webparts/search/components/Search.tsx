import * as React from 'react';
import styles from './Search.module.scss';
import { ISearchProps } from './ISearchProps';
import { escape } from '@microsoft/sp-lodash-subset';
import SearchForm from './Form';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { Container,Col,Row } from 'reactstrap';

export default class Search extends React.Component<ISearchProps, {}> {
          constructor(props) {
            super(props);
  //importing Global CSS
        let cssPath: string = escape(this.props.css);
        if (cssPath !== "") {
        SPComponentLoader.loadCss(cssPath);
        }
      
      }  
      public render(): React.ReactElement<ISearchProps> {
    return (
      <Container fluid>
        <Row>
          <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.search}>
            <h1>Search Demo</h1>
            <Row>
              <SearchForm context={this.props.context} documentsName={this.props.documentsName} webURL={this.props.webURL} css={this.props.css}/>
            </Row>
          </Col>
      </Row>
      </Container>
    );
  }
}
