import * as React from 'react';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IListItem } from '../IListItem';
import styles from './Search.module.scss';
import { Row, Col, Input, Button, Label, Container } from 'reactstrap';
import { SPComponentLoader } from '@microsoft/sp-loader';


export interface ISearchFormProps {
    context: any;
    documentsName: any;
    webURL: any;
    css: any;

}

export interface ISearchFormState {
    txtVal: string;
    libName: string;
    fileName: string;
    fileUrl: string;
    created: string;
    createdBy: string;
    modified: string;
    modifiedBy: string;
    ddList: any;
    isnoData: any;
    filterResult: any;
    isLoader: any;

}

class SearchForm extends React.Component<ISearchFormProps, ISearchFormState> {
    public readonly state: ISearchFormState;

    //Begin Constructor
    constructor(props: ISearchFormProps) {
        super(props);
        //importing Global CSS
        let cssPath: string = escape(this.props.css);
        if (cssPath !== "") {
            SPComponentLoader.loadCss(cssPath);
        }

        this.state = {
            txtVal: '',
            libName: '',
            fileName: '',
            fileUrl: '',
            created: '',
            createdBy: '',
            modified: '',
            modifiedBy: '',
            ddList: [],
            isnoData: true,
            filterResult: [],
            isLoader: false

        };
    }
    //End Constructor

    //Begin Methods
    //Begin GetListData
    private async GetListData(filterTxt: any) {
        debugger;
        try {
            //let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.state.listName + "')/Items?$filter=Title eq '" + filterTxt + "'";
            //let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.state.libName + "')/Items?$Select=ID,BaseName,FileLeafRef,FileRef,Created,Author/Title,Modified,Editor/Title&$expand=Author/Title,Editor/title&$filter=Title eq '" + filterTxt + "'";
            let endpointURL = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + this.state.libName + "')/Items?$Select=ID,File_x0020_Type,BaseName,FileLeafRef,FileRef,Created,Author/Title,Modified,Editor/Title&$expand=Author/Title,Editor/title&$filter=(substringof('" + encodeURIComponent(filterTxt) + "',FileLeafRef)) or (substringof('" + encodeURIComponent(filterTxt) + "',Title))";
            let response = await this.props.context.spHttpClient.get(endpointURL, SPHttpClient.configurations.v1,
                {
                    headers: {
                        'Accept': 'application/json;odata=nometadata',
                        'Content-type': 'application/json;odata=nometadata',
                        'odata-version': ''
                    }
                    //body: body
                })
                .then((responseValues: SPHttpClientResponse): Promise<IListItem> => {
                    return responseValues.json();
                })
                .then((item: IListItem): void => {
                    debugger;
                    console.log("Get Items successfully !!!");
                    if (item['value'].length > 0) {
                        this.setState({
                            //fileName: item['value'][0].BaseName,
                            //fileUrl: this.props.context.pageContext.web.absoluteUrl + "/" + this.state.listName + "/" + item['value'][0].FileLeafRef,
                            // fileUrl: item['value'][0].FileRef,
                            //created: item['value'][0].Created,
                            //createdBy: item['value'][0].Author.Title,
                            //modified: item['value'][0].Modified,
                            //modifiedBy: item['value'][0].Editor.Title,
                            isnoData: false,
                            filterResult: item['value'],
                            isLoader: false

                        });
                    }
                    else {
                        this.setState({
                            isnoData: true,
                            filterResult: [],
                            isLoader: false
                        });
                    }

                }, (error: any): void => {
                    //alert("Error in Get Items !!!");
                });
        }
        catch (error) {
            console.log("Error in Get Items Data : " + error);
        }
    }


    //End GetListData


    //Begin Hanlder

    private txtChangeHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
        //alert(event.target.value);
        this.setState({
            txtVal: event.target.value
        });
    }

    private btnSearchClickHandler = (event: React.MouseEvent<HTMLButtonElement>) => {

        this.setState({ 
            isLoader: true 
        }, () => { 
            this.GetListData(this.state.txtVal); 
        });

    }

    private cancel = (event: React.MouseEvent<HTMLButtonElement>) => {
        //debugger
        this.setState({
            isnoData: true,
            filterResult: [],
            isLoader: false,
            txtVal: ""
        });

    }

    private ddlChangeHandler = (event: React.ChangeEvent<HTMLSelectElement>) => {
        this.setState({
            libName: event.target.value,
        });
    }


    public getDropdownArray = () => {
        debugger;
        if (this.props.documentsName != undefined) {
            let ddArray = this.props.documentsName.split(',');
            let ddlist = [];
            ddArray.map((item, index) => {
                ddlist.push({ label: item, value: item });
            });
            this.setState({
                ddList: ddlist,
                libName: ddlist[0].label
            });
        }


    }
    public componentDidMount() {
        debugger;
        this.getDropdownArray();
    }

    public render() {
        debugger;
        const { txtVal, libName } = this.state;
        const siteUrl: string = this.props.context.pageContext.web.absoluteUrl;
        const uatSite: string = "https://eu023-sp.shell.com";
        const prodSite: string = "https://eu001-sp.shell.com";
        return (
            
            <Row>
                <Col xs={12} sm={12} md={12} lg={12} xl={12} className={styles.colalign}>
                    <Label className={styles.text}><b>Enter Search Text </b></Label><Input type='text' value={txtVal} onChange={this.txtChangeHandler} className={styles.label} placeholder="Enter Document Name (or) Title" />
                        <select value={libName} onChange={this.ddlChangeHandler} className={styles.option}>

                            {this.state.ddList.length > 0 && this.state.ddList.map((item, index) => {
                                return (
                                    <option value={item.value}>{item.label}</option>
                                );
                            })}
                        </select>
                        <Button id='btnSearch' title='Search' onClick={this.btnSearchClickHandler} className={styles.download}> Search</Button>
                        <Button id='clear' title='clear' onClick={this.cancel} className={styles.download}> Clear</Button>

                

                </Col>
                {this.state.isLoader == true && <div className={styles.lds_roller}><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>}
                <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                    <Row className='mt-3'>
                    {this.state.isnoData !== true ? <table className={styles.table}>
                        <tr>
                            <th>FileName</th>
                            <th>Created</th>
                            <th>CreatedBy</th>
                            <th>Modified</th>
                            <th>ModifiedBy</th>
                            <th>Download</th>
                            <th>View</th>
                        </tr>

                        {this.state.filterResult.length > 0 && this.state.filterResult.map((item, index) => {

                            if (item.File_x0020_Type != null) {

                                return (

                                    <>
                                        <tr>
                                            <td>{item.BaseName}</td>
                                            <td>{item.Created}</td>
                                            <td>{item.Author.Title}</td>
                                            <td>{item.Modified}</td>
                                            <td>{item.Editor.Title}</td>
                                            <td>{item.fileUrl != "" ?
                                                <a className={styles.download} href={item.FileRef} download>Download</a> : ""}
                                            </td>
                                            <td>{
                                                <a className={styles.download} href={uatSite + item.FileRef} target="_blank" data-interception="off">View</a>
                                            }</td>
                                        </tr>
                                    </>

                                );
                            }
                        })}


                    </table> :
                        <div className={styles.data}> <img src={this.props.webURL + "/SiteAssets/SPFX/IMAGES/searchnotfound.png"}></img><b>Sorry, no records match your search criteria in our library</b></div>}
                </Row>
                </Col>
            </Row>
        );
    }
    //End Hanlder

}//End Class

export default SearchForm;