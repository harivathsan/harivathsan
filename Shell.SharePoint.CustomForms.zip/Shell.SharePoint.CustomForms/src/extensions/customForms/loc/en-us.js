define([], function() {
  return {
    "Title": "CustomFormsApplicationCustomizer"
  }
});