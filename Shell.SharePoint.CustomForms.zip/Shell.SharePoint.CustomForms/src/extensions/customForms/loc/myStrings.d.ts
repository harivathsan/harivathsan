declare interface ICustomFormsApplicationCustomizerStrings {
  Title: string;
}

declare module 'CustomFormsApplicationCustomizerStrings' {
  const strings: ICustomFormsApplicationCustomizerStrings;
  export = strings;
}
