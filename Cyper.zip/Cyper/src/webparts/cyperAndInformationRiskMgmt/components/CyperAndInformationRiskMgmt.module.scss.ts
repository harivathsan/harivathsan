/* tslint:disable */
require("./CyperAndInformationRiskMgmt.module.css");
const styles = {
  cyperAndInformationRiskMgmt: 'cyperAndInformationRiskMgmt_73428ced',
  first: 'first_73428ced',
  playbtn: 'playbtn_73428ced',
  playbtn1: 'playbtn1_73428ced',
  toogleheader: 'toogleheader_73428ced',
  logo: 'logo_73428ced',
  heading: 'heading_73428ced',
  heading1: 'heading1_73428ced',
  tilesImg: 'tilesImg_73428ced',
  card: 'card_73428ced',
  cardVidoe: 'cardVidoe_73428ced',
  Title: 'Title_73428ced',
  cardtitle: 'cardtitle_73428ced',
  Link: 'Link_73428ced',
  Innerimage: 'Innerimage_73428ced',
  videoInnerimage1: 'videoInnerimage1_73428ced',
  videoInnerimage2: 'videoInnerimage2_73428ced',
  bannerSection: 'bannerSection_73428ced',
  bg1: 'bg1_73428ced',
  bg2: 'bg2_73428ced',
  circle: 'circle_73428ced',
  circle2: 'circle2_73428ced',
  circle3: 'circle3_73428ced',
  circle4: 'circle4_73428ced',
  circle5: 'circle5_73428ced',
  circle6: 'circle6_73428ced',
  line: 'line_73428ced',
  line2: 'line2_73428ced',
  line3: 'line3_73428ced',
  line4: 'line4_73428ced',
  line5: 'line5_73428ced',
  phaseTitle: 'phaseTitle_73428ced',
  phasesubTitle: 'phasesubTitle_73428ced',
  finalarrow: 'finalarrow_73428ced',
  activeCircle: 'activeCircle_73428ced',
  squarerow: 'squarerow_73428ced',
  innerline: 'innerline_73428ced'
};

export default styles;
/* tslint:enable */