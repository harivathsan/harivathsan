import * as React from 'react';
import styles from './CyperAndInformationRiskMgmt.module.scss';
import { ICyperAndInformationRiskMgmtProps } from './ICyperAndInformationRiskMgmtProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { SPComponentLoader } from '@microsoft/sp-loader';
import Banner from './Banner';
import { Col, Container, Row } from 'reactstrap';
import Grid from './Grid';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class CyperAndInformationRiskMgmt extends React.Component<ICyperAndInformationRiskMgmtProps, {}> {
  constructor(props) {

    super(props);
    //importing Global CSS
    let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
  }


  public render(): React.ReactElement<ICyperAndInformationRiskMgmtProps> {
    return (
      <Container fluid>

        <Row className={styles.cyperAndInformationRiskMgmt}>

          <Col xl={12} lg={12} md={12} sm={12} xs={12}>
            <Row>
              <Col xl={6} lg={6} md={6} sm={6} xs={6}>
                <img className={styles.logo} alt="" aria-hidden="true" src="https://eu023-sp.shell.com/sites/SPOAA0342/CIRM/SiteAssets/CIRM_Assets/shellicon.png" />
                <h1 className={styles.heading}>Cyber and Information Risk Dashboard</h1>
              </Col>
              <Col xl={2} lg={2} md={2} sm={2} xs={2}>
                <h4 className={styles.Title}><a href={this.props.url1} target="_blank" data-interception="off" className={styles.Link}>{this.props.name1}</a></h4>
              </Col>
              <Col xl={2} lg={2} md={2} sm={2} xs={2}>
                <h4 className={styles.Title}><a href={this.props.url2} target="_blank" data-interception="off" className={styles.Link}>{this.props.name2}</a></h4>
              </Col>
              <Col xl={2} lg={2} md={2} sm={2} xs={2}>
                <h4 className={styles.Title}><a href={this.props.url3} target="_blank" data-interception="off" className={styles.Link}>{this.props.name3}</a></h4>
              </Col>
              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
              <h1 className={styles.heading1}>{this.props.Title}
            </h1>
            </Col>
            </Row>
            
            <Banner {...this.props} {...this.state} />
            <Grid {...this.props} {...this.state} ></Grid>
          </Col>
        </Row>
      </Container>
    );
  }
}
