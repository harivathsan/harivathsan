import * as React from 'react';
import { Row, Col } from 'reactstrap';
import styles from './CyperAndInformationRiskMgmt.module.scss';
import classNames from "classnames";
import { UncontrolledTooltip } from 'reactstrap';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { Tooltip } from 'react-tippy';

import 'react-tippy/dist/tippy.css';

export default class Banner extends React.Component<any, any> {
  constructor(props) {
    super(props);
    this.state = {
      phaseCollection: [],
      tooltipOpen: false
    };
  }
  public toggle = () => {
    this.setState({
      tooltipOpen: !this.state.tooltipOpen
    });
  }

  public GetList = () => {
    debugger;
    let url = this.props.webURL + "/_api/web/Lists/GetByTitle('" + "Phase List" + "')/items";
    this.props.spHttpClient.get(url, SPHttpClient.configurations.v1)
      .then(async (response: SPHttpClientResponse) => {
        if (response.ok) {
          await response.json().then((res) => {
            debugger;
            if (res != null) {
              debugger;
              this.setState({
                phaseCollection: res.value,

              });
              console.log(res);

            } else {
              console.log('recoard failed');

            }
          });
        }
      });
  }

  public componentDidMount(): void {
    this.GetList();
  }
  public render(): React.ReactElement<any> {

    return (

      <Row className={styles.bannerSection}>
        <Col sm={12} md={12} lg={12} xl={12} className={styles.bg1} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/Banner.png" }}>

          {/* <Col sm={10} md={10} lg={10} xl={10} className={styles.bg2} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/chartArrow.png" }}> */}
          {/* <Row>
            <Col lg={2} className={styles.circle} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/square.png" }}>
              <div className={styles.phaseTitle}>Pahse1 </div>
              <div className={styles.phasesubTitle}>Foundations</div>
            </Col>
            <div className={styles.line}>
              <img src={this.props.webURL+'/SiteAssets/CIRM_Assets/line.png'}/>
            </div>
            <Col lg={2} className={styles.circle2} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/square.png" }}>
              <div className={styles.phaseTitle}>Pahse2 </div>
              <div className={styles.phasesubTitle}>Dashboard</div>
            </Col>
            <div className={styles.line2}>
              <img src={this.props.webURL+'/SiteAssets/CIRM_Assets/line.png'}/>
            </div>

            <Col lg={2} className={classNames(styles.circle3)} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/square.png" }}>
              <div className={styles.phaseTitle}>Pahse3 </div>
              <div className={styles.phasesubTitle}>Perform</div>
            </Col>
            <div className={styles.line3}>
              <img src={this.props.webURL+'/SiteAssets/CIRM_Assets/line.png'}/>
            </div>
            <Col lg={2} className={styles.circle4} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/square.png" }}>
              <div className={styles.phaseTitle}>Pahse4 </div>
              <div className={styles.phasesubTitle}>Simplfy</div>
            </Col>
            <div className={styles.line4}>
              <img src={this.props.webURL+'/SiteAssets/CIRM_Assets/line.png'}/>
            </div>
            <Col lg={2} className={styles.circle5} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/square.png" }}>
              <div className={styles.phaseTitle}>Pahse5 </div>
              <div className={styles.phasesubTitle}>Complete</div>
            </Col>
            <div className={styles.line5}>
              <img src={this.props.webURL+'/SiteAssets/CIRM_Assets/line.png'}/>
            </div>
            <Col lg={2} className={styles.circle6} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/square.png" }}>
              <div className={styles.phaseTitle}>Pahse6 </div>
              <div className={styles.phasesubTitle}>Innovate</div>
            </Col> 
            <div className={styles.finalarrow}>
              <img src={this.props.webURL+'/SiteAssets/CIRM_Assets/finalarrow.png'}/>
            </div>  */}
            <Row className={styles.squarerow}>

            

          <Col sm={12} md={12} lg={12} xl={12}>
            {this.state.phaseCollection.length > 0 && this.state.phaseCollection.map((item, index) => {
              return (
                <>
                  <Col lg={2} className={index == 0 ? classNames(styles.circle, (item.Active == true ? styles.activeCircle : "")) : index == 1 ? classNames(styles.circle2, (item.Active == true ? styles.activeCircle : "")) : index == 2 ? classNames(styles.circle3, (item.Active == true ? styles.activeCircle : "")) : index == 3 ? classNames(styles.circle4, (item.Active == true ? styles.activeCircle : "")) : index == 4 ? classNames(styles.circle5, (item.Active == true ? styles.activeCircle : "")) : index == 5 ? classNames(styles.circle6, (item.Active == true ? styles.activeCircle : "")) : ""} style={{ backgroundImage: "url(" + this.props.webURL + "/SiteAssets/CIRM_Assets/square.png" }}>
                    <Tooltip theme="dark" title={item.ToolTip} position="top" arrow={true} trigger="mouseenter">
                      <div className={styles.phaseTitle}>{item.PhaseLevel}</div>
                      <div className={styles.phasesubTitle}>{item.Title}</div></Tooltip>
                  </Col>
                  {index <= 4 ?
                    <div className={index == 0 ? styles.line : index == 1 ? styles.line2 : index == 2 ? styles.line3 : index == 3 ? styles.line4 : index == 4 ? styles.line5 : ""}>
                      <img src={this.props.webURL + '/SiteAssets/CIRM_Assets/line.png'} className={styles.innerline} />
                      
                    </div> :
                    <div className={styles.finalarrow}>
                      <img src={this.props.webURL + '/SiteAssets/CIRM_Assets/finalarrow.png'} />
                    </div>}
                </>
              );
            })}  
          </Col></Row>
        </Col>

      </Row>


    );
  }
}