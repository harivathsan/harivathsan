import * as React from 'react';
import styles from './CyperAndInformationRiskMgmt.module.scss';
import { ICyperAndInformationRiskMgmtProps } from './ICyperAndInformationRiskMgmtProps';
import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from '@microsoft/sp-http';
import { Col, Row, ListGroup, ListGroupItem, Card, CardBody, CardTitle, CardSubtitle, CardText, CardImg, Button, Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap';
import { Player, BigPlayButton, ControlBar } from 'video-react';
import 'video-react/dist/video-react.css';
import { times } from '@microsoft/sp-lodash-subset';

export default class Grid extends React.Component<ICyperAndInformationRiskMgmtProps, any> {
  constructor(props) {

    super(props);
    //importing Global CSS
    this.state = {
      listCollection: [],
      modal: false,
      modal1: false,
      Title:[]
    };

  }
  public openNewTab = (tabUrl: any) => {
    if (tabUrl != null) {
      window.open(tabUrl);
    }
  }
  public GetList = () => {
    debugger;
    let url = this.props.webURL + "/_api/web/Lists/GetByTitle('" + "Tile List" + "')/items";
    this.props.spHttpClient.get(url, SPHttpClient.configurations.v1)
      .then(async (response: SPHttpClientResponse) => {
        if (response.ok) {
          await response.json().then((res) => {
            debugger;
            if (res != null) {
              debugger;
              this.setState({
                listCollection: res.value,

              });
              console.log(res);

            } else {
              console.log('recoard failed');

            }
          });
        }
      });
  }

   public toggle =(url,Title)=>{
     this.setState({
       modal: !this.state.modal,
       videoUrl:url,
       Title:Title
     });
   }


  public componentDidMount(): void {
    this.GetList();
  }

  public render(): React.ReactElement<ICyperAndInformationRiskMgmtProps> {
    return (
      <>
      <Row>
        {this.state.listCollection.length > 0 && this.state.listCollection.map((item, index) => {
          return (
            <Col xs={3} sm={3} md={3} lg={3} xl={3} className={"mt-4"}>
                {item.ItemType == "Image" ?
                <Card className={styles.card}>
                  {item.ImageURL != undefined &&
                    <a href={'#'} onClick={() => this.openNewTab(item.Link)}>
                      <CardImg alt={index} bottom src={item.ImageURL} className={styles.Innerimage} style={{objectFit:"cover"}} />
                    </a>}
                  <CardBody className={styles.cardtitle}>
                    <CardTitle tag="h5" >{item.Title}</CardTitle>
                  </CardBody>                  
                </Card> :                   
                  <Card className={styles.cardVidoe}>
                    <Row>
                      <div className='w-50 pe-0'>
                      <CardImg alt={index} bottom src={item.videothumbUrl1} onClick={()=>this.toggle(item.VideoURL,item.Title)} className={styles.videoInnerimage1} style={{objectFit:"cover"}}
                      /> <button className={styles.playbtn} onClick={()=>this.toggle(item.VideoURL,item.Title)}>
                      <img src={this.props.webURL + '/SiteAssets/CIRM_Assets/PlayIcon.png'} style={{objectFit:"cover"}} />
                      </button>
                      </div>
                      <div className='w-50 p-0'>
                      <CardImg alt={index} bottom src={item.videothumbUrl2} onClick={()=>this.toggle(item.VideoURL2,item.Title)} className={styles.videoInnerimage2} style={{objectFit:"cover"}}/>
                      <button className={styles.playbtn1} onClick={()=>this.toggle(item.VideoURL2,item.Title)}>
                      <img src={this.props.webURL + '/SiteAssets/CIRM_Assets/PlayIcon.png'} style={{objectFit:"cover"}} />
                      </button>
                      </div>
                    </Row>
                  <CardBody className={styles.cardtitle}>
                    <CardTitle tag="h5" >{item.Title}</CardTitle>
                  </CardBody>                  
                </Card>                
                }
            </Col>
            
          );
        })
        }
      </Row>

        <Modal isOpen={this.state.modal} toggle={()=>this.toggle(null,null)}>
        <ModalHeader toggle={()=>this.toggle(null,null)} className={styles.toogleheader}>{this.state.Title}</ModalHeader>
        <ModalBody>
          <Player>
            <source src={this.state.videoUrl} type="video/mp4" />
            <BigPlayButton position="center" />
            <ControlBar autoHide={false} className="my-class" />
          </Player>
        </ModalBody>
        <ModalFooter>

        </ModalFooter>
        </Modal>
        </>

    );
  }
}
