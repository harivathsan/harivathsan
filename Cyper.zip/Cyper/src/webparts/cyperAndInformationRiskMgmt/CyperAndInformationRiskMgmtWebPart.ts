import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'CyperAndInformationRiskMgmtWebPartStrings';
import CyperAndInformationRiskMgmt from './components/CyperAndInformationRiskMgmt';
import { ICyperAndInformationRiskMgmtProps } from './components/ICyperAndInformationRiskMgmtProps';

export interface ICyperAndInformationRiskMgmtWebPartProps {
  name1: any;
  url1: any;
  name2: any;
  url2: any;
  name3: any;
  Title:any;
  url3: any;
  description: string;
  css: string;
}

export default class CyperAndInformationRiskMgmtWebPart extends BaseClientSideWebPart<ICyperAndInformationRiskMgmtWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ICyperAndInformationRiskMgmtProps> = React.createElement(
      CyperAndInformationRiskMgmt,
      {
        description: this.properties.description,
        css: this.properties.css,
        spHttpClient: this.context.spHttpClient,
        webURL: this.context.pageContext.web.absoluteUrl,
        context: this.context,
        name1: this.properties.name1,
        url1: this.properties.url1,
        name2: this.properties.name2,
        url2: this.properties.url2,
        name3: this.properties.name3,
        url3: this.properties.url3,
        Title:this.properties.Title

      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('css', {
                  label: "~Css"
                }),
                PropertyPaneTextField('name1', {
                  label: "name1"
                }),
                PropertyPaneTextField('url1', {
                  label: "url1"
                }),
                PropertyPaneTextField('name2', {
                  label: "name2"
                }),
                PropertyPaneTextField('url2', {
                  label: "url2"
                }),
                PropertyPaneTextField('name3', {
                  label: "name3"
                }),
                PropertyPaneTextField('url3', {
                  label: "url3"
                }),
                PropertyPaneTextField('Title', {
                  label: "Title"
                }),
                
                
              ]
            }
          ]
        }
      ]
    };
  }
}
