declare interface ICyperAndInformationRiskMgmtWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CyperAndInformationRiskMgmtWebPartStrings' {
  const strings: ICyperAndInformationRiskMgmtWebPartStrings;
  export = strings;
}
