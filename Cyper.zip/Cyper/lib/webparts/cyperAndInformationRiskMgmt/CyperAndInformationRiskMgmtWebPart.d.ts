import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ICyperAndInformationRiskMgmtWebPartProps {
    name1: any;
    url1: any;
    name2: any;
    url2: any;
    name3: any;
    Title: any;
    url3: any;
    description: string;
    css: string;
}
export default class CyperAndInformationRiskMgmtWebPart extends BaseClientSideWebPart<ICyperAndInformationRiskMgmtWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=CyperAndInformationRiskMgmtWebPart.d.ts.map