import * as React from 'react';
import 'react-tippy/dist/tippy.css';
export default class Banner extends React.Component<any, any> {
    constructor(props: any);
    toggle: () => void;
    GetList: () => void;
    componentDidMount(): void;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=Banner.d.ts.map