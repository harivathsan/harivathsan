import { SPHttpClient } from "@microsoft/sp-http";
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface ICyperAndInformationRiskMgmtProps {
    description: string;
    webURL: string;
    spHttpClient: SPHttpClient;
    context: WebPartContext;
    css: string;
    listCollection: any;
    name1: any;
    url1: any;
    name2: any;
    url2: any;
    name3: any;
    url3: any;
    Title: any;
}
//# sourceMappingURL=ICyperAndInformationRiskMgmtProps.d.ts.map