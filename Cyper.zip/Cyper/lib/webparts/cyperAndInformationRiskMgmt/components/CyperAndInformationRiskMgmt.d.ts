import * as React from 'react';
import { ICyperAndInformationRiskMgmtProps } from './ICyperAndInformationRiskMgmtProps';
import 'bootstrap/dist/css/bootstrap.min.css';
export default class CyperAndInformationRiskMgmt extends React.Component<ICyperAndInformationRiskMgmtProps, {}> {
    constructor(props: any);
    render(): React.ReactElement<ICyperAndInformationRiskMgmtProps>;
}
//# sourceMappingURL=CyperAndInformationRiskMgmt.d.ts.map