import * as React from 'react';
import { ICyperAndInformationRiskMgmtProps } from './ICyperAndInformationRiskMgmtProps';
import 'video-react/dist/video-react.css';
export default class Grid extends React.Component<ICyperAndInformationRiskMgmtProps, any> {
    constructor(props: any);
    openNewTab: (tabUrl: any) => void;
    GetList: () => void;
    toggle: (url: any, Title: any) => void;
    componentDidMount(): void;
    render(): React.ReactElement<ICyperAndInformationRiskMgmtProps>;
}
//# sourceMappingURL=Grid.d.ts.map