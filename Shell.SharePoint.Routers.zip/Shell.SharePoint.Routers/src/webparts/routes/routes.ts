import * as React from 'react';

const WeAreTechnology = React.lazy(() => import('../portal/components/WeAreTechnology'));
const InAction = React.lazy(() => import('../portal/components/Inaction'));
const InnovationCentre = React.lazy(() => import('../portal/components/InnovationCentre'));
const Awards = React.lazy(() => import('../portal/components/Awards'));
const IdeaCentral = React.lazy(() => import('../portal/components/IdeaCentral'));
const Resources = React.lazy(() => import('../portal/components/Resources'));
const IdeaPipline = React.lazy(() => import('../portal/components/Ideapipline'));
const OurJourney = React.lazy(() => import('../portal/components/OurJourney'));
const PageNotFound = React.lazy(() => import('../portal/components/PageNotFound'));


const routes = [
    { path: '/', exact: true, name: 'OurJourney', component: OurJourney },
    { path: '/wearetechnology', name: 'WeAreTechnology', component: WeAreTechnology },
    { path: '/inaction', name: 'InAction', component: InAction },
    { path: '/innovationcentre', name: 'InnovationCentre', component: InnovationCentre },
    { path: '/awards', name: 'Awards', component: Awards },
    { path: '/ideacentral', name: 'IdeaCentral', component: IdeaCentral },
    { path: '/ideapipline', name: 'IdeaPipline', component: IdeaPipline },
    { path: '/pagenotfound', name: 'PageNotFound', component: PageNotFound }
];

export default routes;