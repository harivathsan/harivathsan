const menus = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'NEW',
    }
  },
  {
    name: 'Cards',
    url: '/cards',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'NEW',
    }
  }



];
export default menus;