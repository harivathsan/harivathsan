import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'PortalWebPartStrings';
import Portal from './components/Portal';
import { IPortalProps } from './components/IPortalProps';

export interface IPortalWebPartProps {
  description: string;
  css: string;
}

export default class PortalWebPart extends BaseClientSideWebPart<IPortalWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IPortalProps> = React.createElement(
      Portal,
      {
        description: this.properties.description,
        spHttpClient: this.context.spHttpClient,
        siteUrl: this.context.pageContext.web.absoluteUrl,
        css: this.properties.css,
        context: this.context
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', { label: strings.DescriptionFieldLabel }),
                PropertyPaneTextField('css', { label: strings.CssFieldLabel })
              ]
            }
          ]
        }
      ]
    };
  }
}
