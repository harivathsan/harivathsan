import * as React from 'react';

export interface IWeAreTechnologyProps { }

const WeAreTechnology: React.FC<IWeAreTechnologyProps> = (props) => {
    return (
        <div>
            <p>We Are Technology Components</p>
        </div>
    );
};
export default WeAreTechnology;
