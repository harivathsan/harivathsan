import WeAreTechnology from './WeAreTechnology';

export default WeAreTechnology;