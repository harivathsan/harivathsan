import * as React from 'react';

export interface IIdeaCentralProps { }

const IdeaCentral: React.FC<IIdeaCentralProps> = (props) => {
    return (
        <div>
            <p>IdeaCentral Components</p>
        </div>
    );
};

export default IdeaCentral;
