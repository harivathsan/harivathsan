import IdeaCentral from './IdeaCentral';

export default IdeaCentral;