import { SPHttpClient } from '@microsoft/sp-http';
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IPortalProps {
  description: string;
  context: WebPartContext;
  siteUrl: string;
  spHttpClient: SPHttpClient;
  css: string;
}
