/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Portal
Project Handled By                 : IMS US Capacity Projects
Module Name						             : Portal
Module Description                 : Portal Desc
Author                             : Firdous Ali K.A
Created Date                       : 1st September 2020
Modified Date                      : 1st September 2020
Modified Reason                    : 
/* ----------------------------------Module Summary-----------------------------------*/

//#region Import
import * as React from 'react';
import styles from './Portal.module.scss';
import { IPortalProps } from './IPortalProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { SPComponentLoader } from '@microsoft/sp-loader';
import * as $ from 'jquery';
import { HashRouter, Route, Switch, withRouter } from 'react-router-dom';


//Base Css
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../assets/scss/animate/animate.css';
import '../components/Portal.module.scss';
import '../../assets/scss/shell-font.css';
import '../../assets/scss/customStyle.css';
import '../../assets/scss/overwrite.css';
//#endregion 

// Containers
const Layout = React.lazy(() => import('../../views/appLayout'));

//Suspense Component Loader
const loading = () => <div className="animated fadeIn pt-3 text-center">Loading...</div>;

export default class Portal extends React.Component<IPortalProps, {}> {

  //#region constructor 
  constructor(props: IPortalProps) {
    super(props);
    let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
  }
  //#endregion  constructor

  public render(): React.ReactElement<IPortalProps> {
    return (
      <React.Suspense fallback={loading()}>
        <HashRouter>
          <Layout />
        </HashRouter>
      </React.Suspense>
    );
  }
}
