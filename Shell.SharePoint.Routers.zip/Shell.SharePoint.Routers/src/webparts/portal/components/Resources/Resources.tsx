import * as React from 'react';

export interface IResourcesProps { }

const Resources: React.FC<IResourcesProps> = (props) => {
    return (
        <div>
            <p>Resources Components</p>
        </div>
    );
};

export default Resources;
