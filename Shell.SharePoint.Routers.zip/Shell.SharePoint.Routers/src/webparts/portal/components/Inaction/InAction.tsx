import * as React from 'react';

export interface IInActionProps { }

const InAction: React.FC<IInActionProps> = (props) => {
    return (
        <div>
            <p>InAction Components</p>
        </div>
    );
};

export default InAction;
