import InAction from './InAction';

export default InAction;