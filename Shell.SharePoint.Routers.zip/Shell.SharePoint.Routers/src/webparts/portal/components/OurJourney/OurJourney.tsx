import * as React from 'react';

export interface IOurJourneyProps { }

const OurJourney: React.FC<IOurJourneyProps> = (props) => {
    return (
        <div>
            <div className="container ">
                <h1>Grid01</h1>
                <p>This example demonstrates a 50%/50% split on small, medium and large devices.
                    On extra small devices, it will stack (100% width).</p>
                <p>Resize the browser window to see the effects.</p>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="columnOne">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        </div>
                    </div>
                    <div className="col-sm-6">
                        <div className="columnTwo">
                            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                            doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore
                            veritatis et quasi architecto.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OurJourney;
