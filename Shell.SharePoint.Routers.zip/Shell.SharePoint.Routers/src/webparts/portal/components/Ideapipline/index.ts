import Ideapipline from './Ideapipline';

export default Ideapipline;