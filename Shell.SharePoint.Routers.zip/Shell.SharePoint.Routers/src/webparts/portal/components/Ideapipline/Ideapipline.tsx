import * as React from 'react';

export interface IIdeapiplineProps {
}

const Ideapipline: React.FC<IIdeapiplineProps> = (props) => {
    return (
        <div>
            <p>Ideapipline Components</p>
        </div>
    );
};

export default Ideapipline;
