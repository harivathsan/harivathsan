import InnovationCentre from './InnovationCentre';

export default InnovationCentre;