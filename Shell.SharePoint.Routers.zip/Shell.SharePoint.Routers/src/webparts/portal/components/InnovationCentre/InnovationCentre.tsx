import * as React from 'react';

export interface IInnovationCentreProps { }

const InnovationCentre: React.FC<IInnovationCentreProps> = (props) => {
    return (
        <div>
            <p>Innovation Centre Components</p>
        </div>
    );
};

export default InnovationCentre;
