import * as React from 'react';

export interface IAwardsProps {
}

const Awards: React.FC<IAwardsProps> = (props) => {
    return (
        <div>
            <p>Awards Components</p>
        </div>
    );
};

export default Awards;
