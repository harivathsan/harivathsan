declare interface IPortalWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  CssFieldLabel: string;
}

declare module 'PortalWebPartStrings' {
  const strings: IPortalWebPartStrings;
  export = strings;
}
