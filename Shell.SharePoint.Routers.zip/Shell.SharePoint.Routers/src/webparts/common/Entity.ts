class Entity {

    private _ColleageName: string;
    /**
     * Get / Set the Colleage Name       
     */
    public get ColleageName(): string {
        return this._ColleageName;
    }    
    public set ColleageName(colleageName: string) {
        this._ColleageName = colleageName;
    }
}

export default Entity;