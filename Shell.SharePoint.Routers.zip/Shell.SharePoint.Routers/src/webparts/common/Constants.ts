
class Constants {

    /**   
     * @Name Get the Name   
   */
    public static readonly NAME: string = "Firdous";

}

export default Constants;