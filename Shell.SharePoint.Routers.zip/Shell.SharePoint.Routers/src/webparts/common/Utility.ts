import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';

//#region Utility Class
class Utility {

    //#region Method

    /**
   * Get the First Name and Last Name
   * @firstName  This is the firstName parameter
   * @lastName  This is the lastName parameter
   * @returns returns string 
   */
    public static getUserInfo = (firstName: string, lastName: string): string => {

        let name = firstName + " " + lastName;
        return name.toUpperCase();
    }

    //#endregion 
}
//#endregion 

export default Utility;
