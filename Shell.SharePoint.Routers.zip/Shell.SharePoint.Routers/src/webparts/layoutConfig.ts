export const layoutConfiguration = {    
    isShowHeaderNav:true,
    twoColumn:false,
    isShwoSideBar:false,
    threeColumn:false, 
    isShowAsideBar:false,
};