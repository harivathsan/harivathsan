import * as React from 'react';
import { Col } from 'reactstrap';
import { Nav, NavItem, NavLink } from 'reactstrap';
import menus from '../../routes/menus';
const AsideBar = (props) => {
  return (
    <React.Fragment>
      <div className={props.asideBarClass}>
        <Nav vertical>
          {menus.map((item, idx) => {

            return (

              <NavLink href={`#${item.url}`}>{item.name}</NavLink>

            );
          })
          }
        </Nav>
      </div>

    </React.Fragment>
  );
};

export default React.memo(AsideBar);