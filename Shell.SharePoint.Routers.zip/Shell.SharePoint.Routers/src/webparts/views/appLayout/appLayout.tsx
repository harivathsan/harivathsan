import * as React from 'react';
import { Container, Col } from 'reactstrap';
import { Redirect, Route, Switch } from 'react-router-dom';
import * as router from 'react-router-dom';
import Header from '../appLayout/header';
import SideBar from '../appLayout/sidebar';
import AsideBar from '../appLayout/asidebar';
// routes config
import routes from '../../routes/routes';
import { layoutConfiguration } from '../../layoutConfig';

const loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>;
export default class AppLayout extends React.Component<{}, {}> {

    constructor(props) {
        super(props);
    }

    public render(): React.ReactElement<any> {
        return (
            <div className="app">
                {layoutConfiguration.isShowHeaderNav && <React.Suspense fallback={loading()}>
                    <Header />
                </React.Suspense>
                }
                <div className="app-body">
                    {layoutConfiguration.isShwoSideBar && <React.Suspense fallback={loading()}>
                        <SideBar sideBarClass={layoutConfiguration.isShwoSideBar && 'col-sm-2 col-md-2 col-lg-2 col-xl-2'} />
                    </React.Suspense>
                    }
                    <main className="main">

                        <React.Suspense fallback={loading()}>
                            <Switch>
                                {routes.map((route, idx) => {
                                    return route.component ? (
                                        <Route
                                            key={idx}
                                            path={route.path}
                                            exact={route.exact}
                                            name={route.name}
                                            render={props => (
                                                <route.component {...props} />
                                            )} />
                                    ) : (null);
                                })}
                                <Redirect from="/" to={'/pageNotFound'} />
                            </Switch>
                        </React.Suspense>

                    </main>
                    {layoutConfiguration.isShowAsideBar && <React.Suspense fallback={loading()}>
                        <AsideBar asideBarClass={layoutConfiguration.isShwoSideBar && 'col-sm-2 col-md-2 col-lg-2 col-xl-2'} />
                    </React.Suspense>
                    }
                </div>
            </div>
        );
    }
}