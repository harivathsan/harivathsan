import * as React from 'react';
import { Nav, NavItem, NavLink } from 'reactstrap';
import menus from '../../routes/menus';
const SideBar = (props) => {
  debugger;
  return (
    <React.Fragment>
      <div className={props.sideBarClass}>

        <Nav vertical>
          {menus.map((item, idx) => {

            return (

              <NavLink href={`#${item.url}`}>{item.name}</NavLink>

            );
          })
          }
        </Nav>
      </div>

    </React.Fragment>
  );
};

export default React.memo(SideBar);