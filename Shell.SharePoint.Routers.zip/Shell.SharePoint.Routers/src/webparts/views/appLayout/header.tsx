import * as React from 'react';
import { Link } from 'react-router-dom';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavLink,
  NavItem,
  UncontrolledDropdown,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText
} from 'reactstrap';
import styles from '../../assets/scss/header.module.scss';


const Header = (props) => {
  const [isOpen,
    setIsOpen] = React.useState(false);

  const toggle = (e) => {
    e.preventDefault();
    setIsOpen(!isOpen);
  };

  const [dropdownOpen,
    setDropdownOpen] = React.useState(false);

  const toggle1 = () => setDropdownOpen(!dropdownOpen);
  //debugger;
  return (
    <React.Fragment>
      {/* Beging Navigation */}
      <div className="row">
        <div
          className={`${"col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"} ${styles.bgYellow}`}>
          <Navbar light expand="md" className={`${styles.bgYellow} ${styles.menu} navbar-fixed-top`}>
            <NavbarToggler onClick={toggle} />
            <Collapse isOpen={isOpen} navbar>
              <Nav className="mr-auto" navbar>
                <NavItem>
                  <NavLink href="#/">Our Journey</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/wearetechnology">We Are Technology</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/inaction">In Action</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/innovationcentre">Innovation Centre</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/awards">Awards</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/ideacentral">Idea Central</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/ideapipline">Idea Pipline</NavLink>
                </NavItem>
              </Nav>
            </Collapse>
          </Navbar>
        </div>
      </div>
      {/* End Navigation */}

    </React.Fragment>
  );
};

export default React.memo(Header);
