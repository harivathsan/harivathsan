import * as React from 'react';
import { Link } from 'react-router-dom';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText
} from 'reactstrap';
import styles from '../../assets/scss/header.module.scss';

const Header = (props) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const toggle = (e) => {
    e.preventDefault();
    setIsOpen(!isOpen);
  };
  //debugger;
  return (
    <React.Fragment>
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          {/* <Navbar light expand="md" className={`${styles.bgYellow} ${styles.menu}`}>
            <NavbarToggler onClick={toggle} />
            <Collapse isOpen={isOpen} navbar>
              <Nav className="mr-auto" navbar>
                <NavItem>
                  <NavLink href="#/">Our Journey</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/wearetechnology">We Are Technology</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/inaction">In Action</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/innovationcentre">Innovation Centre</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/awards">Awards</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/ideacentral">Idea Central</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#/ideapipline">Idea Pipline</NavLink>
                </NavItem>
                <UncontrolledDropdown nav inNavbar>
                  <DropdownToggle nav caret>
                    Options
                  </DropdownToggle>
                  <DropdownMenu right>
                    <DropdownItem>
                      Option 1
                    </DropdownItem>
                    <DropdownItem>
                      Option 2
                    </DropdownItem>
                    <DropdownItem divider />
                    <DropdownItem>
                      Reset
                    </DropdownItem>
                  </DropdownMenu>
                </UncontrolledDropdown>
              </Nav>
            </Collapse>
          </Navbar> */}
        </div>
      </div>




    </React.Fragment>
  );
};

export default React.memo(Header);

