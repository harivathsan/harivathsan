import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';
import * as strings from 'SpatraNewHsseCommandSetCommandSetStrings';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { SPPermission } from '@microsoft/sp-page-context';


//Prod Lists
const HSSEActionApprovers: string = '6ff683ff-1e08-4fed-bf1b-c96ad1367b15';
const HSSEActionTracking: string = '9c9c2875-c94a-400a-a11f-40d138d3dc28';
const ActionTrackingWorkflowTasks: string = 'ce38ba61-c5ff-47d5-882b-f73105244d4d';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface ISpatraNewHsseCommandSetCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  sampleTextTwo: string;
}

const LOG_SOURCE: string = 'SpatraNewHsseCommandSetCommandSet';

export default class SpatraNewHsseCommandSetCommandSet extends BaseListViewCommandSet<ISpatraNewHsseCommandSetCommandSetProperties> {
  private canCreate: boolean = false;
  private canEdit: boolean = false;
  private canView: boolean = false;
  private listTitle: string = null;

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized SpatraNewHsseCommandSetCommandSet');
    console.log("Begin Sparta New HSSE CommandSet");
    var currentListID = this.context.pageContext.list.id.toString();
    this.listTitle = this.context.pageContext.list.title;
    if (this.listTitle.toLowerCase() === "hsse action approvers" || this.listTitle.toLowerCase() === "hsse action tracking") {
      //Injecting CSS to hide OOTB buttons
      if (currentListID == HSSEActionTracking) {
        SPComponentLoader.loadCss(this.context.pageContext.web.absoluteUrl + "/SiteAssets/css/ChangeRegisterHideBtn.css");
      }
      if (currentListID == HSSEActionApprovers) {
        SPComponentLoader.loadCss(this.context.pageContext.web.absoluteUrl + "/SiteAssets/css/ChangeRegisterHideBtnWithEditGrid.css");
      }
      this.canCreate = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.addListItems);
      this.canEdit = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.editListItems);
      this.canView = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.viewListItems);
    }
    if (this.listTitle.toLowerCase() === "actiontracking workflow tasks") {
      if (currentListID == ActionTrackingWorkflowTasks) {
        SPComponentLoader.loadCss(this.context.pageContext.web.absoluteUrl + "/SiteAssets/css/ChangeRegisterHideBtn.css");
      }
      this.canEdit = new SPPermission(this.context.pageContext.web.permissions.value).hasPermission(SPPermission.editListItems);
    }
    return Promise.resolve();
  }

  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {
    const NewItem: Command = this.tryGetCommand('New');
    const EditItem: Command = this.tryGetCommand('Edit');
    const ViewItem: Command = this.tryGetCommand('View');

    if (this.listTitle.toLowerCase() === "hsse action approvers" || this.listTitle.toLowerCase() === "hsse action tracking" || this.listTitle.toLowerCase() === "actiontracking workflow tasks") {
      //Create Access
      if (NewItem) {
        if (this.canCreate) {
          NewItem.visible = event.selectedRows.length === 0;
          console.log("Is User has Create access: " + this.canCreate);
        } else {
          NewItem.visible = false;
        }
      }
      //Edit Access
      if (EditItem) {
        if (this.canEdit) {
          EditItem.visible = event.selectedRows.length === 1;
          console.log("Is User has Edit access: " + this.canEdit);
        } else {
          EditItem.visible = false;
        }
      }
      //View Access
      if (ViewItem) {
        if (this.canView) {
          ViewItem.visible = event.selectedRows.length === 1;
          console.log("Is User has View access: " + this.canView);
        } else {
          ViewItem.visible = false;
        }
      }
      if (this.listTitle.toLowerCase() === "actiontracking workflow tasks") {

      }

    }//End If Library
    else {
      NewItem.visible = false;
      ViewItem.visible = false;
      EditItem.visible = false;
    }

  }

  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void {
    const itemID: number = event.selectedRows.length > 0 ? event.selectedRows[0].getValueByName('ID') : null;
    console.log("ItemID is: " + event.itemId);
    switch (event.itemId) {
      case 'New':
        if (this.listTitle === "HSSE Action Approvers") {
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/ActionApproversForm.aspx?Mode=New`);
        }
        if (this.listTitle === "HSSE Action Tracking") {
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/ActionTrackingForm.aspx?Mode=New`);
        }
        break;
      case 'Edit':
        if (this.listTitle === "HSSE Action Tracking") {
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/ActionTrackingForm.aspx?itemID=${itemID}&Mode=EditForm`);
        }
        if (this.listTitle === "HSSE Action Approvers") {
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/ActionApproversForm.aspx?itemID=${itemID}&Mode=EditForm`);
        }
        if (this.listTitle === "ActionTracking Workflow Tasks") {
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/WorkflowTaskForm.aspx?itemID=${itemID}&Mode=EditForm`);
        }
        break;
      case 'View':
        if (this.listTitle === "HSSE Action Tracking") {
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/ActionTrackingForm.aspx?itemId=${itemID}&Mode=View`);
        }
        if (this.listTitle === "HSSE Action Approvers") {
          window.location.href = this.context.pageContext.web.absoluteUrl.concat(`/SitePages/ActionApproversForm.aspx?itemId=${itemID}&Mode=View`);
        }
        break;
    }//End Switch

  }//onExecute

}//End Class
