declare interface ISpatraNewHsseCommandSetCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'SpatraNewHsseCommandSetCommandSetStrings' {
  const strings: ISpatraNewHsseCommandSetCommandSetStrings;
  export = strings;
}
