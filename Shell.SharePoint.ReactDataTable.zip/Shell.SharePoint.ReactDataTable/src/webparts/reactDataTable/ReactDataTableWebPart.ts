import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'ReactDataTableWebPartStrings';
import ReactDataTable from './components/ReactDataTable';
import { IReactDataTableProps } from './components/IReactDataTableProps';

export interface IReactDataTableWebPartProps {
  description: string;
  webURL: string;
  spHttpClient: string;
  context: string;
}

export default class ReactDataTableWebPart extends BaseClientSideWebPart<IReactDataTableWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IReactDataTableProps> = React.createElement(
      ReactDataTable,
      {
        description: this.properties.description,
        webURL: this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        context: this.context
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
