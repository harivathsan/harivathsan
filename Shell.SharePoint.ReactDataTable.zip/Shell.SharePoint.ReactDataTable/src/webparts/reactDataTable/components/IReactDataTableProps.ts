import { SPHttpClient } from "../../../../node_modules/@microsoft/sp-http";
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IReactDataTableProps {
  description: string;
  webURL: string;
  spHttpClient: SPHttpClient;
  context: WebPartContext;
}
