import * as React from 'react';
import './fonts.css';
import 'bootstrap-css-only/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';
import './ReactDataTable.module.scss';
import { IReactDataTableProps } from './IReactDataTableProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from "@microsoft/sp-http";
import { MDBDataTableV5 } from 'mdbreact';

export default class ReactDataTable extends React.Component<any, any> {
  constructor(props) {
    super(props);
    this.state = {
      datatable: {
        columns: [],
        rows: []
      }

    }
  }
  getList = () => {
    try {
      debugger;
      let endpointUrl = this.props.webURL.concat("/_api/web/lists/getbytitle('Employee%20Details')/items");
      const itemResults = this.props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1).then((mainResponse: SPHttpClientResponse) => {
        if (mainResponse.ok) {
          debugger;
          mainResponse.json().then((response) => {
            debugger;
            if (response.value.length > 0) {
              this.setState({
                datatable: {
                  columns: [
                    {
                      label: 'Name',
                      field: 'Title',
                      width: 150,
                      attributes: {
                        'aria-controls': 'DataTable',
                        'aria-label': 'Name',
                      },
                    },
                    {
                      label: 'Position',
                      field: 'Position',
                      width: 270,
                    },
                    {
                      label: 'Office',
                      field: 'Office',
                      width: 200,
                    },
                    {
                      label: 'Age',
                      field: 'Age',
                      sort: 'Age',
                      width: 100,
                    },
                    {
                      label: 'Start date',
                      field: 'StartDate',
                      sort: 'disabled',
                      width: 150,
                    },
                    {
                      label: 'Salary',
                      field: 'Salary',
                      sort: 'disabled',
                      width: 100,
                    },
                  ],
                  rows: response.value
                }
              });
            }
          }

          );
        }
      }

      );
    }

    catch (error) {
      console.log("checkUserExist-" + error);
    }
  }
  public componentDidMount() {
    this.getList();
  }


  public render(): React.ReactElement<IReactDataTableProps> {
    return (

      <div className={"container"}>
        <div className={"row"}>
          <div className={'col-sm-12 col-md-12 col-lg-12'}>
            <MDBDataTableV5 hover entriesOptions={[5, 20, 25]} entries={5} pagesAmount={4} data={this.state.datatable} />
          </div>
        </div>
      </div>

    );
  }
}
