declare interface IReactDataTableWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReactDataTableWebPartStrings' {
  const strings: IReactDataTableWebPartStrings;
  export = strings;
}
