declare interface IDemoCustomizerApplicationCustomizerStrings {
  Title: string;
}

declare module 'DemoCustomizerApplicationCustomizerStrings' {
  const strings: IDemoCustomizerApplicationCustomizerStrings;
  export = strings;
}
