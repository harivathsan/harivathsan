define([], function() {
  return {
    "Title": "DemoCustomizerApplicationCustomizer"
  }
});