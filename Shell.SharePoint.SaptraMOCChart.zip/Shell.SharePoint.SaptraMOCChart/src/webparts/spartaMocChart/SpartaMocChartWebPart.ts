import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'SpartaMocChartWebPartStrings';
import SpartaMocChart from './components/SpartaMocChart';
import { ISpartaMocChartProps } from './components/ISpartaMocChartProps';
import { SPHttpClient } from "@microsoft/sp-http";
import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface ISpartaMocChartWebPartProps {
  description: string;
  listName:string;
  urlListName:string;
  contactsListName:string;
}

export default class SpartaMocChartWebPart extends BaseClientSideWebPart<ISpartaMocChartWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ISpartaMocChartProps> = React.createElement(
      SpartaMocChart,
      {
        description: this.properties.description,
        spHttpClient: this.context.spHttpClient,
        context: this.context,
        webURL: this.context.pageContext.web.absoluteUrl,
        listName:this.properties.listName,
        urlListName:this.properties.urlListName,
        contactsListName:this.properties.contactsListName
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('listName', {
                  label: 'Change Control List Name'
                }),
                PropertyPaneTextField('urlListName', {
                  label: 'General MoC Documents List Name'
                }),
                PropertyPaneTextField('contactsListName', {
                  label: 'Contacts MoC List Name'
                }),
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
