declare interface ISpartaMocChartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpartaMocChartWebPartStrings' {
  const strings: ISpartaMocChartWebPartStrings;
  export = strings;
}
