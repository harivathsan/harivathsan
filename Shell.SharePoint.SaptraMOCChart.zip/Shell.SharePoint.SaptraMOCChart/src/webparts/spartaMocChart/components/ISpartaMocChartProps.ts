import { SPHttpClient } from "../../../../node_modules/@microsoft/sp-http";
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface ISpartaMocChartProps {
  description: string;
  spHttpClient: SPHttpClient;
  context: WebPartContext;
  webURL: string;
  listName:string;
  urlListName:string;
  contactsListName:string;
}
