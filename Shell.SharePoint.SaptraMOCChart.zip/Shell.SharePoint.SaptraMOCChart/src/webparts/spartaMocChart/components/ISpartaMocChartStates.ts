export interface ISpartaMocChartStates {
  Data:any[];
  URLs:any[];
  Contacts:any[];
  statusCountMOC: any[];
  countTotalMOC: number;
  isPieMoc:boolean;
  isBarMoc:boolean;
  selectedValueMOC:string;
}
