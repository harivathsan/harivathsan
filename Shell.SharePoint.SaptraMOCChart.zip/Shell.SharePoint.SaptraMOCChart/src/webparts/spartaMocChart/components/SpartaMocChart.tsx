/* ----------------------------------Module Summary-----------------------------------
Project Name                       : Sparta MOCChart For Change Control
Project Handled By                 : AI&DS
Module Name		                     : MOC Chart
Module Description                 : Kendo Chart for Change Control Register 
Author                             : Firdous Ali K.A
Created Date                       : 14th March 2024
Modified Date                      : 14th March 2024
Modified Reason                    : Getting data from lists
/* ----------------------------------Module Summary-----------------------------------*/

//#region imports
import * as React from 'react';
import styles from './SpartaMocChart.module.scss';
import { ISpartaMocChartProps } from './ISpartaMocChartProps';
import { ISpartaMocChartStates } from './ISpartaMocChartStates';
import { escape } from '@microsoft/sp-lodash-subset';
import '@progress/kendo-theme-default';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Chart,ChartLegend,ChartTooltip,ChartSeries,ChartSeriesItem,ChartTitle,ChartSeriesItemTooltip,ChartArea,exportVisual} from "@progress/kendo-react-charts";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { forEach, reduce } from 'lodash';
import "hammerjs";
import Radio from '@material-ui/core/Radio';
import { exportImage, exportPDF } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
//#endregion imports


//#region Class
class SpartaMocChart extends React.Component<ISpartaMocChartProps, ISpartaMocChartStates> {
  //Global Variables
  private _chartMOC: any;
  private _chartDCN: any;
  constructor(props: ISpartaMocChartProps, state: ISpartaMocChartStates) {
    super(props);
    this.state = {
      Data: [],
      URLs: [],
      Contacts: [],
      statusCountMOC: [],
      countTotalMOC: 0,
      isPieMoc: true,
      selectedValueMOC: "Pie",
      isBarMoc: false,
    };
    this.getData = this.getData.bind(this);
    this.getMOCURL = this.getMOCURL.bind(this);
    this.getMOCContacts = this.getMOCContacts.bind(this);
    this.formatDataMOC = this.formatDataMOC.bind(this);
    this.onChangeChoicePie = this.onChangeChoicePie.bind(this);
    this.onChangeChoiceBar = this.onChangeChoiceBar.bind(this);
    this.onImageExportMOC = this.onImageExportMOC.bind(this);
    this.onPDFExportMOC = this.onPDFExportMOC.bind(this);
    this.onImageExportDCN = this.onImageExportDCN.bind(this);
    this.onPDFExportDCN = this.onPDFExportDCN.bind(this);

  }

  public render(): React.ReactElement<ISpartaMocChartProps> {
    const labelContentMOC = (props) => {
      let formatedNumber = Number(props.dataItem.value);
      let percentageValue = Number((formatedNumber / this.state.countTotalMOC) * 100).toLocaleString(undefined, { maximumFractionDigits: 0 });
      if (formatedNumber === 0) {
        return ``;
      }
      else {
        return `${formatedNumber} (${percentageValue}%)`;
      }
    };
    
    return (<div className="container">
      <div className="row">
        <div className={styles.spartaMocChart}>
          <div className="row">
            {/* //MOC */}
            <div className={styles.chartBox}>
              <div className={styles.boxShapeChart}>
                <div className={styles.hrClass}>
                  <div className={styles.radioButtons}>
                    <span className={styles.radioText}>Chart Type </span>
                    <Radio
                      title="Pie"
                      checked={this.state.selectedValueMOC === 'Pie'}
                      onChange={this.onChangeChoicePie}
                      value="Pie"
                      name="radio-button-demo"
                      inputProps={{ 'aria-label': 'Pie' }}
                    />
                    <span className={styles.radioText}>Pie</span>
                    <Radio
                      title="Bar"
                      checked={this.state.selectedValueMOC === 'Bar'}
                      onChange={this.onChangeChoiceBar}
                      value="Bar"
                      name="radio-button-demo"
                      inputProps={{ 'aria-label': 'Bar' }}
                    />
                    <span className={styles.radioText}>Bar</span>
                  </div>
                  <div className={styles.exportButtonDiv}>
                    <a className={styles.exportButton} href="#" onClick={this.onPDFExportMOC}>Export to PDF</a>
                    <a className={styles.exportButton} href="#" onClick={this.onImageExportMOC}>Export to Image</a>
                  </div>
                </div>
                {this.state.statusCountMOC.length === 0 ?
                  <span className={styles.DCNText}>MOC Register - No Data Exist</span> :

                  <Chart ref={(cmp) => this._chartMOC = cmp}>
                    <ChartTitle text="MOC Control Register" />
                    <ChartLegend position="top" />
                    <ChartArea max-width={340} height={340} />
                    <ChartTooltip />
                    <ChartSeries >
                      <ChartSeriesItem
                        type={this.state.isPieMoc ? "pie" : "column"}
                        data={this.state.statusCountMOC}
                        field="value"
                        categoryField="category"
                        labels={{ visible: labelContentMOC === null ? false : true, content: labelContentMOC, padding: 0 }}
                      >
                        <ChartSeriesItemTooltip background="green" />
                      </ChartSeriesItem>
                    </ChartSeries>
                  </Chart>
                }
              </div>
            </div>

            
            <div className={styles.chartBox}>
              <div id="MiddleSection" >
              </div>
              <div id="MocDocumentView" className={styles.boxShape}>
                <h3>General MOC Documents</h3>
                <div >
                  {this.state.URLs != undefined ?
                    this.state.URLs.map((item, key) => {
                      return (
                        <a target="_blank" href={item.URL} data-interception="off" className={styles.AppbarUrl}>{item.Title}</a>
                      );
                    }) : <span className={styles.DCNText}>No Links Exist</span>}
                  
                </div>
              </div>
              <div id="VitoContainer" className={styles.boxShape} >
                <h3 >Key Contacts to Create a MOC</h3>
                <ul>
                  {this.state.Contacts != undefined ?
                    this.state.Contacts.map((item, key) => {
                      return (
                        <li><a className={styles.contactsUrl}>{item.Title}</a></li>
                      );
                    }) : <span className={styles.DCNText}>No Contacts Exist</span>}
                  
                </ul>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
    );
  }
  //#endregion Render Method

  //#region Methods

  /**
   * Component mount
   */
  
  public componentDidMount() {
    this.getData();
    this.getMOCContacts();
    this.getMOCURL();
  }

  /**
   * Gets data from List using Rest API
   * @returns 
   */
  public getData(): Promise<any> {
    return this.props.spHttpClient.get(`${this.props.webURL}/_api/web/lists/getbytitle('${this.props.listName}')/items?$select=approvalStatus,Project_x0020_Change_x0020_Form,ClosedStatus`,
      SPHttpClient.configurations.v1)
      .then(
        (response: SPHttpClientResponse) => {
          response.json().then((responseJSON) => {
            this.setState({ Data: responseJSON.value });
            this.formatDataMOC();
          });
          return response.json();
        },
        (error: any): void => {
          alert("List Does not exist");
        });
  }

  public getMOCURL(): Promise<any> {
    return this.props.spHttpClient.get(`${this.props.webURL}/_api/web/lists/getbytitle('${this.props.urlListName}')/items?$select=Title,URL`,
      SPHttpClient.configurations.v1)
      .then(
        (response: SPHttpClientResponse) => {
          response.json().then((responseJSON) => {
            this.setState({ URLs: responseJSON.value });
          });
          return response.json();
        },
        (error: any): void => {
          alert("List Does not exist");
        });
  }

  public getMOCContacts(): Promise<any> {
    return this.props.spHttpClient.get(`${this.props.webURL}/_api/web/lists/getbytitle('${this.props.contactsListName}')/items?$select=Title`,
      SPHttpClient.configurations.v1)
      .then(
        (response: SPHttpClientResponse) => {
          response.json().then((responseJSON) => {
            this.setState({ Contacts: responseJSON.value });
          });
          return response.json();
        },
        (error: any): void => {
          alert("List Does not exist");
        });
  }

  /**
  * Formats Data for MOC Chart
  */
  public formatDataMOC() {
    let approved = 0;
    let pending = 0;
    let rejected = 0;
    let initiated = 0;
    let closed = 0;
    this.state.Data.forEach(element => {
      if (element.approvalStatus == "Approved" && element.Project_x0020_Change_x0020_Form == "MOC") {
        approved += 1;
      }
      if (element.approvalStatus == "Pending" && element.Project_x0020_Change_x0020_Form == "MOC") {
        pending += 1;
      }
      if (element.approvalStatus == "Rejected" && element.Project_x0020_Change_x0020_Form == "MOC") {
        rejected += 1;
      }
      if (element.approvalStatus == "Approved" && element.Project_x0020_Change_x0020_Form == "MOC" && element.ClosedStatus == "Closed") {
        closed += 1;
      }
      if (element.approvalStatus == "Initiated" && element.Project_x0020_Change_x0020_Form == "MOC") {
        initiated += 1;
      }


    });
    let total = approved + pending + rejected + closed + initiated;
    this.setState({ countTotalMOC: total });
    const countOfStatus = [
      {
        category: "Initiated",
        value: initiated,
        color: "#D4AB0D"
      },
      {
        category: "Approved",
        value: approved,
        color: "#13AD05"
      },
      {
        category: "Pending",
        value: pending,
        color: "#3B5998"
      },
      {
        category: "Rejected",
        value: rejected,
        color: "#D73E24"
      },
      {
        category: "Closed",
        value: closed,
        color: "#1C4D17"
      }
    ];

    this.setState({ statusCountMOC: countOfStatus });
  }

  //Begin Handlers

  //#region On change methos of radio button
  /**
  * On change methoods of radio buttons
  * @param e 
  * @param value 
  */

  public onChangeChoicePie(e, value) {
    this.setState({ selectedValueMOC: "Pie" });
    this.setState({ isPieMoc: true });
    this.setState({ isBarMoc: false });
  }
  public onChangeChoiceBar(e, value) {
    this.setState({ selectedValueMOC: "Bar" });
    this.setState({ isPieMoc: false });
    this.setState({ isBarMoc: true });
  }
  //#endregion On change methos of radio button

  /**
  * Image export Method
  */
  public onImageExportMOC = () => {
    const chartVisual = exportVisual(this._chartMOC);

    if (chartVisual) {
      exportImage(chartVisual).then(dataURI => saveAs(dataURI, 'MOC-ControlRegister-chart.png'));
    }
  }
  public onImageExportDCN = () => {
    const chartVisual = exportVisual(this._chartDCN);

    if (chartVisual) {
      exportImage(chartVisual).then(dataURI => saveAs(dataURI, 'DCN-ControlRegister-chart.png'));
    }
  }

  /**
  * PDF exort method
  */
  public onPDFExportMOC = () => {
    const chartVisual = exportVisual(this._chartMOC);

    if (chartVisual) {
      exportPDF(chartVisual, {
        paperSize: "A4",
        landscape: true
      }).then(dataURI => saveAs(dataURI, 'MOC-ControlRegister-chart.pdf'));
    }
  }
  public onPDFExportDCN = () => {
    const chartVisual = exportVisual(this._chartDCN);

    if (chartVisual) {
      exportPDF(chartVisual, {
        paperSize: "A4",
        landscape: true
      }).then(dataURI => saveAs(dataURI, 'DCN-ControlRegister-chart.pdf'));
    }
  }
  //#endregion Methods
  //End Handlers

}
//#endregion Class

export default SpartaMocChart;