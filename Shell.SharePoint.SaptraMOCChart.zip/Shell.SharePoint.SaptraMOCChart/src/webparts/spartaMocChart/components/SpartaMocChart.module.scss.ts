/* tslint:disable */
require("./SpartaMocChart.module.css");
const styles = {
  spartaMocChart: 'spartaMocChart_a610a0a8',
  container: 'container_a610a0a8',
  row: 'row_a610a0a8',
  column: 'column_a610a0a8',
  'ms-Grid': 'ms-Grid_a610a0a8',
  title: 'title_a610a0a8',
  subTitle: 'subTitle_a610a0a8',
  description: 'description_a610a0a8',
  button: 'button_a610a0a8',
  label: 'label_a610a0a8',
  hrClass: 'hrClass_a610a0a8',
  AppbarUrl: 'AppbarUrl_a610a0a8',
  contactsUrl: 'contactsUrl_a610a0a8',
  exportButtonDiv: 'exportButtonDiv_a610a0a8',
  exportButton: 'exportButton_a610a0a8',
  boxShape: 'boxShape_a610a0a8',
  boxShapeChart: 'boxShapeChart_a610a0a8',
  boxShapeChart2: 'boxShapeChart2_a610a0a8',
  radioButtons: 'radioButtons_a610a0a8',
  radioText: 'radioText_a610a0a8',
  DCNText: 'DCNText_a610a0a8',
  chartBox: 'chartBox_a610a0a8'
};

export default styles;
/* tslint:enable */