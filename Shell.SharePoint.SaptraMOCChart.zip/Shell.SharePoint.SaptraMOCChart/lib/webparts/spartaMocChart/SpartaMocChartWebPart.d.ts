import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ISpartaMocChartWebPartProps {
    description: string;
    listName: string;
    urlListName: string;
    contactsListName: string;
}
export default class SpartaMocChartWebPart extends BaseClientSideWebPart<ISpartaMocChartWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SpartaMocChartWebPart.d.ts.map