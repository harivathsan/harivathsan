declare const styles: {
    spartaMocChart: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    hrClass: string;
    AppbarUrl: string;
    contactsUrl: string;
    exportButtonDiv: string;
    exportButton: string;
    boxShape: string;
    boxShapeChart: string;
    boxShapeChart2: string;
    radioButtons: string;
    radioText: string;
    DCNText: string;
    chartBox: string;
};
export default styles;
//# sourceMappingURL=SpartaMocChart.module.scss.d.ts.map