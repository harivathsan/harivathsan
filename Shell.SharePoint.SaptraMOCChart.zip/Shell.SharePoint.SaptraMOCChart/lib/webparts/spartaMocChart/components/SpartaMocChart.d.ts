import * as React from 'react';
import { ISpartaMocChartProps } from './ISpartaMocChartProps';
import { ISpartaMocChartStates } from './ISpartaMocChartStates';
import '@progress/kendo-theme-default';
import 'bootstrap/dist/css/bootstrap.min.css';
import "hammerjs";
declare class SpartaMocChart extends React.Component<ISpartaMocChartProps, ISpartaMocChartStates> {
    private _chartMOC;
    private _chartDCN;
    constructor(props: ISpartaMocChartProps, state: ISpartaMocChartStates);
    render(): React.ReactElement<ISpartaMocChartProps>;
    /**
     * Component mount
     */
    componentDidMount(): void;
    /**
     * Gets data from List using Rest API
     * @returns
     */
    getData(): Promise<any>;
    getMOCURL(): Promise<any>;
    getMOCContacts(): Promise<any>;
    /**
    * Formats Data for MOC Chart
    */
    formatDataMOC(): void;
    /**
    * On change methoods of radio buttons
    * @param e
    * @param value
    */
    onChangeChoicePie(e: any, value: any): void;
    onChangeChoiceBar(e: any, value: any): void;
    /**
    * Image export Method
    */
    onImageExportMOC: () => void;
    onImageExportDCN: () => void;
    /**
    * PDF exort method
    */
    onPDFExportMOC: () => void;
    onPDFExportDCN: () => void;
}
export default SpartaMocChart;
//# sourceMappingURL=SpartaMocChart.d.ts.map