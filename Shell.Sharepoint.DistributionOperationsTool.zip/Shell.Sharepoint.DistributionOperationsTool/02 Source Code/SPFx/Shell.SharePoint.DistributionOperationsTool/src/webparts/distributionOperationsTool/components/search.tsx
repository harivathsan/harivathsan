import * as React from 'react';
import styles from './DistributionOperationsTool.module.scss';
import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration } from '@microsoft/sp-http';
import { Col, Row, Card, CardBody, CardTitle, CardText, CardSubtitle, Input, Popover, PopoverHeader, PopoverBody } from 'reactstrap';
import classNames from "classnames";
import * as _ from 'lodash';
import { default as ReactSelect } from "react-select";
import { components } from "react-select";
import StaticHeader from './StaticHeader';

const Option = (props) => {
    debugger;
    return (
        <div>
            <components.Option {...props}>
                <input
                    type="checkbox"
                    checked={props.isSelected}
                    onChange={() => null}
                />{" "}
                <label>{props.label}</label>
            </components.Option>
        </div>
    );
};

class Search extends React.Component<any, any>{
    constructor(props) {
        super(props);
        this.state = {
            CategoryTile: [],
            CategoryName: [],
            optionSelected: [],
            listData: [],
            listCollection: [],
            filteredItems: [],
            CategoryArrayList: [],
            searchText: '',
            alphabet: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"],
            popoverOpen: false,
            isAlphapet: false
        };
    }
    private filteritems = (searchText) => {
        const filteredItems = this.state.listCollection.length > 0 && this.state.listCollection.filter(
            //({ Description, Title }) => (Description != undefined && Description.match(new RegExp(searchText, "i"))) || (Title != undefined && Title.match(new RegExp(searchText, "i")))
            ({ Description, Title }) => (Description != undefined && Description.toLowerCase().includes(searchText.toLowerCase())) || (Title != undefined && Title.toLowerCase().includes(searchText.toLowerCase()))
        );
        return filteredItems;

    }
    private Alphapetfilteritems = (searchText) => {
        const filteredItems = this.state.listCollection.length > 0 && this.state.listCollection.filter(
            //({ Description, Title }) => (Description != undefined && Description.match(new RegExp(searchText, "i"))) || (Title != undefined && Title.match(new RegExp(searchText, "i")))
            ({ Title }) => (Title != undefined && Title.toLowerCase().startsWith(searchText.toLowerCase()))
        );
        return filteredItems;

    }

    private onAlphapetClick = async (a_item) => {
        await this.fetchList()
        const filterArray = this.Alphapetfilteritems(a_item);
        debugger;
        this.setState({
            isAlphapet: true,
            searchText: a_item,
            filteredItems: filterArray
        });
    }

    private onSearchTextChange = (ev) => {
        const filterArray = this.filteritems(ev.target.value);
        debugger;
        this.setState({
            isAlphapet: false,
            searchText: ev.target.value,
            filteredItems: filterArray
        });

    }

    private handleMultiSelectChange = (selected) => {

        let category = "";
        console.log(category);
        this.setState({
            optionSelected: selected,
            selectItem: selected.value
        }, () => {

            let temp = [];
            this.state.optionSelected.length > 0 && this.state.optionSelected.map((item, index) => {
                category = "Category eq " + "'" + item.value + "'" + "";
                temp.push(category);
            });
            this.filterList(temp.join('or '));
        });
    }




    public componentDidMount() {
        this.fetchList();
    }



    private fetchList = async () => {
        let CategoryItems = [];
        let categoryOptions = [];
        let CategoryTile = [];
        let url = this.props.webURL + "/_api/web/lists/getbytitle('" + this.props.listName + "')/items";
        await this.props.context.spHttpClient.get(url, SPHttpClient.configurations.v1)
            .then(async (response: SPHttpClientResponse) => {
                if (response.ok) {
                    debugger;
                    await response.json().then((res) => {
                        if (res != null && res.value != null && res.value.length > 0) {
                            res.value.map((item: any) => {
                                CategoryItems.push({ CategoryName: item["Category"] });
                                CategoryTile.push({ iconUrl: item.CategoryIcon, color: item.CategoryColor, CategoryName: item.Category });
                            });
                            let categoryTileArray = _.uniqBy(CategoryTile, obj => obj.CategoryName);
                            let categoryArray = _.uniqBy(CategoryItems, 'CategoryName');

                            categoryArray.map((c_item, index) => {
                                debugger;
                                categoryOptions.push(
                                    { value: c_item.CategoryName, label: c_item.CategoryName }
                                );
                            });

                            this.setState({
                                CategoryTile: categoryTileArray,
                                CategoryName: categoryArray,
                                CategoryOption: categoryOptions,
                                filteredItems: res.value,
                                listCollection: res.value
                            });
                            console.log(res.value);
                        }


                    });
                }
            });


    }

    private filterList = async (filterQuery) => {
        debugger;
        let url = "";
        if (filterQuery != "") {
            url = this.props.webURL + "/_api/web/lists/getbytitle('" + this.props.listName + "')/items?select=*,&$filter=(" + filterQuery + ")";
        }
        else {
            url = this.props.webURL + "/_api/web/lists/getbytitle('" + this.props.listName + "')/items";
        }

        await this.props.context.spHttpClient.get(url, SPHttpClient.configurations.v1)
            .then(async (response: SPHttpClientResponse) => {
                if (response.ok) {
                    debugger;
                    await response.json().then((res) => {
                        if (res != null && res.value != null && res.value.length > 0) {
                            this.setState({
                                listCollection: res.value,
                                filteredItems: res.value
                            }, () => {
                                if (this.state.searchText != '' && this.state.isAlphapet == false) {
                                    const filterArray = this.filteritems(this.state.searchText);
                                    this.setState({
                                        filteredItems: filterArray
                                    });
                                } else {
                                    const AlphapetfilterArray = this.Alphapetfilteritems(this.state.searchText);
                                    this.setState({
                                        filteredItems: AlphapetfilterArray
                                    });
                                }

                            });

                        }
                    });
                }
            });

    }

    handleMouseEnter = (e) => {
        let card = e.nativeEvent.relatedTarget.parentNode.dataset.name;
        this.setState({
            isHover: true,
            cardType: card
        })

    };

    handleMouseLeave = (e) => {
        let card = e.nativeEvent.relatedTarget.parentNode.dataset.name;
        this.setState({ isHover: false, cardType: card })
    };
    clearText = () => {
        const filterArray = this.filteritems('');
        this.setState({
            searchText: '',
            filteredItems: filterArray
        })
    }
    onHandleClick = (pageLink) => {
        window.open(pageLink, "_blank")
    }



    onclickCategory = async (selectedTabName) => {
        let url = "";
        if (selectedTabName != "") {
            url = this.props.webURL + "/_api/web/lists/getbytitle('" + this.props.listName + "')/items?select=*,&$filter=(Category eq '" + selectedTabName + "')";
        }

        await this.props.context.spHttpClient.get(url, SPHttpClient.configurations.v1)
            .then(async (response: SPHttpClientResponse) => {
                if (response.ok) {
                    debugger;
                    await response.json().then((res) => {
                        if (res != null && res.value != null && res.value.length > 0) {
                            this.setState({
                                listCollection: res.value,
                                filteredItems: res.value,
                                optionSelected: [],
                                searchText: "",
                                activeTabName: selectedTabName
                            });

                        }
                    });
                }
            });
    }

    resetKey = async (filter) => {
        let url = "";
        if (filter != "") {
            url = this.props.webURL + "/_api/web/lists/getbytitle('" + this.props.listName + "')/items";
        }
        else {
            url = this.props.webURL + "/_api/web/lists/getbytitle('" + this.props.listName + "')/items?select=*,&$filter=(" + filter + ")";
        }
        debugger
        await this.props.context.spHttpClient.get(url, SPHttpClient.configurations.v1)
            .then(async (response: SPHttpClientResponse) => {
                if (response.ok) {
                    debugger;
                    await response.json().then((res) => {
                        if (res != null && res.value != null && res.value.length > 0) {
                            this.setState({
                                listCollection: res.value,
                                filteredItems: res.value,
                                optionSelected: [],
                                searchText: "",
                                activeTabName: ""
                            });

                        }
                    });
                }
            });
    }


    public render(): React.ReactNode {

        return (
            <React.Fragment>
                <StaticHeader {...this.state} OnclickCategory={this.onclickCategory} />
                <Row>
                    <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                        <button className='btn btn-primary' onClick={this.resetKey}>Reset Filters</button>
                    </Col>
                </Row>

                <Row className='mt-3'>
                    {this.state.alphabet.map((a_item, index) => {
                        return (
                            <Col className='alphabet' onClick={() => this.onAlphapetClick(a_item)}>{a_item}</Col>
                        );
                    })}

                </Row>
                <Row className='mt-3'>
                    <Col md={4} className='p-0'>
                        <div className={styles.multiselect} data-toggle="popover" data-trigger="focus" data-content="Please selecet account(s)">
                            <ReactSelect
                                options={this.state.CategoryOption}
                                isMulti
                                closeMenuOnSelect={false}
                                hideSelectedOptions={false}
                                components={{
                                    Option
                                }}
                                onChange={this.handleMultiSelectChange}
                                value={this.state.optionSelected}
                            />
                        </div>
                    </Col>
                    <Col md={8}>
                        <Input className='form-control' name='search' value={this.state.searchText} onChange={(ev) => this.onSearchTextChange(ev)} />
                        {this.state.searchText !== "" && <span className={styles.close} onClick={this.clearText}>
                            <img src={this.props.webURL + "/SiteAssets/images/close-1.png"}></img>
                        </span>
                        }
                    </Col>
                </Row>
                <Row className={classNames(styles.Search, 'mt-5')} >
                    {this.state.filteredItems.length > 0 && this.state.filteredItems.map((item, index) => {
                        debugger;
                        let imgUrl = this.props.webURL + "/SiteAssets/images/" + item.Category.replace(/\s/g, '') + ".svg";

                        const boxStyle = {
                            cursor: 'pointer',
                            borderBottom: "5px solid",
                            borderBottomColor: (item.Id == this.state.cardType && this.state.isHover) ? item['CategoryColor'] : '#fff'
                            //backgroundColor: (item.Id == this.state.cardType && this.state.isHover) ? item['CategoryColor'] : '#fff',

                        };
                        return (
                            <Col className='mb-3 pl-0'>
                                <Card className={classNames(styles.s_card)} data-name={item.Id} style={boxStyle} onMouseEnter={(e) => this.handleMouseEnter(e)} onMouseLeave={(e) => this.handleMouseLeave(e)} onClick={(e) => this.onHandleClick(item.Link.Url)}>
                                    <Col className={styles.cardHeader}>
                                        <img src={item.CategoryIcon}></img>
                                    </Col>
                                    <CardBody className={item.Description != null ? styles.cardTitle : 'NoDec'}>
                                        {item.Link != null && <CardTitle tag="h5" >
                                            {item.Title}
                                        </CardTitle>}
                                        {item.Link == null && <CardTitle tag="h5" title={item.Title}> {item.Title} </CardTitle>}
                                        <CardText className={styles.blockEllipsis} title={item.Description}> {item.Description} </CardText>
                                    </CardBody>
                                </Card>
                            </Col>

                        );
                    })}

                </Row>
            </React.Fragment>
        );
    }

} export default Search;
