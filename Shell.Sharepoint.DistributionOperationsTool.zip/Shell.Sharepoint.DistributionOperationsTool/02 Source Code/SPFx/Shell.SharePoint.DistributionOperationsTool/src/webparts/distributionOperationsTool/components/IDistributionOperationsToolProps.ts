import { SPHttpClient } from "@microsoft/sp-http";
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IDistributionOperationsToolProps {
  description: string;
  webURL: string;
  spHttpClient: SPHttpClient;
  context: WebPartContext;
  userDisplayName: any;
  userLoginName: any;
  userEmail: any;
  css: string;
  listName: string;
  listPageURL: string;
}
