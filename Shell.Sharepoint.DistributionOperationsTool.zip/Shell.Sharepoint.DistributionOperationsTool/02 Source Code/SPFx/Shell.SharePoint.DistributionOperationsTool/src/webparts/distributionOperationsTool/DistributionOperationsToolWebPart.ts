import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'DistributionOperationsToolWebPartStrings';
import DistributionOperationsTool from './components/DistributionOperationsTool';
import { IDistributionOperationsToolProps } from './components/IDistributionOperationsToolProps';

export interface IDistributionOperationsToolWebPartProps {
  description: string;
  css: string;
  listName: string;
  listPageURL: string;
  userEmail: string;
}

export default class DistributionOperationsToolWebPart extends BaseClientSideWebPart<IDistributionOperationsToolWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IDistributionOperationsToolProps> = React.createElement(
      DistributionOperationsTool,
      {
        description: this.properties.description,
        webURL: this.context.pageContext.web.absoluteUrl,
        spHttpClient: this.context.spHttpClient,
        context: this.context,
        userDisplayName: this.context.pageContext.user.displayName,
        userLoginName: this.context.pageContext.user.loginName,
        userEmail: this.context.pageContext.user.email,
        css: this.properties.css,
        listName: this.properties.listName,
        listPageURL: this.properties.listPageURL
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  protected onInit(): Promise<void> {
    return new Promise<void>((resolve, _reject) => {

      if (this.properties.css === undefined) {
        this.properties.css = this.context.pageContext.web.absoluteUrl + "/SiteAssets/globalCss/globalcss.css";

      }
      resolve(undefined);

    });

  }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('css', {
                  label: '~CSS'
                }),
                PropertyPaneTextField('listName', {
                  label: 'listName'
                }),
                PropertyPaneTextField('listPageURL', {
                  label: 'listPageURL'
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
