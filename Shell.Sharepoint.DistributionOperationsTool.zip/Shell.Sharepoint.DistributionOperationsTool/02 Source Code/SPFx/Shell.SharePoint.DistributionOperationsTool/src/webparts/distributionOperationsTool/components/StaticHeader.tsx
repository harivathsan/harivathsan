import * as React from 'react';
import { Col, Row,Card,CardBody,CardTitle,CardText} from 'reactstrap';
import styles from './DistributionOperationsTool.module.scss';
import classNames from "classnames";
import Search from './search';

class StaticHeader extends React.Component<any, any>{
  
    
    public render(): React.ReactNode {
        debugger
        return (

            <Row className={styles.StaticHeader}>
                {
                    this.props.CategoryTile.length > 0 && this.props.CategoryTile.map((item, index) => {
                        const borderStyle="border_"+index
                        return (
                            <Col name={item.CategoryName} className={classNames('text-center', styles.HearderCard ,borderStyle)} style={{ "borderColor": this.props.activeTabName == item.CategoryName ? item['color'] : "#fff"}} onClick={() => this.props.OnclickCategory(item.CategoryName)}>
                            <img src={item.iconUrl}></img>
                            <Col className={styles.TileName} >{item.CategoryName}</Col> 
                        </Col>
                        );
                    })
                    
                }

            </Row>
        );
    }
}
export default StaticHeader;