import * as React from 'react';
import { Container } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from './DistributionOperationsTool.module.scss';
import './fonts.css';
import classNames from "classnames";
import { SPComponentLoader } from '@microsoft/sp-loader';
import { IDistributionOperationsToolProps } from './IDistributionOperationsToolProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as $ from 'jquery';

import Search from './search';

export default class DistributionOperationsTool extends React.Component<any, any> {
  constructor(props) {

    super(props);
    //importing Global CSS
    let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }
  }

  public componentDidMount() {
    var SITE_TITLE: string = this.props.description;
    $('a[data-navigationcomponent="SiteHeader"]').eq(1).text(SITE_TITLE);
    $('span[data-automationid="SiteHeaderTitle"]').attr("title", SITE_TITLE);
  }
  public render(): React.ReactElement<IDistributionOperationsToolProps> {

    return (
      <Container fluid className={classNames(styles.customPad, styles.searchContainer)}>

        <Search {...this.props} />

      </Container>
    );
  }
}
