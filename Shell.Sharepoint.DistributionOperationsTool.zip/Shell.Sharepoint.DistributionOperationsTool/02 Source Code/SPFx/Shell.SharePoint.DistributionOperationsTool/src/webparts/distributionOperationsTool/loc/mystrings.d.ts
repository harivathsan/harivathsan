declare interface IDistributionOperationsToolWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DistributionOperationsToolWebPartStrings' {
  const strings: IDistributionOperationsToolWebPartStrings;
  export = strings;
}
