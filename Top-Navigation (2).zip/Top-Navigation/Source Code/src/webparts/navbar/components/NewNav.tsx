import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'
import { escape } from '@microsoft/sp-lodash-subset';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';
import NavbarCollapse from 'react-bootstrap/NavbarCollapse'
import { SPComponentLoader } from '@microsoft/sp-loader';
import { Dropdown } from 'react-bootstrap';
import styles from './Navbar.module.scss';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';



export default class NewNavbars extends React.Component<any, any> {
  constructor(props: any) {
  super(props);
  let cssPath: string = escape(this.props.css);
    if (cssPath !== "") {
      SPComponentLoader.loadCss(cssPath);
    }

  this.state = {
    NavItems:[],
    NavItemss:[],
    Menu:[]
  };
}
public async getNewsList() { 
  //let mainMenu: { SubMenu: any; SubSubmenu: any; Menu?: any;MenuOrder?:any;SubMenuOrder?:any;SubSubMenuOrder?:any }[]=[];
  debugger;
  let arr:any = [];
  try {
      let endpointUrl = this.props.webURL.concat(`/_api/web/Lists/GetByTitle('Navigation List')/items?$orderby=MenuOrder,SubMenuOrder,SubSubMenuOrder`);
      const listItems = await this.props.spHttpClient.get(endpointUrl, SPHttpClient.configurations.v1)
          .then(async (response: SPHttpClientResponse) => {
              if (await response.ok) {
                  response.json().then(async (res) => {
                     listItems
                      if(res.value.length>0){
                      let a = this.groupByVal(res.value, 'Menu');
                      debugger;
                      a.map((item: any, index: number) => {                        
                        arr.push({
                          name: item[0].Menu,
                          Url:item[0].MenuLink,
                          Sub: []
                        });
                      });

                      arr.map((l1_item:any,l1_index:number)=>{
                        let filterLevel1 = a.filter(a=>a[0].Menu == l1_item.name);
                        filterLevel1[0].map((p_item:any, p_index:number)=>{
                          if(p_item.SubMenu !=null){
                            if(l1_item.name == p_item.Menu){  
                              let isduplicate = arr[l1_index].Sub.filter((l1: { name: any; })=>l1.name == p_item.SubMenu);                               
                                 if(isduplicate.length == 0){
                                  l1_item.Sub.push({
                                    name:p_item.SubMenu,
                                    Url:p_item.SubMenuLink,
                                    sub:[]
                                    })
                                 }                                 
                            }
                          }                          
                        })                       
                      });

                      arr.map((c1_item:any,c1_index:number)=>{
                        debugger;
                          if(c1_item.Sub.length>0){
                              c1_item.Sub.map((c2_item:any,c2_index:number)=>{
                                let childLevel1 = a.filter(a=>a[0].Menu == c1_item.name);
                                if(childLevel1.length >0){
                                  childLevel1[0].map((c3_item:any,c3_index:number)=>{
                                    if(c2_item.name == c3_item.SubMenu){
                                     debugger;
                                      c1_item.Sub[c2_index].sub.push({
                                        name:c3_item.SubSubMenu,
                                        Url:c3_item.SubSubMenuLink
                                      })
                                    }  
                                  })
                                }                                
                              })
                          }                     

                      })
                        console.log(arr);

                        this.setState({Menu:arr})
                      }                   
                   

                  });
            }
          });
    }
    catch (e) {
      console.log("Error in getCarouselData", e);
    }
  }
componentDidMount(): void {
//var SITE_TITLE: string = this.props.description;
debugger;
this.getNewsList();

}
private groupByVal(list:any, property:any) {
    var i = 0, val, index,
        values = [], result = [];
    for (; i < list.length; i++) {
        val = list[i][property];
        index = values.indexOf(val);
        if (index > -1)
            result[index].push(list[i]);
        else {
            values.push(val);
            result.push([list[i]]);
        }
    }
    return result;
}

  public render(): React.ReactElement<any> {
    return (
      <>
        <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
          <Container>
            {/* <Navbar.Brand href="https://eu023-sp.shell.com/sites/SPOAA1198/GOM/SitePages/NavBar.aspx">HOME</Navbar.Brand> */}
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <NavbarCollapse id="responsive-navbar-nav" role={undefined}>
              <Nav className="me-auto">
                {this.state.Menu.length > 0 && this.state.Menu.map((item: any, key: any) => {
                  return (
                    <>
                      {(item.name.length > 0 && item.Sub.length > 0) ?
                        <NavDropdown title={item.name} id="collapsible-nav-dropdown">
                          {(item.Sub.length > 0 && item.Sub.map((item_1: any, index_1: any) => {
                            return (
                              <>
                                {(item_1.sub[0].name !== null) ?
                                  <NavDropdown
                                    key={'end'}
                                    id={`dropdown-button-drop-${'end'}`}
                                    drop={'end'}
                                    title={item_1.name}
                                    className={styles.inlineoptions}
                                  >
                                   {(item_1.sub.length > 0 && item_1.sub.map((item_2: any, index: any) => {
                                      return (
                                        <>
                                          {(item_2.name !== null && item_2.name.length > 0) ?
                                            <Dropdown.Item target={"_blank"} href={item_2.Url}>{item_2.name}</Dropdown.Item>
                                            : ""}
                                        </>)
                                    }))}
                                  </NavDropdown>
                                  : <NavDropdown.Item target={"_blank"} href={item_1.Url} className={styles.options}>{item_1.name}</NavDropdown.Item>
                                } </>
                            );
                          }))}
                        </NavDropdown>
                        : <Nav.Link target={"_blank"} href={item.Url}>{item.name}</Nav.Link>}
                    </>
                  );
                })}

           
            {/* <Nav.Link target={"_blank"} href="https://copilot.microsoft.com/">Copilot</Nav.Link> */}


          </Nav>
          
        </NavbarCollapse>
      </Container>
    </Navbar>                                                                                                          

</>
    );
  }
}
